<?php
/**
 * Minimal WordPress stand-in so the plugin can be exercised without a site.
 *
 * @package WPD_ReCaptcha
 */

if ( 'cli' !== PHP_SAPI ) {
	http_response_code( 404 );
	exit;
}

error_reporting( E_ALL );
ini_set( 'display_errors', '1' );

define( 'ABSPATH', dirname( __DIR__ ) . '/' );
define( 'MINUTE_IN_SECONDS', 60 );
define( 'HOUR_IN_SECONDS', 3600 );
define( 'DAY_IN_SECONDS', 86400 );

define( 'WPDRC_VERSION', '1.0.0' );
define( 'WPDRC_DIR', dirname( __DIR__ ) . '/' );
define( 'WPDRC_URL', 'https://example.test/wp-content/plugins/wpd-recaptcha/' );
define( 'WPDRC_FILE', WPDRC_DIR . 'wpd-recaptcha.php' );

$GLOBALS['wpdrc_options']   = array();
$GLOBALS['wpdrc_loggedin']  = false;
$GLOBALS['wpdrc_shortcodes'] = array();
$GLOBALS['wpdrc_actions']   = array();

function apply_filters( $tag, $value = null ) { return $value; }
function add_action( $tag, $cb = null, $p = 10, $a = 1 ) { $GLOBALS['wpdrc_actions'][] = $tag; }
function add_filter( $tag, $cb = null, $p = 10, $a = 1 ) { $GLOBALS['wpdrc_actions'][] = $tag; }
function remove_filter( $tag, $cb = null, $p = 10 ) { return true; }
function do_action() {}
function add_shortcode( $tag, $cb ) { $GLOBALS['wpdrc_shortcodes'][ $tag ] = $cb; }
function __( $text, $domain = '' ) { return $text; }
function esc_attr( $text ) { return htmlspecialchars( (string) $text, ENT_QUOTES, 'UTF-8' ); }
function esc_html( $text ) { return htmlspecialchars( (string) $text, ENT_QUOTES, 'UTF-8' ); }
function esc_url( $url ) { return (string) $url; }
function esc_html__( $text, $domain = '' ) { return $text; }
function esc_textarea( $text ) { return htmlspecialchars( (string) $text, ENT_QUOTES, 'UTF-8' ); }
function is_admin() { return false; }
function is_user_logged_in() { return (bool) $GLOBALS['wpdrc_loggedin']; }
function wp_doing_ajax() { return ! empty( $GLOBALS['wpdrc_ajax'] ); }
function wp_is_json_request() { return false; }
function wp_parse_args( $args, $defaults = array() ) { return array_merge( $defaults, (array) $args ); }
function wp_json_encode( $data ) { return json_encode( $data ); }
function wp_unslash( $value ) { return is_string( $value ) ? stripslashes( $value ) : $value; }
function sanitize_text_field( $value ) { return is_string( $value ) ? trim( strip_tags( $value ) ) : ''; }
function add_query_arg( $args, $url = '' ) {
	return $url . ( false === strpos( (string) $url, '?' ) ? '?' : '&' ) . http_build_query( (array) $args );
}
function is_wp_error( $thing ) { return $thing instanceof WP_Error; }
function get_current_user_id() { return 1; }
function human_time_diff( $from, $to = 0 ) { return '2 minutes'; }

function shortcode_atts( $pairs, $atts, $shortcode = '' ) {
	$out = array();

	foreach ( $pairs as $name => $default ) {
		$out[ $name ] = array_key_exists( $name, (array) $atts ) ? $atts[ $name ] : $default;
	}

	return $out;
}

class WP_Error {
	private $code;
	private $message;
	public function __construct( $code = '', $message = '' ) { $this->code = $code; $this->message = $message; }
	public function get_error_code() { return $this->code; }
	public function get_error_message() { return $this->message; }
	public function add( $code, $message ) { $this->code = $code; $this->message = $message; }
}

function get_option( $key, $default = false ) {
	return array_key_exists( $key, $GLOBALS['wpdrc_options'] ) ? $GLOBALS['wpdrc_options'][ $key ] : $default;
}
function update_option( $key, $value, $autoload = null ) { $GLOBALS['wpdrc_options'][ $key ] = $value; return true; }
function add_option( $key, $value, $x = '', $a = null ) { $GLOBALS['wpdrc_options'][ $key ] = $value; return true; }
function delete_option( $key ) { unset( $GLOBALS['wpdrc_options'][ $key ] ); return true; }

/**
 * Google, stubbed.
 *
 * The suite must never reach the network: a captcha test that calls
 * api.google.com is a test that fails on an aeroplane, fails in CI without
 * egress, and passes for the wrong reason when a key expires.
 *
 * $GLOBALS['wpdrc_reply'] is what "Google" returns. Set it to a WP_Error to
 * simulate the case that matters most — being unable to ask at all.
 */
$GLOBALS['wpdrc_reply']    = array( 'success' => true );
$GLOBALS['wpdrc_requests'] = array();

function wp_remote_post( $url, $args = array() ) {
	$GLOBALS['wpdrc_requests'][] = array( 'url' => $url, 'body' => $args['body'] ?? array() );

	$reply = $GLOBALS['wpdrc_reply'];

	if ( $reply instanceof WP_Error ) {
		return $reply;
	}

	return array( 'code' => 200, 'body' => json_encode( $reply ) );
}

function wp_remote_retrieve_response_code( $response ) { return is_array( $response ) ? (int) $response['code'] : 0; }
function wp_remote_retrieve_body( $response ) { return is_array( $response ) ? (string) $response['body'] : ''; }

require_once WPDRC_DIR . 'includes/class-wpdrc-local.php';
require_once WPDRC_DIR . 'includes/class-wpdrc-service.php';
require_once WPDRC_DIR . 'includes/class-wpdrc-options.php';
require_once WPDRC_DIR . 'includes/class-wpdrc-assets.php';
require_once WPDRC_DIR . 'includes/class-wpdrc-custom.php';

/**
 * Start from nothing, with working keys.
 *
 * @param array $overrides Settings to apply.
 */
function wpdrc_reset( array $overrides = array() ) {
	$GLOBALS['wpdrc_options']  = array();
	$GLOBALS['wpdrc_loggedin'] = false;
	$GLOBALS['wpdrc_ajax']     = false;
	$GLOBALS['wpdrc_reply']    = array( 'success' => true );
	$GLOBALS['wpdrc_requests'] = array();
	$GLOBALS['wpdrc_transients'] = array();
	$_POST                     = array();
	$_SERVER['REQUEST_METHOD'] = 'POST';

	$ref = new ReflectionProperty( 'WPDRC_Options', 'cache' );
	$ref->setAccessible( true );
	$ref->setValue( null );

	WPDRC_Service::reset();

	WPDRC_Options::update(
		array_merge(
			array(
				'v2_site_key'   => 'site-key-v2',
				'v2_secret_key' => 'secret-key-v2',
				'v3_site_key'   => 'site-key-v3',
				'v3_secret_key' => 'secret-key-v3',
				'form_custom'   => 1,
				'form_login'    => 1,
			),
			$overrides
		)
	);
}

/**
 * Transients, used by the local captcha's single-use guard.
 */
$GLOBALS['wpdrc_transients'] = array();

function set_transient( $key, $value, $ttl = 0 ) {
	$GLOBALS['wpdrc_transients'][ $key ] = array( 'value' => $value, 'expires' => $ttl ? time() + $ttl : 0 );
	return true;
}

function get_transient( $key ) {
	if ( ! isset( $GLOBALS['wpdrc_transients'][ $key ] ) ) {
		return false;
	}

	$row = $GLOBALS['wpdrc_transients'][ $key ];

	if ( $row['expires'] && $row['expires'] < time() ) {
		return false;
	}

	return $row['value'];
}

function delete_transient( $key ) {
	unset( $GLOBALS['wpdrc_transients'][ $key ] );
	return true;
}

function wp_send_json_error( $data = null, $status = null ) {}
function wp_send_json_success( $data = null, $status = null ) {}
function sanitize_key( $value ) { return preg_replace( '/[^a-z0-9_\-]/', '', strtolower( (string) $value ) ); }
function wp_generate_password( $length = 12, $special = true ) { return substr( str_repeat( 'aB3xY9', 40 ), 0, $length ); }
function wp_rand( $min = 0, $max = 0 ) { return random_int( $min, $max ? $max : PHP_INT_MAX ); }
function admin_url( $path = '' ) { return 'https://example.test/wp-admin/' . $path; }

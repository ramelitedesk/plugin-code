<?php
/**
 * The escape hatch.
 *
 * Its own file because a constant cannot be undefined: every case after it in
 * the main suite would run with the plugin switched off and pass for the wrong
 * reason.
 *
 * This is the setting that matters when everything else has gone wrong — the
 * keys are wrong, the login form is refusing everybody, and the settings screen
 * is on the other side of that login form.
 *
 * @package WPD_ReCaptcha
 */

if ( 'cli' !== PHP_SAPI ) {
	http_response_code( 404 );
	exit;
}

require __DIR__ . '/bootstrap.php';

define( 'WPDRC_DISABLE', true );

$pass = 0;
$fail = 0;

/**
 * @param string $label Assertion.
 * @param bool   $ok    Result.
 */
function check( $label, $ok ) {
	global $pass, $fail;

	if ( $ok ) {
		$pass++;
		printf( "  ok    %s\n", $label );
		return;
	}

	$fail++;
	printf( "  FAIL  %s\n", $label );
}

echo "\n=== WPDRC_DISABLE ===\n";

wpdrc_reset();

check( 'the plugin reports itself inactive', ! WPDRC_Service::active() );
check( 'no widget is rendered', '' === WPDRC_Service::field() );
check( 'a submission with no token is let through', true === WPDRC_Service::verify( 'login' ) );

$GLOBALS['wpdrc_reply'] = array( 'success' => false, 'error-codes' => array( 'invalid-input-response' ) );
check( 'even a token Google would reject is let through', true === WPDRC_Service::verify( 'login', 'anything' ) );
check( 'and Google was never asked', 0 === count( $GLOBALS['wpdrc_requests'] ) );

check( 'the keys are still considered present', WPDRC_Service::configured() );

printf( "\n----\npassed: %d   failed: %d\n", $pass, $fail );

exit( $fail > 0 ? 1 : 0 );

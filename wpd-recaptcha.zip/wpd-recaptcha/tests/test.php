<?php
/**
 * What passes, what is refused, and what happens when Google is not there.
 *
 * A captcha fails in two directions and only one of them is visible. Letting
 * spam through is obvious — the inbox fills up and somebody complains. Refusing
 * real people is silent: they see a message, decide the site is broken, and go
 * away without telling anyone. So most of what is asserted here is about not
 * refusing.
 *
 * WPDRC_DISABLE is covered in disable-test.php, because a constant cannot be
 * undefined once it is set and every case after it would run with the plugin
 * switched off.
 *
 * @package WPD_ReCaptcha
 */

if ( 'cli' !== PHP_SAPI ) {
	http_response_code( 404 );
	exit;
}

require __DIR__ . '/bootstrap.php';

$pass = 0;
$fail = 0;

/**
 * @param string $label Assertion.
 * @param bool   $ok    Result.
 * @param string $note  Shown on failure.
 */
function check( $label, $ok, $note = '' ) {
	global $pass, $fail;

	if ( $ok ) {
		$pass++;
		printf( "  ok    %s\n", $label );
		return;
	}

	$fail++;
	printf( "  FAIL  %s%s\n", $label, '' !== $note ? ' :: ' . $note : '' );
}

/* ================================================================ *
 * Configuration
 * ================================================================ */

echo "\n=== Nothing happens until it is configured ===\n";

wpdrc_reset( array( 'v2_site_key' => '', 'v2_secret_key' => '' ) );

check( 'no keys means not configured', ! WPDRC_Service::configured() );
check( 'and not active', ! WPDRC_Service::active() );
check( 'the field renders as nothing', '' === WPDRC_Service::field() );
check( 'verification passes rather than refusing everyone', true === WPDRC_Service::verify( 'login' ), 'a half-configured plugin must not lock the site' );

wpdrc_reset( array( 'v2_site_key' => 'a', 'v2_secret_key' => '' ) );
check( 'a site key with no secret is still not configured', ! WPDRC_Service::configured(), 'half a pair cannot verify anything' );

wpdrc_reset();
check( 'both keys means active', WPDRC_Service::active() );

echo "\n=== v2 and v3 read different keys ===\n";

wpdrc_reset( array( 'type' => WPDRC_Service::V3 ) );

check( 'v3 uses the v3 site key', 'site-key-v3' === WPDRC_Service::site_key() );
check( 'v3 uses the v3 secret', 'secret-key-v3' === WPDRC_Service::secret_key() );

wpdrc_reset( array( 'type' => WPDRC_Service::V2_CHECKBOX ) );

check( 'v2 uses the v2 site key', 'site-key-v2' === WPDRC_Service::site_key() );
check( 'an unknown type falls back to v2 checkbox', WPDRC_Service::V2_CHECKBOX === WPDRC_Service::type() );

wpdrc_reset( array( 'type' => 'nonsense' ) );
check( 'a corrupted type setting does not become an unknown widget', WPDRC_Service::V2_CHECKBOX === WPDRC_Service::type() );

/* ================================================================ *
 * Verification
 * ================================================================ */

echo "\n=== Verdicts ===\n";

wpdrc_reset();

$_POST = array();
$result = WPDRC_Service::verify( 'login' );
check( 'a submission with no token is refused', is_wp_error( $result ) && 'wpdrc_missing' === $result->get_error_code() );

wpdrc_reset();
$GLOBALS['wpdrc_reply'] = array( 'success' => true );
check( 'a token Google accepts passes', true === WPDRC_Service::verify( 'login', 'token-a' ) );

wpdrc_reset();
$GLOBALS['wpdrc_reply'] = array( 'success' => false, 'error-codes' => array( 'invalid-input-response' ) );
$result = WPDRC_Service::verify( 'login', 'token-b' );
check( 'a token Google rejects is refused', is_wp_error( $result ) && 'wpdrc_failed' === $result->get_error_code() );

echo "\n=== The secret reaches Google and the visitor never sees it ===\n";

wpdrc_reset();
WPDRC_Service::verify( 'login', 'token-c' );

$sent = $GLOBALS['wpdrc_requests'][0]['body'] ?? array();

check( 'the secret is sent', 'secret-key-v2' === ( $sent['secret'] ?? '' ) );
check( 'the token is sent', 'token-c' === ( $sent['response'] ?? '' ) );
check( 'the widget markup never contains the secret', false === strpos( WPDRC_Service::field(), 'secret-key-v2' ), 'a leaked secret key means anyone can forge a pass' );
check( 'the widget markup does contain the site key', false !== strpos( WPDRC_Service::field(), 'site-key-v2' ) );

echo "\n=== A token is only spent once ===\n";

wpdrc_reset();
$GLOBALS['wpdrc_reply'] = array( 'success' => true );

check( 'first check passes', true === WPDRC_Service::verify( 'cf7', 'token-d' ) );

// Google answers timeout-or-duplicate the second time a token is presented.
$GLOBALS['wpdrc_reply'] = array( 'success' => false, 'error-codes' => array( 'timeout-or-duplicate' ) );

check( 'asking again returns the first verdict, not a failure', true === WPDRC_Service::verify( 'cf7', 'token-d' ), 'form plugins validate a field more than once per request' );
check( 'and Google was only asked once', 1 === count( $GLOBALS['wpdrc_requests'] ), count( $GLOBALS['wpdrc_requests'] ) . ' requests' );

/* ================================================================ *
 * v3 scores
 * ================================================================ */

echo "\n=== v3 scores ===\n";

wpdrc_reset( array( 'type' => WPDRC_Service::V3, 'score_threshold' => 0.5 ) );
$GLOBALS['wpdrc_reply'] = array( 'success' => true, 'score' => 0.9, 'action' => 'wpdrc_login' );
check( 'a high score passes', true === WPDRC_Service::verify( 'login', 'token-e' ) );

wpdrc_reset( array( 'type' => WPDRC_Service::V3, 'score_threshold' => 0.5 ) );
$GLOBALS['wpdrc_reply'] = array( 'success' => true, 'score' => 0.1, 'action' => 'wpdrc_login' );
$result = WPDRC_Service::verify( 'login', 'token-f' );
check( 'a low score is refused', is_wp_error( $result ) && 'wpdrc_low_score' === $result->get_error_code() );

wpdrc_reset( array( 'type' => WPDRC_Service::V3, 'score_threshold' => 0.5 ) );
$GLOBALS['wpdrc_reply'] = array( 'success' => true, 'score' => 0.5, 'action' => 'wpdrc_login' );
check( 'a score exactly on the threshold passes', true === WPDRC_Service::verify( 'login', 'token-g' ), 'the threshold is a floor, not a barrier' );

wpdrc_reset( array( 'type' => WPDRC_Service::V2_CHECKBOX, 'score_threshold' => 0.9 ) );
$GLOBALS['wpdrc_reply'] = array( 'success' => true );
check( 'v2 has no score and the threshold is ignored', true === WPDRC_Service::verify( 'login', 'token-h' ), 'v2 responses carry no score; treating a missing one as 0 would refuse everybody' );

echo "\n=== v3 actions ===\n";

check( 'an action is derived from the form name', 'wpdrc_login' === WPDRC_Service::action_for( 'login' ) );
check( 'unsafe characters are stripped', 'wpdrc_my_form' === WPDRC_Service::action_for( 'my form' ) );
check( 'a long name is truncated', 100 >= strlen( WPDRC_Service::action_for( str_repeat( 'x', 300 ) ) ) );

/* ================================================================ *
 * The decision that matters most
 * ================================================================ */

echo "\n=== When Google cannot be reached ===\n";

wpdrc_reset( array( 'fail_closed' => 0 ) );
$GLOBALS['wpdrc_reply'] = new WP_Error( 'http_request_failed', 'Connection timed out' );

check(
	'by default a network failure lets the submission through',
	true === WPDRC_Service::verify( 'login', 'token-i' ),
	'otherwise a slow afternoon at Google locks you out of your own login form'
);

wpdrc_reset( array( 'fail_closed' => 1 ) );
$GLOBALS['wpdrc_reply'] = new WP_Error( 'http_request_failed', 'Connection timed out' );

$result = WPDRC_Service::verify( 'login', 'token-j' );
check( 'with fail-closed on, it refuses', is_wp_error( $result ) && 'wpdrc_unreachable' === $result->get_error_code() );

wpdrc_reset( array( 'fail_closed' => 0 ) );
$GLOBALS['wpdrc_reply'] = array( 'success' => false, 'error-codes' => array( 'invalid-input-response' ) );

check(
	'but a real refusal from Google always blocks',
	is_wp_error( WPDRC_Service::verify( 'login', 'token-k' ) ),
	'failing open is about being unable to ask, never about being told no'
);

echo "\n=== A wrong secret key is a configuration fault, not a bot ===\n";

wpdrc_reset( array( 'fail_closed' => 0 ) );
$GLOBALS['wpdrc_reply'] = array( 'success' => false, 'error-codes' => array( 'invalid-input-secret' ) );

check(
	'a bad secret does not turn real visitors away',
	true === WPDRC_Service::verify( 'login', 'token-l' ),
	'somebody pasted the wrong key; the visitor is not the problem'
);

$log = WPDRC_Log::all();
check( 'and it is always logged, even with logging off', ! empty( $log ) && 'bad_secret' === $log[0]['type'] );

/* ================================================================ *
 * Exemptions
 * ================================================================ */

echo "\n=== Logged-in visitors ===\n";

wpdrc_reset( array( 'skip_logged_in' => 1 ) );
$GLOBALS['wpdrc_loggedin'] = true;

check( 'a signed-in visitor is exempt', WPDRC_Service::exempt() );
check( 'and sees no widget', '' === WPDRC_Service::field() );
check( 'and is never refused', true === WPDRC_Service::verify( 'comment' ) );

wpdrc_reset( array( 'skip_logged_in' => 0 ) );
$GLOBALS['wpdrc_loggedin'] = true;

check( 'unless the setting is off', ! WPDRC_Service::exempt() );
check( 'and then they get a widget like anybody else', '' !== WPDRC_Service::field(), 'the default is off, so this is what setting the plugin up looks like' );
check( 'and are checked like anybody else', is_wp_error( WPDRC_Service::verify( 'comment' ) ), 'with no token in the request a signed-in visitor must now be refused' );

/* ================================================================ *
 * Markup
 * ================================================================ */

echo "\n=== The rendered field ===\n";

wpdrc_reset( array( 'type' => WPDRC_Service::V2_CHECKBOX ) );
$field = WPDRC_Service::field( array( 'form' => 'login' ) );

check( 'v2 renders a widget container', false !== strpos( $field, 'wpdrc-widget' ) );
check( 'carrying the site key', false !== strpos( $field, 'data-sitekey="site-key-v2"' ) );
check( 'and the marker naming the form', false !== strpos( $field, 'name="wpdrc_form" value="login"' ) );
check( 'v2 has no token field of its own', false === strpos( $field, 'wpdrc-token' ), 'the Google widget provides it' );

wpdrc_reset( array( 'type' => WPDRC_Service::V3 ) );
$field = WPDRC_Service::field( array( 'form' => 'newsletter' ) );

check( 'v3 renders a hidden token field', false !== strpos( $field, 'wpdrc-token' ) );
check( 'named the way Google expects', false !== strpos( $field, 'name="g-recaptcha-response"' ) );
check( 'carrying the action', false !== strpos( $field, 'data-action="wpdrc_newsletter"' ) );
check( 'and nothing visible', false === strpos( $field, 'wpdrc-widget' ) );

wpdrc_reset( array( 'type' => WPDRC_Service::V2_INVISIBLE ) );
$field = WPDRC_Service::field();
check( 'invisible v2 is marked as such', false !== strpos( $field, 'wpdrc-widget--invisible' ) );
check( 'and asks Google for the invisible size', false !== strpos( $field, 'data-size="invisible"' ) );

echo "\n=== Two forms on one page get two widgets ===\n";

wpdrc_reset();
$one = WPDRC_Service::field( array( 'form' => 'a' ) );
$two = WPDRC_Service::field( array( 'form' => 'b' ) );

preg_match( '/id="(wpdrc-\d+)"/', $one, $id_one );
preg_match( '/id="(wpdrc-\d+)"/', $two, $id_two );

check( 'each widget has an id', ! empty( $id_one[1] ) && ! empty( $id_two[1] ) );
check( 'and the ids differ', $id_one[1] !== $id_two[1], 'a newsletter box in the footer must not collide with the contact form' );

echo "\n=== The marker is not a nonce ===\n";

wpdrc_reset();
$field = WPDRC_Service::field( array( 'form' => 'custom' ) );

check(
	'no nonce is embedded in the field',
	false === stripos( $field, '_wpnonce' ) && false === stripos( $field, 'nonce' ),
	'a nonce goes stale in a page cache and would break the captcha for every cached visitor'
);

/* ================================================================ *
 * The shortcode
 * ================================================================ */

echo "\n=== The shortcode ===\n";

wpdrc_reset();
$custom = WPDRC_Custom::instance();

check( 'the [recaptcha] shortcode is registered', isset( $GLOBALS['wpdrc_shortcodes']['recaptcha'] ) );

$out = $custom->shortcode( array() );
check( 'it renders a field', false !== strpos( $out, 'wpdrc-widget' ) );
check( 'defaulting to the "custom" form name', false !== strpos( $out, 'value="custom"' ) );

$out = $custom->shortcode( array( 'form' => 'newsletter' ) );
check( 'a form name can be given', false !== strpos( $out, 'value="newsletter"' ) );

wpdrc_reset( array( 'form_custom' => 0 ) );
check( 'it renders nothing when custom forms are switched off', '' === WPDRC_Custom::instance()->shortcode( array() ) );

echo "\n=== The helper functions ===\n";

wpdrc_reset();
$GLOBALS['wpdrc_reply'] = array( 'success' => true );

check( 'wpdrc_verify() exists', function_exists( 'wpdrc_verify' ) );
check( 'wpdrc_passed() exists', function_exists( 'wpdrc_passed' ) );
check( 'wpdrc_field() exists', function_exists( 'wpdrc_field' ) );

$_POST['g-recaptcha-response'] = 'token-m';
check( 'wpdrc_passed() returns a plain true', true === wpdrc_passed( 'custom' ) );

wpdrc_reset();
$_POST = array();
check( 'and false with no token', false === wpdrc_passed( 'custom' ) );

/* ================================================================ *
 * Messages
 * ================================================================ */

echo "\n=== Messages ===\n";

wpdrc_reset();

check( 'each failure has its own wording', WPDRC_Service::message( 'missing' ) !== WPDRC_Service::message( 'low_score' ) );
check( 'an unknown key still returns something', '' !== WPDRC_Service::message( 'nonsense' ) );

wpdrc_reset( array( 'message_missing' => 'Please tick the box.' ) );
check( 'a custom message is used', 'Please tick the box.' === WPDRC_Service::message( 'missing' ) );

wpdrc_reset( array( 'message_missing' => '   ' ) );
check( 'a whitespace-only override falls back to the default', 'Please tick the box.' !== WPDRC_Service::message( 'missing' ) );

/* ================================================================ *
 * Defaults
 * ================================================================ */

echo "\n=== Defaults are cautious ===\n";

$defaults = WPDRC_Options::defaults();

foreach ( array_keys( WPDRC_Options::forms() ) as $form ) {
	check( "'$form' is off by default", empty( $defaults[ 'form_' . $form ] ), 'activating the plugin must not put a captcha on anything' );
}

check( 'fail-closed is off by default', empty( $defaults['fail_closed'] ), 'the default must not be able to lock somebody out' );
check(
	'logged-in users are checked by default',
	empty( $defaults['skip_logged_in'] ),
	'the person setting this up is signed in, so skipping them by default means the first thing they see is a form with no captcha on it'
);
check( 'the default threshold is Google\'s suggestion', 0.5 === $defaults['score_threshold'] );

printf( "\n----\npassed: %d   failed: %d\n", $pass, $fail );

exit( $fail > 0 ? 1 : 0 );

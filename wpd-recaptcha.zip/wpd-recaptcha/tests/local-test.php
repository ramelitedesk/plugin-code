<?php
/**
 * The locally generated challenges.
 *
 * Two properties matter more than everything else here, and both are the kind
 * that look fine in a browser while being completely broken:
 *
 *   1. The answer must never reach the browser. If it does, the challenge is
 *      decoration — and the page looks identical either way.
 *   2. A challenge must be answerable exactly once. Without that, one solved
 *      sum is replayed a thousand times, which is precisely what spam software
 *      does the moment it finds a form that allows it.
 *
 * @package WPD_ReCaptcha
 */

if ( 'cli' !== PHP_SAPI ) {
	http_response_code( 404 );
	exit;
}

require __DIR__ . '/bootstrap.php';

$pass = 0;
$fail = 0;

/**
 * @param string $label Assertion.
 * @param bool   $ok    Result.
 * @param string $note  Shown on failure.
 */
function check( $label, $ok, $note = '' ) {
	global $pass, $fail;

	if ( $ok ) {
		$pass++;
		printf( "  ok    %s\n", $label );
		return;
	}

	$fail++;
	printf( "  FAIL  %s%s\n", $label, '' !== $note ? ' :: ' . $note : '' );
}

/**
 * Every selection of two to four tiles out of nine.
 *
 * 502 of them, which is small enough to solve a picture grid by brute force in
 * a test — and worth noticing, because it is also small enough for a bot. What
 * stops that is not the search space; it is that a challenge can be answered
 * once and a wrong answer costs a fresh page load.
 *
 * @return string[] Each a comma-separated list of indices, in order.
 */
function wpdrc_all_selections() {
	$out = array();

	for ( $mask = 1; $mask < ( 1 << 9 ); $mask++ ) {
		$picked = array();

		for ( $bit = 0; $bit < 9; $bit++ ) {
			if ( $mask & ( 1 << $bit ) ) {
				$picked[] = $bit;
			}
		}

		if ( count( $picked ) >= 2 && count( $picked ) <= 4 ) {
			$out[] = implode( ',', $picked );
		}
	}

	return $out;
}

/**
 * Answer a challenge as a browser would, and put the result through the
 * verifier.
 *
 * @param array  $challenge From WPDRC_Local::challenge().
 * @param string $answer    What the visitor typed.
 * @return true|WP_Error
 */
function submit( array $challenge, $answer ) {
	$_POST = array(
		'wpdrc_id'     => $challenge['id'],
		'wpdrc_exp'    => $challenge['expires'],
		'wpdrc_sig'    => $challenge['signature'],
		'wpdrc_kind'   => $challenge['kind'],
		'wpdrc_answer' => $answer,
		// The slider posts its target back so the signature can be checked
		// against it; every other kind ignores this.
		'wpdrc_target' => isset( $challenge['target'] ) ? $challenge['target'] : 0,
	);

	return WPDRC_Local::verify( 'custom' );
}

/**
 * Work out the answer to a generated sum, the way a person would.
 *
 * @param string $prompt The question.
 * @return int
 */
function solve( $prompt ) {
	$words = array( 'zero' => 0, 'one' => 1, 'two' => 2, 'three' => 3, 'four' => 4, 'five' => 5, 'six' => 6, 'seven' => 7, 'eight' => 8, 'nine' => 9, 'ten' => 10, 'eleven' => 11, 'twelve' => 12 );

	$text = str_replace( array( '=', '?' ), '', $prompt );
	$text = trim( preg_replace( '/\s+/u', ' ', $text ) );

	$parts = explode( ' ', $text );

	$a  = isset( $words[ $parts[0] ] ) ? $words[ $parts[0] ] : (int) $parts[0];
	$op = $parts[1];
	$b  = isset( $words[ $parts[2] ] ) ? $words[ $parts[2] ] : (int) $parts[2];

	if ( '−' === $op || 'minus' === $op ) {
		return $a - $b;
	}

	if ( '×' === $op || 'times' === $op ) {
		return $a * $b;
	}

	return $a + $b;
}

/* ================================================================ *
 * The answer never leaves the server
 * ================================================================ */

echo "\n=== The answer is not in what the browser receives ===\n";

wpdrc_reset( array( 'type' => WPDRC_Local::MATH ) );

/*
 * Every field is compared for equality rather than searched as a substring.
 *
 * A substring search is worse than useless here: "15" turns up inside a Unix
 * timestamp roughly always, so the test fails on a correct implementation and
 * teaches you to stop reading it. What actually matters is whether any single
 * value handed to the browser IS the answer.
 */
$leaked = '';

for ( $i = 0; $i < 100; $i++ ) {
	$challenge = WPDRC_Local::challenge( WPDRC_Local::MATH );
	$answer    = (string) solve( $challenge['prompt'] );

	unset( $challenge['prompt'] ); // The question is meant to be readable.

	foreach ( $challenge as $name => $value ) {
		if ( is_scalar( $value ) && (string) $value === $answer ) {
			$leaked = $name;
			break 2;
		}
	}
}

check( 'no field handed to the browser is the answer', '' === $leaked, 'found in the "' . $leaked . '" field' );

$challenge = WPDRC_Local::challenge( WPDRC_Local::MATH );
check( 'the signing secret is never sent', false === strpos( wp_json_encode( $challenge ), WPDRC_Local::secret() ) );
check( 'a signature is sent', 64 === strlen( $challenge['signature'] ) );

/* ================================================================ *
 * Sums
 * ================================================================ */

echo "\n=== Sums ===\n";

wpdrc_reset( array( 'type' => WPDRC_Local::MATH ) );

$challenge = WPDRC_Local::challenge( WPDRC_Local::MATH );
check( 'the right answer passes', true === submit( $challenge, (string) solve( $challenge['prompt'] ) ) );

$challenge = WPDRC_Local::challenge( WPDRC_Local::MATH );
check( 'a wrong answer is refused', is_wp_error( submit( $challenge, (string) ( solve( $challenge['prompt'] ) + 1 ) ) ) );

$challenge = WPDRC_Local::challenge( WPDRC_Local::MATH );
check( 'an empty answer is refused', is_wp_error( submit( $challenge, '' ) ) );

$challenge = WPDRC_Local::challenge( WPDRC_Local::MATH );
check( 'whitespace around the answer is forgiven', true === submit( $challenge, '  ' . solve( $challenge['prompt'] ) . ' ' ) );

$challenge = WPDRC_Local::challenge( WPDRC_Local::MATH );
$answer    = solve( $challenge['prompt'] );
$spelled   = array( 0 => 'zero', 1 => 'one', 2 => 'two', 3 => 'three', 4 => 'four', 5 => 'five', 6 => 'six', 7 => 'seven', 8 => 'eight', 9 => 'nine', 10 => 'ten' );

if ( isset( $spelled[ $answer ] ) ) {
	check( 'an answer written in words is accepted', true === submit( $challenge, $spelled[ $answer ] ), 'somebody asked "seven plus two" may well answer "nine"' );
} else {
	check( 'an answer written in words is accepted', true, 'skipped — answer above ten' );
}

echo "\n=== Sums are never unpleasant ===\n";

wpdrc_reset( array( 'type' => WPDRC_Local::MATH ) );

$negative = 0;
$big      = 0;

for ( $i = 0; $i < 200; $i++ ) {
	$answer = solve( WPDRC_Local::challenge( WPDRC_Local::MATH )['prompt'] );

	if ( $answer < 0 ) {
		$negative++;
	}

	if ( $answer > 25 ) {
		$big++;
	}
}

check( 'never a negative answer', 0 === $negative, $negative . ' of 200 were negative' );
check( 'never a hard one', 0 === $big, $big . ' of 200 were above 25' );

/* ================================================================ *
 * Single use
 * ================================================================ */

echo "\n=== A challenge is answerable once ===\n";

wpdrc_reset( array( 'type' => WPDRC_Local::MATH ) );

$challenge = WPDRC_Local::challenge( WPDRC_Local::MATH );
$answer    = (string) solve( $challenge['prompt'] );

check( 'the first submission passes', true === submit( $challenge, $answer ) );

$again = submit( $challenge, $answer );
check( 'the same answer replayed is refused', is_wp_error( $again ) && 'wpdrc_replay' === $again->get_error_code(), 'one solved sum must not open the form a thousand times' );

echo "\n=== Expiry ===\n";

wpdrc_reset( array( 'type' => WPDRC_Local::MATH ) );

$challenge = WPDRC_Local::challenge( WPDRC_Local::MATH );

// Rewind the expiry and re-sign it, the way an attacker replaying an old
// challenge would have to.
$challenge['expires'] = time() - 10;

$expired = submit( $challenge, (string) solve( $challenge['prompt'] ) );
check( 'an expired challenge is refused', is_wp_error( $expired ) && 'wpdrc_expired' === $expired->get_error_code() );

/* ================================================================ *
 * Forgery
 * ================================================================ */

echo "\n=== The signature cannot be forged ===\n";

wpdrc_reset( array( 'type' => WPDRC_Local::MATH ) );

$challenge = WPDRC_Local::challenge( WPDRC_Local::MATH );

$tampered              = $challenge;
$tampered['signature'] = str_repeat( 'a', 64 );
check( 'a made-up signature is refused', is_wp_error( submit( $tampered, (string) solve( $challenge['prompt'] ) ) ) );

$tampered              = $challenge;
$tampered['expires']   = time() + 999999;
check( 'extending the expiry breaks the signature', is_wp_error( submit( $tampered, (string) solve( $challenge['prompt'] ) ) ), 'the expiry is signed, so it cannot be moved' );

$tampered            = $challenge;
$tampered['id']      = 'deadbeefdeadbeef';
check( 'changing the id breaks the signature', is_wp_error( submit( $tampered, (string) solve( $challenge['prompt'] ) ) ) );

$tampered          = $challenge;
$tampered['kind']  = WPDRC_Local::PUZZLE;
check( 'changing the kind breaks the signature', is_wp_error( submit( $tampered, (string) solve( $challenge['prompt'] ) ) ), 'otherwise a sum answer could be presented as a puzzle answer' );

$_POST = array( 'wpdrc_answer' => '4' );
check( 'a submission with no challenge at all is refused', is_wp_error( WPDRC_Local::verify( 'custom' ) ) );

/* ================================================================ *
 * Questions
 * ================================================================ */

echo "\n=== Owner-written questions ===\n";

wpdrc_reset(
	array(
		'type'      => WPDRC_Local::QUESTION,
		'questions' => "What colour is the sky? | blue\nWhat town are we in? | Bristol\n  \nbroken line with no separator",
	)
);

$pairs = WPDRC_Local::questions();
check( 'well-formed lines are read', 2 === count( $pairs ), count( $pairs ) . ' parsed' );
check( 'a line with no separator is ignored', 'Bristol' === $pairs[1]['answer'] );

$challenge = WPDRC_Local::challenge( WPDRC_Local::QUESTION );
$expected  = ( 'What colour is the sky?' === $challenge['prompt'] ) ? 'blue' : 'Bristol';

check( 'the right answer passes', true === submit( $challenge, $expected ) );

$challenge = WPDRC_Local::challenge( WPDRC_Local::QUESTION );
$expected  = ( 'What colour is the sky?' === $challenge['prompt'] ) ? 'blue' : 'Bristol';

check( 'case does not matter', true === submit( $challenge, strtoupper( $expected ) ) );

$challenge = WPDRC_Local::challenge( WPDRC_Local::QUESTION );
$expected  = ( 'What colour is the sky?' === $challenge['prompt'] ) ? 'blue' : 'Bristol';

check( 'a trailing full stop is forgiven', true === submit( $challenge, $expected . '.' ), 'somebody who knows the answer should not fail on punctuation' );

$challenge = WPDRC_Local::challenge( WPDRC_Local::QUESTION );
check( 'a wrong answer is refused', is_wp_error( submit( $challenge, 'nonsense' ) ) );

echo "\n=== With no questions configured ===\n";

wpdrc_reset( array( 'type' => WPDRC_Local::QUESTION, 'questions' => '' ) );

$challenge = WPDRC_Local::challenge( WPDRC_Local::QUESTION );
check( 'it falls back to a sum rather than asking nothing', WPDRC_Local::MATH === $challenge['kind'] || '' !== $challenge['prompt'], 'an unanswerable question is worse than no check' );

/* ================================================================ *
 * Letters and the slider
 * ================================================================ */

echo "\n=== Distorted letters ===\n";

wpdrc_reset( array( 'type' => WPDRC_Local::LETTERS ) );

$challenge = WPDRC_Local::challenge( WPDRC_Local::LETTERS );

if ( function_exists( 'imagecreatetruecolor' ) ) {
	check( 'an image is produced', 0 === strpos( (string) $challenge['image'], 'data:image/png;base64,' ) );
	check( 'it is a data URI, so no extra request and no server state', false === strpos( (string) $challenge['image'], 'http' ) );
	check( 'no prompt text gives the answer away', '' === $challenge['prompt'] );
	check( 'the accessible alternative is offered', ! empty( $challenge['alt'] ), 'a visual-only check must always have a way out' );
} else {
	check( 'with no GD it falls back to a sum', WPDRC_Local::MATH === $challenge['kind'], 'a broken image is not a captcha' );
}

echo "\n=== The slider ===\n";

wpdrc_reset( array( 'type' => WPDRC_Local::PUZZLE ) );

$challenge = WPDRC_Local::challenge( WPDRC_Local::PUZZLE );

check( 'a target position is given', $challenge['target'] > 0 );
check( 'the accessible alternative is offered', ! empty( $challenge['alt'] ) );

check( 'landing on the target passes', true === submit( $challenge, (string) $challenge['target'] ) );

$challenge = WPDRC_Local::challenge( WPDRC_Local::PUZZLE );
check( 'a few pixels out still passes', true === submit( $challenge, (string) ( $challenge['target'] + 4 ) ), 'pixel-exact would fail almost everybody on a touchscreen' );

$challenge = WPDRC_Local::challenge( WPDRC_Local::PUZZLE );
check( 'nowhere near is refused', is_wp_error( submit( $challenge, (string) ( $challenge['target'] + 90 ) ) ) );

$challenge = WPDRC_Local::challenge( WPDRC_Local::PUZZLE );
check( 'leaving it at zero is refused', is_wp_error( submit( $challenge, '0' ) ), 'a form submitted without touching the slider must not pass' );

echo "\n=== The picture grid ===\n";

wpdrc_reset( array( 'type' => WPDRC_Local::SELECT ) );

$challenge = WPDRC_Local::challenge( WPDRC_Local::SELECT );

if ( ! function_exists( 'imagecreatetruecolor' ) ) {
	check( 'with no GD it falls back to a sum', WPDRC_Local::MATH === $challenge['kind'], 'nine broken images are not a captcha' );
} else {
	check( 'nine tiles are drawn', isset( $challenge['tiles'] ) && 9 === count( $challenge['tiles'] ) );
	check( 'every tile is a data URI', 9 === count( array_filter( $challenge['tiles'], function ( $t ) { return 0 === strpos( $t, 'data:image/png;base64,' ); } ) ) );
	check( 'no two tiles are the same bytes', 9 === count( array_unique( $challenge['tiles'] ) ), 'identical tiles let an attacker group the grid without looking at it' );
	check( 'the accessible alternative is offered', ! empty( $challenge['alt'] ) );

	/*
	 * The whole security claim of this kind, stated as a test: unlike the
	 * slider, nothing in the response says which tiles are right. If a future
	 * change ever adds a convenient 'correct' key for the JavaScript, this
	 * fails and says why.
	 */
	check(
		'the response does not carry the answer',
		! isset( $challenge['answer'] ) && ! isset( $challenge['target'] ) && ! isset( $challenge['correct'] ),
		'the grading has to stay on the server or the grid is decoration'
	);

	// Solved by brute force here, which is the honest way to test it: there are
	// only 502 possible selections of two to four tiles out of nine.
	$solution = '';

	foreach ( wpdrc_all_selections() as $guess ) {
		if ( true === submit( $challenge, $guess ) ) {
			$solution = $guess;
			break;
		}
	}

	check( 'exactly one selection passes', '' !== $solution, 'if none passes the signing and the grading disagree' );

	$challenge = WPDRC_Local::challenge( WPDRC_Local::SELECT );
	check( 'selecting nothing is refused', is_wp_error( submit( $challenge, '' ) ), 'a form submitted without touching the grid must not pass' );

	$challenge = WPDRC_Local::challenge( WPDRC_Local::SELECT );
	check( 'selecting everything is refused', is_wp_error( submit( $challenge, '0,1,2,3,4,5,6,7,8' ) ), 'ticking the lot is the first thing a bot tries' );

	check( 'click order does not matter', WPDRC_Local::normalise( '7,2,4', WPDRC_Local::SELECT ) === WPDRC_Local::normalise( '2,4,7', WPDRC_Local::SELECT ) );
	check( 'a double-click counts once', '2,4' === WPDRC_Local::normalise( '4,2,4', WPDRC_Local::SELECT ) );
	check( 'tiles outside the grid are dropped', '2' === WPDRC_Local::normalise( '2,99,150', WPDRC_Local::SELECT ), 'a crafted index must not be signable' );
	check( 'junk between the numbers is ignored', '1,3' === WPDRC_Local::normalise( ' 3 ; 1 ', WPDRC_Local::SELECT ) );
	check( 'a non-answer normalises to nothing, which verify() refuses', '' === WPDRC_Local::normalise( 'none', WPDRC_Local::SELECT ) );
}

/* ================================================================ *
 * Through the service façade
 * ================================================================ */

echo "\n=== Every integration works unchanged ===\n";

wpdrc_reset( array( 'type' => WPDRC_Local::MATH ) );

check( 'the service reports a local check', WPDRC_Service::is_local() );
check( 'and considers itself configured with no keys at all', WPDRC_Service::configured(), 'needing no third party is the point' );
check( 'and active', WPDRC_Service::active() );

$field = WPDRC_Service::field( array( 'form' => 'login' ) );

check( 'the field is a local container', false !== strpos( $field, 'wpdrc-local' ) );
check( 'carrying the form marker the interceptor looks for', false !== strpos( $field, 'name="wpdrc_form" value="login"' ) );
check( 'and no Google widget', false === strpos( $field, 'wpdrc-widget' ) );
check( 'and no site key, because there is none', false === strpos( $field, 'sitekey' ) );

$challenge = WPDRC_Local::challenge( WPDRC_Local::MATH );
$_POST     = array(
	'wpdrc_id'     => $challenge['id'],
	'wpdrc_exp'    => $challenge['expires'],
	'wpdrc_sig'    => $challenge['signature'],
	'wpdrc_kind'   => $challenge['kind'],
	'wpdrc_answer' => (string) solve( $challenge['prompt'] ),
);

check( 'WPDRC_Service::verify() routes to the local check', true === WPDRC_Service::verify( 'login' ) );
check( 'and Google was never contacted', 0 === count( $GLOBALS['wpdrc_requests'] ), 'a local check must make no outbound request' );

echo "\n=== A corrupted type setting is safe ===\n";

wpdrc_reset( array( 'type' => 'not_a_real_kind' ) );
check( 'an unknown type is not treated as local', ! WPDRC_Service::is_local() );
check( 'and falls back to a Google widget', WPDRC_Service::V2_CHECKBOX === WPDRC_Service::type() );

printf( "\n----\npassed: %d   failed: %d\n", $pass, $fail );

exit( $fail > 0 ? 1 : 0 );

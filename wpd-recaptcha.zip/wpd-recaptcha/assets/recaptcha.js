/**
 * Wiring the widget to whatever form it landed in.
 *
 * The plugin does not know what forms are on the page. It knows where it put
 * its own markers, so everything here works outwards from those: find the
 * marker, walk up to the form that contains it, and attach to that.
 *
 * The three types need genuinely different handling:
 *
 *   v2 checkbox    The visitor solves it before pressing submit. Nothing to do
 *                  at submit time.
 *   v2 invisible   The challenge runs ON submit. The first submit has to be
 *                  cancelled, the challenge run, and the form submitted again
 *                  from the callback.
 *   v3             No interaction at all, but tokens expire after two minutes.
 *                  A form somebody fills in slowly will submit a dead token
 *                  unless it is refreshed — which is the single commonest way
 *                  a v3 integration fails, and it fails only for slow users,
 *                  so it never shows up in testing.
 *
 * @package WPD_ReCaptcha
 */
( function () {
	'use strict';

	var settings = window.wpdrcSettings || {};
	var widgets = [];

	/**
	 * The form an element belongs to.
	 *
	 * closest('form') rather than element.form, because the marker may be a div
	 * rather than an input and divs have no .form.
	 *
	 * @param {Element} el Element.
	 * @return {HTMLFormElement|null} Its form.
	 */
	function formOf( el ) {
		return el && el.closest ? el.closest( 'form' ) : null;
	}

	/**
	 * Show a message where the widget is, so a failure is visible next to the
	 * thing that failed rather than only in the console.
	 *
	 * @param {Element} near Element to place it after.
	 * @param {string}  text Message.
	 */
	function complain( near, text ) {
		if ( ! near || ! near.parentNode ) {
			return;
		}

		var existing = near.parentNode.querySelector( '.wpdrc-error' );

		if ( ! existing ) {
			existing = document.createElement( 'p' );
			existing.className = 'wpdrc-error';
			existing.setAttribute( 'role', 'alert' );
			near.parentNode.insertBefore( existing, near.nextSibling );
		}

		existing.textContent = text;
	}

	/* ---------------------------------------------------------------- *
	 * v2
	 * ---------------------------------------------------------------- */

	function renderV2() {
		var containers = document.querySelectorAll( '.wpdrc-widget:not([data-wpdrc-done])' );

		Array.prototype.forEach.call( containers, function ( container ) {
			container.setAttribute( 'data-wpdrc-done', '1' );

			var invisible = container.classList.contains( 'wpdrc-widget--invisible' );
			var form = formOf( container );

			var options = {
				sitekey: container.getAttribute( 'data-sitekey' ),
				theme: container.getAttribute( 'data-theme' ) || 'light',
				size: container.getAttribute( 'data-size' ) || 'normal'
			};

			if ( invisible ) {
				options.badge = settings.badge || 'bottomright';
				options.callback = function () {
					/*
					 * The challenge has been solved, so submit for real. The
					 * guard flag is set first: this triggers the submit handler
					 * again, and without it the handler would cancel and run
					 * the challenge a second time, forever.
					 */
					if ( form ) {
						form.setAttribute( 'data-wpdrc-passed', '1' );
						submitForReal( form );
					}
				};

				// A solved challenge goes stale after two minutes. Clearing the
				// guard flag means the next submit runs the challenge again
				// rather than posting a token Google will refuse.
				options['expired-callback'] = function () {
					if ( form ) {
						form.removeAttribute( 'data-wpdrc-passed' );
					}
				};
			}

			var id;

			try {
				id = window.grecaptcha.render( container, options );
			} catch ( e ) {
				// A container rendered twice, or a bad key. Neither is worth
				// breaking the rest of the page over.
				return;
			}

			widgets.push( { id: id, container: container, form: form, invisible: invisible } );

			if ( invisible && form ) {
				bindInvisible( form, id, container );
			}
		} );
	}

	/**
	 * @param {HTMLFormElement} form      Form.
	 * @param {number}          id        Widget id.
	 * @param {Element}         container Widget container.
	 */
	function bindInvisible( form, id, container ) {
		form.addEventListener( 'submit', function ( event ) {
			if ( form.getAttribute( 'data-wpdrc-passed' ) === '1' ) {
				form.removeAttribute( 'data-wpdrc-passed' );
				return; // Second time round; let it through.
			}

			event.preventDefault();
			event.stopImmediatePropagation();

			try {
				window.grecaptcha.reset( id );
				window.grecaptcha.execute( id );
			} catch ( e ) {
				// If the challenge cannot run, let the form submit. The server
				// will refuse it and say why, which is a far better outcome
				// than a button that silently does nothing.
				complain( container, settings.i18n && settings.i18n.jsFailed ? settings.i18n.jsFailed : '' );
				form.setAttribute( 'data-wpdrc-passed', '1' );
				submitForReal( form );
			}
		}, true );
	}

	/* ---------------------------------------------------------------- *
	 * v3
	 * ---------------------------------------------------------------- */

	function startV3() {
		var fields = document.querySelectorAll( '.wpdrc-token:not([data-wpdrc-done])' );

		Array.prototype.forEach.call( fields, function ( field ) {
			field.setAttribute( 'data-wpdrc-done', '1' );

			var form = formOf( field );

			refreshToken( field );

			/*
			 * Tokens last two minutes. Refreshing every ninety seconds means a
			 * form left open on screen still submits a live token — the case
			 * that otherwise fails for exactly the visitors who are reading
			 * carefully and typing slowly.
			 */
			window.setInterval( function () {
				refreshToken( field );
			}, 90000 );

			if ( ! form ) {
				return;
			}

			/*
			 * And one more at the moment of submitting, because an interval
			 * does not run while the tab is in the background — a form filled
			 * in, left in another tab and come back to would otherwise carry a
			 * token minted long ago.
			 */
			form.addEventListener( 'submit', function ( event ) {
				if ( form.getAttribute( 'data-wpdrc-passed' ) === '1' ) {
					form.removeAttribute( 'data-wpdrc-passed' );
					return;
				}

				if ( ! window.grecaptcha || ! window.grecaptcha.execute ) {
					return; // Let it through; the server decides.
				}

				event.preventDefault();
				event.stopImmediatePropagation();

				execute( field, function () {
					form.setAttribute( 'data-wpdrc-passed', '1' );
					submitForReal( form );
				} );
			}, true );
		} );
	}

	/**
	 * @param {Element}  field Hidden token field.
	 * @param {Function} done  Called once the token is in place.
	 */
	function execute( field, done ) {
		try {
			window.grecaptcha.execute( settings.siteKey, {
				action: field.getAttribute( 'data-action' ) || 'wpdrc_form'
			} ).then( function ( token ) {
				field.value = token;

				if ( done ) {
					done();
				}
			}, function () {
				// Google said no. Submit anyway with an empty token and let the
				// server give the visitor a real message.
				if ( done ) {
					done();
				}
			} );
		} catch ( e ) {
			if ( done ) {
				done();
			}
		}
	}

	/**
	 * @param {Element} field Hidden token field.
	 */
	function refreshToken( field ) {
		if ( ! window.grecaptcha || ! window.grecaptcha.execute ) {
			return;
		}

		execute( field, null );
	}

	/* ---------------------------------------------------------------- *
	 * Submitting
	 * ---------------------------------------------------------------- */

	/**
	 * Submit a form the way the page expects.
	 *
	 * requestSubmit() rather than submit(), for two reasons. It re-fires the
	 * submit event, so a site's own handler — the jQuery one doing the AJAX
	 * post, most of the time — still runs, which is the difference between
	 * this working on an AJAX form and turning it into a page reload. And
	 * form.submit() is shadowed to death in WordPress: any field named "submit"
	 * replaces the method with the element, and calling it throws.
	 *
	 * @param {HTMLFormElement} form Form.
	 */
	function submitForReal( form ) {
		if ( typeof form.requestSubmit === 'function' ) {
			var button = form.querySelector( 'input[type="submit"], button[type="submit"]' );

			try {
				form.requestSubmit( button || undefined );
				return;
			} catch ( e ) {
				// Fall through.
			}
		}

		HTMLFormElement.prototype.submit.call( form );
	}

	/* ---------------------------------------------------------------- *
	 * Entry point
	 * ---------------------------------------------------------------- */

	/**
	 * Called by the Google script once it has loaded, by name. It is on window
	 * because the api.js onload parameter can only name a global.
	 */
	window.wpdrcOnload = function () {
		if ( 'v3' === settings.type ) {
			startV3();
		} else {
			renderV2();
		}

		/*
		 * Forms added after load — a modal opened, a step revealed, a block
		 * loaded over AJAX — are picked up here rather than being left without
		 * a widget. Cheap: it only ever looks at elements this plugin printed,
		 * and every one it handles is marked done.
		 */
		if ( window.MutationObserver ) {
			var observer = new window.MutationObserver( function () {
				if ( 'v3' === settings.type ) {
					startV3();
				} else {
					renderV2();
				}
			} );

			observer.observe( document.body, { childList: true, subtree: true } );
		}
	};

	// If the API was already there — a theme or another plugin loaded it — run
	// now rather than waiting for an onload that has been and gone.
	if ( window.grecaptcha && ( window.grecaptcha.render || window.grecaptcha.execute ) ) {
		if ( window.grecaptcha.ready ) {
			window.grecaptcha.ready( window.wpdrcOnload );
		} else {
			window.wpdrcOnload();
		}
	}
}() );

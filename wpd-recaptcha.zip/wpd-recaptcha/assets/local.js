/**
 * Fetching and drawing a locally generated challenge.
 *
 * Every challenge is fetched, never printed into the page. A full-page cache
 * would otherwise hand one challenge to every visitor for hours, and since a
 * challenge can only be answered once, the first person to submit would lock
 * out everybody behind them. Fetching costs one small request and makes the
 * whole thing cache-proof.
 *
 * @package WPD_ReCaptcha
 */
( function () {
	'use strict';

	var settings = window.wpdrcSettings || {};

	/**
	 * @param {Element} host    The .wpdrc-local container.
	 * @param {string}  kind    Kind to ask for, or '' for the configured one.
	 */
	function load( host, kind ) {
		var body = host.querySelector( '.wpdrc-local__body' );

		if ( ! body ) {
			return;
		}

		body.textContent = settings.i18n.loading;

		var url = settings.ajaxUrl
			+ ( settings.ajaxUrl.indexOf( '?' ) === -1 ? '?' : '&' )
			+ 'action=wpdrc_challenge'
			+ ( kind ? '&kind=' + encodeURIComponent( kind ) : '' );

		window.fetch( url, { credentials: 'same-origin' } )
			.then( function ( response ) {
				return response.json();
			} )
			.then( function ( payload ) {
				if ( ! payload || ! payload.success || ! payload.data ) {
					throw new Error( 'no challenge' );
				}

				draw( host, body, payload.data );
			} )
			.catch( function () {
				/*
				 * The check could not be loaded. Say so rather than leaving
				 * "Loading…" on screen forever — the visitor can then reload
				 * rather than filling in the whole form and being refused at
				 * the end of it.
				 */
				body.textContent = settings.i18n.loadFailed;
			} );
	}

	/**
	 * @param {Element} host      Container.
	 * @param {Element} body      Where the challenge goes.
	 * @param {Object}  challenge From the server.
	 */
	function draw( host, body, challenge ) {
		body.textContent = '';

		hidden( body, 'wpdrc_id', challenge.id );
		hidden( body, 'wpdrc_exp', challenge.expires );
		hidden( body, 'wpdrc_sig', challenge.signature );
		hidden( body, 'wpdrc_kind', challenge.kind );

		if ( 'puzzle' === challenge.kind ) {
			drawPuzzle( body, challenge );
		} else if ( 'select' === challenge.kind ) {
			drawSelect( body, challenge );
		} else {
			drawInput( body, challenge );
		}

		if ( challenge.alt ) {
			offerAccessible( host, body );
		}
	}

	/**
	 * A prompt, or an image, and a box to type in.
	 *
	 * @param {Element} body      Where it goes.
	 * @param {Object}  challenge Challenge.
	 */
	function drawInput( body, challenge ) {
		var id = 'wpdrc-a-' + challenge.id;

		var label = document.createElement( 'label' );
		label.className = 'wpdrc-local__label';
		label.setAttribute( 'for', id );
		label.textContent = challenge.label;
		body.appendChild( label );

		if ( challenge.image ) {
			var img = document.createElement( 'img' );
			img.className = 'wpdrc-local__image';
			img.src = challenge.image;
			// The characters are the whole test, so the alt cannot describe
			// them. It says what the image is for and points at the way out.
			img.alt = settings.i18n.imageAlt;
			body.appendChild( img );
		}

		if ( challenge.prompt ) {
			var prompt = document.createElement( 'span' );
			prompt.className = 'wpdrc-local__prompt';
			prompt.textContent = challenge.prompt;
			body.appendChild( prompt );
		}

		var input = document.createElement( 'input' );
		input.type = 'text';
		input.name = 'wpdrc_answer';
		input.id = id;
		input.className = 'wpdrc-local__answer';
		input.autocomplete = 'off';
		input.required = true;
		// A phone keyboard that capitalises and autocorrects turns a correct
		// answer into a wrong one, and the visitor cannot see why.
		input.setAttribute( 'autocapitalize', 'off' );
		input.setAttribute( 'autocorrect', 'off' );
		input.setAttribute( 'spellcheck', 'false' );

		if ( 'math' === challenge.kind ) {
			input.setAttribute( 'inputmode', 'numeric' );
		}

		body.appendChild( input );
	}

	/**
	 * The slider.
	 *
	 * @param {Element} body      Where it goes.
	 * @param {Object}  challenge Challenge.
	 */
	function drawPuzzle( body, challenge ) {
		var track = parseInt( body.parentNode.getAttribute( 'data-track' ), 10 ) || 260;

		var label = document.createElement( 'p' );
		label.className = 'wpdrc-local__label';
		label.textContent = challenge.label;
		body.appendChild( label );

		var rail = document.createElement( 'div' );
		rail.className = 'wpdrc-puzzle';
		rail.style.width = track + 'px';

		var target = document.createElement( 'span' );
		target.className = 'wpdrc-puzzle__target';
		target.style.left = challenge.target + 'px';
		rail.appendChild( target );

		/*
		 * A range input, not a bare div with mouse handlers.
		 *
		 * It is draggable with a finger, with a mouse, and — the part a custom
		 * widget always forgets — with the arrow keys. Somebody who cannot use
		 * a pointing device can still pass this, which is the difference
		 * between an awkward captcha and one that excludes people.
		 */
		var slider = document.createElement( 'input' );
		slider.type = 'range';
		slider.className = 'wpdrc-puzzle__handle';
		slider.min = 0;
		slider.max = track;
		slider.value = 0;
		slider.name = 'wpdrc_answer';
		slider.setAttribute( 'aria-label', challenge.label );
		rail.appendChild( slider );

		slider.addEventListener( 'input', function () {
			var close = Math.abs( parseInt( slider.value, 10 ) - challenge.target ) <= 12;

			rail.classList.toggle( 'is-aligned', close );
		} );

		hidden( body, 'wpdrc_target', challenge.target );

		body.appendChild( rail );
	}

	/**
	 * The picture grid: pick every tile that matches.
	 *
	 * Buttons, not clickable divs. A div with a click handler cannot be tabbed
	 * to, cannot be pressed with the space bar, and announces nothing — which
	 * on a control whose entire job is being pressed is not a detail.
	 *
	 * The selection lives in one hidden field as a list of indices. Nine
	 * checkboxes would work too, but then a form plugin that serialises its own
	 * fields has to know about all nine, and the CF7 and Fluent handlers only
	 * ever look for wpdrc_answer.
	 *
	 * @param {Element} body      Where it goes.
	 * @param {Object}  challenge Challenge.
	 */
	function drawSelect( body, challenge ) {
		var tiles = challenge.tiles || [];

		var label = document.createElement( 'p' );
		label.className = 'wpdrc-local__label';
		label.textContent = challenge.label;
		body.appendChild( label );

		var hint = document.createElement( 'p' );
		hint.className = 'wpdrc-local__hint';
		hint.textContent = settings.i18n.tileHint;
		body.appendChild( hint );

		var answer = document.createElement( 'input' );
		answer.type = 'hidden';
		answer.name = 'wpdrc_answer';
		answer.value = '';

		var grid = document.createElement( 'div' );
		grid.className = 'wpdrc-grid';
		grid.setAttribute( 'role', 'group' );
		grid.setAttribute( 'aria-label', challenge.label );

		var picked = [];

		/**
		 * Rebuild the field from what is pressed, in grid order.
		 *
		 * Rebuilt rather than appended to, because a tile can be turned off
		 * again and a list that only grows would keep a deselected tile in the
		 * answer — a bug the visitor cannot see and cannot work around.
		 */
		function sync() {
			picked.sort( function ( a, b ) {
				return a - b;
			} );

			answer.value = picked.join( ',' );
		}

		tiles.forEach( function ( src, index ) {
			var tile = document.createElement( 'button' );
			tile.type = 'button';
			tile.className = 'wpdrc-grid__tile';
			tile.setAttribute( 'aria-pressed', 'false' );
			tile.setAttribute( 'aria-label', ( settings.i18n.tile || 'Picture %d' ).replace( '%d', index + 1 ) );

			var img = document.createElement( 'img' );
			img.src = src;
			// What is in the picture is the whole question, so there is no alt
			// text that describes it without answering it. The button's label
			// says which tile this is; the way out below is the accessible path.
			img.alt = '';
			img.setAttribute( 'aria-hidden', 'true' );
			img.draggable = false;
			tile.appendChild( img );

			tile.addEventListener( 'click', function () {
				var on = tile.getAttribute( 'aria-pressed' ) === 'true';
				var at = picked.indexOf( index );

				if ( on ) {
					if ( at !== -1 ) {
						picked.splice( at, 1 );
					}
				} else if ( at === -1 ) {
					picked.push( index );
				}

				tile.setAttribute( 'aria-pressed', on ? 'false' : 'true' );
				tile.classList.toggle( 'is-picked', ! on );

				sync();
			} );

			grid.appendChild( tile );
		} );

		body.appendChild( grid );
		body.appendChild( answer );
	}

	/**
	 * The way out of a challenge somebody cannot see.
	 *
	 * @param {Element} host Container.
	 * @param {Element} body Body.
	 */
	function offerAccessible( host, body ) {
		var link = document.createElement( 'button' );
		link.type = 'button';
		link.className = 'wpdrc-local__alt';
		link.textContent = settings.i18n.needAnother;

		link.addEventListener( 'click', function () {
			load( host, 'math' );
		} );

		body.appendChild( link );
	}

	/**
	 * @param {Element} parent Where to put it.
	 * @param {string}  name   Field name.
	 * @param {string}  value  Field value.
	 */
	function hidden( parent, name, value ) {
		var field = document.createElement( 'input' );
		field.type = 'hidden';
		field.name = name;
		field.value = value;
		parent.appendChild( field );
	}

	/**
	 * Pick up every container, including ones added later by a modal or a
	 * revealed step.
	 */
	function scan() {
		var hosts = document.querySelectorAll( '.wpdrc-local:not([data-wpdrc-done])' );

		Array.prototype.forEach.call( hosts, function ( host ) {
			host.setAttribute( 'data-wpdrc-done', '1' );
			load( host, '' );
		} );
	}

	if ( ! window.fetch ) {
		return;
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', scan );
	} else {
		scan();
	}

	if ( window.MutationObserver ) {
		new window.MutationObserver( scan ).observe( document.documentElement, { childList: true, subtree: true } );
	}
}() );

<?php
/**
 * Captchas this site generates itself: sums, questions, letters, a slider, and
 * a grid of pictures to pick from.
 *
 * WHAT THESE ARE FOR, honestly.
 *
 * They do not compete with Google on strength and it would be dishonest to
 * imply otherwise. A sum is solvable by four lines of Python. Distorted letters
 * are solvable by OCR that has been commodity for a decade. A slider puzzle is
 * solvable by anyone who reads the request it sends. The picture grid draws
 * eight things, so anyone who writes all eight down beats it for good. Any of
 * them is solvable by a language model for a fraction of a penny.
 *
 * What they actually buy you:
 *
 *   • Nothing leaves the site. No third-party script, no data sent to Google,
 *     nothing to declare in a privacy policy or a cookie banner.
 *   • They work where Google does not — behind a firewall, in China, on an
 *     intranet, on a server with no outbound HTTPS.
 *   • They stop the overwhelming majority of what actually hits a small site's
 *     contact form, which is generic spam software crawling for any form at
 *     all, not somebody targeting you.
 *
 * That last one is the real case. Most spam is not an attack; it is weather.
 * A local captcha is an umbrella. If somebody is actually aiming at your site,
 * none of this will stop them and Google's will not either — rate limiting and
 * moderation will.
 *
 * HOW A CHALLENGE IS KEPT HONEST
 *
 * The answer is never sent to the browser. What goes out is the question, an
 * id, an expiry and an HMAC of the answer signed with a site secret. The server
 * recomputes that HMAC from whatever was typed and compares in constant time,
 * so there is nothing to store between the two requests and nothing in the page
 * that gives the answer away.
 *
 * Challenges are fetched over AJAX rather than printed into the page. That is
 * not decoration: a full-page cache would otherwise serve one challenge to
 * every visitor for hours, and single-use protection would then mean the first
 * person to submit locks out everybody else.
 *
 * @package WPD_ReCaptcha
 */

defined( 'ABSPATH' ) || exit;

class WPDRC_Local {

	/** Challenge kinds. */
	const MATH     = 'math';
	const QUESTION = 'question';
	const LETTERS  = 'letters';
	const PUZZLE   = 'puzzle';
	const SELECT   = 'select';

	/** How long a challenge stays answerable. */
	const TTL = 900;

	/** Slider tolerance, in pixels either side. */
	const PUZZLE_TOLERANCE = 12;

	/** The track the slider runs along. */
	const PUZZLE_TRACK = 260;

	/** Tiles in the picture grid, and how big each one is drawn. */
	const SELECT_TILES = 9;
	const SELECT_SIZE  = 96;

	/** @var WPDRC_Local|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_ajax_wpdrc_challenge', array( $this, 'ajax_challenge' ) );
		add_action( 'wp_ajax_nopriv_wpdrc_challenge', array( $this, 'ajax_challenge' ) );
	}

	/**
	 * @return string[] The kinds this class handles.
	 */
	public static function kinds() {
		return array( self::MATH, self::QUESTION, self::LETTERS, self::PUZZLE, self::SELECT );
	}

	/**
	 * @param string $type A type from the settings.
	 * @return bool
	 */
	public static function handles( $type ) {
		return in_array( $type, self::kinds(), true );
	}

	/**
	 * Kinds a screen reader cannot use.
	 *
	 * Each of these is offered with a link that swaps to a sum, and that link
	 * is not optional politeness. A captcha nobody blind can pass is a form
	 * nobody blind can submit, which in most of the world is a legal problem as
	 * well as a rude one.
	 *
	 * The picture grid is the sharpest case: its whole question is "what is in
	 * this image", so there is no alt text that can describe a tile without
	 * also answering it. The way out is the only accessible path it has.
	 *
	 * @return string[]
	 */
	public static function visual_only() {
		return array( self::LETTERS, self::PUZZLE, self::SELECT );
	}

	/* ------------------------------------------------------------------ *
	 * The placeholder that goes in the form
	 * ------------------------------------------------------------------ */

	/**
	 * @param array $args form, kind.
	 * @return string
	 */
	public static function field( array $args ) {
		$kind = self::kind();
		$form = isset( $args['form'] ) ? (string) $args['form'] : 'form';

		WPDRC_Assets::instance()->needed();

		return sprintf(
			'<div class="wpdrc-local" data-kind="%1$s" data-form="%2$s" data-track="%3$d">'
				. '<div class="wpdrc-local__body"><p class="wpdrc-local__loading">%4$s</p></div>'
				. '<noscript><p class="wpdrc-local__noscript">%5$s</p></noscript>'
				. '</div>'
				. '<input type="hidden" name="wpdrc_form" value="%2$s" />',
			esc_attr( $kind ),
			esc_attr( $form ),
			(int) self::PUZZLE_TRACK,
			esc_html__( 'Loading the check…', 'wpd-recaptcha' ),
			esc_html__( 'This form needs JavaScript to show its spam check.', 'wpd-recaptcha' )
		);
	}

	/**
	 * @return string The configured kind.
	 */
	public static function kind() {
		$kind = (string) WPDRC_Options::get( 'type', self::MATH );

		return self::handles( $kind ) ? $kind : self::MATH;
	}

	/* ------------------------------------------------------------------ *
	 * Generating
	 * ------------------------------------------------------------------ */

	/**
	 * Hand out a fresh challenge.
	 */
	public function ajax_challenge() {
		if ( ! WPDRC_Service::active() ) {
			wp_send_json_error( array( 'message' => __( 'No check is configured.', 'wpd-recaptcha' ) ), 400 );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$wanted = isset( $_REQUEST['kind'] ) ? sanitize_key( wp_unslash( $_REQUEST['kind'] ) ) : '';

		/*
		 * The only kind a visitor may ask for by name is the accessible one.
		 * Letting the request pick freely would let a bot ask for whichever
		 * challenge it finds easiest, which is the whole game.
		 */
		$kind = ( 'math' === $wanted ) ? self::MATH : self::kind();

		wp_send_json_success( self::challenge( $kind ) );
	}

	/**
	 * @param string $kind Challenge kind.
	 * @return array Everything the browser needs, and nothing it should not have.
	 */
	public static function challenge( $kind ) {
		$made = self::make( $kind );

		/*
		 * What was actually made, which is not always what was asked for.
		 *
		 * Three kinds fall back to a sum: letters and the picture grid when the
		 * server has no GD, and a question when none has been written. The kind
		 * has to follow, because it is what the browser draws from and what the
		 * signature is made over.
		 *
		 * Getting this wrong is quiet and total. Ask for a picture grid on a
		 * server without GD, keep the label 'select', and the browser is told to
		 * draw nine tiles it was never sent — an empty box with nothing to
		 * click, on every protected form on the site, with no error anywhere.
		 */
		$kind = isset( $made['kind'] ) ? $made['kind'] : $kind;

		$id      = bin2hex( self::random( 8 ) );
		$expires = time() + self::TTL;

		/*
		 * Signed in its normalised form, not as written.
		 *
		 * The verifier normalises whatever was typed before comparing, so
		 * signing the raw answer means "Bristol" is signed and "bristol" is
		 * checked, and they never match. It looked fine in testing because the
		 * first question in the list happened to be lower case already — which
		 * is exactly how this sort of bug reaches a live site.
		 */
		$signed = ( self::PUZZLE === $kind ) ? $made['answer'] : self::normalise( $made['answer'], $kind );

		$out = array(
			'kind'      => $kind,
			'id'        => $id,
			'expires'   => $expires,
			'signature' => self::sign( $signed, $id, $expires, $kind ),
			'prompt'    => $made['prompt'],
			'label'     => $made['label'],
			// Whether to offer the "give me one I can read" link.
			'alt'       => in_array( $kind, self::visual_only(), true ),
		);

		// Only sent where they mean something. A field carrying a placeholder
		// is one more thing for a reader of this response to wonder about.
		if ( ! empty( $made['image'] ) ) {
			$out['image'] = $made['image'];
		}

		if ( isset( $made['target'] ) ) {
			$out['target'] = $made['target'];
		}

		/*
		 * The tiles go out; which of them are right does not. The browser is
		 * given nine pictures and a sentence, and the only thing that knows
		 * the answer is the signature — which cannot be read backwards.
		 */
		if ( ! empty( $made['tiles'] ) ) {
			$out['tiles'] = $made['tiles'];
		}

		return $out;
	}

	/**
	 * @param string $kind Challenge kind.
	 * @return array answer, prompt, label, and maybe image/target.
	 */
	private static function make( $kind ) {
		switch ( $kind ) {
			case self::QUESTION:
				return self::make_question();

			case self::LETTERS:
				return self::make_letters();

			case self::PUZZLE:
				return self::make_puzzle();

			case self::SELECT:
				return self::make_select();

			default:
				return self::make_math();
		}
	}

	/**
	 * A sum, written in words as often as in digits.
	 *
	 * Digits alone are picked out by a regex in one line, and the crawlers that
	 * bother with maths captchas at all do exactly that. Words cost a real
	 * person nothing and cost a scraper a lookup table.
	 *
	 * @return array
	 */
	private static function make_math() {
		$words = array( 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve' );

		$a  = self::pick( 1, 9 );
		$b  = self::pick( 1, 9 );
		$op = self::pick( 0, 2 );

		if ( 2 === $op ) {
			// Never a negative answer: "three minus seven" is a fair question
			// and a terrible captcha.
			if ( $a < $b ) {
				list( $a, $b ) = array( $b, $a );
			}

			$answer = $a - $b;
			$symbol = '−';
			$verb   = __( 'minus', 'wpd-recaptcha' );
		} elseif ( 1 === $op ) {
			$a      = self::pick( 2, 5 );
			$b      = self::pick( 2, 5 );
			$answer = $a * $b;
			$symbol = '×';
			$verb   = __( 'times', 'wpd-recaptcha' );
		} else {
			$answer = $a + $b;
			$symbol = '+';
			$verb   = __( 'plus', 'wpd-recaptcha' );
		}

		$as_words = self::pick( 0, 1 ) > 0;

		$prompt = $as_words
			? sprintf( '%s %s %s', $words[ $a ], $verb, $words[ $b ] )
			: sprintf( '%d %s %d', $a, $symbol, $b );

		return array(
			// Stated rather than assumed, because this is also what the other
			// kinds fall back to and the caller has to know it happened.
			'kind'   => self::MATH,
			'answer' => (string) $answer,
			'prompt' => $prompt . ' = ?',
			'label'  => __( 'What is the answer?', 'wpd-recaptcha' ),
		);
	}

	/**
	 * A question the site owner wrote.
	 *
	 * The strongest of these against generic software, because no crawler
	 * has a table of answers to a question about your business — and the
	 * weakest against anybody who reads the page once.
	 *
	 * @return array
	 */
	private static function make_question() {
		$pairs = self::questions();

		if ( ! $pairs ) {
			// Nothing configured. Falling back to a sum is better than a form
			// with an unanswerable question on it.
			return self::make_math();
		}

		$chosen = $pairs[ self::pick( 0, count( $pairs ) - 1 ) ];

		return array(
			'answer' => $chosen['answer'],
			'prompt' => $chosen['question'],
			'label'  => __( 'Your answer', 'wpd-recaptcha' ),
		);
	}

	/**
	 * @return array[] question, answer.
	 */
	public static function questions() {
		$raw   = (string) WPDRC_Options::get( 'questions', '' );
		$pairs = array();

		foreach ( preg_split( '/[\r\n]+/', $raw ) as $line ) {
			$line = trim( $line );

			if ( '' === $line || false === strpos( $line, '|' ) ) {
				continue;
			}

			list( $question, $answer ) = array_map( 'trim', explode( '|', $line, 2 ) );

			if ( '' !== $question && '' !== $answer ) {
				$pairs[] = array( 'question' => $question, 'answer' => $answer );
			}
		}

		return $pairs;
	}

	/**
	 * Distorted letters, drawn with GD and returned as a data URI.
	 *
	 * A data URI rather than a separate image endpoint, because an endpoint
	 * needs to remember which challenge it is drawing — which means a session
	 * or a transient, which means state that a page cache can serve stale.
	 *
	 * Characters that look like each other are left out entirely. There is
	 * nothing clever about a captcha where a real person fails because they
	 * could not tell 0 from O, and the ones who fail are disproportionately
	 * the ones on a small screen.
	 *
	 * @return array
	 */
	private static function make_letters() {
		$alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
		$length   = 5;
		$text     = '';

		for ( $i = 0; $i < $length; $i++ ) {
			$text .= $alphabet[ self::pick( 0, strlen( $alphabet ) - 1 ) ];
		}

		$image = self::draw( $text );

		if ( '' === $image ) {
			// No GD. A sum is a working captcha; a broken image is not.
			return self::make_math();
		}

		return array(
			'answer' => $text,
			'prompt' => '',
			'image'  => $image,
			'label'  => __( 'Type the characters shown', 'wpd-recaptcha' ),
		);
	}

	/**
	 * @param string $text Characters to draw.
	 * @return string A data URI, or ''.
	 */
	private static function draw( $text ) {
		if ( ! function_exists( 'imagecreatetruecolor' ) || ! function_exists( 'imagepng' ) ) {
			return '';
		}

		$width  = 200;
		$height = 64;

		$image = imagecreatetruecolor( $width, $height );

		if ( ! $image ) {
			return '';
		}

		$background = imagecolorallocate( $image, 245, 245, 246 );
		imagefilledrectangle( $image, 0, 0, $width, $height, $background );

		// Noise first, so it sits behind the characters rather than obscuring
		// them. Noise heavy enough to stop OCR is heavy enough to stop people.
		for ( $i = 0; $i < 400; $i++ ) {
			$grey = imagecolorallocate( $image, self::pick( 190, 225 ), self::pick( 190, 225 ), self::pick( 190, 225 ) );
			imagesetpixel( $image, self::pick( 0, $width ), self::pick( 0, $height ), $grey );
		}

		for ( $i = 0; $i < 4; $i++ ) {
			$grey = imagecolorallocate( $image, self::pick( 200, 230 ), self::pick( 200, 230 ), self::pick( 200, 230 ) );
			imageline( $image, self::pick( 0, $width ), self::pick( 0, $height ), self::pick( 0, $width ), self::pick( 0, $height ), $grey );
		}

		$length = strlen( $text );
		$step   = (int) floor( ( $width - 30 ) / max( 1, $length ) );

		for ( $i = 0; $i < $length; $i++ ) {
			$ink = imagecolorallocate( $image, self::pick( 20, 90 ), self::pick( 20, 90 ), self::pick( 40, 110 ) );
			$x   = 18 + ( $i * $step );
			$y   = self::pick( 20, 44 );

			/*
			 * imagestring() rather than a TrueType font: imagettftext() needs a
			 * font file, and shipping one means shipping its licence and
			 * hoping FreeType is compiled in. The built-in font is uglier and
			 * always there.
			 */
			imagestring( $image, 5, $x, $y - 14, $text[ $i ], $ink );

			// A second pass a pixel or two off makes the glyph edges ragged,
			// which is most of what defeats a naive threshold-and-match.
			imagestring( $image, 5, $x + self::pick( -1, 1 ), $y - 14 + self::pick( -1, 1 ), $text[ $i ], $ink );
		}

		ob_start();
		imagepng( $image );
		$binary = ob_get_clean();

		imagedestroy( $image );

		if ( ! $binary ) {
			return '';
		}

		return 'data:image/png;base64,' . base64_encode( $binary );
	}

	/**
	 * A slider: drag the handle until the two marks line up.
	 *
	 * The weakest of these and it is worth saying why: the target position
	 * is sent to the browser, because the browser has to draw the gap. Anybody
	 * who reads one response knows where to put the handle. It stops software
	 * that does not run JavaScript, which is still most spam software, and it
	 * stops nothing else.
	 *
	 * @return array
	 */
	private static function make_puzzle() {
		$target = self::pick( 60, self::PUZZLE_TRACK - 40 );

		/*
		 * The exact target is signed, and verification compares the dropped
		 * position against it within a tolerance.
		 *
		 * An earlier version rounded the position into buckets so that a near
		 * miss hashed to the same value. That is wrong at every bucket
		 * boundary: a target of 65 and a drop at 69 are four pixels apart and
		 * land in different buckets, so the visitor is refused for being
		 * accurate. Tolerance has to be a comparison, not a rounding.
		 */
		return array(
			'answer' => (string) $target,
			'prompt' => '',
			'target' => $target,
			'label'  => __( 'Slide the handle until the shapes line up', 'wpd-recaptcha' ),
		);
	}

	/* ------------------------------------------------------------------ *
	 * The picture grid
	 * ------------------------------------------------------------------ */

	/**
	 * "Select every picture with a bicycle in it."
	 *
	 * The familiar shape, done without Google and without shipping a single
	 * photograph. Every tile is drawn here with GD from a handful of lines and
	 * polygons, so there is no image library to license, nothing to keep in the
	 * plugin folder, and no request to anybody else's server.
	 *
	 * WHAT IT IS AND IS NOT.
	 *
	 * Google's version works because the pictures are real photographs it has
	 * millions of, labelled by everyone who has ever solved one. This has eight
	 * pictograms. Anybody willing to write down what each of the eight looks
	 * like beats it permanently, and it would be dishonest to sell it as more
	 * than that.
	 *
	 * What it does do: it cannot be solved by software that does not run
	 * JavaScript and cannot see, which is nearly all of what actually reaches a
	 * contact form. And unlike the slider, the answer is genuinely not in the
	 * response — the tiles go out, the grading does not.
	 *
	 * Two defences against the obvious attack, which is hashing the tile and
	 * looking it up. Each tile is drawn at a random scale and offset, in a
	 * random ink over a random tint, mirrored at random, and speckled — so no
	 * two renderings of "a car" are ever the same bytes. That defeats a hash
	 * table. It does not defeat anybody who looks at the picture, and nothing
	 * drawn in a 96-pixel box could.
	 *
	 * @return array
	 */
	private static function make_select() {
		if ( ! function_exists( 'imagecreatetruecolor' ) || ! function_exists( 'imagepng' ) ) {
			// No GD. A sum is a working captcha; nine broken images are not.
			return self::make_math();
		}

		$subjects = self::select_subjects();
		$keys     = array_keys( $subjects );

		$wanted = $keys[ self::pick( 0, count( $keys ) - 1 ) ];
		$decoys = array_values( array_diff( $keys, array( $wanted ) ) );

		/*
		 * Two to four right tiles, never nought and never all nine.
		 *
		 * A grid with no right answer cannot be told apart from one the visitor
		 * has not finished, and a grid where everything is right is passed by
		 * selecting everything — which is what a bot does first.
		 */
		$right = self::pick( 2, 4 );

		$slots = range( 0, self::SELECT_TILES - 1 );
		self::shuffle( $slots );

		$correct = array_slice( $slots, 0, $right );
		sort( $correct, SORT_NUMERIC );

		$tiles = array();

		for ( $i = 0; $i < self::SELECT_TILES; $i++ ) {
			$subject = in_array( $i, $correct, true )
				? $wanted
				: $decoys[ self::pick( 0, count( $decoys ) - 1 ) ];

			$drawn = self::draw_tile( $subject );

			if ( '' === $drawn ) {
				// One tile failing means a grid with a hole in it, which is
				// unanswerable. Better to ask something else entirely.
				return self::make_math();
			}

			$tiles[] = $drawn;
		}

		return array(
			'answer' => implode( ',', $correct ),
			'prompt' => '',
			'tiles'  => $tiles,
			/* translators: %s: what to look for, already phrased — "a bicycle", "stairs". */
			'label'  => sprintf( __( 'Select every picture with %s in it', 'wpd-recaptcha' ), $subjects[ $wanted ] ),
		);
	}

	/**
	 * The things that can be drawn, and how to name each in the question.
	 *
	 * Phrased whole rather than assembled from an article and a noun, because
	 * "a" before "umbrella" is wrong in English and there is no rule that
	 * survives translation. A translator gets the finished phrase.
	 *
	 * @return array<string,string>
	 */
	public static function select_subjects() {
		return array(
			'car'     => __( 'a car', 'wpd-recaptcha' ),
			'bicycle' => __( 'a bicycle', 'wpd-recaptcha' ),
			'lights'  => __( 'a traffic light', 'wpd-recaptcha' ),
			'stairs'  => __( 'stairs', 'wpd-recaptcha' ),
			'tree'    => __( 'a tree', 'wpd-recaptcha' ),
			'house'   => __( 'a house', 'wpd-recaptcha' ),
			'boat'    => __( 'a boat', 'wpd-recaptcha' ),
			'brolly'  => __( 'an umbrella', 'wpd-recaptcha' ),
		);
	}

	/**
	 * One tile, as a data URI.
	 *
	 * A data URI rather than an image endpoint, for the same reason the letters
	 * use one: an endpoint would have to remember which tile it was drawing,
	 * which means state, which a page cache can serve stale.
	 *
	 * @param string $subject Key from select_subjects().
	 * @return string A data URI, or '' if it could not be drawn.
	 */
	private static function draw_tile( $subject ) {
		$size = self::SELECT_SIZE;

		$image = imagecreatetruecolor( $size, $size );

		if ( ! $image ) {
			return '';
		}

		// A tinted ground rather than white. Nine white squares in a row read
		// as a broken image before they read as a puzzle.
		$tint = imagecolorallocate( $image, self::pick( 232, 248 ), self::pick( 234, 249 ), self::pick( 236, 250 ) );
		imagefilledrectangle( $image, 0, 0, $size, $size, $tint );

		$ink = imagecolorallocate( $image, self::pick( 24, 72 ), self::pick( 28, 78 ), self::pick( 40, 96 ) );

		/*
		 * Where the pictogram lands inside the tile. Everything below is drawn
		 * in a 0–100 box and mapped through here, so one scale and one offset
		 * move the whole drawing — and every tile gets its own.
		 */
		$scale = self::pick( 78, 96 ) / 100;
		$room  = (int) round( $size * ( 1 - $scale ) );

		$map = array(
			'scale' => ( $size * $scale ) / 100,
			'dx'    => self::pick( 0, max( 0, $room ) ),
			'dy'    => self::pick( 0, max( 0, $room ) ),
		);

		self::speckle( $image, $size );

		imagesetthickness( $image, max( 2, (int) round( 4 * $scale ) ) );

		switch ( $subject ) {
			case 'car':
				self::draw_car( $image, $map, $ink, $tint );
				break;
			case 'bicycle':
				self::draw_bicycle( $image, $map, $ink );
				break;
			case 'lights':
				self::draw_lights( $image, $map, $ink );
				break;
			case 'stairs':
				self::draw_stairs( $image, $map, $ink );
				break;
			case 'tree':
				self::draw_tree( $image, $map, $ink );
				break;
			case 'house':
				self::draw_house( $image, $map, $ink, $tint );
				break;
			case 'boat':
				self::draw_boat( $image, $map, $ink );
				break;
			default:
				self::draw_brolly( $image, $map, $ink );
				break;
		}

		/*
		 * Mirrored half the time. Free, costs a person nothing, and doubles the
		 * size of any table somebody builds of what these look like.
		 */
		if ( function_exists( 'imageflip' ) && self::pick( 0, 1 ) ) {
			imageflip( $image, IMG_FLIP_HORIZONTAL );
		}

		ob_start();
		imagepng( $image );
		$binary = ob_get_clean();

		imagedestroy( $image );

		if ( ! $binary ) {
			return '';
		}

		return 'data:image/png;base64,' . base64_encode( $binary );
	}

	/**
	 * Faint grain, so no two tiles are ever the same bytes.
	 *
	 * Light enough to be invisible at a glance and heavy enough that a hash of
	 * the file tells an attacker nothing. Noise strong enough to trouble a
	 * person is noise that has gone too far — they are the ones who have to
	 * pass this.
	 *
	 * @param resource|GdImage $image The tile.
	 * @param int              $size  Its width and height.
	 */
	private static function speckle( $image, $size ) {
		for ( $i = 0; $i < 90; $i++ ) {
			$grey = imagecolorallocate( $image, self::pick( 200, 232 ), self::pick( 202, 234 ), self::pick( 204, 236 ) );

			imagesetpixel( $image, self::pick( 0, $size - 1 ), self::pick( 0, $size - 1 ), $grey );
		}
	}

	/**
	 * Map a point in the 0–100 drawing box onto the tile.
	 *
	 * @param array $map scale, dx, dy.
	 * @param float $x   X in the drawing box.
	 * @param float $y   Y in the drawing box.
	 * @return int[] x, y in pixels.
	 */
	private static function at( array $map, $x, $y ) {
		return array(
			(int) round( ( $x * $map['scale'] ) + $map['dx'] ),
			(int) round( ( $y * $map['scale'] ) + $map['dy'] ),
		);
	}

	/**
	 * @param resource|GdImage $image  Tile.
	 * @param array            $map    Placement.
	 * @param int[]            $points Pairs, in the drawing box.
	 * @param int              $colour Fill.
	 */
	private static function poly( $image, array $map, array $points, $colour ) {
		$flat = array();

		for ( $i = 0; $i < count( $points ); $i += 2 ) {
			list( $x, $y ) = self::at( $map, $points[ $i ], $points[ $i + 1 ] );

			$flat[] = $x;
			$flat[] = $y;
		}

		/*
		 * PHP 8 dropped the point-count argument and PHP 7 requires it. Passing
		 * it on 8 is deprecated; leaving it off on 7 is a fatal. The plugin
		 * supports both, so it has to ask.
		 */
		if ( PHP_VERSION_ID >= 80000 ) {
			imagefilledpolygon( $image, $flat, $colour );
		} else {
			imagefilledpolygon( $image, $flat, (int) ( count( $flat ) / 2 ), $colour );
		}
	}

	/**
	 * @param resource|GdImage $image  Tile.
	 * @param array            $map    Placement.
	 * @param float            $x1     Left.
	 * @param float            $y1     Top.
	 * @param float            $x2     Right.
	 * @param float            $y2     Bottom.
	 * @param int              $colour Fill.
	 */
	private static function box( $image, array $map, $x1, $y1, $x2, $y2, $colour ) {
		list( $ax, $ay ) = self::at( $map, $x1, $y1 );
		list( $bx, $by ) = self::at( $map, $x2, $y2 );

		imagefilledrectangle( $image, $ax, $ay, $bx, $by, $colour );
	}

	/**
	 * @param resource|GdImage $image  Tile.
	 * @param array            $map    Placement.
	 * @param float            $x1     From x.
	 * @param float            $y1     From y.
	 * @param float            $x2     To x.
	 * @param float            $y2     To y.
	 * @param int              $colour Ink.
	 */
	private static function stroke( $image, array $map, $x1, $y1, $x2, $y2, $colour ) {
		list( $ax, $ay ) = self::at( $map, $x1, $y1 );
		list( $bx, $by ) = self::at( $map, $x2, $y2 );

		imageline( $image, $ax, $ay, $bx, $by, $colour );
	}

	/**
	 * @param resource|GdImage $image    Tile.
	 * @param array            $map      Placement.
	 * @param float            $cx       Centre x.
	 * @param float            $cy       Centre y.
	 * @param float            $diameter Width and height.
	 * @param int              $colour   Colour.
	 * @param bool             $filled   Solid or outline.
	 */
	private static function disc( $image, array $map, $cx, $cy, $diameter, $colour, $filled = true ) {
		list( $x, $y ) = self::at( $map, $cx, $cy );

		$d = max( 2, (int) round( $diameter * $map['scale'] ) );

		if ( $filled ) {
			imagefilledellipse( $image, $x, $y, $d, $d, $colour );
			return;
		}

		imageellipse( $image, $x, $y, $d, $d, $colour );
	}

	/** @param resource|GdImage $image Tile. @param array $map Placement. @param int $ink Ink. @param int $tint Ground. */
	private static function draw_car( $image, array $map, $ink, $tint ) {
		self::poly( $image, $map, array( 8, 62, 20, 62, 30, 44, 68, 44, 80, 62, 92, 62, 92, 74, 8, 74 ), $ink );

		// Windows punched back out in the ground colour. A solid lump reads as
		// a brick; the glass is most of what says "car".
		self::box( $image, $map, 34, 48, 48, 60, $tint );
		self::box( $image, $map, 52, 48, 66, 60, $tint );

		self::disc( $image, $map, 27, 76, 26, $ink );
		self::disc( $image, $map, 73, 76, 26, $ink );
		self::disc( $image, $map, 27, 76, 10, $tint );
		self::disc( $image, $map, 73, 76, 10, $tint );
	}

	/** @param resource|GdImage $image Tile. @param array $map Placement. @param int $ink Ink. */
	private static function draw_bicycle( $image, array $map, $ink ) {
		self::disc( $image, $map, 22, 66, 42, $ink, false );
		self::disc( $image, $map, 78, 66, 42, $ink, false );

		self::stroke( $image, $map, 22, 66, 46, 66, $ink );
		self::stroke( $image, $map, 46, 66, 40, 36, $ink );
		self::stroke( $image, $map, 40, 36, 68, 36, $ink );
		self::stroke( $image, $map, 68, 36, 46, 66, $ink );
		self::stroke( $image, $map, 68, 36, 78, 66, $ink );

		// Saddle and handlebar. Without them it is two circles and a triangle.
		self::stroke( $image, $map, 33, 33, 47, 33, $ink );
		self::stroke( $image, $map, 62, 30, 76, 30, $ink );
		self::stroke( $image, $map, 68, 36, 70, 30, $ink );
	}

	/** @param resource|GdImage $image Tile. @param array $map Placement. @param int $ink Ink. */
	private static function draw_lights( $image, array $map, $ink ) {
		self::box( $image, $map, 45, 74, 55, 96, $ink );
		self::box( $image, $map, 32, 6, 68, 78, $ink );

		/*
		 * Red, amber, green, always in that order and always those colours.
		 * The ink around them is jittered but these are not: a traffic light
		 * with the lamps in the wrong order is a picture of something else.
		 */
		$lamps = array(
			array( 22, imagecolorallocate( $image, 214, 62, 54 ) ),
			array( 42, imagecolorallocate( $image, 234, 176, 46 ) ),
			array( 62, imagecolorallocate( $image, 68, 168, 90 ) ),
		);

		foreach ( $lamps as $lamp ) {
			self::disc( $image, $map, 50, $lamp[0], 22, $lamp[1] );
		}
	}

	/** @param resource|GdImage $image Tile. @param array $map Placement. @param int $ink Ink. */
	private static function draw_stairs( $image, array $map, $ink ) {
		self::poly( $image, $map, array( 8, 92, 8, 74, 34, 74, 34, 54, 60, 54, 60, 34, 86, 34, 86, 92 ), $ink );
	}

	/** @param resource|GdImage $image Tile. @param array $map Placement. @param int $ink Ink. */
	private static function draw_tree( $image, array $map, $ink ) {
		self::box( $image, $map, 44, 62, 56, 94, $ink );

		// Two stacked triangles: a pine is far harder to mistake for the
		// umbrella than a lollipop-shaped one is.
		self::poly( $image, $map, array( 50, 6, 82, 48, 18, 48 ), $ink );
		self::poly( $image, $map, array( 50, 28, 90, 72, 10, 72 ), $ink );
	}

	/** @param resource|GdImage $image Tile. @param array $map Placement. @param int $ink Ink. @param int $tint Ground. */
	private static function draw_house( $image, array $map, $ink, $tint ) {
		self::poly( $image, $map, array( 50, 8, 94, 46, 6, 46 ), $ink );
		self::box( $image, $map, 16, 46, 84, 92, $ink );

		self::box( $image, $map, 42, 66, 58, 92, $tint );
		self::box( $image, $map, 24, 56, 36, 68, $tint );
		self::box( $image, $map, 64, 56, 76, 68, $tint );
	}

	/** @param resource|GdImage $image Tile. @param array $map Placement. @param int $ink Ink. */
	private static function draw_boat( $image, array $map, $ink ) {
		self::poly( $image, $map, array( 8, 68, 92, 68, 76, 90, 24, 90 ), $ink );

		self::box( $image, $map, 47, 16, 53, 68, $ink );
		self::poly( $image, $map, array( 56, 22, 86, 64, 56, 64 ), $ink );
	}

	/** @param resource|GdImage $image Tile. @param array $map Placement. @param int $ink Ink. */
	private static function draw_brolly( $image, array $map, $ink ) {
		list( $cx, $cy ) = self::at( $map, 50, 52 );

		$span = max( 4, (int) round( 84 * $map['scale'] ) );

		imagefilledarc( $image, $cx, $cy, $span, $span, 180, 360, $ink, IMG_ARC_PIE );

		self::box( $image, $map, 47, 52, 53, 82, $ink );

		// The hook. A straight stick under a dome is a mushroom.
		list( $hx, $hy ) = self::at( $map, 39, 82 );

		$hook = max( 4, (int) round( 22 * $map['scale'] ) );

		imagearc( $image, $hx, $hy, $hook, $hook, 0, 180, $ink );
	}

	/**
	 * Fisher–Yates, using the same source of randomness as everything else.
	 *
	 * shuffle() draws on mt_rand, which is seeded predictably enough that a run
	 * of observed grids narrows down where the right tiles will be next time.
	 * The positions are half the answer, so they get the good generator too.
	 *
	 * @param array $items Shuffled in place.
	 */
	private static function shuffle( array &$items ) {
		for ( $i = count( $items ) - 1; $i > 0; $i-- ) {
			$j = self::pick( 0, $i );

			$swap         = $items[ $i ];
			$items[ $i ]  = $items[ $j ];
			$items[ $j ]  = $swap;
		}
	}

	/* ------------------------------------------------------------------ *
	 * Verifying
	 * ------------------------------------------------------------------ */

	/**
	 * @param string $form Form key, unused here but kept for symmetry.
	 * @return true|WP_Error
	 */
	public static function verify( $form = 'form' ) {
		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$id        = isset( $_POST['wpdrc_id'] ) ? sanitize_text_field( wp_unslash( $_POST['wpdrc_id'] ) ) : '';
		$expires   = isset( $_POST['wpdrc_exp'] ) ? (int) wp_unslash( $_POST['wpdrc_exp'] ) : 0;
		$signature = isset( $_POST['wpdrc_sig'] ) ? sanitize_text_field( wp_unslash( $_POST['wpdrc_sig'] ) ) : '';
		$kind      = isset( $_POST['wpdrc_kind'] ) ? sanitize_key( wp_unslash( $_POST['wpdrc_kind'] ) ) : '';
		$answer    = isset( $_POST['wpdrc_answer'] ) ? sanitize_text_field( wp_unslash( $_POST['wpdrc_answer'] ) ) : '';
		// phpcs:enable

		if ( '' === $id || '' === $signature || ! self::handles( $kind ) ) {
			return new WP_Error( 'wpdrc_missing', WPDRC_Service::message( 'missing' ) );
		}

		if ( '' === trim( $answer ) ) {
			return new WP_Error( 'wpdrc_missing', WPDRC_Service::message( 'missing' ) );
		}

		if ( $expires < time() ) {
			WPDRC_Log::record( 'expired', 'A challenge was answered after it expired' );

			return new WP_Error( 'wpdrc_expired', __( 'That check expired. Here is a new one — please try again.', 'wpd-recaptcha' ) );
		}

		// A challenge is answerable once. Without this, one solved sum could be
		// replayed a thousand times, which is exactly what spam software does
		// the moment it finds a form that lets it.
		if ( self::already_used( $id ) ) {
			WPDRC_Log::record( 'replay', 'A challenge answer was submitted twice' );

			return new WP_Error( 'wpdrc_replay', __( 'That check has already been used. Here is a new one — please try again.', 'wpd-recaptcha' ) );
		}

		if ( self::PUZZLE === $kind ) {
			/*
			 * The slider is checked differently because a near miss has to
			 * pass. The signature proves the target was not tampered with;
			 * the comparison then allows a few pixels either side, because
			 * demanding a pixel-exact drag would fail almost everybody using
			 * a finger.
			 */
			// phpcs:ignore WordPress.Security.NonceVerification.Missing
			$target = isset( $_POST['wpdrc_target'] ) ? (int) wp_unslash( $_POST['wpdrc_target'] ) : -1;

			if ( ! hash_equals( self::sign( (string) $target, $id, $expires, $kind ), $signature ) ) {
				WPDRC_Log::record( 'failed', 'A slider target did not match its signature' );

				return new WP_Error( 'wpdrc_failed', WPDRC_Service::message( 'failed' ) );
			}

			if ( abs( (int) $answer - $target ) > self::PUZZLE_TOLERANCE ) {
				WPDRC_Log::record( 'failed', 'The slider was not close enough' );

				return new WP_Error( 'wpdrc_failed', WPDRC_Service::message( 'failed' ) );
			}

			self::mark_used( $id, $expires );

			return true;
		}

		$offered = self::normalise( $answer, $kind );

		if ( ! hash_equals( self::sign( $offered, $id, $expires, $kind ), $signature ) ) {
			WPDRC_Log::record( 'failed', sprintf( 'Wrong answer to a %s challenge', $kind ) );

			return new WP_Error( 'wpdrc_failed', WPDRC_Service::message( 'failed' ) );
		}

		self::mark_used( $id, $expires );

		return true;
	}

	/**
	 * Put an answer into the one form the signature was made from.
	 *
	 * @param string $answer What was typed.
	 * @param string $kind   Challenge kind.
	 * @return string
	 */
	public static function normalise( $answer, $kind ) {
		$answer = trim( (string) $answer );

		if ( self::PUZZLE === $kind ) {
			// The slider never reaches here — it is compared numerically
			// against a signed target instead, so a near miss can pass.
			return (string) (int) $answer;
		}

		if ( self::SELECT === $kind ) {
			/*
			 * A set, not a list. Somebody who picks tiles 7, 2 and 4 has given
			 * the same answer as somebody who picks 2, 4 and 7, and grading on
			 * the order they happened to click in would fail most of them.
			 *
			 * Deduplicated too: a double-click that toggles a tile on twice is
			 * one selection, not two.
			 */
			$picked = array();

			foreach ( preg_split( '/[^0-9]+/', $answer ) as $one ) {
				if ( '' === $one ) {
					continue;
				}

				$index = (int) $one;

				// Anything outside the grid is dropped rather than signed, so
				// a crafted "0,1,2,...,99" cannot be made to match by accident.
				if ( $index >= 0 && $index < self::SELECT_TILES ) {
					$picked[ $index ] = true;
				}
			}

			$picked = array_keys( $picked );

			sort( $picked, SORT_NUMERIC );

			return implode( ',', $picked );
		}

		if ( self::LETTERS === $kind ) {
			// Case is not the point of the test, and insisting on it fails
			// people on a phone keyboard that capitalised the first letter.
			return strtoupper( $answer );
		}

		if ( self::MATH === $kind ) {
			// "7", " 7 " and "seven" are the same answer to a person.
			$words = array( 'zero' => 0, 'one' => 1, 'two' => 2, 'three' => 3, 'four' => 4, 'five' => 5, 'six' => 6, 'seven' => 7, 'eight' => 8, 'nine' => 9, 'ten' => 10, 'eleven' => 11, 'twelve' => 12, 'thirteen' => 13, 'fourteen' => 14, 'fifteen' => 15, 'sixteen' => 16, 'seventeen' => 17, 'eighteen' => 18, 'twenty' => 20, 'twentyfive' => 25 );

			$lower = strtolower( str_replace( array( ' ', '-' ), '', $answer ) );

			if ( isset( $words[ $lower ] ) ) {
				return (string) $words[ $lower ];
			}

			return (string) (int) $answer;
		}

		// A question's answer is compared loosely: lower case, collapsed
		// whitespace, no trailing punctuation. Somebody who knows the answer
		// should not fail on a full stop.
		$answer = strtolower( $answer );
		$answer = preg_replace( '/\s+/u', ' ', $answer );

		return trim( (string) $answer, " .,!?'\"" );
	}

	/**
	 * @param string $answer  The normalised answer.
	 * @param string $id      Challenge id.
	 * @param int    $expires Expiry.
	 * @param string $kind    Kind.
	 * @return string
	 */
	private static function sign( $answer, $id, $expires, $kind ) {
		return hash_hmac( 'sha256', $answer . '|' . $id . '|' . (int) $expires . '|' . $kind, self::secret() );
	}

	/**
	 * The site's signing secret, made once.
	 *
	 * @return string
	 */
	public static function secret() {
		$secret = (string) WPDRC_Options::get( 'local_secret', '' );

		if ( '' === $secret ) {
			$secret = bin2hex( self::random( 32 ) );

			WPDRC_Options::update( array( 'local_secret' => $secret ) );
		}

		return $secret;
	}

	/**
	 * @param string $id Challenge id.
	 * @return bool
	 */
	private static function already_used( $id ) {
		return (bool) get_transient( 'wpdrc_used_' . $id );
	}

	/**
	 * @param string $id      Challenge id.
	 * @param int    $expires When the challenge would have expired anyway.
	 */
	private static function mark_used( $id, $expires ) {
		// Remembered only for as long as the challenge could still be replayed.
		$ttl = max( 60, $expires - time() );

		set_transient( 'wpdrc_used_' . $id, 1, $ttl );
	}

	/* ------------------------------------------------------------------ *
	 * Randomness
	 * ------------------------------------------------------------------ */

	/**
	 * @param int $bytes How many.
	 * @return string
	 */
	private static function random( $bytes ) {
		if ( function_exists( 'random_bytes' ) ) {
			try {
				return random_bytes( $bytes );
			} catch ( Exception $e ) {
				// Fall through.
			}
		}

		return wp_generate_password( $bytes * 2, false );
	}

	/**
	 * A random integer, from a source worth using.
	 *
	 * rand() is predictable enough that a few observed challenges give away the
	 * sequence — which for a captcha means the next answer is knowable before
	 * it is asked.
	 *
	 * @param int $min Low.
	 * @param int $max High.
	 * @return int
	 */
	private static function pick( $min, $max ) {
		if ( $min >= $max ) {
			return $min;
		}

		if ( function_exists( 'random_int' ) ) {
			try {
				return random_int( $min, $max );
			} catch ( Exception $e ) {
				// Fall through.
			}
		}

		return wp_rand( $min, $max );
	}
}

<?php
/**
 * Settings, and the small log that explains refusals.
 *
 * @package WPD_ReCaptcha
 */

defined( 'ABSPATH' ) || exit;

class WPDRC_Options {

	const OPTION = 'wpdrc_settings';

	/** @var array|null */
	private static $cache = null;

	/**
	 * Which forms can be protected, and what each is called on screen.
	 *
	 * The key doubles as the setting name (form_{key}) and the v3 action, so
	 * adding one here is most of the work of supporting it.
	 *
	 * @return array<string,array{label:string,group:string,note:string}>
	 */
	public static function forms() {
		return array(
			'login'        => array(
				'label' => __( 'Log in', 'wpd-recaptcha' ),
				'group' => __( 'WordPress', 'wpd-recaptcha' ),
				'note'  => __( 'The one worth protecting first. Set the keys and test in a private window before you rely on it — and keep the escape hatch below in mind.', 'wpd-recaptcha' ),
			),
			'register'     => array(
				'label' => __( 'Register', 'wpd-recaptcha' ),
				'group' => __( 'WordPress', 'wpd-recaptcha' ),
				'note'  => __( 'Only appears if registration is open.', 'wpd-recaptcha' ),
			),
			'lostpassword' => array(
				'label' => __( 'Lost password', 'wpd-recaptcha' ),
				'group' => __( 'WordPress', 'wpd-recaptcha' ),
				'note'  => __( 'Stops the reset form being used to enumerate accounts and to send mail on your behalf.', 'wpd-recaptcha' ),
			),
			'comment'      => array(
				'label' => __( 'Comments', 'wpd-recaptcha' ),
				'group' => __( 'WordPress', 'wpd-recaptcha' ),
				'note'  => '',
			),
			'cf7'          => array(
				'label' => __( 'Contact Form 7', 'wpd-recaptcha' ),
				'group' => __( 'Form plugins', 'wpd-recaptcha' ),
				'note'  => __( 'Applies to every CF7 form on the site. No tag to add — the widget is placed automatically before the submit button.', 'wpd-recaptcha' ),
			),
			'wpforms'      => array(
				'label' => __( 'WPForms', 'wpd-recaptcha' ),
				'group' => __( 'Form plugins', 'wpd-recaptcha' ),
				'note'  => '',
			),
			'fluentform'   => array(
				'label' => __( 'Fluent Forms', 'wpd-recaptcha' ),
				'group' => __( 'Form plugins', 'wpd-recaptcha' ),
				'note'  => '',
			),
			'elementor'    => array(
				'label' => __( 'Elementor Pro forms', 'wpd-recaptcha' ),
				'group' => __( 'Form plugins', 'wpd-recaptcha' ),
				'note'  => '',
			),
			'woo_login'    => array(
				'label' => __( 'WooCommerce login &amp; registration', 'wpd-recaptcha' ),
				'group' => __( 'WooCommerce', 'wpd-recaptcha' ),
				'note'  => '',
			),
			'woo_checkout' => array(
				'label' => __( 'WooCommerce checkout', 'wpd-recaptcha' ),
				'group' => __( 'WooCommerce', 'wpd-recaptcha' ),
				'note'  => __( 'Think hard about this one. A captcha between a customer and paying you is the most expensive place on the site to put an obstacle. v3 is the only sensible choice here.', 'wpd-recaptcha' ),
			),
			'custom'       => array(
				'label' => __( 'Custom forms (shortcode)', 'wpd-recaptcha' ),
				'group' => __( 'Anything else', 'wpd-recaptcha' ),
				'note'  => __( 'Paste [recaptcha] inside your form. Any submission carrying it is checked before your handler runs — AJAX or ordinary POST, no code changes.', 'wpd-recaptcha' ),
			),
		);
	}

	/**
	 * @return array
	 */
	public static function defaults() {
		$defaults = array(
			'_schema'         => 1,

			'type'            => WPDRC_Service::V2_CHECKBOX,

			'v2_site_key'     => '',
			'v2_secret_key'   => '',
			'v3_site_key'     => '',
			'v3_secret_key'   => '',

			'score_threshold' => 0.5,

			'theme'           => 'light',
			'size'            => 'normal',
			'badge'           => 'bottomright',
			'language'        => '',

			// Signing key for locally generated challenges. Made on first use.
			'local_secret'    => '',

			// One question per line, as: question | answer
			'questions'       => '',

			/*
			 * Off, so the check applies to everybody.
			 *
			 * This used to default on, and the reasoning was sound in itself —
			 * an editor is not the traffic this defends against, and handing
			 * one a puzzle to comment on their own site is irritating. What it
			 * missed is who looks at a form first.
			 *
			 * The person setting this up is signed in. With the skip on by
			 * default they tick a form, load the page, see no captcha, and have
			 * every reason to conclude the plugin is broken — the one case
			 * where it renders nothing at all is the case they are guaranteed
			 * to hit. A default whose first effect is to look like a bug is the
			 * wrong default however good the argument behind it.
			 *
			 * The setting is still there, and still worth ticking on a site
			 * with real logged-in members. It just is not what a fresh install
			 * does.
			 */
			'skip_logged_in'  => 0,

			/*
			 * Off, and this is the most consequential default here.
			 *
			 * On means a submission is refused when Google cannot be reached —
			 * a timeout, a blocked outbound request, a slow afternoon. On the
			 * login form that is a lockout from your own site caused by
			 * somebody else's server. Being unable to ask is not the same as
			 * being told no.
			 */
			'fail_closed'     => 0,

			// Off. A spam wave would otherwise fill the log with a thousand
			// identical rows and bury the one refusal somebody rang up about.
			'logging'         => 0,

			'message_missing'     => '',
			'message_failed'      => '',
			'message_low_score'   => '',
			'message_unreachable' => '',
		);

		foreach ( array_keys( self::forms() ) as $key ) {
			// Nothing is protected until somebody says so. Switching a captcha
			// on to every form the moment the plugin is activated is a good way
			// to break a checkout without noticing.
			$defaults[ 'form_' . $key ] = 0;
		}

		return apply_filters( 'wpdrc_default_settings', $defaults );
	}

	/**
	 * @return array
	 */
	public static function all() {
		if ( null === self::$cache ) {
			$saved       = get_option( self::OPTION, array() );
			self::$cache = wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
		}

		return self::$cache;
	}

	/**
	 * @param string $key     Key.
	 * @param mixed  $default Fallback.
	 * @return mixed
	 */
	public static function get( $key, $default = null ) {
		$all = self::all();

		return array_key_exists( $key, $all ) ? $all[ $key ] : $default;
	}

	/**
	 * @param string $key Key.
	 * @return bool
	 */
	public static function enabled( $key ) {
		return (bool) self::get( $key, false );
	}

	/**
	 * Is a given form switched on?
	 *
	 * @param string $form Form key.
	 * @return bool
	 */
	public static function protects( $form ) {
		/**
		 * @param bool   $on   Whether this form is protected.
		 * @param string $form Form key.
		 */
		return (bool) apply_filters( 'wpdrc_protects', self::enabled( 'form_' . $form ), $form );
	}

	/**
	 * @param array $values Values.
	 */
	public static function update( array $values ) {
		update_option( self::OPTION, wp_parse_args( $values, self::all() ), false );

		self::$cache = null;
	}

	public static function install_defaults() {
		if ( false === get_option( self::OPTION, false ) ) {
			add_option( self::OPTION, self::defaults(), '', false );
		}
	}
}

/**
 * Why submissions were refused.
 *
 * Small and deliberately so. The question this answers is the one that comes
 * in by email: "a customer says they cannot submit the form." Without it the
 * only available answer is a shrug, because a refusal leaves no trace anywhere
 * — the visitor sees a message and goes away.
 */
class WPDRC_Log {

	const OPTION = 'wpdrc_log';

	const MAX = 100;

	/**
	 * @param string $type    missing|failed|low_score|unreachable|bad_secret.
	 * @param string $message What happened.
	 */
	public static function record( $type, $message ) {
		if ( ! WPDRC_Options::enabled( 'logging' ) && 'unreachable' !== $type && 'bad_secret' !== $type ) {
			// Configuration problems are always recorded. Ordinary refusals are
			// opt-in, because a spam wave would otherwise fill the row.
			return;
		}

		$entries = self::all();

		array_unshift(
			$entries,
			array(
				'time'    => time(),
				'type'    => (string) $type,
				'message' => (string) $message,
				// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
				'uri'     => isset( $_SERVER['REQUEST_URI'] ) ? substr( (string) wp_unslash( $_SERVER['REQUEST_URI'] ), 0, 200 ) : '',
			)
		);

		update_option( self::OPTION, array_slice( $entries, 0, self::MAX ), false );
	}

	/**
	 * @return array[]
	 */
	public static function all() {
		$stored = get_option( self::OPTION, array() );

		return is_array( $stored ) ? $stored : array();
	}

	public static function clear() {
		delete_option( self::OPTION );
	}
}

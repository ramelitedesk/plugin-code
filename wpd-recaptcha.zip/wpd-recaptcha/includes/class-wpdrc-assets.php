<?php
/**
 * Loading Google's script, and only where it is wanted.
 *
 * reCAPTCHA is not a small script. Loading it on every page of a site to
 * protect one contact form costs every visitor a third-party request they did
 * not need, and on v3 it also means Google is watching pages that have no form
 * on them at all.
 *
 * So nothing is enqueued until something asks for it. Every widget rendered
 * calls needed(), and the enqueue happens at wp_footer — by which point the
 * page has been built and the answer is known.
 *
 * The login screen is the exception: it has no wp_footer worth speaking of and
 * its form is printed before anything else, so it enqueues directly.
 *
 * @package WPD_ReCaptcha
 */

defined( 'ABSPATH' ) || exit;

class WPDRC_Assets {

	/** @var WPDRC_Assets|null */
	private static $instance = null;

	/** @var bool Has anything on this page asked for the script? */
	private $wanted = false;

	/** @var bool Has it already gone out? */
	private $printed = false;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_footer', array( $this, 'print_assets' ), 5 );
		add_action( 'login_footer', array( $this, 'print_assets' ), 5 );
		add_action( 'wp_enqueue_scripts', array( $this, 'styles' ) );
		add_action( 'login_enqueue_scripts', array( $this, 'styles' ) );
	}

	/**
	 * A widget has been rendered; the script will be needed.
	 */
	public function needed() {
		$this->wanted = true;
	}

	/**
	 * @return bool
	 */
	public function is_wanted() {
		return $this->wanted;
	}

	public function styles() {
		wp_register_style( 'wpdrc', WPDRC_URL . 'assets/recaptcha.css', array(), WPDRC_VERSION );
		wp_enqueue_style( 'wpdrc' );
	}

	/**
	 * Print the scripts, once, at the foot of a page that has a widget on it.
	 */
	public function print_assets() {
		if ( $this->printed || ! $this->wanted || ! WPDRC_Service::active() ) {
			return;
		}

		$this->printed = true;

		$type  = WPDRC_Service::type();
		$local = WPDRC_Service::is_local();

		$settings = array(
			'type'    => $local ? 'local' : ( WPDRC_Service::V3 === $type ? 'v3' : 'v2' ),
			'siteKey' => $local ? '' : WPDRC_Service::site_key(),
			'badge'   => (string) WPDRC_Options::get( 'badge', 'bottomright' ),
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'i18n'    => array(
				'jsFailed'    => __( 'The reCAPTCHA challenge could not be shown. Your submission will still be checked.', 'wpd-recaptcha' ),
				'loading'     => __( 'Loading the check…', 'wpd-recaptcha' ),
				'loadFailed'  => __( 'The spam check could not be loaded. Please reload the page.', 'wpd-recaptcha' ),
				'imageAlt'    => __( 'A spam check showing letters and numbers. Use the button below if you cannot read it.', 'wpd-recaptcha' ),
				'needAnother' => __( 'I cannot read this — give me a question instead', 'wpd-recaptcha' ),
				/* translators: %d: the tile's position in the grid, 1 to 9. */
				'tile'        => __( 'Picture %d', 'wpd-recaptcha' ),
				'tileHint'    => __( 'Pick every one that matches, then submit the form.', 'wpd-recaptcha' ),
			),
		);

		printf(
			'<script id="wpdrc-settings">window.wpdrcSettings = %s;</script>' . "\n",
			wp_json_encode( $settings )
		);

		if ( $local ) {
			/*
			 * A locally generated challenge needs no third party at all. That
			 * is the whole reason somebody chooses one, so nothing is loaded
			 * from google.com — not the script, not the badge, not a single
			 * request.
			 */
			printf(
				'<script id="wpdrc-runtime">%s</script>' . "\n",
				// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- a static file this plugin ships.
				$this->file( 'assets/local.js' )
			);

			return;
		}

		printf(
			'<script id="wpdrc-runtime">%s</script>' . "\n",
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- a static file this plugin ships.
			$this->file( 'assets/recaptcha.js' )
		);

		/*
		 * Loaded last, and asynchronously.
		 *
		 * The runtime above defines window.wpdrcOnload before Google's script
		 * can call it. Doing it the other way round is a race that only shows
		 * up on fast connections — which is to say, never on the machine of the
		 * person who wrote it.
		 */
		printf(
			'<script src="%s" async defer></script>' . "\n",
			esc_url( $this->api_url( $type ) )
		);
	}

	/**
	 * @param string $type Widget type.
	 * @return string
	 */
	private function api_url( $type ) {
		$base = 'https://www.google.com/recaptcha/api.js';

		/**
		 * Swap in recaptcha.net, which is reachable from places google.com is
		 * not.
		 *
		 * @param string $base API base URL.
		 */
		$base = (string) apply_filters( 'wpdrc_api_url', $base );

		$args = array( 'onload' => 'wpdrcOnload' );

		if ( WPDRC_Service::V3 === $type ) {
			$args['render'] = WPDRC_Service::site_key();
		} else {
			$args['render'] = 'explicit';
		}

		$language = (string) WPDRC_Options::get( 'language', '' );

		if ( '' !== $language ) {
			$args['hl'] = $language;
		}

		return add_query_arg( $args, $base );
	}

	/**
	 * @param string $relative Path inside the plugin.
	 * @return string Its contents.
	 */
	private function file( $relative ) {
		$path = WPDRC_DIR . $relative;

		if ( ! is_readable( $path ) ) {
			return '';
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		return (string) file_get_contents( $path );
	}
}

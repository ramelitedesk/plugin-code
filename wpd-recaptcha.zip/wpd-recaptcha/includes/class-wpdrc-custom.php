<?php
/**
 * Custom forms: the shortcode, and making it actually verify.
 *
 * This is the part of the plugin that has to work without knowing anything
 * about the form it is protecting. Somebody has hand-written a form and a
 * handler; they paste [recaptcha] into the markup; the widget must appear and
 * a failed check must stop the submission. No hooks to learn, no callback to
 * register.
 *
 * The showing half is easy. The stopping half is the whole problem, because
 * their handler is their code and this has no idea where it lives.
 *
 * The approach: the shortcode plants a marker field naming the form. Very early
 * in the request — before their handler has run — anything POSTing that marker
 * is verified. Fail, and the request stops there.
 *
 * Two things make that safe rather than clever:
 *
 *   1. It only ever acts on requests carrying the marker. A POST that has
 *      nothing to do with this plugin is untouched, so there is no way for it
 *      to break a form it was never added to.
 *   2. It refuses in the shape the caller asked for. Killing an AJAX request
 *      with an HTML error page produces "unexpected token < in JSON" in the
 *      console and a form that hangs forever — which is worse than no captcha,
 *      because nobody can tell what went wrong.
 *
 * @package WPD_ReCaptcha
 */

defined( 'ABSPATH' ) || exit;

class WPDRC_Custom {

	/** @var WPDRC_Custom|null */
	private static $instance = null;

	/** The field naming which form a submission came from. */
	const MARKER = 'wpdrc_form';

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'recaptcha', array( $this, 'shortcode' ) );

		/*
		 * Priority 1 on init.
		 *
		 * Custom handlers hook init, wp_loaded, template_redirect, admin_post_*
		 * or wp_ajax_* — all of which run after this. Going earlier than init
		 * is not an option: the current user is not resolved before it, so the
		 * "skip this for logged-in editors" setting could not be honoured and
		 * every logged-in admin would be handed a captcha.
		 */
		add_action( 'init', array( $this, 'maybe_verify_request' ), 1 );
	}

	/**
	 * [recaptcha] — or [recaptcha form="newsletter" theme="dark"].
	 *
	 * @param array $atts Attributes.
	 * @return string
	 */
	public function shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'form'  => 'custom',
				'theme' => (string) WPDRC_Options::get( 'theme', 'light' ),
				'size'  => (string) WPDRC_Options::get( 'size', 'normal' ),
			),
			(array) $atts,
			'recaptcha'
		);

		if ( ! WPDRC_Options::enabled( 'form_custom' ) ) {
			return '';
		}

		return WPDRC_Service::field( $atts );
	}

	/* ------------------------------------------------------------------ *
	 * Verification
	 * ------------------------------------------------------------------ */

	/**
	 * Verify any POST that carries our marker.
	 */
	public function maybe_verify_request() {
		if ( ! $this->should_check() ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$form = sanitize_text_field( wp_unslash( $_POST[ self::MARKER ] ) );

		/**
		 * Take one form back out of automatic verification, to check it
		 * yourself with wpdrc_verify() at the point that suits the handler.
		 *
		 * @param bool   $auto Whether to verify here.
		 * @param string $form The form key from the marker field.
		 */
		if ( ! apply_filters( 'wpdrc_auto_verify', true, $form ) ) {
			return;
		}

		$result = WPDRC_Service::verify( $form );

		if ( ! is_wp_error( $result ) ) {
			return;
		}

		/**
		 * Handle the refusal yourself — to re-render the form with the values
		 * still in it, say, rather than ending the request.
		 *
		 * @param bool     $handled Return true to take over.
		 * @param WP_Error $result  Why it failed.
		 * @param string   $form    Form key.
		 */
		if ( apply_filters( 'wpdrc_handle_failure', false, $result, $form ) ) {
			return;
		}

		$this->refuse( $result, $form );
	}

	/**
	 * @return bool Whether this request is one to check.
	 */
	private function should_check() {
		if ( 'POST' !== $this->method() ) {
			return false;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( empty( $_POST[ self::MARKER ] ) ) {
			return false;
		}

		if ( ! WPDRC_Options::enabled( 'form_custom' ) ) {
			return false;
		}

		if ( ! WPDRC_Service::active() || WPDRC_Service::exempt() ) {
			return false;
		}

		/*
		 * Never in wp-admin. The marker could reach an admin screen through a
		 * shortcode preview or a page builder saving its own content, and
		 * refusing a page save because a captcha token was stale would be a
		 * baffling way to lose somebody's work.
		 */
		if ( is_admin() && ! wp_doing_ajax() ) {
			return false;
		}

		return true;
	}

	/**
	 * Stop the request, in whatever shape the caller can read.
	 *
	 * @param WP_Error $error Why.
	 * @param string   $form  Form key.
	 */
	private function refuse( WP_Error $error, $form ) {
		/**
		 * @param WP_Error $error The refusal.
		 * @param string   $form  Form key.
		 */
		do_action( 'wpdrc_submission_blocked', $error, $form );

		if ( $this->wants_json() ) {
			/*
			 * Several shapes of JSON are in circulation and a custom handler
			 * could be reading any of them, so this answers in all three at
			 * once: WordPress's {success,data}, a bare {error}, and a plain
			 * {message}. Costs a few bytes; saves the person debugging it from
			 * a form that fails silently because their code looked for a key
			 * that was not there.
			 */
			status_header( 403 );
			nocache_headers();

			wp_send_json(
				array(
					'success' => false,
					'error'   => $error->get_error_message(),
					'message' => $error->get_error_message(),
					'code'    => $error->get_error_code(),
					'data'    => array( 'message' => $error->get_error_message() ),
				),
				403
			);
		}

		wp_die(
			esc_html( $error->get_error_message() ),
			esc_html__( 'Submission not accepted', 'wpd-recaptcha' ),
			array(
				'response'  => 403,
				'back_link' => true,
			)
		);
	}

	/**
	 * Is the caller expecting JSON back?
	 *
	 * Asked several ways because a hand-written fetch() often sets none of the
	 * headers a library would. Getting this wrong turns a clear error message
	 * into a console parse error and a spinner that never stops.
	 *
	 * @return bool
	 */
	private function wants_json() {
		if ( wp_doing_ajax() ) {
			return true;
		}

		if ( function_exists( 'wp_is_json_request' ) && wp_is_json_request() ) {
			return true;
		}

		// phpcs:disable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$requested = isset( $_SERVER['HTTP_X_REQUESTED_WITH'] ) ? strtolower( (string) wp_unslash( $_SERVER['HTTP_X_REQUESTED_WITH'] ) ) : '';
		$accept    = isset( $_SERVER['HTTP_ACCEPT'] ) ? strtolower( (string) wp_unslash( $_SERVER['HTTP_ACCEPT'] ) ) : '';
		$type      = isset( $_SERVER['CONTENT_TYPE'] ) ? strtolower( (string) wp_unslash( $_SERVER['CONTENT_TYPE'] ) ) : '';
		// phpcs:enable

		if ( 'xmlhttprequest' === $requested ) {
			return true;
		}

		if ( false !== strpos( $type, 'application/json' ) ) {
			return true;
		}

		/*
		 * Accept is the weakest signal of the four: browsers send a long list
		 * on ordinary navigations. It only counts when JSON is asked for and
		 * HTML is not, which is what fetch() with an explicit Accept looks like
		 * and what a page navigation never does.
		 */
		if ( false !== strpos( $accept, 'application/json' ) && false === strpos( $accept, 'text/html' ) ) {
			return true;
		}

		// The form said so itself.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		return ! empty( $_POST['wpdrc_ajax'] );
	}

	/**
	 * @return string
	 */
	private function method() {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		return isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( (string) wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : 'GET';
	}
}

if ( ! function_exists( 'wpdrc_field' ) ) {
	/**
	 * Print the widget from a template, where a shortcode would be awkward.
	 *
	 * @param string $form Form key.
	 */
	function wpdrc_field( $form = 'custom' ) {
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built and escaped in WPDRC_Service::field().
		echo WPDRC_Service::field( array( 'form' => $form ) );
	}
}

if ( ! function_exists( 'wpdrc_verify' ) ) {
	/**
	 * Check a submission by hand.
	 *
	 * For handlers that would rather decide what to do about a failure than
	 * have the request ended for them — re-rendering the form with the values
	 * still in it, for instance. Pair it with:
	 *
	 *     add_filter( 'wpdrc_auto_verify', '__return_false' );
	 *
	 * or the request will already have been stopped before this is reached.
	 *
	 * @param string $form Form key.
	 * @return true|WP_Error
	 */
	function wpdrc_verify( $form = 'custom' ) {
		return WPDRC_Service::verify( $form );
	}
}

if ( ! function_exists( 'wpdrc_passed' ) ) {
	/**
	 * The same thing as a plain boolean.
	 *
	 * @param string $form Form key.
	 * @return bool
	 */
	function wpdrc_passed( $form = 'custom' ) {
		return ! is_wp_error( wpdrc_verify( $form ) );
	}
}

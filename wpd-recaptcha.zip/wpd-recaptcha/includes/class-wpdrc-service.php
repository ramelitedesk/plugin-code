<?php
/**
 * Rendering a widget, and deciding whether a submission passed.
 *
 * Everything else in this plugin is an adapter that calls into here. There is
 * exactly one place that talks to Google and exactly one place that decides
 * pass or fail, because a captcha with two verification paths eventually has
 * one of them that does not check the score.
 *
 * THE DECISION THAT MATTERS MOST is what happens when Google cannot be reached.
 *
 * A captcha that fails closed on a network error is a captcha that locks you
 * out of your own login form when Google is slow, when the host blocks outbound
 * requests, or when a firewall rule changes on a Sunday. A captcha that fails
 * open lets spam through for the length of the outage. Neither is free.
 *
 * The answer here: a *verification failure* always blocks — that is a real
 * answer from Google saying no. A *transport failure* — timeout, DNS, TLS —
 * fails open by default and is logged, because being unable to ask is not the
 * same as being told no, and the cost of getting it wrong is losing the site.
 * Sites that would rather bounce visitors than accept that can turn it round.
 *
 * @package WPD_ReCaptcha
 */

defined( 'ABSPATH' ) || exit;

class WPDRC_Service {

	/** Widget types. */
	const V2_CHECKBOX  = 'v2_checkbox';
	const V2_INVISIBLE = 'v2_invisible';
	const V3           = 'v3';

	const VERIFY_URL = 'https://www.google.com/recaptcha/api/siteverify';

	/** @var array<string,array> Verdicts already reached this request, by token. */
	private static $verified = array();

	/** @var int Widgets rendered so far, so each gets its own id. */
	private static $rendered = 0;

	/* ------------------------------------------------------------------ *
	 * Configuration
	 * ------------------------------------------------------------------ */

	/**
	 * @return string[] Every type this plugin can be set to.
	 */
	public static function types() {
		return array_merge(
			array( self::V2_CHECKBOX, self::V2_INVISIBLE, self::V3 ),
			WPDRC_Local::kinds()
		);
	}

	/**
	 * @return string One of the type constants, or a local kind.
	 */
	public static function type() {
		$type = (string) WPDRC_Options::get( 'type', self::V2_CHECKBOX );

		return in_array( $type, self::types(), true ) ? $type : self::V2_CHECKBOX;
	}

	/**
	 * Is the check done here rather than by Google?
	 *
	 * @return bool
	 */
	public static function is_local() {
		return WPDRC_Local::handles( self::type() );
	}

	/**
	 * @return bool
	 */
	public static function is_v3() {
		return self::V3 === self::type();
	}

	/**
	 * @return string
	 */
	public static function site_key() {
		return trim( (string) WPDRC_Options::get( self::is_v3() ? 'v3_site_key' : 'v2_site_key', '' ) );
	}

	/**
	 * @return string
	 */
	public static function secret_key() {
		return trim( (string) WPDRC_Options::get( self::is_v3() ? 'v3_secret_key' : 'v2_secret_key', '' ) );
	}

	/**
	 * Is there enough here to do anything at all?
	 *
	 * Everything checks this before rendering or verifying. Without it, saving
	 * an empty key would render a broken widget on the login form and then
	 * refuse every login — the exact shape of problem that ends with somebody
	 * renaming the plugin folder over FTP.
	 *
	 * @return bool
	 */
	public static function configured() {
		// A local challenge needs no keys from anybody. That is most of the
		// point of it.
		if ( self::is_local() ) {
			return true;
		}

		return '' !== self::site_key() && '' !== self::secret_key();
	}

	/**
	 * Should this request be checked at all?
	 *
	 * @return bool
	 */
	public static function active() {
		if ( ! self::configured() ) {
			return false;
		}

		// A deliberate escape hatch, for the afternoon when the keys are wrong
		// and the login form is the thing that is broken.
		if ( defined( 'WPDRC_DISABLE' ) && WPDRC_DISABLE ) {
			return false;
		}

		/**
		 * Switch the whole plugin off for this request.
		 *
		 * @param bool $active Whether reCAPTCHA applies.
		 */
		return (bool) apply_filters( 'wpdrc_active', true );
	}

	/**
	 * Users who should never see a captcha.
	 *
	 * Logged-in editors filling in a front-end form are not the traffic this
	 * defends against, and making them solve a puzzle to leave a comment on
	 * their own site is how a plugin gets removed.
	 *
	 * @return bool
	 */
	public static function exempt() {
		if ( WPDRC_Options::enabled( 'skip_logged_in' ) && is_user_logged_in() ) {
			return true;
		}

		/**
		 * @param bool $exempt Whether to skip the captcha for this visitor.
		 */
		return (bool) apply_filters( 'wpdrc_exempt', false );
	}

	/* ------------------------------------------------------------------ *
	 * Rendering
	 * ------------------------------------------------------------------ */

	/**
	 * The markup for one widget.
	 *
	 * Every form gets its own container with its own id. Rendering one widget
	 * and hoping there is only ever one form on the page is how a captcha
	 * breaks the moment somebody puts a newsletter box in the footer.
	 *
	 * @param array $args form (a label for v3 actions), size, theme.
	 * @return string
	 */
	public static function field( array $args = array() ) {
		if ( ! self::active() || self::exempt() ) {
			return '';
		}

		$args = wp_parse_args(
			$args,
			array(
				'form'  => 'form',
				'theme' => (string) WPDRC_Options::get( 'theme', 'light' ),
				'size'  => (string) WPDRC_Options::get( 'size', 'normal' ),
			)
		);

		self::$rendered++;

		$id     = 'wpdrc-' . self::$rendered;
		$action = self::action_for( $args['form'] );

		WPDRC_Assets::instance()->needed();

		if ( self::is_local() ) {
			return WPDRC_Local::field( $args );
		}

		/*
		 * The marker field is what tells the request interceptor that this
		 * submission was meant to carry a token. It is deliberately NOT a
		 * nonce: a nonce goes stale in a page cache, and a captcha that stops
		 * working the moment somebody installs a caching plugin is a captcha
		 * that gets blamed for everything. The reCAPTCHA token is itself the
		 * proof of freshness — that is its entire job.
		 */
		$html = sprintf(
			'<input type="hidden" name="wpdrc_form" value="%s" />',
			esc_attr( $args['form'] )
		);

		if ( self::V3 === self::type() ) {
			// v3 has nothing to show. The token arrives in a hidden field that
			// the script fills in and refreshes.
			return $html . sprintf(
				'<input type="hidden" name="g-recaptcha-response" id="%1$s" class="wpdrc-token" data-action="%2$s" value="" />',
				esc_attr( $id ),
				esc_attr( $action )
			);
		}

		$invisible = self::V2_INVISIBLE === self::type();

		return $html . sprintf(
			'<div class="wpdrc-widget%1$s" id="%2$s" data-sitekey="%3$s" data-theme="%4$s" data-size="%5$s" data-action="%6$s"></div>',
			$invisible ? ' wpdrc-widget--invisible' : '',
			esc_attr( $id ),
			esc_attr( self::site_key() ),
			esc_attr( 'dark' === $args['theme'] ? 'dark' : 'light' ),
			esc_attr( $invisible ? 'invisible' : ( 'compact' === $args['size'] ? 'compact' : 'normal' ) ),
			esc_attr( $action )
		);
	}

	/**
	 * The v3 action name for a form.
	 *
	 * Actions matter more than they look. Google returns the action a token was
	 * minted for, and checking it is what stops a token harvested from a
	 * low-value page — a search box, say — being replayed against the login
	 * form. A plugin that ignores the returned action has a score check that
	 * can be walked around.
	 *
	 * @param string $form Form key.
	 * @return string
	 */
	public static function action_for( $form ) {
		$action = 'wpdrc_' . preg_replace( '/[^a-zA-Z0-9_\/]/', '_', (string) $form );

		return substr( $action, 0, 100 );
	}

	/* ------------------------------------------------------------------ *
	 * Verification
	 * ------------------------------------------------------------------ */

	/**
	 * Did this submission pass?
	 *
	 * @param string $form  Form key, for the v3 action check.
	 * @param string $token Token, or '' to read it from the request.
	 * @return true|WP_Error
	 */
	public static function verify( $form = 'form', $token = '' ) {
		if ( ! self::active() || self::exempt() ) {
			return true;
		}

		// A local challenge is answered in the request, not by a token from a
		// third party. Every integration calls this same method either way, so
		// none of them needs to know which is configured.
		if ( self::is_local() ) {
			return WPDRC_Local::verify( $form );
		}

		if ( '' === $token ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$token = isset( $_POST['g-recaptcha-response'] ) ? sanitize_text_field( wp_unslash( $_POST['g-recaptcha-response'] ) ) : '';
		}

		if ( '' === $token ) {
			return new WP_Error( 'wpdrc_missing', self::message( 'missing' ) );
		}

		$cached = self::$verified[ $token ] ?? null;

		if ( null !== $cached ) {
			/*
			 * A token is single-use at Google: asking twice returns
			 * timeout-or-duplicate and the second answer is a failure. Several
			 * form plugins validate a field more than once per request, so
			 * without this the second call would reject a submission that had
			 * already passed.
			 */
			return $cached;
		}

		$result = self::ask( $token );

		self::$verified[ $token ] = $result;

		return $result;
	}

	/**
	 * One request to Google.
	 *
	 * @param string $token Token.
	 * @return true|WP_Error
	 */
	private static function ask( $token ) {
		$response = wp_remote_post(
			self::VERIFY_URL,
			array(
				'timeout' => (int) apply_filters( 'wpdrc_verify_timeout', 8 ),
				'body'    => array(
					'secret'   => self::secret_key(),
					'response' => $token,
					'remoteip' => self::ip(),
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::transport_failure( $response->get_error_message() );
		}

		$code = (int) wp_remote_retrieve_response_code( $response );

		if ( $code < 200 || $code >= 300 ) {
			return self::transport_failure( sprintf( 'HTTP %d from Google', $code ) );
		}

		$body = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( ! is_array( $body ) ) {
			return self::transport_failure( 'Google returned something that was not JSON' );
		}

		if ( empty( $body['success'] ) ) {
			$codes = isset( $body['error-codes'] ) ? (array) $body['error-codes'] : array();

			/*
			 * Two of Google's error codes mean the site is misconfigured rather
			 * than the visitor being a robot. Blocking a real person because
			 * somebody pasted the v2 secret into the v3 box helps nobody, and
			 * the message they see should say which it was.
			 */
			if ( array_intersect( $codes, array( 'invalid-input-secret', 'missing-input-secret' ) ) ) {
				return self::transport_failure( 'Google rejected the secret key: ' . implode( ', ', $codes ), 'bad_secret' );
			}

			WPDRC_Log::record( 'failed', 'Verification refused: ' . ( $codes ? implode( ', ', $codes ) : 'no reason given' ) );

			return new WP_Error( 'wpdrc_failed', self::message( 'failed' ) );
		}

		return self::check_score( $body );
	}

	/**
	 * v3's score, and the action the token was minted for.
	 *
	 * @param array $body Decoded response.
	 * @return true|WP_Error
	 */
	private static function check_score( array $body ) {
		if ( ! self::is_v3() ) {
			return true;
		}

		$score     = isset( $body['score'] ) ? (float) $body['score'] : 0.0;
		$threshold = (float) WPDRC_Options::get( 'score_threshold', 0.5 );

		/**
		 * @param float $threshold Minimum acceptable score.
		 * @param array $body      Google's response.
		 */
		$threshold = (float) apply_filters( 'wpdrc_score_threshold', $threshold, $body );

		if ( $score < $threshold ) {
			WPDRC_Log::record(
				'low_score',
				sprintf( 'Score %.2f below the %.2f threshold (action: %s)', $score, $threshold, isset( $body['action'] ) ? $body['action'] : '?' )
			);

			return new WP_Error( 'wpdrc_low_score', self::message( 'low_score' ) );
		}

		return true;
	}

	/**
	 * The check could not be completed — as distinct from being failed.
	 *
	 * A wrong secret key belongs here rather than with the refusals, and that
	 * is the point of the distinction. Google is answering, but it is answering
	 * about the site's configuration, not about the visitor. Treating it as a
	 * failed check would turn away every real person on the site because
	 * somebody pasted a v2 secret into the v3 box.
	 *
	 * @param string $why  Reason, for the log.
	 * @param string $type Log type: unreachable|bad_secret.
	 * @return true|WP_Error
	 */
	private static function transport_failure( $why, $type = 'unreachable' ) {
		WPDRC_Log::record( $type, 'Could not verify: ' . $why );

		if ( WPDRC_Options::enabled( 'fail_closed' ) ) {
			return new WP_Error( 'wpdrc_unreachable', self::message( 'unreachable' ) );
		}

		/*
		 * Fails open, and says so in the log rather than silently.
		 *
		 * Being unable to ask is not the same as being told no. The cost of
		 * getting this wrong in the other direction is every login on the site
		 * failing while Google is slow — including the one you would use to
		 * switch the plugin off.
		 */
		return true;
	}

	/**
	 * @param string $key missing|failed|low_score|unreachable.
	 * @return string
	 */
	public static function message( $key ) {
		$messages = array(
			'missing'     => __( 'Please complete the reCAPTCHA before submitting.', 'wpd-recaptcha' ),
			'failed'      => __( 'The reCAPTCHA check did not pass. Please try again.', 'wpd-recaptcha' ),
			'low_score'   => __( 'This submission looks automated and was not accepted. If that is wrong, please get in touch another way.', 'wpd-recaptcha' ),
			'unreachable' => __( 'The reCAPTCHA service could not be reached, so this submission was not accepted. Please try again shortly.', 'wpd-recaptcha' ),
		);

		$custom = (string) WPDRC_Options::get( 'message_' . $key, '' );

		if ( '' !== trim( $custom ) ) {
			return $custom;
		}

		/**
		 * @param string $message The message shown to the visitor.
		 * @param string $key     Which failure this is.
		 */
		return (string) apply_filters( 'wpdrc_message', $messages[ $key ] ?? $messages['failed'], $key );
	}

	/**
	 * The visitor's address, as far as it can be trusted.
	 *
	 * Sent to Google as a hint, never used to make a decision here — a proxy
	 * header is attacker-controlled, and REMOTE_ADDR behind a CDN is the CDN.
	 *
	 * @return string
	 */
	private static function ip() {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) wp_unslash( $_SERVER['REMOTE_ADDR'] ) : '';

		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '';
	}

	/**
	 * Forget this request's verdicts. Tests only.
	 */
	public static function reset() {
		self::$verified = array();
		self::$rendered = 0;
	}
}

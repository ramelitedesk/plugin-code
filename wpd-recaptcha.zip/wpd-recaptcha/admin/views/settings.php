<?php
/**
 * The settings screen.
 *
 * @var array $settings Current settings.
 * @var array $forms    Form definitions.
 *
 * @package WPD_ReCaptcha
 */

defined( 'ABSPATH' ) || exit;

$wpdrc_type   = WPDRC_Service::type();
$wpdrc_result = WPDRC_Admin::take_test_result();

$wpdrc_groups = array();

foreach ( $forms as $wpdrc_key => $wpdrc_form ) {
	$wpdrc_groups[ $wpdrc_form['group'] ][ $wpdrc_key ] = $wpdrc_form;
}
?>
<div class="wrap wpdrc-wrap">
	<h1><?php esc_html_e( 'reCAPTCHA', 'wpd-recaptcha' ); ?></h1>

	<?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
	<?php if ( isset( $_GET['updated'] ) ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Settings saved.', 'wpd-recaptcha' ); ?></p></div>
	<?php endif; ?>

	<?php if ( '' !== $wpdrc_result ) : ?>
		<?php
		$wpdrc_messages = array(
			'ok'           => array( 'success', __( 'The secret key works. Google accepted it and rejected the fake token, which is exactly right.', 'wpd-recaptcha' ) ),
			'bad_secret'   => array( 'error', __( 'Google rejected the secret key. Check you have not pasted the site key into the secret box, or a v2 key into the v3 fields — they are not interchangeable.', 'wpd-recaptcha' ) ),
			'unreachable'  => array( 'error', __( 'Google could not be reached from this server at all. Outbound HTTPS may be blocked. Until that is fixed, leave "refuse when Google cannot be reached" switched off or the forms below will refuse everyone.', 'wpd-recaptcha' ) ),
			'unconfigured' => array( 'warning', __( 'No keys saved yet.', 'wpd-recaptcha' ) ),
			'unknown'      => array( 'warning', __( 'Google answered, but not in a way that confirms the key either way. Try a real submission in a private window.', 'wpd-recaptcha' ) ),
		);

		$wpdrc_shown = $wpdrc_messages[ $wpdrc_result ] ?? $wpdrc_messages['unknown'];
		?>
		<div class="notice notice-<?php echo esc_attr( $wpdrc_shown[0] ); ?>"><p><?php echo esc_html( $wpdrc_shown[1] ); ?></p></div>
	<?php endif; ?>

	<?php if ( ! WPDRC_Service::configured() ) : ?>
		<div class="notice notice-info">
			<p>
				<?php
				printf(
					/* translators: %s: link to the Google admin console. */
					esc_html__( 'Keys come from %s. Register the site, choose the same version you select below, and copy both keys across — the site key goes in the page, the secret key never leaves your server.', 'wpd-recaptcha' ),
					'<a href="https://www.google.com/recaptcha/admin" target="_blank" rel="noopener noreferrer">Google reCAPTCHA admin</a>'
				);
				?>
			</p>
		</div>
	<?php endif; ?>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="wpdrc_save" />
		<?php wp_nonce_field( WPDRC_Admin::NONCE ); ?>

		<div class="wpdrc-panel">
			<h2><?php esc_html_e( 'Which version', 'wpd-recaptcha' ); ?></h2>

			<p class="description">
				<?php esc_html_e( 'One version for the whole site. v2 and v3 use different keys and a different script, and running both on one page makes them refuse each other\'s tokens.', 'wpd-recaptcha' ); ?>
			</p>

			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Type', 'wpd-recaptcha' ); ?></th>
					<td>
						<?php
						$wpdrc_types = array(
							WPDRC_Service::V2_CHECKBOX  => array(
								__( 'v2 — "I\'m not a robot" tick box', 'wpd-recaptcha' ),
								__( 'Visible and familiar. The visitor knows a check happened, and when it refuses somebody they can see why. The safest choice for a form you cannot afford to lose submissions from.', 'wpd-recaptcha' ),
							),
							WPDRC_Service::V2_INVISIBLE => array(
								__( 'v2 — invisible', 'wpd-recaptcha' ),
								__( 'No tick box. The challenge only appears when Google is unsure, so most visitors see nothing but a badge. Runs on submit, which means a slow challenge delays the form by a moment.', 'wpd-recaptcha' ),
							),
							WPDRC_Service::V3           => array(
								__( 'v3 — score, no interaction', 'wpd-recaptcha' ),
								__( 'Nothing to solve, ever. Google returns a score and you decide the cut-off. Nobody is asked to prove anything — but a real person scoring badly is turned away with no way to appeal, and they will never tell you.', 'wpd-recaptcha' ),
							),
						);
						?>
						<?php foreach ( $wpdrc_types as $wpdrc_value => $wpdrc_meta ) : ?>
							<label class="wpdrc-choice">
								<input type="radio" name="type" value="<?php echo esc_attr( $wpdrc_value ); ?>" <?php checked( $wpdrc_type, $wpdrc_value ); ?> />
								<span class="wpdrc-choice__label"><?php echo esc_html( $wpdrc_meta[0] ); ?></span>
								<span class="wpdrc-choice__note"><?php echo esc_html( $wpdrc_meta[1] ); ?></span>
							</label>
						<?php endforeach; ?>

						<hr class="wpdrc-rule" />

						<p class="wpdrc-subhead"><?php esc_html_e( 'Or generate the check on this site, with no third party involved', 'wpd-recaptcha' ); ?></p>

						<?php
						$wpdrc_local_types = array(
							WPDRC_Local::MATH     => array(
								__( 'A sum', 'wpd-recaptcha' ),
								__( 'Two small numbers, written in digits or in words. Works for everybody, including screen readers, and needs no keys. The one to pick if you are not sure.', 'wpd-recaptcha' ),
							),
							WPDRC_Local::QUESTION => array(
								__( 'A question you write', 'wpd-recaptcha' ),
								__( 'The strongest of these against generic spam software — no crawler has a table of answers about your business. Useless against anyone who reads the page once.', 'wpd-recaptcha' ),
							),
							WPDRC_Local::LETTERS  => array(
								__( 'Distorted letters', 'wpd-recaptcha' ),
								__( 'The familiar squiggly-text box, drawn here with GD. OCR has beaten this for over a decade, and it is the hardest of these for real people. Offered because people ask for it.', 'wpd-recaptcha' ),
							),
							WPDRC_Local::PUZZLE   => array(
								__( 'A slider puzzle', 'wpd-recaptcha' ),
								__( 'Drag a handle until two marks line up. Pleasant to use and the weakest of these: the target position has to be sent to the browser so it can be drawn, so anyone who reads one response knows where to put the handle.', 'wpd-recaptcha' ),
							),
							WPDRC_Local::SELECT   => array(
								__( 'Pick the pictures', 'wpd-recaptcha' ),
								__( 'The familiar grid — "select every picture with a bicycle in it" — drawn here with GD from simple shapes rather than photographs, so nothing is fetched from anybody and there is no image licence to worry about. Unlike the slider, the answer genuinely is not in the response. But there are only eight things it can draw, so anyone who writes all eight down beats it permanently.', 'wpd-recaptcha' ),
							),
						);
						?>

						<?php foreach ( $wpdrc_local_types as $wpdrc_value => $wpdrc_meta ) : ?>
							<label class="wpdrc-choice">
								<input type="radio" name="type" value="<?php echo esc_attr( $wpdrc_value ); ?>" <?php checked( $wpdrc_type, $wpdrc_value ); ?> />
								<span class="wpdrc-choice__label"><?php echo esc_html( $wpdrc_meta[0] ); ?></span>
								<span class="wpdrc-choice__note"><?php echo esc_html( $wpdrc_meta[1] ); ?></span>
							</label>
						<?php endforeach; ?>

						<div class="notice notice-info inline wpdrc-honest">
							<p>
								<strong><?php esc_html_e( 'What the local checks are actually worth.', 'wpd-recaptcha' ); ?></strong>
								<?php esc_html_e( 'None of them competes with Google on strength, and it would be dishonest to suggest otherwise. A sum is solvable by four lines of code; distorted letters by ordinary OCR; a slider by anyone who reads the request it sends. Any of them is solvable by a language model for a fraction of a penny.', 'wpd-recaptcha' ); ?>
							</p>
							<p>
								<?php esc_html_e( 'What they do buy you: nothing leaves the site, so there is nothing to declare in a privacy policy and no cookie banner to add. They work behind a firewall and in countries Google is not reachable from. And they stop the overwhelming majority of what actually reaches a small site\'s contact form, which is generic software crawling for any form at all rather than anybody aiming at you.', 'wpd-recaptcha' ); ?>
							</p>
							<p>
								<?php esc_html_e( 'If somebody is genuinely targeting your site, none of this stops them — and Google\'s will not either. Rate limiting and moderation will.', 'wpd-recaptcha' ); ?>
							</p>
						</div>

						<?php if ( in_array( $wpdrc_type, WPDRC_Local::visual_only(), true ) ) : ?>
							<div class="notice notice-warning inline">
								<p>
									<strong><?php esc_html_e( 'This one cannot be used by everybody.', 'wpd-recaptcha' ); ?></strong>
									<?php esc_html_e( 'Letters, the slider and the picture grid are all visual. Each carries a "give me a question I can read instead" button that swaps to a sum, which is what keeps the form usable with a screen reader — but a sum on its own is the kinder choice. The picture grid is the sharpest case: its whole question is what is in the image, so no alt text can describe a tile without giving the answer away.', 'wpd-recaptcha' ); ?>
								</p>
							</div>
						<?php endif; ?>

						<?php if ( in_array( $wpdrc_type, array( WPDRC_Local::LETTERS, WPDRC_Local::SELECT ), true ) && ! function_exists( 'imagecreatetruecolor' ) ) : ?>
							<div class="notice notice-error inline">
								<p><?php esc_html_e( 'This server has no GD image library, so nothing can be drawn. A sum is shown instead until that is installed — the form still works and is still checked.', 'wpd-recaptcha' ); ?></p>
							</div>
						<?php endif; ?>
					</td>
				</tr>
			</table>
		</div>

		<?php if ( WPDRC_Local::QUESTION === $wpdrc_type ) : ?>
			<div class="wpdrc-panel">
				<h2><?php esc_html_e( 'Your questions', 'wpd-recaptcha' ); ?></h2>

				<p class="description">
					<?php esc_html_e( 'One per line, as: question | answer. A random one is asked each time. Answers are compared loosely — case, extra spaces and a trailing full stop are all forgiven — so somebody who knows the answer does not fail on punctuation.', 'wpd-recaptcha' ); ?>
				</p>

				<p>
					<textarea name="questions" rows="6" class="large-text code" placeholder="<?php echo esc_attr( "What colour is the sky? | blue\nWhat town are we in? | Bristol\nHow many legs has a dog? | four" ); ?>"><?php echo esc_textarea( (string) WPDRC_Options::get( 'questions', '' ) ); ?></textarea>
				</p>

				<?php $wpdrc_pairs = WPDRC_Local::questions(); ?>

				<?php if ( ! $wpdrc_pairs ) : ?>
					<div class="notice notice-warning inline">
						<p><?php esc_html_e( 'No usable questions yet, so a sum is being asked instead. A form with an unanswerable question on it is worse than no check at all.', 'wpd-recaptcha' ); ?></p>
					</div>
				<?php else : ?>
					<p class="description">
						<?php
						printf(
							/* translators: %d: number of questions. */
							esc_html( _n( '%d question in rotation.', '%d questions in rotation.', count( $wpdrc_pairs ), 'wpd-recaptcha' ) ),
							count( $wpdrc_pairs )
						);
						?>
						<?php esc_html_e( 'Two or three is plenty; a single question is one somebody can hard-code.', 'wpd-recaptcha' ); ?>
					</p>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<div class="wpdrc-panel">
			<h2><?php esc_html_e( "Keys", "wpd-recaptcha" ); ?></h2>

			<?php if ( WPDRC_Service::is_local() ) : ?>
				<p class="description"><?php esc_html_e( "Not needed for the check you have chosen — it is generated here and verified here. The fields stay so you can switch back to Google without retyping them.", "wpd-recaptcha" ); ?></p>
			<?php endif; ?>

			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="v2_site_key"><?php esc_html_e( 'v2 site key', 'wpd-recaptcha' ); ?></label></th>
					<td><input type="text" class="regular-text code" id="v2_site_key" name="v2_site_key" value="<?php echo esc_attr( (string) $settings['v2_site_key'] ); ?>" autocomplete="off" /></td>
				</tr>
				<tr>
					<th scope="row"><label for="v2_secret_key"><?php esc_html_e( 'v2 secret key', 'wpd-recaptcha' ); ?></label></th>
					<td><input type="password" class="regular-text code" id="v2_secret_key" name="v2_secret_key" value="<?php echo esc_attr( (string) $settings['v2_secret_key'] ); ?>" autocomplete="off" /></td>
				</tr>
				<tr>
					<th scope="row"><label for="v3_site_key"><?php esc_html_e( 'v3 site key', 'wpd-recaptcha' ); ?></label></th>
					<td><input type="text" class="regular-text code" id="v3_site_key" name="v3_site_key" value="<?php echo esc_attr( (string) $settings['v3_site_key'] ); ?>" autocomplete="off" /></td>
				</tr>
				<tr>
					<th scope="row"><label for="v3_secret_key"><?php esc_html_e( 'v3 secret key', 'wpd-recaptcha' ); ?></label></th>
					<td><input type="password" class="regular-text code" id="v3_secret_key" name="v3_secret_key" value="<?php echo esc_attr( (string) $settings['v3_secret_key'] ); ?>" autocomplete="off" /></td>
				</tr>
				<tr>
					<th scope="row"><label for="score_threshold"><?php esc_html_e( 'v3 score threshold', 'wpd-recaptcha' ); ?></label></th>
					<td>
						<input type="number" step="0.1" min="0" max="1" class="small-text" id="score_threshold" name="score_threshold" value="<?php echo esc_attr( (string) $settings['score_threshold'] ); ?>" />
						<p class="description">
							<?php esc_html_e( '0.0 is certainly a bot, 1.0 is certainly a person. Google suggests 0.5. Raise it and you turn away more real people; lower it and you let more bots through — and only one of those two shows up in your inbox.', 'wpd-recaptcha' ); ?>
						</p>
					</td>
				</tr>
			</table>
		</div>

		<div class="wpdrc-panel">
			<h2><?php esc_html_e( 'Where to show it', 'wpd-recaptcha' ); ?></h2>

			<p class="description">
				<?php esc_html_e( 'Nothing is protected until it is ticked here. Activating this plugin does not put a captcha on anything.', 'wpd-recaptcha' ); ?>
			</p>

			<?php foreach ( $wpdrc_groups as $wpdrc_group => $wpdrc_items ) : ?>
				<h3><?php echo esc_html( $wpdrc_group ); ?></h3>

				<?php foreach ( $wpdrc_items as $wpdrc_key => $wpdrc_form ) : ?>
					<?php
					$wpdrc_available = true;
					$wpdrc_reason    = '';

					$wpdrc_requires = array(
						'cf7'          => array( 'WPDRC_CF7', 'Contact Form 7' ),
						'wpforms'      => array( 'WPDRC_WPForms', 'WPForms' ),
						'fluentform'   => array( 'WPDRC_Fluent', 'Fluent Forms' ),
						'elementor'    => array( 'WPDRC_Elementor', 'Elementor Pro' ),
						'woo_login'    => array( 'WPDRC_Woo', 'WooCommerce' ),
						'woo_checkout' => array( 'WPDRC_Woo', 'WooCommerce' ),
					);

					if ( isset( $wpdrc_requires[ $wpdrc_key ] ) ) {
						list( $wpdrc_class, $wpdrc_name ) = $wpdrc_requires[ $wpdrc_key ];

						if ( ! class_exists( $wpdrc_class ) || ! $wpdrc_class::available() ) {
							$wpdrc_available = false;
							/* translators: %s: plugin name. */
							$wpdrc_reason = sprintf( __( '%s is not active on this site.', 'wpd-recaptcha' ), $wpdrc_name );
						}
					}

					if ( 'register' === $wpdrc_key && ! get_option( 'users_can_register' ) ) {
						$wpdrc_available = false;
						$wpdrc_reason    = __( 'Registration is closed, so this form is not reachable.', 'wpd-recaptcha' );
					}
					?>
					<div class="wpdrc-form <?php echo $wpdrc_available ? '' : 'is-unavailable'; ?>">
						<label>
							<input type="checkbox" name="form_<?php echo esc_attr( $wpdrc_key ); ?>" value="1" <?php checked( ! empty( $settings[ 'form_' . $wpdrc_key ] ) ); ?> <?php disabled( ! $wpdrc_available ); ?> />
							<strong><?php echo esc_html( $wpdrc_form['label'] ); ?></strong>
						</label>

						<?php if ( ! $wpdrc_available ) : ?>
							<p class="description"><?php echo esc_html( $wpdrc_reason ); ?></p>
						<?php elseif ( '' !== $wpdrc_form['note'] ) : ?>
							<p class="description"><?php echo esc_html( $wpdrc_form['note'] ); ?></p>
						<?php endif; ?>

						<?php if ( 'cf7' === $wpdrc_key && $wpdrc_available && WPDRC_CF7::cf7_has_own() ) : ?>
							<p class="wpdrc-warn">
								<?php esc_html_e( 'Contact Form 7 already has its own reCAPTCHA keys saved, so this stands down rather than fighting it. Clear them in Contact → Integration if you want this plugin to handle CF7 instead.', 'wpd-recaptcha' ); ?>
							</p>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			<?php endforeach; ?>
		</div>

		<div class="wpdrc-panel">
			<h2><?php esc_html_e( 'Behaviour', 'wpd-recaptcha' ); ?></h2>

			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Logged-in users', 'wpd-recaptcha' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="skip_logged_in" value="1" <?php checked( ! empty( $settings['skip_logged_in'] ) ); ?> />
							<?php esc_html_e( 'Skip the captcha for anyone already signed in', 'wpd-recaptcha' ); ?>
						</label>
						<p class="description"><?php esc_html_e( 'Off by default, so the check applies to everybody. Worth ticking on a site with real members: they are not the traffic this defends against, and asking an editor to solve a puzzle to comment on their own site is how a captcha plugin gets removed.', 'wpd-recaptcha' ); ?></p>

						<?php if ( ! empty( $settings['skip_logged_in'] ) ) : ?>
							<?php
							/*
							 * The single most confusing state this plugin can be
							 * in, and it looks exactly like a broken install.
							 *
							 * You are reading this page, so you are signed in, so
							 * every protected form on the site renders nothing for
							 * you. Ticking a form and finding no captcha on it is
							 * then the expected behaviour — but nothing anywhere
							 * says so, and the obvious conclusion is that the
							 * plugin does not work.
							 */
							?>
							<div class="notice notice-warning inline">
								<p>
									<strong><?php esc_html_e( 'This is why you cannot see the check yourself.', 'wpd-recaptcha' ); ?></strong>
									<?php esc_html_e( 'You are signed in, so every protected form will look to you as though no captcha is on it. That is this setting working, not a fault. Open the form in a private window to see what a visitor sees — or untick this while you are testing.', 'wpd-recaptcha' ); ?>
								</p>
							</div>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'If Google cannot be reached', 'wpd-recaptcha' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="fail_closed" value="1" <?php checked( ! empty( $settings['fail_closed'] ) ); ?> />
							<?php esc_html_e( 'Refuse the submission', 'wpd-recaptcha' ); ?>
						</label>
						<p class="description">
							<strong><?php esc_html_e( 'Think about this one before you tick it.', 'wpd-recaptcha' ); ?></strong>
							<?php esc_html_e( 'It means a timeout, a blocked outbound request or a slow afternoon at Google stops every protected form — including the login form you would use to switch this off. Being unable to ask is not the same as being told no.', 'wpd-recaptcha' ); ?>
						</p>
						<p class="description">
							<?php
							printf(
								/* translators: %s: the constant. */
								esc_html__( 'Whatever you choose: %s in wp-config.php disables the whole plugin, which is the way back in if the login form is what is broken.', 'wpd-recaptcha' ),
								'<code>define( \'WPDRC_DISABLE\', true );</code>'
							);
							?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Record refusals', 'wpd-recaptcha' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="logging" value="1" <?php checked( ! empty( $settings['logging'] ) ); ?> />
							<?php esc_html_e( 'Keep a short log of submissions that were turned away', 'wpd-recaptcha' ); ?>
						</label>
						<p class="description"><?php esc_html_e( 'So that "a customer says they cannot submit the form" has an answer other than a shrug. Key and connection problems are always recorded; ordinary refusals only with this on.', 'wpd-recaptcha' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Appearance', 'wpd-recaptcha' ); ?></th>
					<td>
						<select name="theme">
							<option value="light" <?php selected( $settings['theme'], 'light' ); ?>><?php esc_html_e( 'Light', 'wpd-recaptcha' ); ?></option>
							<option value="dark" <?php selected( $settings['theme'], 'dark' ); ?>><?php esc_html_e( 'Dark', 'wpd-recaptcha' ); ?></option>
						</select>
						<select name="size">
							<option value="normal" <?php selected( $settings['size'], 'normal' ); ?>><?php esc_html_e( 'Normal', 'wpd-recaptcha' ); ?></option>
							<option value="compact" <?php selected( $settings['size'], 'compact' ); ?>><?php esc_html_e( 'Compact', 'wpd-recaptcha' ); ?></option>
						</select>
						<select name="badge">
							<option value="bottomright" <?php selected( $settings['badge'], 'bottomright' ); ?>><?php esc_html_e( 'Badge bottom right', 'wpd-recaptcha' ); ?></option>
							<option value="bottomleft" <?php selected( $settings['badge'], 'bottomleft' ); ?>><?php esc_html_e( 'Badge bottom left', 'wpd-recaptcha' ); ?></option>
							<option value="inline" <?php selected( $settings['badge'], 'inline' ); ?>><?php esc_html_e( 'Badge inline', 'wpd-recaptcha' ); ?></option>
						</select>
						<p class="description">
							<?php esc_html_e( 'Google\'s terms require the badge to be visible, or the notice it links to shown near your form. Hiding it with CSS and saying nothing is a breach of the terms you agreed to when you took the keys.', 'wpd-recaptcha' ); ?>
						</p>
					</td>
				</tr>
			</table>
		</div>

		<?php submit_button( __( 'Save changes', 'wpd-recaptcha' ) ); ?>
	</form>

	<div class="wpdrc-panel">
		<h2><?php esc_html_e( 'Check the secret key', 'wpd-recaptcha' ); ?></h2>
		<p class="description">
			<?php esc_html_e( 'Sends a deliberately invalid token and reads which way Google complains. It cannot prove the whole thing works — that needs a real browser — but it catches the mistyped secret, which otherwise looks identical to a working setup until a real visitor is refused.', 'wpd-recaptcha' ); ?>
		</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="wpdrc_test" />
			<?php wp_nonce_field( WPDRC_Admin::NONCE ); ?>
			<?php submit_button( __( 'Test the connection', 'wpd-recaptcha' ), 'secondary', 'submit', false ); ?>
		</form>
	</div>

	<div class="wpdrc-panel">
		<h2><?php esc_html_e( 'Custom forms', 'wpd-recaptcha' ); ?></h2>

		<p><?php esc_html_e( 'Paste this anywhere inside your form markup:', 'wpd-recaptcha' ); ?></p>
		<p><input type="text" class="regular-text code" readonly onfocus="this.select()" value="[recaptcha]" /></p>

		<p class="description">
			<?php esc_html_e( 'That is the whole integration. Any submission carrying it is checked before your handler runs, whether the form posts normally and redirects, or posts over AJAX. A refusal comes back as JSON to an AJAX caller and as an error page to a normal post, so neither one hangs.', 'wpd-recaptcha' ); ?>
		</p>

		<p><?php esc_html_e( 'Give each form its own name if you have several, so the v3 scores are reported separately in Google\'s console:', 'wpd-recaptcha' ); ?></p>
		<p><input type="text" class="regular-text code" readonly onfocus="this.select()" value="[recaptcha form=&quot;newsletter&quot;]" /></p>

		<p class="description">
			<?php
			printf(
				/* translators: 1: PHP function, 2: filter name. */
				esc_html__( 'From a template rather than a shortcode, call %1$s. To check it yourself at the point that suits your handler, switch the automatic check off with %2$s and call wpdrc_verify() where you want it.', 'wpd-recaptcha' ),
				'<code>wpdrc_field()</code>',
				'<code>add_filter( \'wpdrc_auto_verify\', \'__return_false\' )</code>'
			);
			?>
		</p>
	</div>

	<?php $wpdrc_log = WPDRC_Log::all(); ?>

	<?php if ( $wpdrc_log ) : ?>
		<div class="wpdrc-panel">
			<h2><?php esc_html_e( 'Recent refusals', 'wpd-recaptcha' ); ?></h2>

			<table class="widefat striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'When', 'wpd-recaptcha' ); ?></th>
						<th><?php esc_html_e( 'What', 'wpd-recaptcha' ); ?></th>
						<th><?php esc_html_e( 'Where', 'wpd-recaptcha' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( array_slice( $wpdrc_log, 0, 25 ) as $wpdrc_entry ) : ?>
						<tr>
							<td>
								<?php
								printf(
									/* translators: %s: human time difference. */
									esc_html__( '%s ago', 'wpd-recaptcha' ),
									esc_html( human_time_diff( (int) $wpdrc_entry['time'] ) )
								);
								?>
							</td>
							<td><?php echo esc_html( $wpdrc_entry['message'] ); ?></td>
							<td class="wpdrc-mono"><?php echo esc_html( $wpdrc_entry['uri'] ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="wpdrc_clear_log" />
					<?php wp_nonce_field( WPDRC_Admin::NONCE ); ?>
					<?php submit_button( __( 'Clear the log', 'wpd-recaptcha' ), 'secondary', 'submit', false ); ?>
				</form>
			</p>
		</div>
	<?php endif; ?>
</div>

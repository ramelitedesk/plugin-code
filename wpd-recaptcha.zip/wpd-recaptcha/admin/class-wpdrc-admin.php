<?php
/**
 * Settings: Settings → reCAPTCHA.
 *
 * @package WPD_ReCaptcha
 */

defined( 'ABSPATH' ) || exit;

class WPDRC_Admin {

	const PAGE  = 'wpd-recaptcha';
	const NONCE = 'wpdrc_save';

	/** @var WPDRC_Admin|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_post_wpdrc_save', array( $this, 'handle_save' ) );
		add_action( 'admin_post_wpdrc_test', array( $this, 'handle_test' ) );
		add_action( 'admin_post_wpdrc_clear_log', array( $this, 'handle_clear_log' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
		add_action( 'admin_notices', array( $this, 'setup_notice' ) );
	}

	public function add_menu() {
		add_options_page(
			__( 'reCAPTCHA', 'wpd-recaptcha' ),
			__( 'reCAPTCHA', 'wpd-recaptcha' ),
			'manage_options',
			self::PAGE,
			array( $this, 'render' )
		);
	}

	/**
	 * @param string $hook Current screen.
	 */
	public function enqueue( $hook ) {
		if ( false === strpos( (string) $hook, self::PAGE ) ) {
			return;
		}

		wp_enqueue_style( 'wpdrc-admin', WPDRC_URL . 'assets/admin.css', array(), WPDRC_VERSION );
	}

	/**
	 * Say so if forms are ticked but the keys are missing.
	 *
	 * Without this the failure is silent in the worst way: the settings screen
	 * looks configured, and the forms are simply unprotected.
	 */
	public function setup_notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$screen = get_current_screen();

		if ( $screen && false !== strpos( (string) $screen->id, self::PAGE ) ) {
			return;
		}

		if ( WPDRC_Service::configured() || ! $this->any_form_on() ) {
			return;
		}

		printf(
			'<div class="notice notice-warning"><p><strong>%s</strong> %s <a href="%s">%s</a></p></div>',
			esc_html__( 'reCAPTCHA:', 'wpd-recaptcha' ),
			esc_html__( 'forms are selected but no keys are saved, so nothing is being checked.', 'wpd-recaptcha' ),
			esc_url( admin_url( 'options-general.php?page=' . self::PAGE ) ),
			esc_html__( 'Add the keys', 'wpd-recaptcha' )
		);
	}

	/**
	 * @return bool
	 */
	private function any_form_on() {
		foreach ( array_keys( WPDRC_Options::forms() ) as $key ) {
			if ( WPDRC_Options::enabled( 'form_' . $key ) ) {
				return true;
			}
		}

		return false;
	}

	public function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'wpd-recaptcha' ) );
		}

		$settings = WPDRC_Options::all();
		$forms    = WPDRC_Options::forms();

		require WPDRC_DIR . 'admin/views/settings.php';
	}

	public function handle_save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'wpd-recaptcha' ) );
		}

		check_admin_referer( self::NONCE );

		$clean = array();

		foreach ( WPDRC_Options::defaults() as $key => $default ) {
			if ( '_schema' === $key ) {
				$clean[ $key ] = 1;
				continue;
			}

			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked above.
			$posted = isset( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : null;

			if ( is_int( $default ) ) {
				$clean[ $key ] = null === $posted ? 0 : 1;
				continue;
			}

			if ( is_float( $default ) ) {
				// Anything outside 0–1 is not a score, and a threshold of 0
				// would accept everything while looking like it was configured.
				$clean[ $key ] = min( 1.0, max( 0.0, (float) $posted ) );
				continue;
			}

			if ( 0 === strpos( $key, 'message_' ) ) {
				$clean[ $key ] = is_string( $posted ) ? sanitize_text_field( $posted ) : '';
				continue;
			}

			$clean[ $key ] = is_string( $posted ) ? sanitize_text_field( $posted ) : $default;
		}

		WPDRC_Options::update( $clean );

		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE, 'updated' => '1' ), admin_url( 'options-general.php' ) ) );
		exit;
	}

	/**
	 * Ask Google whether the secret key is even valid.
	 *
	 * Not a full round trip — that needs a real token from a real browser. It
	 * sends a deliberately invalid token and reads which way Google complains:
	 * "invalid-input-response" means the secret was accepted and the token was
	 * not, which is exactly what a correct secret and a fake token should
	 * produce. "invalid-input-secret" means the key is wrong.
	 *
	 * Worth having because a mistyped secret is otherwise indistinguishable
	 * from a working setup right up until a real visitor is refused.
	 */
	public function handle_test() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'wpd-recaptcha' ) );
		}

		check_admin_referer( self::NONCE );

		$verdict = 'unknown';

		if ( ! WPDRC_Service::configured() ) {
			$verdict = 'unconfigured';
		} else {
			$response = wp_remote_post(
				WPDRC_Service::VERIFY_URL,
				array(
					'timeout' => 10,
					'body'    => array(
						'secret'   => WPDRC_Service::secret_key(),
						'response' => 'wpdrc-connection-test',
					),
				)
			);

			if ( is_wp_error( $response ) ) {
				$verdict = 'unreachable';
			} else {
				$body  = json_decode( (string) wp_remote_retrieve_body( $response ), true );
				$codes = is_array( $body ) && isset( $body['error-codes'] ) ? (array) $body['error-codes'] : array();

				if ( array_intersect( $codes, array( 'invalid-input-secret', 'missing-input-secret' ) ) ) {
					$verdict = 'bad_secret';
				} elseif ( in_array( 'invalid-input-response', $codes, true ) ) {
					$verdict = 'ok';
				} else {
					$verdict = 'unknown';
				}
			}
		}

		set_transient( 'wpdrc_test_' . get_current_user_id(), $verdict, 60 );

		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE, 'tested' => '1' ), admin_url( 'options-general.php' ) ) );
		exit;
	}

	public function handle_clear_log() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'wpd-recaptcha' ) );
		}

		check_admin_referer( self::NONCE );

		WPDRC_Log::clear();

		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE ), admin_url( 'options-general.php' ) ) );
		exit;
	}

	/**
	 * @return string The stored test verdict, consumed.
	 */
	public static function take_test_result() {
		$key    = 'wpdrc_test_' . get_current_user_id();
		$stored = get_transient( $key );

		if ( false === $stored ) {
			return '';
		}

		delete_transient( $key );

		return (string) $stored;
	}
}

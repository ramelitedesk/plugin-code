<?php
/**
 * Plugin Name:       WPD reCAPTCHA
 * Plugin URI:        https://webart.technology/
 * Description:       reCAPTCHA v2 and v3 on any form — WordPress login and comments, Contact Form 7, WPForms, Fluent Forms, Elementor Pro, WooCommerce, and hand-written forms via a shortcode that works with AJAX or an ordinary POST.
 * Version:           1.1.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Ramakrishna
 * License:           GPL-2.0-or-later
 * Text Domain:       wpd-recaptcha
 *
 * @package WPD_ReCaptcha
 */

defined( 'ABSPATH' ) || exit;

define( 'WPDRC_VERSION', '1.1.0' );
define( 'WPDRC_FILE', __FILE__ );
define( 'WPDRC_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPDRC_URL', plugin_dir_url( __FILE__ ) );

/**
 * A captcha plugin can fail in two directions and only one of them is visible.
 *
 * Letting spam through is annoying and obvious: the inbox fills up and somebody
 * complains. Refusing real people is silent — they see a message, decide the
 * site is broken, and leave. Nobody reports it, and the form looks like it is
 * working perfectly from the inside.
 *
 * Everything here leans against the silent one:
 *
 *   • Nothing is protected until it is switched on. Activating this does not
 *     put a captcha on a checkout.
 *   • A network failure at Google fails OPEN by default and is logged. Being
 *     unable to ask is not the same as being told no, and the alternative is a
 *     login form that stops working because somebody else's server is slow.
 *   • WPDRC_DISABLE in wp-config.php switches the whole thing off, for the
 *     afternoon the keys are wrong and the login form is what is broken.
 *   • Refusals are recorded, so "a customer says they cannot submit the form"
 *     has an answer other than a shrug.
 */
final class WPD_ReCaptcha {

	/** @var WPD_ReCaptcha|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->boot();
		}
		return self::$instance;
	}

	private function boot() {
		require_once WPDRC_DIR . 'includes/class-wpdrc-updates.php';
		require_once WPDRC_DIR . 'includes/class-wpdrc-options.php';
		require_once WPDRC_DIR . 'includes/class-wpdrc-local.php';
		require_once WPDRC_DIR . 'includes/class-wpdrc-service.php';
		require_once WPDRC_DIR . 'includes/class-wpdrc-assets.php';
		require_once WPDRC_DIR . 'includes/class-wpdrc-custom.php';

		require_once WPDRC_DIR . 'integrations/class-wpdrc-wp.php';
		require_once WPDRC_DIR . 'integrations/class-wpdrc-plugins.php';

		if ( is_admin() ) {
			require_once WPDRC_DIR . 'admin/class-wpdrc-admin.php';
		}

		WPDRC_Updates::hook();

		add_action( 'init', array( $this, 'load_textdomain' ), 1 );

		/*
		 * Priority 20 on plugins_loaded, so every form plugin has declared
		 * itself before the integrations look for it. Going earlier means
		 * class_exists( 'WooCommerce' ) answers no on a site that has it.
		 */
		add_action( 'plugins_loaded', array( $this, 'init' ), 20 );

		register_activation_hook( WPDRC_FILE, array( __CLASS__, 'on_activate' ) );
	}

	public function load_textdomain() {
		load_plugin_textdomain( 'wpd-recaptcha', false, dirname( plugin_basename( WPDRC_FILE ) ) . '/languages' );
	}

	public function init() {
		WPDRC_Assets::instance();
		WPDRC_Local::instance();

		// The shortcode is always registered, even when nothing is configured.
		// A page containing [recaptcha] should render as an empty string rather
		// than print the shortcode text at a visitor.
		WPDRC_Custom::instance();

		if ( WPDRC_Service::active() ) {
			WPDRC_WP::instance();

			foreach ( array( 'WPDRC_CF7', 'WPDRC_WPForms', 'WPDRC_Fluent', 'WPDRC_Elementor', 'WPDRC_Woo' ) as $class ) {
				if ( class_exists( $class ) && $class::available() ) {
					$class::instance();
				}
			}
		}

		if ( is_admin() && class_exists( 'WPDRC_Admin' ) ) {
			WPDRC_Admin::instance();
		}

		do_action( 'wpdrc_loaded', $this );
	}

	public static function on_activate() {
		require_once WPDRC_DIR . 'includes/class-wpdrc-local.php';
		require_once WPDRC_DIR . 'includes/class-wpdrc-service.php';
		require_once WPDRC_DIR . 'includes/class-wpdrc-options.php';

		WPDRC_Options::install_defaults();
	}
}

WPD_ReCaptcha::instance();

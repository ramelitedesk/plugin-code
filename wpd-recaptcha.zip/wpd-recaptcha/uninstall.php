<?php
/**
 * Runs when the plugin is deleted.
 *
 * @package WPD_ReCaptcha
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'wpdrc_settings' );
delete_option( 'wpdrc_log' );

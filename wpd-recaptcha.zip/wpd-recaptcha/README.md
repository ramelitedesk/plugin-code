# WPD reCAPTCHA

reCAPTCHA v2 and v3 on any form — or a sum, a question, distorted letters or a slider generated on your own server with no third party at all.

---

## The failure this is built around

A captcha fails in two directions and **only one of them is visible.**

Letting spam through is obvious: the inbox fills up and somebody complains. Refusing real people is silent — they see a message, decide the site is broken, and leave. Nobody reports it, and from the inside the form looks like it is working perfectly.

So the defaults all lean the same way:

- **Nothing is protected until you tick it.** Activating this does not put a captcha on your checkout.
- **A network failure at Google fails open**, and is logged. Being unable to ask is not the same as being told no — and the alternative is a login form that stops working because somebody else's server is slow. A real refusal from Google always blocks; that distinction is the whole design.
- **`define( 'WPDRC_DISABLE', true );`** in `wp-config.php` switches everything off. Somebody will eventually paste the wrong key and lock themselves out at the exact moment they cannot reach the settings screen to fix it.
- **Refusals are recorded**, so *"a customer says they cannot submit the form"* has an answer other than a shrug.

---

## Which version

Two families to choose from: Google, or a challenge this site generates itself.

One version site-wide. v2 and v3 use different keys and a different script, and running both on one page makes them refuse each other's tokens.

| | |
| --- | --- |
| **v2 checkbox** | Visible and familiar. The visitor knows a check happened, and when it refuses them they can see why. The safest choice for a form you cannot afford to lose submissions from. |
| **v2 invisible** | No tick box; a challenge only appears when Google is unsure. Runs on submit, so a slow challenge delays the form by a moment. |
| **v3** | Nothing to solve, ever. Google returns a score and you set the cut-off. Nobody is asked to prove anything — but a real person scoring badly is turned away with no way to appeal, and they will never tell you. |

### Or: no third party at all

Five checks this site generates and verifies itself. No Google, no external script, no request leaving your server.

| | |
| --- | --- |
| **A sum** | `seven plus two = ?`, written in digits or in words. Works for everybody including screen readers. The one to pick if you are not sure. |
| **A question you write** | `What town are we in? | Bristol`. The strongest of these against generic spam software — no crawler has a table of answers about your business. Useless against anyone who reads the page once. |
| **Distorted letters** | The familiar squiggly-text box, drawn with GD. |
| **A slider puzzle** | Drag a handle until two marks line up. |
| **Pick the pictures** | The familiar grid — "select every picture with a bicycle in it" — drawn here with GD from simple shapes rather than photographs. Nothing is fetched from anybody, and unlike the slider the answer is genuinely not in the response. |

#### What these are actually worth

Being straight about it: **none of them competes with Google on strength.** A sum is solvable by four lines of code. Distorted letters are solvable by OCR that has been commodity for a decade. A slider is solvable by anyone who reads the request it sends — the target position has to go to the browser so it can be drawn. The picture grid can draw eight things, so anyone who writes all eight down beats it permanently. Any of them is solvable by a language model for a fraction of a penny.

What they do buy you:

- **Nothing leaves the site.** No third-party script, nothing to declare in a privacy policy, no cookie banner.
- **They work where Google does not** — behind a firewall, in China, on an intranet, on a server with no outbound HTTPS.
- **They stop the overwhelming majority of what actually reaches a small site's contact form**, which is generic software crawling for any form at all rather than anybody aiming at you.

Most spam is not an attack; it is weather, and a local captcha is an umbrella. If somebody is genuinely targeting your site, none of this stops them — and Google's will not either. Rate limiting and moderation will.

#### How they are kept honest

The answer never reaches the browser. What goes out is the question, an id, an expiry and an **HMAC of the answer** signed with a site secret. The server recomputes that HMAC from whatever was typed and compares in constant time — so there is nothing to store between the two requests and nothing in the page that gives the answer away.

Challenges are **fetched over AJAX, never printed into the page.** A full-page cache would otherwise serve one challenge to every visitor for hours, and since a challenge is answerable only once, the first person to submit would lock out everybody behind them.

The expiry, the id and the kind are all inside the signature, so none of them can be moved. Each challenge is single-use, remembered just long enough that it could not still be replayed.

#### Accessibility

Letters and the slider are visual, so **both carry a "give me a question I can read instead" button** that swaps to a sum. That is not politeness — a captcha nobody blind can pass is a form nobody blind can submit. The slider is a real `<input type="range">`, so it works with arrow keys as well as a finger.

A sum on its own is still the kinder choice.

---

## Where it works

**WordPress** — login, register, lost password, comments.
**Form plugins** — Contact Form 7, WPForms, Fluent Forms, Elementor Pro.
**WooCommerce** — login/registration, and checkout if you really want it.
**Anything else** — the shortcode below.

Each integration checks the plugin is actually active before hooking anything, and the settings screen greys out the ones that are not installed rather than offering a switch that does nothing.

**Contact Form 7 has its own reCAPTCHA.** If CF7's keys are already saved, this stands down rather than fighting it — two scripts both calling `grecaptcha.execute` on one page argue over the badge and can refuse each other's tokens. The settings screen says so.

---

## Custom forms

Paste this inside your form:

```
[recaptcha]
```

That is the entire integration. The widget appears, and **any submission carrying it is verified before your handler runs** — whether the form posts normally and redirects to a thank-you page, or posts over AJAX.

Give each form its own name if you have several, so v3 scores are reported separately in Google's console:

```
[recaptcha form="newsletter"]
```

From a template rather than a shortcode: `<?php wpdrc_field( 'newsletter' ); ?>`

### How it can possibly work without touching your code

The shortcode plants a hidden field naming the form. Very early in the request — `init` at priority 1, before your handler on `init`, `wp_loaded`, `template_redirect`, `admin_post_*` or `wp_ajax_*` — anything POSTing that field is verified. Fail, and the request stops there.

Two things make that safe rather than clever:

1. **It only ever acts on requests carrying the marker.** A POST that has nothing to do with this plugin is untouched, so it cannot break a form it was never added to.
2. **It refuses in the shape the caller asked for.** Killing an AJAX request with an HTML error page produces `unexpected token < in JSON` in the console and a form that hangs forever — worse than no captcha, because nobody can tell what went wrong. AJAX callers get JSON (in three shapes at once, since a hand-written handler could be reading any of them); ordinary posts get an error page with a back link.

### If you would rather check it yourself

```php
add_filter( 'wpdrc_auto_verify', '__return_false' );

// then, wherever suits your handler:
if ( is_wp_error( wpdrc_verify( 'newsletter' ) ) ) {
    // re-render the form with the values still in it
}
```

`wpdrc_passed( 'newsletter' )` is the same thing as a plain boolean.

---

## Things that catch people out, handled

**Page caching.** The field carries **no nonce**. A nonce goes stale in a page cache and the captcha would break the moment someone installs a caching plugin. The reCAPTCHA token is itself the proof of freshness — that is its whole job.

**v3 tokens expire after two minutes.** A form somebody fills in slowly would submit a dead token. The script refreshes every 90 seconds *and* again at the moment of submitting, because an interval does not run while the tab is in the background. This is the commonest way a v3 integration fails, and it fails only for slow users, so it never shows up in testing.

**Several forms on one page.** Each gets its own widget with its own id. One widget and a hope that there is only ever one form is how a captcha breaks when someone adds a newsletter box to the footer.

**Forms added after page load** — a modal, a revealed step, a block loaded over AJAX — are picked up by a MutationObserver rather than left without a widget.

**A token is only spent once.** Google answers `timeout-or-duplicate` the second time it sees one, and several form plugins validate a field more than once per request. Verdicts are cached per request, so the second check returns the first answer instead of a spurious failure.

**XML-RPC, REST and application passwords never see a captcha.** There is no human there to solve one, so protecting them this way would break every mobile app and deploy script on the site while doing nothing about a password attack — which does not go through the login form anyway.

**The login check runs after the password check**, at priority 30 on `authenticate`. Running earlier would refuse a good password before checking it, and the timing difference tells a brute-force tool which usernames are real.

---

## Tests

```bash
cd wpd-recaptcha/tests
php test.php          # 78 cases
php local-test.php    # 46 cases
php disable-test.php  # 6 cases
```

No WordPress, no PHPUnit, and **no network** — Google is stubbed, because a captcha suite that calls `google.com` fails on an aeroplane, fails in CI without egress, and passes for the wrong reason when a key expires.

Most of it asserts the plugin does *not* refuse: with no keys, with half a key pair, when Google times out, when the secret is wrong, for a logged-in editor, on a v2 response that carries no score. There are also tests that the secret key never appears in rendered markup, that two widgets on a page get different ids, and that no nonce is embedded anywhere.

---

## Honest limits

- **Google decides, not this plugin.** A v3 score is Google's opinion of a visitor based on data neither you nor they will explain. Someone on a VPN, a shared office IP, or a privacy-hardened browser can score badly forever with no way to appeal. That is the trade v3 asks you to make, and it is why v2 is the default here.
- **A captcha on checkout is the most expensive obstacle on a site.** It sits between a customer and paying you. The setting exists; think hard before ticking it, and use v3 if you do.
- **The badge is not optional.** Google's terms require it to be visible, or the notice it links to shown near the form. Hiding it with CSS and saying nothing breaches the terms you agreed to when you took the keys.
- **The local checks are weak, and the plugin says so on its own settings screen.** They are for privacy and for not depending on Google, not for strength. If spam gets through one, that is the trade you made — move to v2.
- **This is not spam filtering.** It stops automated submissions. It does nothing about a person paid to fill in your form by hand.

## Documentation

`DOCUMENTATION.html` is the full manual — open it in a browser. It covers choosing between the seven checks, the local ones in detail, the custom-form interceptor, what happens when Google is unreachable, getting back in when you are locked out, and a troubleshooting table.

---

## Requirements

WordPress 5.8+, PHP 7.4+. Keys from [Google reCAPTCHA admin](https://www.google.com/recaptcha/admin). No dependencies, no build step.

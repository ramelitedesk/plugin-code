<?php
/**
 * WordPress's own forms: login, register, lost password, comments.
 *
 * The login form is the one this plugin exists for and the one most able to
 * ruin somebody's day, so it gets the most care:
 *
 *   • Only browser logins are checked. XML-RPC, the REST API and application
 *     passwords never see a captcha, because there is no human there to solve
 *     one — protecting them this way would break every mobile app and every
 *     deploy script on the site while doing nothing about a password attack,
 *     which does not go through the login form anyway.
 *
 *   • The check runs at priority 30 on `authenticate`, after core has decided
 *     whether the password was right. Running earlier would refuse a good
 *     password before checking it, which sounds harmless until a brute-force
 *     tool uses the difference in response time to tell valid usernames apart.
 *
 *   • WPDRC_DISABLE in wp-config.php turns the whole thing off. Somebody will
 *     eventually paste the wrong key and lock themselves out at the exact
 *     moment they cannot reach the settings screen to fix it.
 *
 * @package WPD_ReCaptcha
 */

defined( 'ABSPATH' ) || exit;

class WPDRC_WP {

	/** @var WPDRC_WP|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		if ( WPDRC_Options::protects( 'login' ) ) {
			add_action( 'login_form', array( $this, 'login_field' ) );
			add_filter( 'authenticate', array( $this, 'check_login' ), 30, 3 );
		}

		if ( WPDRC_Options::protects( 'register' ) ) {
			add_action( 'register_form', array( $this, 'register_field' ) );
			add_filter( 'registration_errors', array( $this, 'check_register' ), 10 );
		}

		if ( WPDRC_Options::protects( 'lostpassword' ) ) {
			add_action( 'lostpassword_form', array( $this, 'lostpassword_field' ) );
			add_action( 'lostpassword_post', array( $this, 'check_lostpassword' ) );
		}

		if ( WPDRC_Options::protects( 'comment' ) ) {
			add_action( 'comment_form_after_fields', array( $this, 'comment_field' ) );
			add_action( 'comment_form_logged_in_after', array( $this, 'comment_field' ) );
			add_filter( 'preprocess_comment', array( $this, 'check_comment' ) );
		}
	}

	/* ------------------------------------------------------------------ *
	 * Fields
	 * ------------------------------------------------------------------ */

	public function login_field() {
		$this->field( 'login' );
	}

	public function register_field() {
		$this->field( 'register' );
	}

	public function lostpassword_field() {
		$this->field( 'lostpassword' );
	}

	public function comment_field() {
		$this->field( 'comment' );
	}

	/**
	 * @param string $form Form key.
	 */
	private function field( $form ) {
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built and escaped in WPDRC_Service::field().
		echo '<div class="wpdrc-field wpdrc-field--' . esc_attr( $form ) . '">' . WPDRC_Service::field( array( 'form' => $form ) ) . '</div>';
	}

	/* ------------------------------------------------------------------ *
	 * Checks
	 * ------------------------------------------------------------------ */

	/**
	 * @param null|WP_User|WP_Error $user     Result so far.
	 * @param string                $username Username.
	 * @param string                $password Password.
	 * @return null|WP_User|WP_Error
	 */
	public function check_login( $user, $username, $password ) {
		if ( ! $this->is_browser_login() ) {
			return $user;
		}

		// Nothing was submitted — the login form was merely rendered.
		if ( '' === (string) $username && '' === (string) $password ) {
			return $user;
		}

		/*
		 * Core has already decided. If the credentials were wrong, say so and
		 * stop — adding a captcha failure on top tells an attacker their
		 * password was wrong AND that a captcha exists, and costs a real person
		 * an extra round trip to learn the same thing.
		 */
		if ( is_wp_error( $user ) ) {
			return $user;
		}

		$result = WPDRC_Service::verify( 'login' );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return $user;
	}

	/**
	 * Only a real person at a real login form.
	 *
	 * @return bool
	 */
	private function is_browser_login() {
		if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) {
			return false;
		}

		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return false;
		}

		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			return false;
		}

		// Application passwords authenticate over Basic auth with no form.
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		if ( ! empty( $_SERVER['PHP_AUTH_USER'] ) && empty( $_POST['log'] ) ) {
			return false;
		}

		if ( 'POST' !== $this->method() ) {
			return false;
		}

		/**
		 * @param bool $browser Whether this is a form login a person can solve.
		 */
		return (bool) apply_filters( 'wpdrc_is_browser_login', true );
	}

	/**
	 * @param WP_Error $errors Registration errors.
	 * @return WP_Error
	 */
	public function check_register( $errors ) {
		$result = WPDRC_Service::verify( 'register' );

		if ( is_wp_error( $result ) ) {
			$errors->add( 'wpdrc', $result->get_error_message() );
		}

		return $errors;
	}

	public function check_lostpassword() {
		$result = WPDRC_Service::verify( 'lostpassword' );

		if ( is_wp_error( $result ) ) {
			wp_die(
				esc_html( $result->get_error_message() ),
				esc_html__( 'Request not accepted', 'wpd-recaptcha' ),
				array( 'response' => 403, 'back_link' => true )
			);
		}
	}

	/**
	 * @param array $data Comment data.
	 * @return array
	 */
	public function check_comment( $data ) {
		// A trackback or pingback has no browser and no captcha to solve. The
		// place to stop those is the discussion settings, not here.
		if ( ! empty( $data['comment_type'] ) && ! in_array( $data['comment_type'], array( '', 'comment' ), true ) ) {
			return $data;
		}

		$result = WPDRC_Service::verify( 'comment' );

		if ( is_wp_error( $result ) ) {
			wp_die(
				esc_html( $result->get_error_message() ),
				esc_html__( 'Comment not accepted', 'wpd-recaptcha' ),
				array( 'response' => 403, 'back_link' => true )
			);
		}

		return $data;
	}

	/**
	 * @return string
	 */
	private function method() {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		return isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( (string) wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : 'GET';
	}
}

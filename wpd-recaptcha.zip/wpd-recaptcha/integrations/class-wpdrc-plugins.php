<?php
/**
 * The form plugins.
 *
 * Each one is a few lines because each one already has the two hooks that
 * matter: somewhere to put a field, and somewhere to refuse a submission. What
 * differs is only where those are and what a refusal has to look like.
 *
 * They all guard on class_exists() rather than on a setting alone. A site can
 * have "protect WPForms" ticked and WPForms deactivated a month later, and
 * hooking a filter for a plugin that is not there is how a captcha plugin
 * becomes the thing in the fatal error.
 *
 * @package WPD_ReCaptcha
 */

defined( 'ABSPATH' ) || exit;

/**
 * Contact Form 7.
 *
 * CF7 is the one people ask for most and the one with the sharpest edge: it
 * posts over AJAX and reads a very specific JSON shape back. A refusal that
 * does not use CF7's own invalidation mechanism produces a form that spins
 * forever, so this uses wpcf7_validate rather than anything more direct.
 */
class WPDRC_CF7 {

	/** @var WPDRC_CF7|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * @return bool
	 */
	public static function available() {
		return defined( 'WPCF7_VERSION' ) || class_exists( 'WPCF7' );
	}

	private function __construct() {
		if ( ! self::available() ) {
			return;
		}

		add_filter( 'wpcf7_form_elements', array( $this, 'insert_widget' ), 20 );
		add_filter( 'wpcf7_spam', array( $this, 'check' ), 10, 2 );

		/*
		 * CF7 ships its own v3 integration. Two scripts both calling
		 * grecaptcha.execute on the same page fight over the badge and can
		 * refuse each other's tokens, so if theirs is configured this stands
		 * down and says so on the settings screen.
		 */
		if ( $this->cf7_has_own() ) {
			remove_filter( 'wpcf7_form_elements', array( $this, 'insert_widget' ), 20 );
			remove_filter( 'wpcf7_spam', array( $this, 'check' ), 10 );
		}
	}

	/**
	 * @return bool Whether CF7's own reCAPTCHA is set up.
	 */
	public static function cf7_has_own() {
		if ( ! class_exists( 'WPCF7' ) || ! method_exists( 'WPCF7', 'get_option' ) ) {
			return false;
		}

		$keys = WPCF7::get_option( 'recaptcha' );

		return ! empty( $keys );
	}

	/**
	 * Put the widget just before the submit button.
	 *
	 * Before, not after: after means it renders below the button, which reads
	 * as an afterthought and is easy to miss on a phone — and a visitor who
	 * misses it presses submit, is refused, and has no idea why.
	 *
	 * @param string $elements Form HTML.
	 * @return string
	 */
	public function insert_widget( $elements ) {
		if ( ! WPDRC_Options::protects( 'cf7' ) ) {
			return $elements;
		}

		$widget = WPDRC_Service::field( array( 'form' => 'cf7' ) );

		if ( '' === $widget ) {
			return $elements;
		}

		$widget = '<div class="wpdrc-field wpdrc-field--cf7">' . $widget . '</div>';

		if ( preg_match( '/<(input|button)[^>]*type=["\']submit["\'][^>]*>/i', $elements, $match ) ) {
			return str_replace( $match[0], $widget . $match[0], $elements );
		}

		return $elements . $widget;
	}

	/**
	 * @param bool   $spam   Whether CF7 already thinks this is spam.
	 * @param object $result Submission result object (CF7 5.6+).
	 * @return bool
	 */
	public function check( $spam, $result = null ) {
		if ( $spam || ! WPDRC_Options::protects( 'cf7' ) ) {
			return $spam;
		}

		$verified = WPDRC_Service::verify( 'cf7' );

		if ( is_wp_error( $verified ) ) {
			/*
			 * Marked as spam rather than as a validation error, which is what
			 * CF7 expects for a bot check: the visitor gets CF7's own "there
			 * was an error" message, the submission is not mailed, and it is
			 * recorded in Flamingo if that is installed — so a false positive
			 * can be found and read rather than being lost.
			 */
			return true;
		}

		return $spam;
	}
}

/**
 * WPForms.
 */
class WPDRC_WPForms {

	/** @var WPDRC_WPForms|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * @return bool
	 */
	public static function available() {
		return function_exists( 'wpforms' ) || defined( 'WPFORMS_VERSION' );
	}

	private function __construct() {
		if ( ! self::available() ) {
			return;
		}

		add_action( 'wpforms_frontend_output', array( $this, 'widget' ), 20, 1 );
		add_action( 'wpforms_process', array( $this, 'check' ), 10, 3 );
	}

	/**
	 * @param array $form_data Form configuration.
	 */
	public function widget( $form_data ) {
		if ( ! WPDRC_Options::protects( 'wpforms' ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in WPDRC_Service::field().
		echo '<div class="wpdrc-field wpdrc-field--wpforms">' . WPDRC_Service::field( array( 'form' => 'wpforms' ) ) . '</div>';
	}

	/**
	 * @param array $fields    Submitted fields.
	 * @param array $entry     Raw entry.
	 * @param array $form_data Form configuration.
	 */
	public function check( $fields, $entry, $form_data ) {
		if ( ! WPDRC_Options::protects( 'wpforms' ) ) {
			return;
		}

		$result = WPDRC_Service::verify( 'wpforms' );

		if ( is_wp_error( $result ) ) {
			wpforms()->process->errors[ $form_data['id'] ]['header'] = $result->get_error_message();
		}
	}
}

/**
 * Fluent Forms.
 */
class WPDRC_Fluent {

	/** @var WPDRC_Fluent|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * @return bool
	 */
	public static function available() {
		return defined( 'FLUENTFORM' ) || function_exists( 'wpFluentForm' );
	}

	private function __construct() {
		if ( ! self::available() ) {
			return;
		}

		add_filter( 'fluentform/rendering_form', array( $this, 'mark' ), 10, 1 );
		add_action( 'fluentform/before_insert_submission', array( $this, 'check' ), 10, 3 );
	}

	/**
	 * Fluent Forms renders its markup from a structure rather than a string, so
	 * the widget is printed after the form instead of injected into it.
	 *
	 * @param object $form Form object.
	 * @return object
	 */
	public function mark( $form ) {
		if ( WPDRC_Options::protects( 'fluentform' ) ) {
			add_action( 'fluentform/form_element_end', array( $this, 'widget' ), 10, 1 );
		}

		return $form;
	}

	/**
	 * @param object $form Form object.
	 */
	public function widget( $form ) {
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in WPDRC_Service::field().
		echo '<div class="wpdrc-field wpdrc-field--fluent">' . WPDRC_Service::field( array( 'form' => 'fluentform' ) ) . '</div>';
	}

	/**
	 * @param array $insert_data Submission data.
	 * @param array $data        Raw data.
	 * @param object $form       Form object.
	 */
	public function check( $insert_data, $data, $form ) {
		if ( ! WPDRC_Options::protects( 'fluentform' ) ) {
			return;
		}

		$result = WPDRC_Service::verify( 'fluentform' );

		if ( is_wp_error( $result ) ) {
			wp_send_json( array( 'errors' => array( 'recaptcha' => array( $result->get_error_message() ) ) ), 422 );
		}
	}
}

/**
 * Elementor Pro forms.
 */
class WPDRC_Elementor {

	/** @var WPDRC_Elementor|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * @return bool
	 */
	public static function available() {
		return defined( 'ELEMENTOR_PRO_VERSION' );
	}

	private function __construct() {
		if ( ! self::available() ) {
			return;
		}

		add_action( 'elementor_pro/forms/render/after', array( $this, 'widget' ), 10, 1 );
		add_action( 'elementor_pro/forms/validation', array( $this, 'check' ), 10, 2 );
	}

	/**
	 * @param object $form Form widget.
	 */
	public function widget( $form = null ) {
		if ( ! WPDRC_Options::protects( 'elementor' ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in WPDRC_Service::field().
		echo '<div class="wpdrc-field wpdrc-field--elementor">' . WPDRC_Service::field( array( 'form' => 'elementor' ) ) . '</div>';
	}

	/**
	 * @param object $record       Form record.
	 * @param object $ajax_handler Handler.
	 */
	public function check( $record, $ajax_handler ) {
		if ( ! WPDRC_Options::protects( 'elementor' ) ) {
			return;
		}

		$result = WPDRC_Service::verify( 'elementor' );

		if ( is_wp_error( $result ) && is_object( $ajax_handler ) && method_exists( $ajax_handler, 'add_error_message' ) ) {
			$ajax_handler->add_error_message( $result->get_error_message() );

			if ( method_exists( $ajax_handler, 'is_success' ) ) {
				$ajax_handler->is_success = false;
			}
		}
	}
}

/**
 * WooCommerce.
 */
class WPDRC_Woo {

	/** @var WPDRC_Woo|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * @return bool
	 */
	public static function available() {
		return class_exists( 'WooCommerce' );
	}

	private function __construct() {
		if ( ! self::available() ) {
			return;
		}

		if ( WPDRC_Options::protects( 'woo_login' ) ) {
			add_action( 'woocommerce_login_form', array( $this, 'login_widget' ) );
			add_action( 'woocommerce_register_form', array( $this, 'register_widget' ) );
			add_filter( 'woocommerce_process_login_errors', array( $this, 'check_login' ), 10, 1 );
			add_filter( 'woocommerce_registration_errors', array( $this, 'check_register' ), 10, 1 );
		}

		if ( WPDRC_Options::protects( 'woo_checkout' ) ) {
			add_action( 'woocommerce_review_order_before_submit', array( $this, 'checkout_widget' ) );
			add_action( 'woocommerce_checkout_process', array( $this, 'check_checkout' ) );
		}
	}

	public function login_widget() {
		$this->widget( 'woo_login' );
	}

	public function register_widget() {
		$this->widget( 'woo_login' );
	}

	public function checkout_widget() {
		$this->widget( 'woo_checkout' );
	}

	/**
	 * @param string $form Form key.
	 */
	private function widget( $form ) {
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in WPDRC_Service::field().
		echo '<div class="wpdrc-field wpdrc-field--woo">' . WPDRC_Service::field( array( 'form' => $form ) ) . '</div>';
	}

	/**
	 * @param WP_Error $errors Errors so far.
	 * @return WP_Error
	 */
	public function check_login( $errors ) {
		$result = WPDRC_Service::verify( 'woo_login' );

		if ( is_wp_error( $result ) ) {
			$errors->add( 'wpdrc', $result->get_error_message() );
		}

		return $errors;
	}

	/**
	 * @param WP_Error $errors Errors so far.
	 * @return WP_Error
	 */
	public function check_register( $errors ) {
		$result = WPDRC_Service::verify( 'woo_login' );

		if ( is_wp_error( $result ) ) {
			$errors->add( 'wpdrc', $result->get_error_message() );
		}

		return $errors;
	}

	public function check_checkout() {
		$result = WPDRC_Service::verify( 'woo_checkout' );

		if ( is_wp_error( $result ) && function_exists( 'wc_add_notice' ) ) {
			wc_add_notice( $result->get_error_message(), 'error' );
		}
	}
}

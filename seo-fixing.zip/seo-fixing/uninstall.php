<?php
/**
 * Runs when the plugin is deleted.
 *
 * @package SEO_Fixing
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

foreach ( array( 'seofix_settings', 'seofix_issues', 'seofix_link_sources', 'seofix_link_status', 'seofix_scan_state' ) as $option ) {
	delete_option( $option );
}

wp_clear_scheduled_hook( 'seofix_scheduled_scan' );

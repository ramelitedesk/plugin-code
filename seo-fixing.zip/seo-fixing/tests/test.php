<?php
/**
 * What the auditor reports, and — more importantly — what it does not.
 *
 * An SEO audit tool has one failure mode that destroys its usefulness: crying
 * wolf. A report listing forty things, six of which are wrong, does not get
 * worked through. It gets closed, and then the four real problems in it go
 * unfixed for a year.
 *
 * So roughly half the cases here assert that a *correct* page is reported
 * clean, including the constructions that naive checkers get wrong: alt="" on a
 * decorative image, an image link carrying its text in the alt, an aria-label,
 * a short contact page.
 *
 * @package SEO_Fixing
 */

if ( 'cli' !== PHP_SAPI ) {
	http_response_code( 404 );
	exit;
}

require __DIR__ . '/bootstrap.php';

$pass = 0;
$fail = 0;

/**
 * @param string $label Assertion.
 * @param bool   $ok    Result.
 * @param string $note  Shown on failure.
 */
function check( $label, $ok, $note = '' ) {
	global $pass, $fail;

	if ( $ok ) {
		$pass++;
		printf( "  ok    %s\n", $label );
		return;
	}

	$fail++;
	printf( "  FAIL  %s%s\n", $label, '' !== $note ? ' :: ' . $note : '' );
}

/**
 * @param string $html Page HTML.
 * @return string[] Issue ids.
 */
function ids( $html ) {
	$out = array();

	foreach ( ( new SEOFIX_Analyzer( $html, 'https://example.test/x/' ) )->issues() as $issue ) {
		$out[] = $issue['id'];
	}

	return $out;
}

/**
 * @param string $html Page HTML.
 * @param string $id   Issue id.
 * @return bool
 */
function flags( $html, $id ) {
	return in_array( $id, ids( $html ), true );
}

seofix_reset();

/* ================================================================ *
 * A correct page must come back clean
 * ================================================================ */

echo "\n=== A page with nothing wrong with it ===\n";

$good = seofix_page( '<h1>The Page Heading</h1><h2>A section</h2>' . seofix_filler() . '<img src="/a.jpg" alt="A described image">' );

check( 'a well-formed page reports nothing', array() === ids( $good ), implode( ', ', ids( $good ) ) );

echo "\n=== Constructions a naive checker gets wrong ===\n";

// alt="" is the CORRECT markup for a decorative image. Reporting it teaches
// people to write alt="image" on a spacer, which is actively worse.
$decorative = seofix_page( '<h1>Heading</h1>' . seofix_filler() . '<img src="/divider.png" alt="">' );
check( 'alt="" is not reported as missing alt', ! flags( $decorative, 'img_alt_missing' ) );

$image_link = seofix_page( '<h1>Heading</h1>' . seofix_filler() . '<a href="/x/"><img src="/logo.png" alt="Go to the home page"></a>' );
check( 'an image link with alt text is not "no readable text"', ! flags( $image_link, 'link_no_text' ) );

$aria = seofix_page( '<h1>Heading</h1>' . seofix_filler() . '<a href="/x/" aria-label="Close"><span class="icon"></span></a>' );
check( 'an aria-label counts as readable text', ! flags( $aria, 'link_no_text' ) );

$anchor = seofix_page( '<h1>Heading</h1>' . seofix_filler() . '<a href="#main">Skip</a>' );
check( 'an in-page anchor is not treated as a link to check', ! flags( $anchor, 'link_no_text' ) );

$ordered = seofix_page( '<h1>One</h1><h2>Two</h2><h3>Three</h3><h2>Two again</h2>' . seofix_filler() );
check( 'going back up a level is not a skip', ! flags( $ordered, 'heading_skip' ) );

/* ================================================================ *
 * Real problems must be caught
 * ================================================================ */

echo "\n=== Headings ===\n";

check( 'a page with no H1 is caught', flags( seofix_page( '<h2>Not a heading</h2>' . seofix_filler() ), 'h1_missing' ) );
check( 'two H1s are caught', flags( seofix_page( '<h1>One</h1><h1>Two</h1>' . seofix_filler() ), 'h1_multiple' ) );
check( 'an empty H1 is caught', flags( seofix_page( '<h1><img src="/logo.png" alt="Logo"></h1>' . seofix_filler() ), 'h1_empty' ) );
check( 'H1 → H3 is a skipped level', flags( seofix_page( '<h1>One</h1><h3>Three</h3>' . seofix_filler() ), 'heading_skip' ) );

echo "\n=== Head tags ===\n";

$no_title = str_replace( '<title>A perfectly reasonable page title here</title>', '', seofix_page( '<h1>H</h1>' . seofix_filler() ) );
check( 'a missing title is caught', flags( $no_title, 'title_missing' ) );

$long_title = str_replace( 'A perfectly reasonable page title here', str_repeat( 'Very long title ', 8 ), seofix_page( '<h1>H</h1>' . seofix_filler() ) );
check( 'an over-long title is caught', flags( $long_title, 'title_long' ) );

$no_desc = preg_replace( '/<meta name="description"[^>]*>/', '', seofix_page( '<h1>H</h1>' . seofix_filler() ) );
check( 'a missing meta description is caught', flags( $no_desc, 'description_missing' ) );

$no_canon = preg_replace( '/<link rel="canonical"[^>]*>/', '', seofix_page( '<h1>H</h1>' . seofix_filler() ) );
check( 'a missing canonical is caught', flags( $no_canon, 'canonical_missing' ) );
check( 'and it is marked as fixable', 'canonical' === array_column( ( new SEOFIX_Analyzer( $no_canon ) )->issues(), 'fix', 'id' )['canonical_missing'] );

$no_lang = seofix_page( '<h1>H</h1>' . seofix_filler(), '', '' );
check( 'a missing lang attribute is caught', flags( $no_lang, 'lang_missing' ) );

$no_viewport = preg_replace( '/<meta name="viewport"[^>]*>/', '', seofix_page( '<h1>H</h1>' . seofix_filler() ) );
check( 'a missing viewport is caught', flags( $no_viewport, 'viewport_missing' ) );

$noindex = seofix_page( '<h1>H</h1>' . seofix_filler(), '<meta name="robots" content="noindex, follow">' );
check( 'an accidental noindex is caught', flags( $noindex, 'noindex' ) );
check( 'and it is critical', SEOFIX_Analyzer::CRITICAL === array_column( ( new SEOFIX_Analyzer( $noindex ) )->issues(), 'severity', 'id' )['noindex'] );

echo "\n=== Images and links ===\n";

check( 'an image with no alt at all is caught', flags( seofix_page( '<h1>H</h1>' . seofix_filler() . '<img src="/a.jpg">' ), 'img_alt_missing' ) );
check( 'an empty link is caught', flags( seofix_page( '<h1>H</h1>' . seofix_filler() . '<a href="/x/"></a>' ), 'link_no_text' ) );
check( '"click here" is caught', flags( seofix_page( '<h1>H</h1>' . seofix_filler() . '<a href="/x/">click here</a>' ), 'link_generic_text' ) );
check( '"Read more →" is caught despite the arrow', flags( seofix_page( '<h1>H</h1>' . seofix_filler() . '<a href="/x/">Read more →</a>' ), 'link_generic_text' ) );
check( 'a descriptive link is not', ! flags( seofix_page( '<h1>H</h1>' . seofix_filler() . '<a href="/x/">Our returns policy</a>' ), 'link_generic_text' ) );

echo "\n=== Ratio and length ===\n";

$markup_heavy = seofix_page( '<h1>H</h1>' . str_repeat( '<div class="wrapper"><div class="inner"><div class="col"><span></span></div></div></div>', 200 ) . '<p>A few words.</p>' );
check( 'a page that is nearly all markup is caught', flags( $markup_heavy, 'text_html_ratio' ) );

check( 'a page with almost no text is caught', flags( seofix_page( '<h1>Hi</h1><p>Short.</p>' ), 'thin_content' ) );
check( 'a normal page is not', ! flags( $good, 'thin_content' ) );

// script and style content is text to the DOM. Counting it would make a page of
// jQuery look like a page of prose, and hide a genuinely thin page.
$scripty = seofix_page( '<h1>Hi</h1><p>Short.</p><script>' . str_repeat( 'var alpha = "some long string of javascript"; ', 60 ) . '</script>' );
check( 'script bodies do not count as readable text', flags( $scripty, 'thin_content' ), 'a page of JS must not pass as content' );

echo "\n=== Broken input ===\n";

check( 'a non-HTML response is reported, not crashed on', array( 'unparseable' ) === ids( '{"json":true}' ) );
check( 'an empty response is reported', array( 'unparseable' ) === ids( '' ) );
check( 'malformed HTML is still analysed', ! in_array( 'unparseable', ids( '<html><body><h1>Unclosed' ), true ) );

/* ================================================================ *
 * Links
 * ================================================================ */

echo "\n=== Link normalisation ===\n";

check( 'mailto is not a link to check', '' === SEOFIX_Links::normalise( 'mailto:a@b.test' ) );
check( 'tel is not a link to check', '' === SEOFIX_Links::normalise( 'tel:+441234' ) );
check( 'javascript: is not a link to check', '' === SEOFIX_Links::normalise( 'javascript:void(0)' ) );
check( 'a fragment is not a link to check', '' === SEOFIX_Links::normalise( '#section' ) );
check( 'a root-relative link becomes absolute', 'https://example.test/a/' === SEOFIX_Links::normalise( '/a/' ) );
check( 'a protocol-relative link becomes absolute', 'https://other.test/a' === SEOFIX_Links::normalise( '//other.test/a' ) );
check( 'the fragment is dropped', 'https://example.test/a/' === SEOFIX_Links::normalise( '/a/#top' ), SEOFIX_Links::normalise( '/a/#top' ) );
check( 'the query string is kept', 'https://example.test/a/?x=1' === SEOFIX_Links::normalise( '/a/?x=1' ) );
check( 'internal is recognised', SEOFIX_Links::is_internal( 'https://example.test/a/' ) );
check( 'external is recognised', ! SEOFIX_Links::is_internal( 'https://other.test/a/' ) );

echo "\n=== Collecting links from a page ===\n";

$page = seofix_page( '<h1>H</h1><a href="/one/">One</a><a href="mailto:a@b.test">Mail</a><a href="https://other.test/two">Two</a><a href="/one/#x">One again</a>' );
$found = SEOFIX_Links::collect( $page, 'https://example.test/src/' );

check( 'real links are collected', isset( $found['https://example.test/one/'] ) && isset( $found['https://other.test/two'] ) );
check( 'mailto is not collected', ! isset( $found['mailto:a@b.test'] ) );
check( 'the same URL twice is collected once', 2 === count( $found ), count( $found ) . ' collected' );
check( 'the source page is recorded', 'https://example.test/src/' === $found['https://example.test/one/'] );

echo "\n=== Broken link verdicts ===\n";

seofix_reset();

$GLOBALS['seofix_http'] = array(
	'https://example.test/ok/'      => array( 'code' => 200, 'message' => 'OK', 'body' => '' ),
	'https://example.test/gone/'    => array( 'code' => 404, 'message' => 'Not Found', 'body' => '' ),
	'https://other.test/redirects'  => array( 'code' => 301, 'message' => 'Moved', 'body' => '' ),
	'https://other.test/server-err' => array( 'code' => 500, 'message' => 'Server Error', 'body' => '' ),
);

$sources = array(
	'https://example.test/ok/'      => 'https://example.test/a/',
	'https://example.test/gone/'    => 'https://example.test/a/',
	'https://other.test/redirects'  => 'https://example.test/a/',
	'https://other.test/server-err' => 'https://example.test/a/',
	'https://nowhere.invalid/x'     => 'https://example.test/a/',
);

SEOFIX_Links::check( array_keys( $sources ) );

$broken = SEOFIX_Links::broken( $sources );
$by_url = array_column( $broken, 'code', 'url' );

check( 'a 200 is not broken', ! isset( $by_url['https://example.test/ok/'] ) );
check( 'a 301 is not broken', ! isset( $by_url['https://other.test/redirects'] ), 'a redirect is a working link' );
check( 'a 404 is broken', isset( $by_url['https://example.test/gone/'] ) );
check( 'a 500 is broken', isset( $by_url['https://other.test/server-err'] ) );
check( 'an unreachable host is reported separately', 0 === $by_url['https://nowhere.invalid/x'] );

$kinds = array_column( $broken, 'kind', 'url' );
check( 'a failed request is "unreachable", not a 404', 'unreachable' === $kinds['https://nowhere.invalid/x'] );
check( 'internal breakage is listed first', $broken[0]['internal'], 'yours to fix comes before someone else\'s' );

echo "\n=== A cached verdict is not re-requested ===\n";

$again = SEOFIX_Links::check( array_keys( $sources ) );
check( 'nothing was re-checked', 0 === $again['checked'], $again['checked'] . ' re-checked' );

SEOFIX_Links::forget();
check( 'forgetting clears the cache', array() === SEOFIX_Links::all() );

/* ================================================================ *
 * The report
 * ================================================================ */

echo "\n=== Grouping ===\n";

seofix_reset();
SEOFIX_Report::clear();

SEOFIX_Report::add( ( new SEOFIX_Analyzer( seofix_page( '<h2>x</h2>' . seofix_filler() ), 'https://example.test/one/' ) )->issues() );
SEOFIX_Report::add( ( new SEOFIX_Analyzer( seofix_page( '<h2>x</h2>' . seofix_filler() ), 'https://example.test/two/' ) )->issues() );

$stored = SEOFIX_Report::all();

check( 'the same issue on two pages is one row', isset( $stored['h1_missing'] ) && 2 === (int) $stored['h1_missing']['count'] );
check( 'both URLs are kept', 2 === count( $stored['h1_missing']['urls'] ) );

// A per-page label ("3 images with no alt") must not be presented as though it
// described every page once a second page reports the same issue.
SEOFIX_Report::clear();
SEOFIX_Report::add( ( new SEOFIX_Analyzer( seofix_page( '<h1>H</h1>' . seofix_filler() . '<img src="/a.jpg"><img src="/b.jpg">' ), 'https://example.test/one/' ) )->issues() );
check( 'one page keeps its specific count', false !== strpos( SEOFIX_Report::all()['img_alt_missing']['label'], '2' ) );

SEOFIX_Report::add( ( new SEOFIX_Analyzer( seofix_page( '<h1>H</h1>' . seofix_filler() . '<img src="/c.jpg">' ), 'https://example.test/two/' ) )->issues() );
check( 'two pages get a general label', false === strpos( SEOFIX_Report::all()['img_alt_missing']['label'], '2 images' ), SEOFIX_Report::all()['img_alt_missing']['label'] );

echo "\n=== Severity ordering ===\n";

SEOFIX_Report::clear();
SEOFIX_Report::add( ( new SEOFIX_Analyzer( seofix_page( '<h2>x</h2><p>Short.</p>' ), 'https://example.test/one/' ) )->issues() );

$order = array_keys( SEOFIX_Report::sorted() );
$first = SEOFIX_Report::sorted()[ $order[0] ];

check( 'the most severe issue is listed first', SEOFIX_Analyzer::CRITICAL === $first['severity'], $first['severity'] . ' — ' . $first['id'] );

/* ================================================================ *
 * The fixer
 * ================================================================ */

echo "\n=== Fixes ===\n";

seofix_reset();
SEOFIX_Options::install_defaults();

$fixer = SEOFIX_Fixer::instance();
$ref   = new ReflectionMethod( 'SEOFIX_Fixer', 'repair' );

$no_lang_page = seofix_page( '<h1>H</h1>' . seofix_filler(), '', '' );
$repaired     = $fixer->repair( $no_lang_page );

check( 'lang is added', false !== strpos( $repaired, 'lang="en-GB"' ) );
check( 'the page is not otherwise damaged', false !== strpos( $repaired, '<h1>H</h1>' ) );

$blank_target = seofix_page( '<h1>H</h1><a href="https://other.test" target="_blank">Out</a>' );
check( 'rel=noopener is added', false !== strpos( $fixer->repair( $blank_target ), 'noopener' ) );

$already = seofix_page( '<h1>H</h1><a href="https://other.test" target="_blank" rel="noopener">Out</a>' );
check( 'an existing noopener is not doubled', 1 === substr_count( $fixer->repair( $already ), 'noopener' ) );

// A tracking script containing target="_blank" as a string must not be
// rewritten as though it were markup.
$scripted = seofix_page( '<h1>H</h1><script>var a = \'<a target="_blank">x</a>\';</script>' );
check( 'inline JavaScript is left alone', false !== strpos( $fixer->repair( $scripted ), 'var a = \'<a target="_blank">x</a>\';' ) );

check( 'a non-HTML response passes straight through', '{"a":1}' === $fixer->repair( '{"a":1}' ) );
check( 'an empty response passes straight through', '' === $fixer->repair( '' ) );

echo "\n=== Alt text is filled in, never invented ===\n";

$GLOBALS['seofix_state']['alt'] = array( 7 => 'A cat asleep on a keyboard' );

$content = '<img src="/a.jpg" class="wp-image-7">';
check( 'library alt text is used', false !== strpos( $fixer->fill_alt_from_library( $content ), 'A cat asleep on a keyboard' ) );

$decorative_content = '<img src="/line.png" alt="">';
check( 'an intentional alt="" is never overwritten', $decorative_content === $fixer->fill_alt_from_library( $decorative_content ) );

$described = '<img src="/a.jpg" alt="Already described">';
check( 'existing alt text is never overwritten', $described === $fixer->fill_alt_from_library( $described ) );

$unknown = '<img src="/b.jpg">';
check( 'an image with no library entry gets an empty alt, not a guess', false !== strpos( $fixer->fill_alt_from_library( $unknown ), 'alt=""' ) );

echo "\n=== The H1 fix is conservative ===\n";

SEOFIX_Options::update( array( 'fix_h1' => 1 ) );

$without = seofix_page( '<div class="title">A Page Title</div>' . seofix_filler() );
$with_h1 = $fixer->repair( $without );
check( 'an H1 is added when there is none', 1 === substr_count( $with_h1, '<h1' ), substr_count( $with_h1, '<h1' ) . ' found' );

$has_one = seofix_page( '<h1>Already here</h1>' . seofix_filler() );
check( 'no second H1 is added when one exists', 1 === substr_count( $fixer->repair( $has_one ), '<h1' ) );

$GLOBALS['seofix_state']['singular'] = false;
check( 'nothing is added on an archive', 0 === substr_count( $fixer->repair( $without ), '<h1' ) );
$GLOBALS['seofix_state']['singular'] = true;

/* ------------------------------------------------------------------ */

printf( "\n----\npassed: %d   failed: %d\n", $pass, $fail );

exit( $fail > 0 ? 1 : 0 );

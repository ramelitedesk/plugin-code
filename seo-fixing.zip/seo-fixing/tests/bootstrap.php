<?php
/**
 * Minimal WordPress stand-in so the plugin can be exercised without a site.
 *
 * @package SEO_Fixing
 */

if ( 'cli' !== PHP_SAPI ) {
	http_response_code( 404 );
	exit;
}

error_reporting( E_ALL );
ini_set( 'display_errors', '1' );

define( 'ABSPATH', dirname( __DIR__ ) . '/' );
define( 'WEEK_IN_SECONDS', 604800 );
define( 'HOUR_IN_SECONDS', 3600 );
define( 'DAY_IN_SECONDS', 86400 );
define( 'MINUTE_IN_SECONDS', 60 );

define( 'SEOFIX_VERSION', '1.0.0' );
define( 'SEOFIX_DIR', dirname( __DIR__ ) . '/' );
define( 'SEOFIX_URL', 'https://example.test/wp-content/plugins/seo-fixing/' );
define( 'SEOFIX_FILE', SEOFIX_DIR . 'seo-fixing.php' );

$GLOBALS['seofix_options'] = array();
$GLOBALS['seofix_state']   = array( 'singular' => true, 'title' => 'A Page Title' );

function apply_filters( $tag, $value = null ) { return $value; }
function add_action() {}
function add_filter() {}
function do_action() {}
function has_action( $tag, $callback = false ) { return false; }
function __( $text, $domain = '' ) { return $text; }
function _n( $single, $plural, $number, $domain = '' ) { return 1 === (int) $number ? $single : $plural; }
function esc_html( $text ) { return htmlspecialchars( (string) $text, ENT_QUOTES, 'UTF-8' ); }
function esc_attr( $text ) { return htmlspecialchars( (string) $text, ENT_QUOTES, 'UTF-8' ); }
function esc_url( $url ) { return (string) $url; }
function home_url( $path = '/' ) { return 'https://example.test' . $path; }
function admin_url( $path = '' ) { return 'https://example.test/wp-admin/' . $path; }
function is_ssl() { return true; }
function is_admin() { return false; }
function is_404() { return false; }
function is_search() { return false; }
function is_feed() { return false; }
function is_embed() { return false; }
function is_singular() { return (bool) $GLOBALS['seofix_state']['singular']; }
function get_queried_object_id() { return 1; }
function get_the_title( $id = 0 ) { return $GLOBALS['seofix_state']['title']; }
function get_permalink( $id = 0 ) { return 'https://example.test/a-page/'; }
function get_bloginfo( $what = 'name' ) { return 'language' === $what ? 'en-GB' : 'Example'; }
function wp_parse_url( $url, $component = -1 ) { return parse_url( (string) $url, $component ); }
function wp_parse_args( $args, $defaults = array() ) { return array_merge( $defaults, (array) $args ); }
function number_format_i18n( $number, $decimals = 0 ) { return number_format( (float) $number, (int) $decimals ); }
function size_format( $bytes, $decimals = 0 ) { return round( $bytes / 1024, $decimals ) . ' KB'; }
function human_time_diff( $from, $to = 0 ) { return '5 minutes'; }
function wp_next_scheduled( $hook ) { return false; }
function wp_schedule_event() { return true; }
function wp_clear_scheduled_hook() { return true; }
function get_post_meta( $id, $key, $single = false ) { return $GLOBALS['seofix_state']['alt'][ $id ] ?? ''; }
function get_post_types( $args = array(), $output = 'names' ) { return array( 'post', 'page' ); }
function get_posts( $args = array() ) { return array( 1, 2 ); }
function sanitize_text_field( $value ) { return is_string( $value ) ? trim( strip_tags( $value ) ) : ''; }
function sanitize_key( $value ) { return preg_replace( '/[^a-z0-9_\-]/', '', strtolower( (string) $value ) ); }
function wp_unslash( $value ) { return $value; }
function is_wp_error( $thing ) { return $thing instanceof WP_Error; }

class WP_Error {
	private $message;
	public function __construct( $code = '', $message = '' ) { $this->message = $message; }
	public function get_error_message() { return $this->message; }
}

function get_option( $key, $default = false ) {
	return array_key_exists( $key, $GLOBALS['seofix_options'] ) ? $GLOBALS['seofix_options'][ $key ] : $default;
}
function update_option( $key, $value, $autoload = null ) { $GLOBALS['seofix_options'][ $key ] = $value; return true; }
function add_option( $key, $value, $x = '', $a = null ) { $GLOBALS['seofix_options'][ $key ] = $value; return true; }
function delete_option( $key ) { unset( $GLOBALS['seofix_options'][ $key ] ); return true; }

/*
 * HTTP is stubbed from a table the test fills in. Nothing here should ever make
 * a real request — a test suite that reaches the network is a test suite that
 * fails on an aeroplane.
 */
$GLOBALS['seofix_http'] = array();

function wp_remote_head( $url, $args = array() ) { return wp_remote_get( $url, $args ); }

function wp_remote_get( $url, $args = array() ) {
	$key = strtok( (string) $url, '?' );

	if ( ! isset( $GLOBALS['seofix_http'][ $key ] ) ) {
		return new WP_Error( 'http_request_failed', 'No stub for ' . $key );
	}

	return $GLOBALS['seofix_http'][ $key ];
}

function wp_remote_retrieve_response_code( $response ) { return is_array( $response ) ? (int) $response['code'] : 0; }
function wp_remote_retrieve_response_message( $response ) { return is_array( $response ) ? (string) $response['message'] : ''; }
function wp_remote_retrieve_body( $response ) { return is_array( $response ) ? (string) $response['body'] : ''; }

require_once SEOFIX_DIR . 'includes/class-seofix-options.php';
require_once SEOFIX_DIR . 'includes/class-seofix-analyzer.php';
require_once SEOFIX_DIR . 'includes/class-seofix-links.php';
require_once SEOFIX_DIR . 'includes/class-seofix-report.php';
require_once SEOFIX_DIR . 'includes/class-seofix-scan.php';
require_once SEOFIX_DIR . 'includes/class-seofix-fixer.php';

/**
 * @param string $body Body HTML, wrapped in a valid document.
 * @param string $head Extra head markup.
 * @param string $html Attributes for the html element.
 * @return string
 */
function seofix_page( $body, $head = '', $html = ' lang="en"' ) {
	return "<!doctype html>\n<html{$html}>\n<head>\n<meta charset=\"utf-8\">\n"
		. "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n"
		. "<title>A perfectly reasonable page title here</title>\n"
		. "<meta name=\"description\" content=\"" . str_repeat( 'A sensible description. ', 4 ) . "\">\n"
		. "<link rel=\"canonical\" href=\"https://example.test/a-page/\">\n"
		. $head
		. "</head>\n<body>\n" . $body . "\n</body>\n</html>";
}

/**
 * Enough prose to clear the thin-content and ratio floors, so a fixture only
 * reports the thing it is testing.
 *
 * @return string
 */
function seofix_filler() {
	return '<p>' . str_repeat( 'This paragraph exists so the page has enough readable text that the word count and the text ratio are not the thing being reported. ', 12 ) . '</p>';
}

/**
 * Reset stored state between cases.
 */
function seofix_reset() {
	$GLOBALS['seofix_options'] = array();
	$GLOBALS['seofix_http']    = array();

	foreach ( array( 'SEOFIX_Options' => 'cache', 'SEOFIX_Links' => 'cache' ) as $class => $property ) {
		$ref = new ReflectionProperty( $class, $property );
		$ref->setAccessible( true );
		$ref->setValue( null );
	}
}

<?php
/**
 * Plugin Name:       SEO Fixing
 * Plugin URI:        https://webart.technology/
 * Description:       Finds the SEO problems on a site and fixes the ones that can be fixed safely — missing H1, broken links, missing alt text, text-to-HTML ratio, titles and descriptions, canonical and lang. Audits the page a visitor actually receives, not what is stored in the database.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Ramakrishna
 * License:           GPL-2.0-or-later
 * Text Domain:       seo-fixing
 *
 * @package SEO_Fixing
 */

defined( 'ABSPATH' ) || exit;

define( 'SEOFIX_VERSION', '1.0.0' );
define( 'SEOFIX_FILE', __FILE__ );
define( 'SEOFIX_DIR', plugin_dir_path( __FILE__ ) );
define( 'SEOFIX_URL', plugin_dir_url( __FILE__ ) );

/**
 * This plugin does not do SEO. It repairs it.
 *
 * There is no keyword field here, no readability score, no traffic-light
 * telling you to use your focus phrase one more time. Those tools already
 * exist, several of them are better than anything that would be written here,
 * and none of them answer the question this one exists for:
 *
 *     "Something is wrong with this site. What, and where?"
 *
 * So it crawls the pages a visitor actually receives, lists what is broken,
 * groups it by problem rather than by page, and fixes the handful of things
 * that can be fixed without guessing what you meant.
 */
final class SEO_Fixing {

	/** @var SEO_Fixing|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->boot();
		}
		return self::$instance;
	}

	private function boot() {
		require_once SEOFIX_DIR . 'includes/class-seofix-options.php';
		require_once SEOFIX_DIR . 'includes/class-seofix-analyzer.php';
		require_once SEOFIX_DIR . 'includes/class-seofix-links.php';
		require_once SEOFIX_DIR . 'includes/class-seofix-report.php';
		require_once SEOFIX_DIR . 'includes/class-seofix-scan.php';
		require_once SEOFIX_DIR . 'includes/class-seofix-fixer.php';

		if ( is_admin() ) {
			require_once SEOFIX_DIR . 'admin/class-seofix-admin.php';
		}

		add_action( 'init', array( $this, 'load_textdomain' ), 1 );
		add_action( 'plugins_loaded', array( $this, 'init' ), 5 );

		register_activation_hook( SEOFIX_FILE, array( __CLASS__, 'on_activate' ) );
		register_deactivation_hook( SEOFIX_FILE, array( __CLASS__, 'on_deactivate' ) );
	}

	public function load_textdomain() {
		load_plugin_textdomain( 'seo-fixing', false, dirname( plugin_basename( SEOFIX_FILE ) ) . '/languages' );
	}

	public function init() {
		SEOFIX_Scan::instance();
		SEOFIX_Fixer::instance();

		if ( is_admin() && class_exists( 'SEOFIX_Admin' ) ) {
			SEOFIX_Admin::instance();
		}

		do_action( 'seofix_loaded', $this );
	}

	public static function on_activate() {
		require_once SEOFIX_DIR . 'includes/class-seofix-options.php';
		require_once SEOFIX_DIR . 'includes/class-seofix-scan.php';

		SEOFIX_Options::install_defaults();
		SEOFIX_Scan::schedule();
	}

	public static function on_deactivate() {
		wp_clear_scheduled_hook( 'seofix_scheduled_scan' );
	}
}

SEO_Fixing::instance();

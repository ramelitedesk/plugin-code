<?php
/**
 * What the last scan found.
 *
 * Stored grouped by issue type rather than by URL, because that is the shape of
 * the work. "Forty pages have no meta description" is one afternoon's job.
 * Forty separate rows, one per page, each saying the same thing, is the same
 * job made to look like forty.
 *
 * @package SEO_Fixing
 */

defined( 'ABSPATH' ) || exit;

class SEOFIX_Report {

	const ISSUES_OPTION = 'seofix_issues';
	const LINKS_OPTION  = 'seofix_link_sources';

	/** URLs listed per issue type before the rest are summarised as a count. */
	const SAMPLE = 25;

	/**
	 * @param array[] $issues Issues from the analyzer.
	 */
	public static function add( array $issues ) {
		$stored = self::all();

		foreach ( $issues as $issue ) {
			$id = (string) $issue['id'];

			if ( ! isset( $stored[ $id ] ) ) {
				$stored[ $id ] = array(
					'id'       => $id,
					'label'    => $issue['label'],
					'severity' => $issue['severity'],
					'detail'   => $issue['detail'],
					'fix'      => isset( $issue['fix'] ) ? $issue['fix'] : '',
					'count'    => 0,
					'urls'     => array(),
				);
			}

			$stored[ $id ]['count']++;

			if ( count( $stored[ $id ]['urls'] ) < self::SAMPLE ) {
				$stored[ $id ]['urls'][] = array(
					'url'   => $issue['url'],
					'label' => $issue['label'],
				);
			}

			/*
			 * The label carries a per-page number for several checks ("3 images
			 * with no alt"). Once a second page reports the same issue, the
			 * stored label has to become the general one or the summary claims
			 * every page has exactly three.
			 */
			if ( $stored[ $id ]['count'] > 1 ) {
				$stored[ $id ]['label'] = self::generic_label( $id, $stored[ $id ]['label'] );
			}
		}

		update_option( self::ISSUES_OPTION, $stored, false );
	}

	/**
	 * @param string $id      Issue id.
	 * @param string $current Current label.
	 * @return string
	 */
	private static function generic_label( $id, $current ) {
		$map = array(
			'img_alt_missing'   => __( 'Images with no alt attribute', 'seo-fixing' ),
			'link_no_text'      => __( 'Links with no readable text', 'seo-fixing' ),
			'link_generic_text' => __( 'Links that say nothing about their destination', 'seo-fixing' ),
			'heading_skip'      => __( 'Skipped heading levels', 'seo-fixing' ),
			'h1_multiple'       => __( 'More than one H1 on a page', 'seo-fixing' ),
			'title_long'        => __( 'Title tag too long', 'seo-fixing' ),
			'title_short'       => __( 'Title tag too short', 'seo-fixing' ),
			'description_long'  => __( 'Meta description too long', 'seo-fixing' ),
			'description_short' => __( 'Meta description too short', 'seo-fixing' ),
			'text_html_ratio'   => __( 'Low text-to-HTML ratio', 'seo-fixing' ),
			'thin_content'      => __( 'Very little text on the page', 'seo-fixing' ),
		);

		return isset( $map[ $id ] ) ? $map[ $id ] : $current;
	}

	/**
	 * @param array<string,string> $links URL => page it was found on.
	 */
	public static function add_links( array $links ) {
		$stored = self::links();

		update_option( self::LINKS_OPTION, array_slice( $links + $stored, 0, 5000, true ), false );
	}

	/**
	 * @return array Issue types, most severe first.
	 */
	public static function all() {
		$stored = get_option( self::ISSUES_OPTION, array() );

		return is_array( $stored ) ? $stored : array();
	}

	/**
	 * @return array<string,string>
	 */
	public static function links() {
		$stored = get_option( self::LINKS_OPTION, array() );

		return is_array( $stored ) ? $stored : array();
	}

	/**
	 * Issues in the order a person should work through them.
	 *
	 * @return array[]
	 */
	public static function sorted() {
		$issues = self::all();

		$weight = array(
			SEOFIX_Analyzer::CRITICAL => 0,
			SEOFIX_Analyzer::WARNING  => 1,
			SEOFIX_Analyzer::NOTICE   => 2,
		);

		uasort(
			$issues,
			static function ( $a, $b ) use ( $weight ) {
				$sa = isset( $weight[ $a['severity'] ] ) ? $weight[ $a['severity'] ] : 3;
				$sb = isset( $weight[ $b['severity'] ] ) ? $weight[ $b['severity'] ] : 3;

				// Same severity: the one affecting more pages first.
				return ( $sa <=> $sb ) ?: ( (int) $b['count'] <=> (int) $a['count'] );
			}
		);

		return $issues;
	}

	/**
	 * @return array{critical:int,warning:int,notice:int,pages:int}
	 */
	public static function summary() {
		$out = array( 'critical' => 0, 'warning' => 0, 'notice' => 0 );

		foreach ( self::all() as $issue ) {
			if ( isset( $out[ $issue['severity'] ] ) ) {
				$out[ $issue['severity'] ] += (int) $issue['count'];
			}
		}

		$state          = SEOFIX_Scan::state();
		$out['pages']   = (int) $state['fetched'];

		return $out;
	}

	public static function clear() {
		delete_option( self::ISSUES_OPTION );
		delete_option( self::LINKS_OPTION );
	}
}

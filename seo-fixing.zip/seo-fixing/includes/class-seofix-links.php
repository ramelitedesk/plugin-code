<?php
/**
 * Broken link detection.
 *
 * Two things make this different from the per-page checks, and both come from
 * the same fact: checking a link costs a network request.
 *
 * First, URLs are checked once for the whole site, not once per page. A footer
 * link appears on every page; checking it a thousand times would take a
 * thousand requests to learn one thing, and would look like a denial of service
 * to whoever is on the other end.
 *
 * Second, results are cached with an expiry, so a re-scan tomorrow does not
 * re-request every URL that was fine today.
 *
 * @package SEO_Fixing
 */

defined( 'ABSPATH' ) || exit;

class SEOFIX_Links {

	/** Cached per-URL verdicts. */
	const OPTION = 'seofix_link_status';

	/** How long a verdict is trusted. */
	const TTL = WEEK_IN_SECONDS;

	/** Verdicts kept before the oldest are dropped. */
	const MAX = 3000;

	/** @var array|null */
	private static $cache = null;

	/**
	 * Pull every link out of a page, so the scan can collect them as it goes.
	 *
	 * @param string $html Rendered HTML.
	 * @param string $page The URL this HTML came from, for reporting.
	 * @return array<string,string> URL => the page it was found on.
	 */
	public static function collect( $html, $page ) {
		$found = array();

		if ( ! preg_match_all( '/<a\b[^>]*\shref\s*=\s*(["\'])(.*?)\1/is', (string) $html, $matches ) ) {
			return $found;
		}

		foreach ( $matches[2] as $href ) {
			$url = self::normalise( html_entity_decode( $href, ENT_QUOTES, 'UTF-8' ) );

			if ( '' !== $url ) {
				$found[ $url ] = $page;
			}
		}

		return $found;
	}

	/**
	 * Turn an href into something worth requesting, or ''.
	 *
	 * @param string $href Raw href.
	 * @return string
	 */
	public static function normalise( $href ) {
		$href = trim( (string) $href );

		if ( '' === $href ) {
			return '';
		}

		// Fragments, and the schemes that are not fetchable at all.
		if ( 0 === strpos( $href, '#' ) ) {
			return '';
		}

		if ( preg_match( '#^(mailto|tel|sms|javascript|data|ftp|callto|whatsapp|skype):#i', $href ) ) {
			return '';
		}

		if ( 0 === strpos( $href, '//' ) ) {
			$href = ( is_ssl() ? 'https:' : 'http:' ) . $href;
		} elseif ( 0 === strpos( $href, '/' ) ) {
			$href = home_url( $href );
		}

		$parts = wp_parse_url( $href );

		if ( empty( $parts['scheme'] ) || ! in_array( strtolower( $parts['scheme'] ), array( 'http', 'https' ), true ) ) {
			return '';
		}

		// The fragment is not sent to the server, so two URLs differing only by
		// one are the same request.
		$clean = $parts['scheme'] . '://' . $parts['host']
			. ( isset( $parts['port'] ) ? ':' . (int) $parts['port'] : '' )
			. ( isset( $parts['path'] ) ? $parts['path'] : '/' )
			. ( isset( $parts['query'] ) ? '?' . $parts['query'] : '' );

		return $clean;
	}

	/**
	 * Check a batch of URLs, skipping any with a fresh verdict already.
	 *
	 * @param string[] $urls     URLs.
	 * @param float    $deadline microtime() to stop at. 0 for no limit.
	 * @return array{checked:int,skipped:int}
	 */
	public static function check( array $urls, $deadline = 0 ) {
		$known   = self::all();
		$now     = time();
		$checked = 0;
		$skipped = 0;

		foreach ( array_unique( $urls ) as $url ) {
			if ( isset( $known[ $url ] ) && ( $now - (int) $known[ $url ]['time'] ) < self::TTL ) {
				continue;
			}

			if ( $deadline > 0 && microtime( true ) >= $deadline ) {
				$skipped++;
				continue;
			}

			$known[ $url ] = self::request( $url ) + array( 'time' => $now );
			$checked++;
		}

		self::store( $known );

		return array( 'checked' => $checked, 'skipped' => $skipped );
	}

	/**
	 * One URL, asked as politely as possible.
	 *
	 * HEAD first, because it costs the far end almost nothing. Plenty of
	 * servers and CDNs refuse HEAD with a 405 or answer it wrongly, though, so
	 * anything that is not a clean answer is retried with a ranged GET rather
	 * than reported as broken. Reporting a working page as a 404 because its
	 * host dislikes HEAD is the classic failure of link checkers.
	 *
	 * @param string $url URL.
	 * @return array{code:int,message:string}
	 */
	private static function request( $url ) {
		$args = array(
			'timeout'     => (int) apply_filters( 'seofix_link_timeout', 8 ),
			'redirection' => 5,
			'sslverify'   => true,
			'user-agent'  => 'Mozilla/5.0 (compatible; SEO Fixing link check; +' . home_url( '/' ) . ')',
			'headers'     => array( 'Accept' => '*/*' ),
		);

		$response = wp_remote_head( $url, $args );
		$code     = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );

		if ( 0 === $code || $code >= 400 ) {
			// Ask for the first kilobyte only; enough to learn the status.
			$args['headers']['Range'] = 'bytes=0-1023';

			$response = wp_remote_get( $url, $args );
			$code     = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
		}

		if ( is_wp_error( $response ) ) {
			return array( 'code' => 0, 'message' => $response->get_error_message() );
		}

		return array( 'code' => $code, 'message' => (string) wp_remote_retrieve_response_message( $response ) );
	}

	/**
	 * Verdicts worth showing someone.
	 *
	 * A 0 means the request itself failed — DNS, TLS, a timeout. That is
	 * reported separately from a 404, because the two need different actions
	 * and because a 0 is quite often this server's fault rather than the
	 * link's.
	 *
	 * @param array<string,string> $sources URL => page it was found on.
	 * @return array[]
	 */
	public static function broken( array $sources ) {
		$known  = self::all();
		$broken = array();

		foreach ( $sources as $url => $page ) {
			if ( ! isset( $known[ $url ] ) ) {
				continue;
			}

			$code = (int) $known[ $url ]['code'];

			if ( $code > 0 && $code < 400 ) {
				continue;
			}

			$broken[] = array(
				'url'     => $url,
				'found_on' => $page,
				'code'    => $code,
				'message' => (string) $known[ $url ]['message'],
				'kind'    => 0 === $code ? 'unreachable' : 'error',
				'internal' => self::is_internal( $url ),
			);
		}

		usort(
			$broken,
			static function ( $a, $b ) {
				// Internal first: they are yours to fix, and they are the ones
				// costing you something.
				return ( $b['internal'] <=> $a['internal'] ) ?: strcmp( $a['url'], $b['url'] );
			}
		);

		return $broken;
	}

	/**
	 * @param string $url URL.
	 * @return bool
	 */
	public static function is_internal( $url ) {
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		$test = wp_parse_url( $url, PHP_URL_HOST );

		return $test && $host && strtolower( $test ) === strtolower( $host );
	}

	/**
	 * @return array
	 */
	public static function all() {
		if ( null === self::$cache ) {
			$stored      = get_option( self::OPTION, array() );
			self::$cache = is_array( $stored ) ? $stored : array();
		}

		return self::$cache;
	}

	/**
	 * @param array $verdicts Verdicts.
	 */
	private static function store( array $verdicts ) {
		if ( count( $verdicts ) > self::MAX ) {
			uasort(
				$verdicts,
				static function ( $a, $b ) {
					return (int) $b['time'] <=> (int) $a['time'];
				}
			);
			$verdicts = array_slice( $verdicts, 0, self::MAX, true );
		}

		self::$cache = $verdicts;

		update_option( self::OPTION, $verdicts, false );
	}

	public static function forget() {
		self::$cache = array();
		delete_option( self::OPTION );
	}
}

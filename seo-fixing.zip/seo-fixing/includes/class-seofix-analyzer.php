<?php
/**
 * Everything that can be judged from one rendered page.
 *
 * The whole plugin turns on a decision made here: issues are read from the
 * *rendered* HTML, not from post_content.
 *
 * It would be far easier to read post_content. No HTTP, no timeouts, no
 * loopback to fail. It would also be wrong on most sites, because the thing
 * people call "the H1" is almost never in the content — it is printed by the
 * theme template from the post title. Auditing post_content reports "H1
 * missing" on a site whose every page has a perfectly good H1, and a report
 * that is wrong about the first thing you check is a report nobody reads again.
 *
 * So this takes the bytes a visitor receives, and says only what those bytes
 * support.
 *
 * @package SEO_Fixing
 */

defined( 'ABSPATH' ) || exit;

class SEOFIX_Analyzer {

	/* Severities. */
	const CRITICAL = 'critical';
	const WARNING  = 'warning';
	const NOTICE   = 'notice';

	/** @var DOMDocument|null */
	private $dom = null;

	/** @var DOMXPath|null */
	private $xpath = null;

	/** @var string Raw HTML. */
	private $html = '';

	/** @var string The URL this HTML came from. */
	private $url = '';

	/**
	 * @param string $html Rendered page HTML.
	 * @param string $url  Where it came from.
	 */
	public function __construct( $html, $url = '' ) {
		$this->html = (string) $html;
		$this->url  = (string) $url;
	}

	/**
	 * Every issue found on this page.
	 *
	 * @return array[] Each: id, label, severity, detail, fixable.
	 */
	public function issues() {
		if ( ! $this->parse() ) {
			return array(
				$this->issue(
					'unparseable',
					__( 'Page could not be read', 'seo-fixing' ),
					self::WARNING,
					__( 'The response was not HTML, or was too broken to parse. Nothing else could be checked on this URL.', 'seo-fixing' )
				),
			);
		}

		$issues = array();

		foreach ( array( 'check_headings', 'check_title', 'check_description', 'check_canonical', 'check_lang', 'check_images', 'check_links', 'check_ratio', 'check_content_length', 'check_indexability', 'check_viewport' ) as $check ) {
			foreach ( (array) $this->$check() as $issue ) {
				$issues[] = $issue;
			}
		}

		return $issues;
	}

	/* ------------------------------------------------------------------ *
	 * Checks
	 * ------------------------------------------------------------------ */

	/**
	 * The H1, and the heading order beneath it.
	 *
	 * @return array[]
	 */
	private function check_headings() {
		$issues = array();
		$h1s    = $this->xpath->query( '//h1' );
		$count  = $h1s->length;

		if ( 0 === $count ) {
			$issues[] = $this->issue(
				'h1_missing',
				__( 'No H1 on the page', 'seo-fixing' ),
				self::CRITICAL,
				__( 'Nothing on this page says what it is about in a way a machine can read. Search engines and screen readers both use the H1 as the page\'s name.', 'seo-fixing' ),
				array( 'fix' => 'h1_from_title' )
			);
		} elseif ( $count > 1 ) {
			$texts = array();

			foreach ( $h1s as $node ) {
				$text = $this->text( $node );
				if ( '' !== $text ) {
					$texts[] = $text;
				}
			}

			$issues[] = $this->issue(
				'h1_multiple',
				sprintf(
					/* translators: %d: heading count. */
					__( '%d H1 headings on one page', 'seo-fixing' ),
					$count
				),
				self::WARNING,
				sprintf(
					/* translators: %s: comma-separated heading text. */
					__( 'A page has one subject, so it has one H1. These are competing: %s', 'seo-fixing' ),
					implode( ' · ', array_slice( $texts, 0, 4 ) )
				)
			);
		}

		// An empty H1 is worse than a missing one: it looks correct to a quick
		// glance and says nothing.
		if ( $count > 0 && '' === $this->text( $h1s->item( 0 ) ) ) {
			$issues[] = $this->issue(
				'h1_empty',
				__( 'The H1 is empty', 'seo-fixing' ),
				self::CRITICAL,
				__( 'There is an H1 element, but it contains no text — usually a heading holding only an image or an icon.', 'seo-fixing' )
			);
		}

		$issues = array_merge( $issues, $this->check_heading_order() );

		return $issues;
	}

	/**
	 * Headings that skip a level.
	 *
	 * @return array[]
	 */
	private function check_heading_order() {
		$nodes  = $this->xpath->query( '//h1|//h2|//h3|//h4|//h5|//h6' );
		$last   = 0;
		$skips  = array();

		foreach ( $nodes as $node ) {
			$level = (int) substr( $node->nodeName, 1 );

			if ( $last > 0 && $level > $last + 1 ) {
				$skips[] = sprintf( 'H%d → H%d (%s)', $last, $level, $this->shorten( $this->text( $node ), 40 ) );
			}

			$last = $level;
		}

		if ( ! $skips ) {
			return array();
		}

		return array(
			$this->issue(
				'heading_skip',
				sprintf(
					/* translators: %d: number of skips. */
					_n( '%d skipped heading level', '%d skipped heading levels', count( $skips ), 'seo-fixing' ),
					count( $skips )
				),
				self::NOTICE,
				sprintf(
					/* translators: %s: list of skips. */
					__( 'The outline jumps a level, which breaks how screen readers navigate the page: %s', 'seo-fixing' ),
					implode( ' · ', array_slice( $skips, 0, 4 ) )
				)
			),
		);
	}

	/**
	 * @return array[]
	 */
	private function check_title() {
		$title = $this->first_text( '//head/title' );
		$length = mb_strlen( $title );

		if ( '' === $title ) {
			return array(
				$this->issue(
					'title_missing',
					__( 'No title tag', 'seo-fixing' ),
					self::CRITICAL,
					__( 'This is the line shown in search results and in the browser tab. Without it, the search engine invents one.', 'seo-fixing' )
				),
			);
		}

		if ( $length > 65 ) {
			return array(
				$this->issue(
					'title_long',
					sprintf(
						/* translators: %d: character count. */
						__( 'Title is %d characters', 'seo-fixing' ),
						$length
					),
					self::NOTICE,
					sprintf(
						/* translators: %s: the title. */
						__( 'It will be cut off in search results at roughly 60. The end is the part that disappears: %s', 'seo-fixing' ),
						$title
					)
				),
			);
		}

		if ( $length < 15 ) {
			return array(
				$this->issue(
					'title_short',
					sprintf(
						/* translators: %d: character count. */
						__( 'Title is only %d characters', 'seo-fixing' ),
						$length
					),
					self::NOTICE,
					sprintf(
						/* translators: %s: the title. */
						__( 'Too short to describe the page: %s', 'seo-fixing' ),
						$title
					)
				),
			);
		}

		return array();
	}

	/**
	 * @return array[]
	 */
	private function check_description() {
		$description = $this->attribute( '//head/meta[translate(@name,"DESCRIPTION","description")="description"]', 'content' );

		if ( '' === trim( $description ) ) {
			return array(
				$this->issue(
					'description_missing',
					__( 'No meta description', 'seo-fixing' ),
					self::WARNING,
					__( 'The search engine will cut two lines out of the page body instead, and they are rarely the two lines you would have chosen.', 'seo-fixing' )
				),
			);
		}

		$length = mb_strlen( $description );

		if ( $length > 165 ) {
			return array(
				$this->issue(
					'description_long',
					sprintf(
						/* translators: %d: character count. */
						__( 'Meta description is %d characters', 'seo-fixing' ),
						$length
					),
					self::NOTICE,
					__( 'It will be truncated at roughly 160.', 'seo-fixing' )
				),
			);
		}

		if ( $length < 50 ) {
			return array(
				$this->issue(
					'description_short',
					sprintf(
						/* translators: %d: character count. */
						__( 'Meta description is only %d characters', 'seo-fixing' ),
						$length
					),
					self::NOTICE,
					__( 'There is room for around 160. This is leaving most of it unused.', 'seo-fixing' )
				),
			);
		}

		return array();
	}

	/**
	 * @return array[]
	 */
	private function check_canonical() {
		$canonical = $this->attribute( '//head/link[@rel="canonical"]', 'href' );

		if ( '' !== trim( $canonical ) ) {
			return array();
		}

		return array(
			$this->issue(
				'canonical_missing',
				__( 'No canonical URL', 'seo-fixing' ),
				self::WARNING,
				__( 'Without one, the same page reached through a tracking parameter, a trailing slash or an http:// link can be treated as several different pages competing with each other.', 'seo-fixing' ),
				array( 'fix' => 'canonical' )
			),
		);
	}

	/**
	 * @return array[]
	 */
	private function check_lang() {
		$lang = $this->attribute( '//html', 'lang' );

		if ( '' !== trim( $lang ) ) {
			return array();
		}

		return array(
			$this->issue(
				'lang_missing',
				__( 'The html element has no lang attribute', 'seo-fixing' ),
				self::WARNING,
				__( 'Screen readers use it to pick a pronunciation, and search engines use it to decide which country to show the page in.', 'seo-fixing' ),
				array( 'fix' => 'lang' )
			),
		);
	}

	/**
	 * @return array[]
	 */
	private function check_viewport() {
		$viewport = $this->attribute( '//head/meta[@name="viewport"]', 'content' );

		if ( '' !== trim( $viewport ) ) {
			return array();
		}

		return array(
			$this->issue(
				'viewport_missing',
				__( 'No viewport meta tag', 'seo-fixing' ),
				self::CRITICAL,
				__( 'Mobile browsers will render this page at desktop width and zoom out. It is an automatic mobile-usability failure.', 'seo-fixing' )
			),
		);
	}

	/**
	 * Images with no alt attribute at all.
	 *
	 * alt="" is deliberately NOT reported. It is the correct markup for a
	 * decorative image and the correct thing for a screen reader to skip.
	 * Treating it as a fault is how these tools train people to write
	 * alt="image" on a spacer gif, which is worse than nothing.
	 *
	 * @return array[]
	 */
	private function check_images() {
		$missing = array();

		foreach ( $this->xpath->query( '//img' ) as $img ) {
			if ( $img->hasAttribute( 'alt' ) ) {
				continue;
			}

			$src = $img->getAttribute( 'src' );

			if ( '' === $src ) {
				$src = $img->getAttribute( 'data-src' );
			}

			$missing[] = $this->shorten( basename( (string) wp_parse_url( $src, PHP_URL_PATH ) ), 50 );
		}

		if ( ! $missing ) {
			return array();
		}

		return array(
			$this->issue(
				'img_alt_missing',
				sprintf(
					/* translators: %d: image count. */
					_n( '%d image with no alt attribute', '%d images with no alt attribute', count( $missing ), 'seo-fixing' ),
					count( $missing )
				),
				self::WARNING,
				sprintf(
					/* translators: %s: filenames. */
					__( 'Not the same as alt="", which is correct for decoration and is not reported here. These have no alt at all: %s', 'seo-fixing' ),
					implode( ', ', array_slice( $missing, 0, 6 ) )
				),
				array( 'fix' => 'alt', 'count' => count( $missing ) )
			),
		);
	}

	/**
	 * Links worth looking at: empty ones, and ones whose text says nothing.
	 *
	 * Whether a link is *broken* is not decided here — that needs a request per
	 * URL and is done once, site-wide, by SEOFIX_Links. Doing it per page would
	 * check the same footer link on every page of the site.
	 *
	 * @return array[]
	 */
	private function check_links() {
		$issues  = array();
		$empty   = 0;
		$generic = array();

		$vague = array( 'click here', 'here', 'read more', 'more', 'link', 'this', 'this page', 'learn more', 'continue' );

		foreach ( $this->xpath->query( '//a[@href]' ) as $link ) {
			$href = trim( $link->getAttribute( 'href' ) );

			if ( '' === $href || '#' === $href ) {
				continue;
			}

			$text = $this->text( $link );

			if ( '' === $text ) {
				// An image link with alt text is perfectly accessible.
				$alt = '';

				foreach ( $link->getElementsByTagName( 'img' ) as $img ) {
					$alt .= $img->getAttribute( 'alt' );
				}

				if ( '' === trim( $alt ) && '' === trim( $link->getAttribute( 'aria-label' ) ) ) {
					$empty++;
				}
				continue;
			}

			/*
			 * Trailing decoration is stripped before the comparison, because
			 * "Read more →" and "Read more" are the same link text as far as a
			 * reader is concerned. A byte-based trim() cannot do this: the
			 * arrow is three bytes, and trimming it by byte would either miss
			 * it or cut a character in half.
			 */
			$bare = preg_replace( '/^[\s\p{P}\p{S}]+|[\s\p{P}\p{S}]+$/u', '', $text );

			if ( null !== $bare && in_array( mb_strtolower( $bare ), $vague, true ) ) {
				$generic[] = $text;
			}
		}

		if ( $empty > 0 ) {
			$issues[] = $this->issue(
				'link_no_text',
				sprintf(
					/* translators: %d: link count. */
					_n( '%d link with no readable text', '%d links with no readable text', $empty, 'seo-fixing' ),
					$empty
				),
				self::WARNING,
				__( 'No text, no image alt, no aria-label. A screen reader announces these as "link" and nothing else.', 'seo-fixing' )
			);
		}

		if ( $generic ) {
			$issues[] = $this->issue(
				'link_generic_text',
				sprintf(
					/* translators: %d: link count. */
					_n( '%d link says nothing about its destination', '%d links say nothing about their destination', count( $generic ), 'seo-fixing' ),
					count( $generic )
				),
				self::NOTICE,
				sprintf(
					/* translators: %s: the link texts. */
					__( 'Link text is one of the strongest signals about the page being linked to, and these spend it on nothing: %s', 'seo-fixing' ),
					implode( ', ', array_unique( array_slice( $generic, 0, 6 ) ) )
				)
			);
		}

		return $issues;
	}

	/**
	 * Text-to-HTML ratio.
	 *
	 * Reported as a notice and never higher, because on its own it means very
	 * little. A low ratio is a symptom — of a builder emitting six wrapper divs
	 * per element, or of inline CSS that belongs in a file — and the ratio is
	 * how you notice, not what you fix.
	 *
	 * @return array[]
	 */
	private function check_ratio() {
		$bytes = strlen( $this->html );

		if ( $bytes < 1024 ) {
			return array();
		}

		$text  = $this->visible_text();
		$ratio = ( strlen( $text ) / $bytes ) * 100;

		$floor = (float) apply_filters( 'seofix_min_text_ratio', 10 );

		if ( $ratio >= $floor ) {
			return array();
		}

		return array(
			$this->issue(
				'text_html_ratio',
				sprintf(
					/* translators: %s: percentage. */
					__( 'Text is %s%% of the page', 'seo-fixing' ),
					number_format_i18n( $ratio, 1 )
				),
				self::NOTICE,
				sprintf(
					/* translators: 1: text size, 2: page size. */
					__( '%1$s of readable text inside %2$s of markup. That is usually inline CSS or JavaScript that belongs in a file, or a builder emitting several wrapper elements per visible thing.', 'seo-fixing' ),
					size_format( strlen( $text ) ),
					size_format( $bytes )
				),
				array( 'ratio' => round( $ratio, 1 ) )
			),
		);
	}

	/**
	 * @return array[]
	 */
	private function check_content_length() {
		$words = str_word_count( $this->visible_text() );
		$floor = (int) apply_filters( 'seofix_min_words', 150 );

		if ( $words >= $floor ) {
			return array();
		}

		return array(
			$this->issue(
				'thin_content',
				sprintf(
					/* translators: %d: word count. */
					__( 'Only %d words of text', 'seo-fixing' ),
					$words
				),
				self::NOTICE,
				__( 'Short is not automatically bad — a contact page is short and should be. This is worth looking at only if the page was meant to say something.', 'seo-fixing' ),
				array( 'words' => $words )
			),
		);
	}

	/**
	 * @return array[]
	 */
	private function check_indexability() {
		$robots = strtolower( $this->attribute( '//head/meta[translate(@name,"ROBTS","robts")="robots"]', 'content' ) );

		if ( false === strpos( $robots, 'noindex' ) ) {
			return array();
		}

		return array(
			$this->issue(
				'noindex',
				__( 'This page tells search engines not to index it', 'seo-fixing' ),
				self::CRITICAL,
				sprintf(
					/* translators: %s: the robots meta value. */
					__( 'meta robots is "%s". If that was not deliberate, this page cannot appear in search results at all and nothing else on this list matters for it.', 'seo-fixing' ),
					$robots
				)
			),
		);
	}

	/* ------------------------------------------------------------------ *
	 * Plumbing
	 * ------------------------------------------------------------------ */

	/**
	 * @return bool Whether the HTML could be parsed.
	 */
	private function parse() {
		if ( null !== $this->dom ) {
			return true;
		}

		if ( '' === trim( $this->html ) || false === stripos( $this->html, '<html' ) ) {
			return false;
		}

		$previous = libxml_use_internal_errors( true );

		$dom = new DOMDocument();

		/*
		 * The encoding hint matters. Without it DOMDocument assumes ISO-8859-1
		 * and mangles every non-ASCII character, which turns a page of correct
		 * German into a page of mojibake and a word count that is wrong.
		 */
		$loaded = $dom->loadHTML(
			'<?xml encoding="UTF-8">' . $this->html,
			defined( 'LIBXML_NOWARNING' ) ? LIBXML_NOWARNING | LIBXML_NOERROR : 0
		);

		libxml_clear_errors();
		libxml_use_internal_errors( $previous );

		if ( ! $loaded ) {
			return false;
		}

		$this->dom   = $dom;
		$this->xpath = new DOMXPath( $dom );

		return true;
	}

	/**
	 * Text a person would actually read.
	 *
	 * script and style content is text as far as the DOM is concerned, and
	 * counting it would make a page of jQuery look like a page of prose.
	 *
	 * @return string
	 */
	private function visible_text() {
		$body = $this->xpath->query( '//body' )->item( 0 );

		if ( ! $body ) {
			return '';
		}

		$clone = $body->cloneNode( true );
		$inner = new DOMXPath( $this->dom );

		foreach ( iterator_to_array( $inner->query( './/script|.//style|.//noscript|.//template', $clone ) ) as $node ) {
			if ( $node->parentNode ) {
				$node->parentNode->removeChild( $node );
			}
		}

		return trim( preg_replace( '/\s+/u', ' ', (string) $clone->textContent ) );
	}

	/**
	 * @param DOMNode|null $node Node.
	 * @return string
	 */
	private function text( $node ) {
		if ( ! $node ) {
			return '';
		}

		return trim( (string) preg_replace( '/\s+/u', ' ', (string) $node->textContent ) );
	}

	/**
	 * @param string $query XPath.
	 * @return string
	 */
	private function first_text( $query ) {
		$nodes = $this->xpath->query( $query );

		return $nodes->length ? $this->text( $nodes->item( 0 ) ) : '';
	}

	/**
	 * @param string $query XPath.
	 * @param string $name  Attribute.
	 * @return string
	 */
	private function attribute( $query, $name ) {
		$nodes = $this->xpath->query( $query );

		if ( ! $nodes->length ) {
			return '';
		}

		$node = $nodes->item( 0 );

		return $node instanceof DOMElement ? (string) $node->getAttribute( $name ) : '';
	}

	/**
	 * @param string $text  Text.
	 * @param int    $limit Length.
	 * @return string
	 */
	private function shorten( $text, $limit ) {
		$text = (string) $text;

		return mb_strlen( $text ) > $limit ? mb_substr( $text, 0, $limit ) . '…' : $text;
	}

	/**
	 * @param string $id       Machine id.
	 * @param string $label    One-line summary.
	 * @param string $severity critical|warning|notice.
	 * @param string $detail   Why it matters.
	 * @param array  $extra    Extra data, e.g. a fix key.
	 * @return array
	 */
	private function issue( $id, $label, $severity, $detail, array $extra = array() ) {
		return array_merge(
			array(
				'id'       => $id,
				'label'    => $label,
				'severity' => $severity,
				'detail'   => $detail,
				'url'      => $this->url,
			),
			$extra
		);
	}
}

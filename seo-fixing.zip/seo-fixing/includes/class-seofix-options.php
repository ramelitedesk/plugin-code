<?php
/**
 * Settings and defaults.
 *
 * @package SEO_Fixing
 */

defined( 'ABSPATH' ) || exit;

class SEOFIX_Options {

	const OPTION = 'seofix_settings';

	const SCHEMA_VERSION = 1;

	/** @var array|null */
	private static $cache = null;

	/**
	 * @return array
	 */
	public static function defaults() {
		return apply_filters(
			'seofix_default_settings',
			array(
				'_schema'          => self::SCHEMA_VERSION,

				/*
				 * The three fixes that cannot be wrong.
				 *
				 * Each of them adds something the page was missing without
				 * changing anything the page already said, so there is no
				 * judgement call to get wrong and no reason to make someone opt
				 * in to having a lang attribute.
				 */
				'fix_lang'         => 1,
				'fix_alt'          => 1,
				'fix_noopener'     => 1,

				// Adds a tag only when nothing else has printed one, so it is
				// safe — but it is the one that interacts with other SEO
				// plugins, so it is worth being able to switch off.
				'fix_canonical'    => 1,

				/*
				 * Off by default, and it should be.
				 *
				 * Inserting a heading changes what the page looks like. On a
				 * theme that already shows the title as a styled div, this adds
				 * a second visible one. It is offered because "no H1" is a real
				 * problem with no other automatic answer, not because it is
				 * safe to leave running unattended.
				 */
				'fix_h1'           => 0,

				// Scanning.
				'scan_schedule'    => 'weekly',
				'check_links'      => 1,
				'check_external'   => 1,
			)
		);
	}

	/**
	 * @return array
	 */
	public static function all() {
		if ( null === self::$cache ) {
			$saved       = get_option( self::OPTION, array() );
			self::$cache = wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
		}

		return self::$cache;
	}

	/**
	 * @param string $key     Setting key.
	 * @param mixed  $default Fallback.
	 * @return mixed
	 */
	public static function get( $key, $default = null ) {
		$all   = self::all();
		$value = array_key_exists( $key, $all ) ? $all[ $key ] : $default;

		return apply_filters( 'seofix_option', $value, $key );
	}

	/**
	 * @param string $key Setting key.
	 * @return bool
	 */
	public static function enabled( $key ) {
		return (bool) self::get( $key, false );
	}

	/**
	 * @param array $values Values to persist.
	 */
	public static function update( array $values ) {
		$clean = wp_parse_args( $values, self::all() );

		update_option( self::OPTION, $clean );

		self::$cache = null;
	}

	public static function install_defaults() {
		if ( false === get_option( self::OPTION, false ) ) {
			add_option( self::OPTION, self::defaults() );
		}
	}
}

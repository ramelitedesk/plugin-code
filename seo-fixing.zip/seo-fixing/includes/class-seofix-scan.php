<?php
/**
 * Walking the site.
 *
 * A scan fetches each public URL over HTTP and hands the response to the
 * analyzer. Two consequences follow from that, and both shape this file.
 *
 * It is slow. A hundred pages is a hundred requests, and a shared host will
 * kill the PHP process long before that finishes. So a scan runs in batches
 * against a time budget, stores a cursor, and picks up where it stopped —
 * and the screen says how far it got rather than pretending it finished.
 *
 * It needs the site to be able to reach itself. Plenty of installs cannot:
 * local development, staging behind basic auth, hosts that block outbound
 * requests to their own address. When that happens the scan reports the
 * connection failure as a connection failure. Saying "no issues found" because
 * nothing could be fetched would be the most damaging thing this plugin could
 * do — it would be a clean bill of health with no examination behind it.
 *
 * @package SEO_Fixing
 */

defined( 'ABSPATH' ) || exit;

class SEOFIX_Scan {

	const STATE_OPTION = 'seofix_scan_state';

	/** @var SEOFIX_Scan|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'seofix_scheduled_scan', array( $this, 'run_scheduled' ) );
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( 'seofix_scheduled_scan' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'weekly', 'seofix_scheduled_scan' );
		}
	}

	public function run_scheduled() {
		self::start();

		// Cron has no browser waiting on it, so let it run until it finishes or
		// runs out of time on its own terms.
		while ( ! self::state()['done'] ) {
			$before = self::state()['cursor'];

			self::step();

			if ( self::state()['cursor'] <= $before ) {
				break; // Made no progress; stop rather than spin.
			}
		}
	}

	/* ------------------------------------------------------------------ *
	 * The queue
	 * ------------------------------------------------------------------ */

	/**
	 * Every URL worth auditing.
	 *
	 * Ordered so the pages that matter come first: the front page, then posts
	 * and pages by recency. A scan that runs out of time has then spent it on
	 * the URLs someone actually visits.
	 *
	 * @return string[]
	 */
	public static function urls() {
		$urls = array( home_url( '/' ) );

		$types = (array) apply_filters(
			'seofix_scan_post_types',
			array_values( get_post_types( array( 'public' => true, 'show_ui' => true ), 'names' ) )
		);

		$types = array_diff( $types, array( 'attachment' ) );

		if ( $types ) {
			$posts = get_posts(
				array(
					'post_type'        => $types,
					'post_status'      => 'publish',
					'numberposts'      => (int) apply_filters( 'seofix_scan_max_urls', 300 ),
					'orderby'          => 'modified',
					'order'            => 'DESC',
					'fields'           => 'ids',
					'suppress_filters' => false,
				)
			);

			foreach ( $posts as $id ) {
				$link = get_permalink( $id );

				if ( $link ) {
					$urls[] = $link;
				}
			}
		}

		/**
		 * @param string[] $urls URLs to audit.
		 */
		return array_values( array_unique( (array) apply_filters( 'seofix_scan_urls', $urls ) ) );
	}

	/* ------------------------------------------------------------------ *
	 * Running
	 * ------------------------------------------------------------------ */

	/**
	 * Begin a scan. Clears the previous results.
	 *
	 * @return array The new state.
	 */
	public static function start() {
		$urls = self::urls();

		$state = array(
			'started'  => time(),
			'urls'     => $urls,
			'cursor'   => 0,
			'done'     => empty( $urls ),
			'fetched'  => 0,
			'failed'   => 0,
			'first_error' => '',
		);

		update_option( self::STATE_OPTION, $state, false );

		SEOFIX_Report::clear();

		return $state;
	}

	/**
	 * Fetch and analyse the next batch.
	 *
	 * @return array The state after the batch.
	 */
	public static function step() {
		$state = self::state();

		if ( $state['done'] || ! $state['urls'] ) {
			return $state;
		}

		$limit  = (int) ini_get( 'max_execution_time' );
		$budget = ( $limit > 0 ) ? max( 5, (int) floor( $limit * 0.6 ) ) : 20;

		/**
		 * @param int $budget Seconds one batch may spend fetching.
		 */
		$budget   = (int) apply_filters( 'seofix_scan_batch_seconds', min( $budget, 20 ) );
		$deadline = microtime( true ) + $budget;

		$found = array();
		$links = array();

		while ( $state['cursor'] < count( $state['urls'] ) ) {
			if ( microtime( true ) >= $deadline ) {
				break;
			}

			$url  = $state['urls'][ $state['cursor'] ];
			$html = self::fetch( $url, $error );

			$state['cursor']++;

			if ( null === $html ) {
				$state['failed']++;

				if ( '' === $state['first_error'] ) {
					$state['first_error'] = $error;
				}
				continue;
			}

			$state['fetched']++;

			$analyzer = new SEOFIX_Analyzer( $html, $url );

			foreach ( $analyzer->issues() as $issue ) {
				$found[] = $issue;
			}

			$links += SEOFIX_Links::collect( $html, $url );
		}

		if ( $found ) {
			SEOFIX_Report::add( $found );
		}

		if ( $links ) {
			SEOFIX_Report::add_links( $links );
		}

		$state['done'] = $state['cursor'] >= count( $state['urls'] );

		update_option( self::STATE_OPTION, $state, false );

		// Link checking happens once the crawl is finished, so each URL is
		// requested once no matter how many pages linked to it.
		if ( $state['done'] ) {
			self::check_links();
		}

		return $state;
	}

	/**
	 * @return array Progress of the link-checking pass.
	 */
	public static function check_links() {
		$sources = SEOFIX_Report::links();

		if ( ! $sources ) {
			return array( 'checked' => 0, 'skipped' => 0 );
		}

		$limit  = (int) ini_get( 'max_execution_time' );
		$budget = ( $limit > 0 ) ? max( 5, (int) floor( $limit * 0.6 ) ) : 20;
		$budget = (int) apply_filters( 'seofix_link_batch_seconds', min( $budget, 20 ) );

		return SEOFIX_Links::check( array_keys( $sources ), microtime( true ) + $budget );
	}

	/**
	 * Fetch one URL as a visitor would see it.
	 *
	 * The request is deliberately made logged-out — no cookies. What is being
	 * audited is the page a search engine gets, and an admin-bar-bearing,
	 * logged-in copy of the page is a different document.
	 *
	 * @param string $url   URL.
	 * @param string $error Set to the failure reason.
	 * @return string|null HTML, or null on failure.
	 */
	private static function fetch( $url, &$error = '' ) {
		$error = '';

		$response = wp_remote_get(
			add_query_arg( 'seofix-scan', '1', $url ),
			array(
				'timeout'     => (int) apply_filters( 'seofix_fetch_timeout', 15 ),
				'redirection' => 3,
				'sslverify'   => apply_filters( 'https_local_ssl_verify', false ),
				'user-agent'  => 'Mozilla/5.0 (compatible; SEO Fixing scan; +' . home_url( '/' ) . ')',
			)
		);

		if ( is_wp_error( $response ) ) {
			$error = $response->get_error_message();
			return null;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );

		if ( $code < 200 || $code >= 300 ) {
			$error = sprintf(
				/* translators: 1: HTTP status code, 2: URL. */
				__( 'HTTP %1$d from %2$s', 'seo-fixing' ),
				$code,
				$url
			);
			return null;
		}

		return (string) wp_remote_retrieve_body( $response );
	}

	/**
	 * @return array
	 */
	public static function state() {
		$state = get_option( self::STATE_OPTION, array() );

		return wp_parse_args(
			is_array( $state ) ? $state : array(),
			array(
				'started'     => 0,
				'urls'        => array(),
				'cursor'      => 0,
				'done'        => true,
				'fetched'     => 0,
				'failed'      => 0,
				'first_error' => '',
			)
		);
	}

	/**
	 * Did the scan reach the site at all?
	 *
	 * Distinguished from "found nothing" on purpose. They look identical on a
	 * results screen and mean opposite things.
	 *
	 * @return bool
	 */
	public static function loopback_failed() {
		$state = self::state();

		return $state['started'] > 0 && 0 === (int) $state['fetched'] && (int) $state['failed'] > 0;
	}
}

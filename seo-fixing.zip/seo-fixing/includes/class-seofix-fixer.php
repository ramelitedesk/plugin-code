<?php
/**
 * The fixes.
 *
 * Every one of these works on the page as it is being sent, not on what is
 * stored in the database. That is the central decision in this file and it is
 * worth being explicit about why.
 *
 * Rewriting post_content to fix an SEO issue is a one-way operation on work
 * somebody else did. Get it wrong — and a regex over builder markup will get it
 * wrong — and the damage is in their content, permanently, discovered weeks
 * later. Filtering the output instead means a mistake lasts exactly as long as
 * the checkbox stays ticked, and unticking it puts everything back.
 *
 * WHAT IS NOT HERE, and deliberately:
 *
 *   • Writing an H1. The correct H1 is the one that says what the page is
 *     about, and this plugin does not know what your page is about. It can
 *     promote the page title, which is usually right, and that is offered as a
 *     choice rather than done quietly.
 *   • Writing alt text. An invented alt is worse than no alt: it passes the
 *     audit while telling a blind visitor something untrue. Only alt text a
 *     human already wrote — in the media library — is used.
 *   • Repointing broken links. Only you know where that page went.
 *
 * @package SEO_Fixing
 */

defined( 'ABSPATH' ) || exit;

class SEOFIX_Fixer {

	/** @var SEOFIX_Fixer|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		if ( is_admin() ) {
			return;
		}

		if ( SEOFIX_Options::enabled( 'fix_alt' ) ) {
			add_filter( 'the_content', array( $this, 'fill_alt_from_library' ), 30 );
			add_filter( 'post_thumbnail_html', array( $this, 'fill_alt_from_library' ), 30 );
		}

		if ( SEOFIX_Options::enabled( 'fix_canonical' ) ) {
			add_action( 'wp_head', array( $this, 'print_canonical' ), 1 );
		}

		if ( SEOFIX_Options::enabled( 'fix_noopener' ) ) {
			add_filter( 'nav_menu_link_attributes', array( $this, 'link_attributes' ), 10 );
		}

		// The whole-document repairs need the finished page, so they run on a
		// buffer rather than a content filter.
		if ( $this->needs_buffer() ) {
			add_action( 'template_redirect', array( $this, 'start_buffer' ), 1 );
		}
	}

	/**
	 * @return bool
	 */
	private function needs_buffer() {
		return SEOFIX_Options::enabled( 'fix_lang' )
			|| SEOFIX_Options::enabled( 'fix_noopener' )
			|| SEOFIX_Options::enabled( 'fix_h1' );
	}

	/* ------------------------------------------------------------------ *
	 * Content-level fixes
	 * ------------------------------------------------------------------ */

	/**
	 * Give an image the alt text somebody already wrote for it.
	 *
	 * Only from the media library, and only where there is no alt attribute at
	 * all. An existing alt="" is left exactly as it is: that is the correct
	 * markup for a decorative image, and overwriting it with the filename would
	 * make a screen reader read out "hero-banner-2-final-v3" to somebody.
	 *
	 * @param string $html Content or image HTML.
	 * @return string
	 */
	public function fill_alt_from_library( $html ) {
		$html = (string) $html;

		if ( false === stripos( $html, '<img' ) ) {
			return $html;
		}

		$result = preg_replace_callback(
			'/<img\s[^>]*>/i',
			static function ( $matches ) {
				$tag = $matches[0];

				// Has an alt of any kind, including an intentional empty one.
				if ( preg_match( '/\salt\s*=/i', $tag ) ) {
					return $tag;
				}

				$alt = '';

				if ( preg_match( '/wp-image-(\d+)/', $tag, $id ) ) {
					$alt = (string) get_post_meta( (int) $id[1], '_wp_attachment_image_alt', true );
				}

				/*
				 * An empty alt is the fallback, and it is the right one. It
				 * satisfies the markup requirement, tells assistive technology
				 * to skip a decorative image, and — unlike a guess — is never
				 * a lie.
				 */
				return preg_replace( '/<img\s/i', '<img alt="' . esc_attr( $alt ) . '" ', $tag, 1 );
			},
			$html
		);

		return ( null === $result || PREG_NO_ERROR !== preg_last_error() ) ? $html : $result;
	}

	/**
	 * A canonical URL, but only where nothing else has printed one.
	 *
	 * WordPress prints its own on singular views, and every SEO plugin prints
	 * one too. Two canonical tags is a worse problem than none, so this checks
	 * before it writes.
	 */
	public function print_canonical() {
		if ( is_404() || is_search() || ! is_singular() ) {
			return;
		}

		// Core's own, or another plugin's via the same hook.
		if ( has_action( 'wp_head', 'rel_canonical' ) || $this->another_seo_plugin() ) {
			return;
		}

		$url = get_permalink( get_queried_object_id() );

		if ( ! $url ) {
			return;
		}

		printf( '<link rel="canonical" href="%s" />' . "\n", esc_url( $url ) );
	}

	/**
	 * @param array $atts Link attributes.
	 * @return array
	 */
	public function link_attributes( $atts ) {
		if ( empty( $atts['target'] ) || '_blank' !== $atts['target'] ) {
			return $atts;
		}

		$rel = isset( $atts['rel'] ) ? $atts['rel'] . ' ' : '';

		$atts['rel'] = trim( $rel . 'noopener noreferrer' );

		return $atts;
	}

	/* ------------------------------------------------------------------ *
	 * Whole-document fixes
	 * ------------------------------------------------------------------ */

	public function start_buffer() {
		if ( is_admin() || is_feed() || is_embed() ) {
			return;
		}

		ob_start( array( $this, 'repair' ) );
	}

	/**
	 * @param string $html Finished page.
	 * @return string
	 */
	public function repair( $html ) {
		$html = (string) $html;

		// Only real HTML documents. Sitemaps, JSON and feeds go straight back.
		if ( '' === trim( $html ) || false === stripos( $html, '</html>' ) ) {
			return $html;
		}

		/*
		 * Script and style bodies are stashed before anything is rewritten.
		 * Without this, an analytics snippet containing the literal string
		 * target="_blank" — link trackers do exactly that — gets rewritten as
		 * though it were markup, and the JavaScript breaks.
		 */
		$stash   = array();
		$stashed = preg_replace_callback(
			'#<(script|style)\b[^>]*>.*?</\1>#is',
			static function ( $matches ) use ( &$stash ) {
				$key           = '<!--seofix-keep-' . count( $stash ) . '-->';
				$stash[ $key ] = $matches[0];
				return $key;
			},
			$html
		);

		if ( null === $stashed || PREG_NO_ERROR !== preg_last_error() ) {
			return $html;
		}

		$working = $stashed;

		if ( SEOFIX_Options::enabled( 'fix_lang' ) ) {
			$working = $this->add_lang( $working );
		}

		if ( SEOFIX_Options::enabled( 'fix_noopener' ) ) {
			$working = $this->add_noopener( $working );
		}

		if ( SEOFIX_Options::enabled( 'fix_h1' ) ) {
			$working = $this->promote_title_to_h1( $working );
		}

		foreach ( $stash as $key => $snippet ) {
			$working = str_replace( $key, $snippet, $working );
		}

		// Any sign the rewrite went wrong and the original wins. A page served
		// blank because a regex failed is worse than any issue on the report.
		if ( '' === trim( $working ) ) {
			return $html;
		}

		return $working;
	}

	/**
	 * @param string $html Page HTML.
	 * @return string
	 */
	private function add_lang( $html ) {
		if ( ! preg_match( '/<html\b(?![^>]*\blang\s*=)[^>]*>/i', $html, $matches ) ) {
			return $html;
		}

		$lang = get_bloginfo( 'language' );

		if ( '' === $lang ) {
			return $html;
		}

		return str_replace( $matches[0], rtrim( $matches[0], '>' ) . ' lang="' . esc_attr( $lang ) . '">', $html );
	}

	/**
	 * @param string $html Page HTML.
	 * @return string
	 */
	private function add_noopener( $html ) {
		$result = preg_replace_callback(
			'/<a\s[^>]*target\s*=\s*["\']_blank["\'][^>]*>/i',
			static function ( $matches ) {
				$tag = $matches[0];

				if ( preg_match( '/\srel\s*=\s*["\'][^"\']*noopener/i', $tag ) ) {
					return $tag;
				}

				if ( preg_match( '/\srel\s*=\s*["\']([^"\']*)["\']/i', $tag, $rel ) ) {
					return str_replace( $rel[0], ' rel="' . trim( $rel[1] . ' noopener noreferrer' ) . '"', $tag );
				}

				return rtrim( $tag, '>' ) . ' rel="noopener noreferrer">';
			},
			$html
		);

		return ( null === $result || PREG_NO_ERROR !== preg_last_error() ) ? $html : $result;
	}

	/**
	 * Give a page an H1 when the theme printed none.
	 *
	 * The most conservative version of this that is still useful. It runs only
	 * on singular views, only when the document genuinely contains no h1, and
	 * it uses the page's own title — the one thing on the page that is already
	 * a statement of what the page is.
	 *
	 * If the theme is already printing the title as an h2 or a div, this adds a
	 * second visible heading, which is why it is off by default and why the
	 * settings screen says to look at the page afterwards.
	 *
	 * @param string $html Page HTML.
	 * @return string
	 */
	private function promote_title_to_h1( $html ) {
		if ( ! is_singular() ) {
			return $html;
		}

		if ( preg_match( '/<h1[\s>]/i', $html ) ) {
			return $html;
		}

		$title = get_the_title( get_queried_object_id() );

		if ( '' === trim( (string) $title ) ) {
			return $html;
		}

		$heading = sprintf(
			'<h1 class="seofix-h1">%s</h1>',
			esc_html( $title )
		);

		/**
		 * Where the generated H1 is inserted.
		 *
		 * @param string $heading The h1 markup.
		 */
		$heading = (string) apply_filters( 'seofix_generated_h1', $heading );

		// Immediately after the opening body tag, so it is the first thing in
		// the document outline rather than buried inside a layout wrapper.
		if ( preg_match( '/<body\b[^>]*>/i', $html, $matches ) ) {
			return str_replace( $matches[0], $matches[0] . "\n" . $heading, $html );
		}

		return $html;
	}

	/**
	 * @return bool Whether another SEO plugin is printing head tags.
	 */
	private function another_seo_plugin() {
		return defined( 'WPSEO_VERSION' )
			|| defined( 'RANK_MATH_VERSION' )
			|| defined( 'SEOPRESS_VERSION' )
			|| class_exists( 'All_in_One_SEO_Pack' )
			|| function_exists( 'aioseo' );
	}
}

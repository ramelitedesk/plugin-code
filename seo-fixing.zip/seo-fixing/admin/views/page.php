<?php
/**
 * The whole admin screen.
 *
 * @var string $tab      Current tab.
 * @var array  $settings Settings.
 * @var array  $state    Scan state.
 * @var array  $summary  Issue counts.
 *
 * @package SEO_Fixing
 */

defined( 'ABSPATH' ) || exit;

$seofix_tabs = array(
	'issues'   => __( 'Issues', 'seo-fixing' ),
	'links'    => __( 'Broken links', 'seo-fixing' ),
	'settings' => __( 'Fixes &amp; settings', 'seo-fixing' ),
);

$seofix_total = count( $state['urls'] );
$seofix_done  = min( (int) $state['cursor'], $seofix_total );
?>
<div class="wrap seofix-wrap">
	<h1><?php esc_html_e( 'SEO Fixing', 'seo-fixing' ); ?></h1>

	<nav class="nav-tab-wrapper">
		<?php foreach ( $seofix_tabs as $seofix_slug => $seofix_label ) : ?>
			<a
				class="nav-tab <?php echo $tab === $seofix_slug ? 'nav-tab-active' : ''; ?>"
				href="<?php echo esc_url( admin_url( 'admin.php?page=' . SEOFIX_Admin::PAGE . '&tab=' . $seofix_slug ) ); ?>"
			><?php echo esc_html( $seofix_label ); ?></a>
		<?php endforeach; ?>
	</nav>

	<?php if ( SEOFIX_Scan::loopback_failed() ) : ?>
		<div class="notice notice-error">
			<p>
				<strong><?php esc_html_e( 'The scan could not reach this site.', 'seo-fixing' ); ?></strong>
				<?php esc_html_e( 'Every request failed, so nothing was examined — this is not a clean result, it is no result. Local installs, staging behind HTTP authentication, and hosts that block requests to their own address all cause this.', 'seo-fixing' ); ?>
			</p>
			<?php if ( '' !== $state['first_error'] ) : ?>
				<p><code><?php echo esc_html( $state['first_error'] ); ?></code></p>
			<?php endif; ?>
		</div>
	<?php endif; ?>

	<?php if ( 'issues' === $tab ) : ?>

		<div class="seofix-stats">
			<div class="seofix-stat seofix-stat--critical">
				<span class="n"><?php echo esc_html( number_format_i18n( $summary['critical'] ) ); ?></span>
				<span class="l"><?php esc_html_e( 'critical', 'seo-fixing' ); ?></span>
			</div>
			<div class="seofix-stat seofix-stat--warning">
				<span class="n"><?php echo esc_html( number_format_i18n( $summary['warning'] ) ); ?></span>
				<span class="l"><?php esc_html_e( 'warnings', 'seo-fixing' ); ?></span>
			</div>
			<div class="seofix-stat">
				<span class="n"><?php echo esc_html( number_format_i18n( $summary['notice'] ) ); ?></span>
				<span class="l"><?php esc_html_e( 'worth a look', 'seo-fixing' ); ?></span>
			</div>
			<div class="seofix-stat">
				<span class="n"><?php echo esc_html( number_format_i18n( $summary['pages'] ) ); ?></span>
				<span class="l"><?php esc_html_e( 'pages examined', 'seo-fixing' ); ?></span>
			</div>
		</div>

		<div class="seofix-panel">
			<?php if ( ! $state['started'] ) : ?>
				<p><?php esc_html_e( 'No scan has run yet.', 'seo-fixing' ); ?></p>
			<?php elseif ( ! $state['done'] ) : ?>
				<p>
					<strong><?php esc_html_e( 'The scan is part-way through.', 'seo-fixing' ); ?></strong>
					<?php
					printf(
						/* translators: 1: pages done, 2: total pages. */
						esc_html__( '%1$d of %2$d pages. It stops before the server does and waits to be continued, rather than dying half-way and losing everything.', 'seo-fixing' ),
						(int) $seofix_done,
						(int) $seofix_total
					);
					?>
				</p>
				<progress max="<?php echo esc_attr( (string) max( 1, $seofix_total ) ); ?>" value="<?php echo esc_attr( (string) $seofix_done ); ?>"></progress>
			<?php else : ?>
				<p>
					<?php
					printf(
						/* translators: 1: page count, 2: time ago. */
						esc_html__( '%1$d pages examined, %2$s ago.', 'seo-fixing' ),
						(int) $state['fetched'],
						esc_html( human_time_diff( (int) $state['started'] ) )
					);

					if ( (int) $state['failed'] > 0 ) {
						echo ' ';
						printf(
							/* translators: %d: failed URL count. */
							esc_html__( '%d could not be fetched and were not examined.', 'seo-fixing' ),
							(int) $state['failed']
						);
					}
					?>
				</p>
			<?php endif; ?>

			<p>
				<?php SEOFIX_Admin::button( 'scan', __( 'Scan the site', 'seo-fixing' ), 'button button-primary', __( 'Scanning…', 'seo-fixing' ) ); ?>
				<?php if ( $state['started'] && ! $state['done'] ) : ?>
					<?php SEOFIX_Admin::button( 'continue', __( 'Continue', 'seo-fixing' ), 'button', __( 'Continuing…', 'seo-fixing' ) ); ?>
				<?php endif; ?>
				<?php if ( SEOFIX_Report::all() ) : ?>
					<?php SEOFIX_Admin::button( 'clear', __( 'Clear results', 'seo-fixing' ) ); ?>
				<?php endif; ?>
			</p>
		</div>

		<?php $seofix_issues = SEOFIX_Report::sorted(); ?>

		<?php if ( ! $seofix_issues && $state['done'] && $state['fetched'] > 0 ) : ?>
			<div class="seofix-panel">
				<p class="seofix-clean"><?php esc_html_e( 'Nothing flagged on the pages examined.', 'seo-fixing' ); ?></p>
			</div>
		<?php endif; ?>

		<?php foreach ( $seofix_issues as $seofix_issue ) : ?>
			<div class="seofix-issue seofix-issue--<?php echo esc_attr( $seofix_issue['severity'] ); ?>">
				<h3>
					<?php echo esc_html( $seofix_issue['label'] ); ?>
					<span class="seofix-count">
						<?php
						printf(
							/* translators: %d: page count. */
							esc_html( _n( 'on %d page', 'on %d pages', (int) $seofix_issue['count'], 'seo-fixing' ) ),
							(int) $seofix_issue['count']
						);
						?>
					</span>
				</h3>

				<p class="seofix-detail"><?php echo esc_html( $seofix_issue['detail'] ); ?></p>

				<?php if ( ! empty( $seofix_issue['fix'] ) ) : ?>
					<?php
					$seofix_fix_map = array(
						'lang'          => array( 'fix_lang', __( 'This one is fixed automatically when "Add a lang attribute" is on.', 'seo-fixing' ) ),
						'canonical'     => array( 'fix_canonical', __( 'This one is fixed automatically when "Add a canonical URL" is on.', 'seo-fixing' ) ),
						'alt'           => array( 'fix_alt', __( 'Alt text already written in the media library is filled in automatically when "Use alt text from the media library" is on. Images with none there still need a person — an invented alt is worse than none.', 'seo-fixing' ) ),
						'h1_from_title' => array( 'fix_h1', __( 'The page title can be promoted to an H1 automatically, but it changes what the page looks like — see the Fixes tab.', 'seo-fixing' ) ),
					);
					?>
					<?php if ( isset( $seofix_fix_map[ $seofix_issue['fix'] ] ) ) : ?>
						<?php list( $seofix_key, $seofix_note ) = $seofix_fix_map[ $seofix_issue['fix'] ]; ?>
						<p class="seofix-fixnote <?php echo empty( $settings[ $seofix_key ] ) ? 'is-off' : 'is-on'; ?>">
							<?php echo esc_html( $seofix_note ); ?>
							<?php if ( empty( $settings[ $seofix_key ] ) ) : ?>
								<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . SEOFIX_Admin::PAGE . '&tab=settings' ) ); ?>"><?php esc_html_e( 'It is currently off.', 'seo-fixing' ); ?></a>
							<?php endif; ?>
						</p>
					<?php endif; ?>
				<?php endif; ?>

				<?php if ( ! empty( $seofix_issue['urls'] ) ) : ?>
					<details>
						<summary><?php esc_html_e( 'Which pages', 'seo-fixing' ); ?></summary>
						<ul class="seofix-urls">
							<?php foreach ( $seofix_issue['urls'] as $seofix_row ) : ?>
								<li>
									<a href="<?php echo esc_url( $seofix_row['url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $seofix_row['url'] ); ?></a>
									<?php if ( $seofix_row['label'] !== $seofix_issue['label'] ) : ?>
										<span class="seofix-perpage"><?php echo esc_html( $seofix_row['label'] ); ?></span>
									<?php endif; ?>
								</li>
							<?php endforeach; ?>
						</ul>
						<?php if ( (int) $seofix_issue['count'] > count( $seofix_issue['urls'] ) ) : ?>
							<p class="description">
								<?php
								printf(
									/* translators: %d: remaining page count. */
									esc_html__( '… and %d more.', 'seo-fixing' ),
									(int) $seofix_issue['count'] - count( $seofix_issue['urls'] )
								);
								?>
							</p>
						<?php endif; ?>
					</details>
				<?php endif; ?>
			</div>
		<?php endforeach; ?>

	<?php elseif ( 'links' === $tab ) : ?>

		<?php
		$seofix_sources = SEOFIX_Report::links();
		$seofix_broken  = SEOFIX_Links::broken( $seofix_sources );
		$seofix_known   = SEOFIX_Links::all();
		?>

		<div class="seofix-panel">
			<h2><?php esc_html_e( 'Broken links', 'seo-fixing' ); ?></h2>
			<p class="description">
				<?php
				printf(
					/* translators: 1: links found, 2: links checked. */
					esc_html__( '%1$d unique links found across the pages scanned, %2$d checked so far. Each URL is requested once for the whole site, not once per page that links to it.', 'seo-fixing' ),
					count( $seofix_sources ),
					count( $seofix_known )
				);
				?>
			</p>
			<p>
				<?php SEOFIX_Admin::button( 'check_links', __( 'Check links now', 'seo-fixing' ), 'button button-primary', __( 'Checking…', 'seo-fixing' ) ); ?>
				<?php SEOFIX_Admin::button( 'forget_links', __( 'Forget cached results', 'seo-fixing' ) ); ?>
			</p>
			<p class="description">
				<?php esc_html_e( 'Verdicts are cached for a week, so running this again only re-requests what has expired. Forget them if you have just fixed a batch and want a fresh answer.', 'seo-fixing' ); ?>
			</p>
		</div>

		<?php if ( $seofix_broken ) : ?>
			<table class="widefat striped seofix-links">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Link', 'seo-fixing' ); ?></th>
						<th><?php esc_html_e( 'Result', 'seo-fixing' ); ?></th>
						<th><?php esc_html_e( 'Found on', 'seo-fixing' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $seofix_broken as $seofix_link ) : ?>
						<tr>
							<td class="seofix-mono">
								<a href="<?php echo esc_url( $seofix_link['url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $seofix_link['url'] ); ?></a>
								<?php if ( $seofix_link['internal'] ) : ?>
									<span class="seofix-badge seofix-badge--critical"><?php esc_html_e( 'yours', 'seo-fixing' ); ?></span>
								<?php endif; ?>
							</td>
							<td>
								<?php if ( 'unreachable' === $seofix_link['kind'] ) : ?>
									<span class="seofix-badge seofix-badge--warning"><?php esc_html_e( 'no response', 'seo-fixing' ); ?></span>
									<span class="description"><?php echo esc_html( $seofix_link['message'] ); ?></span>
								<?php else : ?>
									<span class="seofix-badge seofix-badge--critical"><?php echo esc_html( (string) $seofix_link['code'] ); ?></span>
									<span class="description"><?php echo esc_html( $seofix_link['message'] ); ?></span>
								<?php endif; ?>
							</td>
							<td class="seofix-mono"><a href="<?php echo esc_url( $seofix_link['found_on'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $seofix_link['found_on'] ); ?></a></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<p class="description">
				<?php esc_html_e( 'Nothing here is repointed automatically. Only you know where that page went — and a link silently sent somewhere it was never meant to go is a worse problem than a 404, because nobody notices it.', 'seo-fixing' ); ?>
			</p>
			<p class="description">
				<?php esc_html_e( '"No response" is not always the link\'s fault. A timeout, a TLS failure or a host that blocks unknown clients all look the same from here — open one before you delete it.', 'seo-fixing' ); ?>
			</p>
		<?php elseif ( $seofix_known ) : ?>
			<div class="seofix-panel"><p class="seofix-clean"><?php esc_html_e( 'Every link checked so far answered.', 'seo-fixing' ); ?></p></div>
		<?php endif; ?>

	<?php else : ?>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="seofix_action" />
			<input type="hidden" name="do" value="save" />
			<?php wp_nonce_field( SEOFIX_Admin::NONCE ); ?>

			<div class="seofix-panel">
				<h2><?php esc_html_e( 'Fixes that cannot be wrong', 'seo-fixing' ); ?></h2>
				<p class="description">
					<?php esc_html_e( 'Each of these adds something the page was missing without changing anything the page already said. They are applied as the page is sent, never written into your content — so switching one off puts everything back exactly as it was.', 'seo-fixing' ); ?>
				</p>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'Language', 'seo-fixing' ); ?></th>
						<td><label><input type="checkbox" name="fix_lang" value="1" <?php checked( ! empty( $settings['fix_lang'] ) ); ?> /> <?php esc_html_e( 'Add a lang attribute to the html element when the theme omits one', 'seo-fixing' ); ?></label></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Alt text', 'seo-fixing' ); ?></th>
						<td>
							<label><input type="checkbox" name="fix_alt" value="1" <?php checked( ! empty( $settings['fix_alt'] ) ); ?> /> <?php esc_html_e( 'Use alt text from the media library for images that have no alt attribute', 'seo-fixing' ); ?></label>
							<p class="description"><?php esc_html_e( 'Only alt text a person already wrote. Where there is none, an empty alt is used — which is the correct markup for a decorative image, and honest. An invented alt passes the audit while telling a blind visitor something untrue.', 'seo-fixing' ); ?></p>
							<p class="description"><?php esc_html_e( 'An existing alt="" is never overwritten. It usually means someone decided the image is decorative, and they were probably right.', 'seo-fixing' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'External links', 'seo-fixing' ); ?></th>
						<td><label><input type="checkbox" name="fix_noopener" value="1" <?php checked( ! empty( $settings['fix_noopener'] ) ); ?> /> <?php esc_html_e( 'Add rel="noopener noreferrer" to links that open in a new tab', 'seo-fixing' ); ?></label></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Canonical', 'seo-fixing' ); ?></th>
						<td>
							<label><input type="checkbox" name="fix_canonical" value="1" <?php checked( ! empty( $settings['fix_canonical'] ) ); ?> /> <?php esc_html_e( 'Add a canonical URL when nothing else has printed one', 'seo-fixing' ); ?></label>
							<p class="description"><?php esc_html_e( 'Checked before it writes. Two canonical tags is a worse problem than none, so this stands down if WordPress or another SEO plugin is already handling it.', 'seo-fixing' ); ?></p>
						</td>
					</tr>
				</table>
			</div>

			<div class="seofix-panel">
				<h2><?php esc_html_e( 'The fix that needs your judgement', 'seo-fixing' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'Missing H1', 'seo-fixing' ); ?></th>
						<td>
							<label><input type="checkbox" name="fix_h1" value="1" <?php checked( ! empty( $settings['fix_h1'] ) ); ?> /> <?php esc_html_e( 'On a page with no H1 at all, promote the page title to one', 'seo-fixing' ); ?></label>
							<p class="description">
								<strong><?php esc_html_e( 'This one changes what the page looks like.', 'seo-fixing' ); ?></strong>
								<?php esc_html_e( 'It only runs where the document genuinely contains no H1, but plenty of themes show the title as a styled div — in which case this adds a second visible heading. Turn it on, then look at a page before leaving it on.', 'seo-fixing' ); ?>
							</p>
							<p class="description"><?php esc_html_e( 'The real fix is a template that prints an H1. This is what you do until then.', 'seo-fixing' ); ?></p>
						</td>
					</tr>
				</table>
			</div>

			<div class="seofix-panel">
				<h2><?php esc_html_e( 'Scanning', 'seo-fixing' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'Link checking', 'seo-fixing' ); ?></th>
						<td>
							<label><input type="checkbox" name="check_links" value="1" <?php checked( ! empty( $settings['check_links'] ) ); ?> /> <?php esc_html_e( 'Request every link found, to see whether it still answers', 'seo-fixing' ); ?></label>
							<p class="description"><?php esc_html_e( 'This makes outbound requests to other people\'s servers. It is polite about it — one request per unique URL, HEAD where possible, results cached for a week — but it is the one thing here that reaches outside your site.', 'seo-fixing' ); ?></p>
						</td>
					</tr>
				</table>
			</div>

			<?php submit_button( __( 'Save changes', 'seo-fixing' ) ); ?>
		</form>

		<div class="seofix-panel">
			<h2><?php esc_html_e( 'What this plugin will not do', 'seo-fixing' ); ?></h2>
			<ul class="seofix-wont">
				<li><?php esc_html_e( 'Write your H1, your titles or your meta descriptions. It reports which pages are missing them. What they should say is the part that needs a person.', 'seo-fixing' ); ?></li>
				<li><?php esc_html_e( 'Invent alt text. An alt attribute that describes the wrong thing is worse than one that is absent, because it looks correct to everyone except the person relying on it.', 'seo-fixing' ); ?></li>
				<li><?php esc_html_e( 'Repoint a broken link. Only you know where that page went.', 'seo-fixing' ); ?></li>
				<li><?php esc_html_e( 'Edit anything in your database. Every fix is applied to the page on its way out, so unticking a box undoes it completely.', 'seo-fixing' ); ?></li>
				<li><?php esc_html_e( 'Give you SEO advice. There is no keyword field and no readability score here — this finds what is broken, not what could be better.', 'seo-fixing' ); ?></li>
			</ul>
		</div>

	<?php endif; ?>
</div>

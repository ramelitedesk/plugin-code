<?php
/**
 * Admin: Tools → SEO Fixing.
 *
 * @package SEO_Fixing
 */

defined( 'ABSPATH' ) || exit;

class SEOFIX_Admin {

	const PAGE  = 'seo-fixing';
	const NONCE = 'seofix_action';

	/** @var SEOFIX_Admin|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_post_seofix_action', array( $this, 'handle_action' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
	}

	public function add_menu() {
		$critical = SEOFIX_Report::summary()['critical'];

		add_menu_page(
			__( 'SEO Fixing', 'seo-fixing' ),
			$critical
				? sprintf(
					/* translators: %s: bubble markup. */
					__( 'SEO Fixing %s', 'seo-fixing' ),
					'<span class="update-plugins count-' . (int) $critical . '"><span class="update-count">' . (int) $critical . '</span></span>'
				)
				: __( 'SEO Fixing', 'seo-fixing' ),
			'manage_options',
			self::PAGE,
			array( $this, 'render' ),
			'dashicons-search',
			65
		);
	}

	/**
	 * @param string $hook Current screen.
	 */
	public function enqueue( $hook ) {
		if ( false === strpos( (string) $hook, self::PAGE ) ) {
			return;
		}

		wp_enqueue_style( 'seofix-admin', SEOFIX_URL . 'assets/admin.css', array(), SEOFIX_VERSION );
	}

	public function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'seo-fixing' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'issues';

		$settings = SEOFIX_Options::all();
		$state    = SEOFIX_Scan::state();
		$summary  = SEOFIX_Report::summary();

		require SEOFIX_DIR . 'admin/views/page.php';
	}

	public function handle_action() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'seo-fixing' ) );
		}

		check_admin_referer( self::NONCE );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked above.
		$do  = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
		$tab = 'issues';

		switch ( $do ) {
			case 'scan':
				SEOFIX_Scan::start();
				SEOFIX_Scan::step();
				break;

			case 'continue':
				SEOFIX_Scan::step();
				break;

			case 'check_links':
				SEOFIX_Scan::check_links();
				$tab = 'links';
				break;

			case 'forget_links':
				SEOFIX_Links::forget();
				$tab = 'links';
				break;

			case 'clear':
				SEOFIX_Report::clear();
				break;

			case 'save':
				$this->save_settings();
				$tab = 'settings';
				break;
		}

		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE, 'tab' => $tab, 'done' => '1' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	private function save_settings() {
		$defaults = SEOFIX_Options::defaults();
		$clean    = array();

		foreach ( $defaults as $key => $default ) {
			if ( '_schema' === $key ) {
				$clean[ $key ] = SEOFIX_Options::SCHEMA_VERSION;
				continue;
			}

			if ( is_int( $default ) ) {
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked by the caller.
				$clean[ $key ] = isset( $_POST[ $key ] ) ? 1 : 0;
				continue;
			}

			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked by the caller.
			$clean[ $key ] = isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : $default;
		}

		SEOFIX_Options::update( $clean );
	}

	/**
	 * An action button.
	 *
	 * @param string $do      Action key.
	 * @param string $label   Button text.
	 * @param string $classes CSS classes.
	 * @param string $busy    Text while the request is in flight.
	 */
	public static function button( $do, $label, $classes = 'button', $busy = '' ) {
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline" data-seofix-busy>
			<input type="hidden" name="action" value="seofix_action" />
			<input type="hidden" name="do" value="<?php echo esc_attr( $do ); ?>" />
			<?php wp_nonce_field( self::NONCE ); ?>
			<button
				type="submit"
				class="<?php echo esc_attr( $classes ); ?>"
				data-busy-label="<?php echo esc_attr( '' !== $busy ? $busy : __( 'Working…', 'seo-fixing' ) ); ?>"
			><?php echo esc_html( $label ); ?></button>
		</form>
		<?php
	}
}

# SEO Fixing

Finds the SEO problems on a site and fixes the ones that can be fixed safely.

Split out of the WPD SEO & Performance Suite. This is the SEO half; the performance half is now the **SpeedPage** plugin.

---

## This plugin does not do SEO

There is no keyword field here, no readability score, no traffic light telling you to use your focus phrase one more time. Those tools already exist, several of them are better than anything that would be written here, and none of them answer the question this one exists for:

> **Something is wrong with this site. What, and where?**

So it crawls the pages a visitor actually receives, lists what is broken, groups it by problem rather than by page, and fixes the handful of things that can be fixed without guessing what you meant.

---

## It audits the rendered page, not the database

This is the decision everything else follows from.

Reading `post_content` would be far easier — no HTTP, no timeouts, no loopback to fail. It would also be **wrong on most sites**, because the thing people call "the H1" is almost never in the content. It is printed by the theme template from the post title. An audit of `post_content` reports "H1 missing" on a site whose every page has a perfectly good one, and a report that is wrong about the first thing you check is a report nobody opens again.

So the scan fetches each URL over HTTP, logged out, and says only what those bytes support.

**When the site cannot reach itself** — local installs, staging behind HTTP auth, hosts that block requests to their own address — the screen says so in as many words. Reporting "no issues found" because nothing could be fetched would be the most damaging thing this plugin could do: a clean bill of health with no examination behind it.

---

## What it checks

| | |
| --- | --- |
| **Headings** | No H1, more than one H1, an empty H1, skipped levels (H1 → H3) |
| **Links** | Broken internal and external links with status codes, links with no readable text, links whose text says nothing ("click here") |
| **Ratio** | Text-to-HTML ratio, and pages with almost no text |
| **Images** | Images with no alt attribute at all |
| **Head** | Missing or badly sized title, missing or badly sized meta description, missing canonical, missing `lang`, missing viewport |
| **Indexability** | A page telling search engines not to index it |

### Broken links are checked once per site, not once per page

A footer link appears on every page. Checking it a thousand times would take a thousand requests to learn one thing, and would look like a denial of service to whoever is on the other end. Verdicts are cached for a week.

`HEAD` first, because it costs the far end almost nothing — but plenty of servers and CDNs answer `HEAD` with a 405 or answer it wrongly, so anything that is not a clean answer is retried with a ranged `GET` rather than reported as broken. Reporting a working page as a 404 because its host dislikes `HEAD` is the classic failure of link checkers.

A failed request is reported as **"no response"**, never as a 404. A timeout, a TLS failure and a host that blocks unknown clients all look identical from here, and quite often the fault is at this end.

---

## What it fixes

Every fix is applied **to the page as it is sent**, never written into your content. That is deliberate: rewriting `post_content` is a one-way operation on work somebody else did, and a regex over builder markup *will* get it wrong eventually — discovered weeks later, permanently. Filtering the output means a mistake lasts exactly as long as the checkbox stays ticked.

**On by default — these cannot be wrong.** Each adds something the page was missing without changing anything it already said.

- A `lang` attribute where the theme omits one
- Alt text **already written in the media library** for images with no alt attribute
- `rel="noopener noreferrer"` on links opening in a new tab
- A canonical URL, but only where nothing else has printed one

**Off by default — this one needs your judgement.**

- Promoting the page title to an H1 where the document contains no H1 at all. It changes what the page looks like: plenty of themes render the title as a styled div, in which case this adds a second visible heading. The real fix is a template that prints an H1; this is what you do until then.

### What it will not do

- **Write your H1, titles or meta descriptions.** It reports which pages are missing them. What they should *say* is the part that needs a person.
- **Invent alt text.** An alt attribute describing the wrong thing is worse than one that is absent, because it looks correct to everyone except the person relying on it. Where the media library has nothing, an empty `alt` is used — correct markup for a decorative image, and honest.
- **Overwrite an existing `alt=""`.** It usually means somebody decided the image is decorative, and they were probably right. Reporting it as an error is how these tools train people to write `alt="image"` on a spacer.
- **Repoint a broken link.** Only you know where that page went. A link silently sent somewhere it was never meant to go is a worse problem than a 404, because nobody notices it.
- **Edit anything in your database.**

---

## Scanning

A scan runs in batches against a time budget, stores a cursor, and picks up where it stopped. A hundred pages is a hundred requests and a shared host will kill the process long before that finishes — so it stops before the server does, says how far it got, and waits to be continued. It does not die half-way and lose everything.

Results are grouped by issue type, because that is the shape of the work. *"Forty pages have no meta description"* is one afternoon's job. Forty separate rows saying the same thing is the same job made to look like forty.

---

## Structure

```
seo-fixing/
├── seo-fixing.php                  Bootstrap
├── includes/
│   ├── class-seofix-options.php    Settings and defaults
│   ├── class-seofix-analyzer.php   Everything judged from one rendered page
│   ├── class-seofix-links.php      Link checking, cached and rate-conscious
│   ├── class-seofix-scan.php       The crawl: batching, budget, cursor
│   ├── class-seofix-report.php     Results, grouped by problem
│   └── class-seofix-fixer.php      The output-layer fixes
├── admin/                          Tools screen: issues, links, fixes
└── tests/                          Runnable without WordPress
```

---

## Tests

```bash
cd seo-fixing/tests
php test.php    # 73 cases
```

No WordPress, no database, no PHPUnit, and **no network** — a suite that reaches the internet is a suite that fails on an aeroplane, so HTTP is stubbed from a table.

Roughly half the cases assert that a *correct* page comes back clean. An audit tool has one failure mode that destroys its usefulness: crying wolf. A report listing forty things, six of which are wrong, does not get worked through — it gets closed, and the four real problems in it go unfixed for a year. So the constructions naive checkers get wrong are all asserted explicitly: `alt=""` on a decorative image, an image link carrying its text in the alt, an `aria-label`, an in-page anchor, a heading outline going back up a level.

---

## Honest limits

- **It needs the site to be able to reach itself.** No loopback, no scan. This is stated on screen rather than hidden behind an empty result.
- **It reads syntax, not meaning.** It can tell you a page has no H1. It cannot tell you the H1 it does have is vague, or that the page is about the wrong thing.
- **Text-to-HTML ratio is a symptom, not a fault.** It is reported as a notice and never higher. A low ratio is how you *notice* inline CSS or a builder emitting six wrappers per element — it is not itself the thing to fix.
- **Thin content is not automatically bad.** A contact page is short and should be. It is flagged only so you can check the pages that were meant to say something.
- **Link checking reaches other people's servers.** It is polite about it — one request per unique URL, `HEAD` where possible, cached for a week — but it is the one thing here that goes outside your site, and it can be switched off.

## Requirements

WordPress 5.8+, PHP 7.4+, `DOMDocument` (part of every standard PHP build). No dependencies, no build step.

<?php
/**
 * Enough of WordPress to exercise the logic, and nothing more.
 *
 * The classes worth testing here — where am I, does this rule apply, what does
 * this request mean, what goes on the query — are all pure decisions about
 * arrays. They need WordPress's function names, not WordPress.
 *
 * @package Custom_Filter_Widget
 */

if ( 'cli' !== PHP_SAPI ) {
	http_response_code( 404 );
	exit;
}

define( 'ABSPATH', __DIR__ );
define( 'HOUR_IN_SECONDS', 3600 );

define( 'CFW_VERSION', 'test' );
define( 'CFW_FILE', dirname( __DIR__ ) . '/custom-filter-widget.php' );
define( 'CFW_DIR', dirname( __DIR__ ) . '/' );
define( 'CFW_URL', 'http://example.test/wp-content/plugins/custom-filter-widget/' );

/* ---------------------------------------------------------------- *
 * The fake site
 * ---------------------------------------------------------------- */

$GLOBALS['cfw_test'] = array(
	// Which conditional tags answer true.
	'view'       => array(),
	'queried'    => null,
	'post_type'  => 'post',
	'meta'       => array(),
	'woo'        => false,
	'home'       => 'https://example.test',
	'id_queries' => 0,
	'ids'        => array(),
	'taxonomies' => array(
		'category'    => array( 'hierarchical' => true,  'label' => 'Category',   'object_type' => array( 'post' ) ),
		'post_tag'    => array( 'hierarchical' => false, 'label' => 'Tag',        'object_type' => array( 'post' ) ),
		'product_cat' => array( 'hierarchical' => true,  'label' => 'Category',   'object_type' => array( 'product' ) ),
		'pa_colour'   => array( 'hierarchical' => false, 'label' => 'Colour',     'object_type' => array( 'product' ) ),
	),
);

/**
 * Put the fake site into a known state.
 *
 * @param array $view      Conditional tags that should answer true.
 * @param mixed $queried   Queried object, if any.
 * @param array $extra     post_type, woo.
 */
function cfw_view( array $view, $queried = null, array $extra = array() ) {
	$GLOBALS['cfw_test']['view']      = $view;
	$GLOBALS['cfw_test']['queried']   = $queried;
	$GLOBALS['cfw_test']['post_type'] = $extra['post_type'] ?? 'post';
	$GLOBALS['cfw_test']['woo']       = ! empty( $extra['woo'] );

	CFW_Location::reset();
}

/**
 * @param string $tag Conditional name.
 * @return bool
 */
function cfw_is( $tag ) {
	return in_array( $tag, $GLOBALS['cfw_test']['view'], true );
}

/* ---------------------------------------------------------------- *
 * WordPress, approximately
 * ---------------------------------------------------------------- */

function __( $text, $domain = '' ) { return $text; }
function _n( $single, $plural, $number, $domain = '' ) { return 1 === (int) $number ? $single : $plural; }
function esc_html( $text ) { return htmlspecialchars( (string) $text, ENT_QUOTES ); }
function esc_attr( $text ) { return htmlspecialchars( (string) $text, ENT_QUOTES ); }
function esc_url( $url ) { return $url; }
function esc_url_raw( $url ) { return $url; }
function esc_textarea( $text ) { return htmlspecialchars( (string) $text, ENT_QUOTES ); }
function esc_html__( $t, $d = '' ) { return $t; }
function esc_attr__( $t, $d = '' ) { return $t; }

function absint( $value ) { return abs( (int) $value ); }
function sanitize_text_field( $value ) { return trim( strip_tags( (string) $value ) ); }
function sanitize_key( $value ) { return preg_replace( '/[^a-z0-9_\-]/', '', strtolower( (string) $value ) ); }
function sanitize_hex_color( $value ) { return preg_match( '/^#([A-Fa-f0-9]{3}|[A-Fa-f0-9]{6})$/', (string) $value ) ? $value : null; }
function wp_strip_all_tags( $value ) { return strip_tags( (string) $value ); }
function wp_unslash( $value ) { return is_array( $value ) ? array_map( 'wp_unslash', $value ) : stripslashes( (string) $value ); }
function map_deep( $value, $callback ) { return is_array( $value ) ? array_map( function ( $v ) use ( $callback ) { return map_deep( $v, $callback ); }, $value ) : call_user_func( $callback, $value ); }

function wp_parse_args( $args, $defaults = array() ) { return array_merge( $defaults, (array) $args ); }
function wp_list_pluck( $list, $field ) { return array_map( function ( $row ) use ( $field ) { return is_array( $row ) ? ( $row[ $field ] ?? null ) : null; }, (array) $list ); }

function apply_filters( $tag, $value ) { return $value; }
function add_action() {}
function add_filter() {}
function do_action() {}

function get_option( $name, $default = false ) { return 'posts_per_page' === $name ? 10 : $default; }
function home_url( $path = '' ) { return rtrim( $GLOBALS['cfw_test']['home'], '/' ) . $path; }
function wp_parse_url( $url, $component = -1 ) { return parse_url( (string) $url, $component ); }
function remove_query_arg( $keys, $url ) {
	$parts = parse_url( $url );
	parse_str( $parts['query'] ?? '', $args );
	foreach ( (array) $keys as $key ) { unset( $args[ $key ] ); }
	$base = ( $parts['scheme'] ?? 'http' ) . '://' . ( $parts['host'] ?? '' ) . ( $parts['path'] ?? '' );
	return $args ? $base . '?' . http_build_query( $args ) : $base;
}
function wp_enqueue_style( $handle ) {}
function wp_enqueue_script( $handle ) {}
function get_transient( $key ) { return false; }
function set_transient( $key, $value, $ttl ) { return true; }
function delete_transient( $key ) { return true; }

function get_post_meta( $id, $key, $single = false ) { return $GLOBALS['cfw_test']['meta'][ $id ][ $key ] ?? ( $single ? '' : array() ); }
function update_post_meta( $id, $key, $value ) { $GLOBALS['cfw_test']['meta'][ $id ][ $key ] = $value; return true; }
function get_post_type( $id = null ) { return $GLOBALS['cfw_test']['post_type']; }

function get_posts( $args = array() ) { $GLOBALS['cfw_test']['id_queries']++; return $GLOBALS['cfw_test']['ids'] ?? array(); }

function current_time( $type ) { return time(); }
function wp_date( $format, $timestamp = null ) { return gmdate( $format, $timestamp ?? time() ); }

/* ---------------- conditionals ---------------- */

function is_admin() { return cfw_is( 'admin' ); }
function is_feed() { return cfw_is( 'feed' ); }
function is_404() { return cfw_is( '404' ); }
function is_search() { return cfw_is( 'search' ); }
function is_front_page() { return cfw_is( 'front' ); }
function is_home() { return cfw_is( 'home' ); }
function is_singular( $type = '' ) { return cfw_is( 'singular' ); }
function is_tax( $tax = '' ) { return cfw_is( 'tax' ); }
function is_category() { return cfw_is( 'category' ); }
function is_tag() { return cfw_is( 'tag' ); }
function is_author() { return cfw_is( 'author' ); }
function is_date() { return cfw_is( 'date' ); }
function is_post_type_archive( $type = '' ) { return cfw_is( 'post_type_archive' ); }
function is_shop() { return cfw_is( 'shop' ); }

function get_queried_object() { return $GLOBALS['cfw_test']['queried']; }
function get_queried_object_id() {
	$object = $GLOBALS['cfw_test']['queried'];

	if ( $object instanceof WP_Term ) { return $object->term_id; }

	return is_object( $object ) && isset( $object->ID ) ? $object->ID : 0;
}
function get_query_var( $name, $default = '' ) { return 'post_type' === $name ? $GLOBALS['cfw_test']['post_type'] : $default; }

/* ---------------- taxonomies ---------------- */

function taxonomy_exists( $name ) { return isset( $GLOBALS['cfw_test']['taxonomies'][ $name ] ); }

function get_taxonomy( $name ) {
	if ( ! taxonomy_exists( $name ) ) { return false; }

	$spec = $GLOBALS['cfw_test']['taxonomies'][ $name ];

	return (object) array(
		'name'         => $name,
		'public'       => true,
		'hierarchical' => $spec['hierarchical'],
		'object_type'  => $spec['object_type'],
		'labels'       => (object) array( 'name' => $spec['label'] . 's', 'singular_name' => $spec['label'] ),
	);
}

function get_taxonomies( $args = array(), $output = 'names' ) {
	$out = array();

	foreach ( array_keys( $GLOBALS['cfw_test']['taxonomies'] ) as $name ) {
		$out[ $name ] = 'objects' === $output ? get_taxonomy( $name ) : $name;
	}

	return $out;
}

function get_object_taxonomies( $type, $output = 'names' ) {
	$out = array();

	foreach ( $GLOBALS['cfw_test']['taxonomies'] as $name => $spec ) {
		if ( in_array( $type, $spec['object_type'], true ) ) {
			$out[ $name ] = 'objects' === $output ? get_taxonomy( $name ) : $name;
		}
	}

	return $out;
}

function get_post_types( $args = array(), $output = 'names' ) {
	$types = array( 'post', 'page', 'product' );
	$out   = array();

	foreach ( $types as $name ) {
		$out[ $name ] = 'objects' === $output
			? (object) array(
				'name'        => $name,
				'has_archive' => 'page' !== $name,
				'labels'      => (object) array( 'name' => ucfirst( $name ) . 's', 'singular_name' => ucfirst( $name ) ),
			)
			: $name;
	}

	return $out;
}

function get_terms( $args = array() ) { return array(); }
function get_term( $id, $tax ) { return false; }
function get_users( $args = array() ) { return array(); }

function is_wp_error( $thing ) { return $thing instanceof WP_Error; }

class WP_Error {}

class WP_Term {
	public $term_id;
	public $taxonomy;
	public $name;
	public $slug;
	public $parent = 0;
	public $count  = 0;

	public function __construct( $id, $taxonomy, $name = '', $slug = '' ) {
		$this->term_id  = $id;
		$this->taxonomy = $taxonomy;
		$this->name     = $name;
		$this->slug     = $slug;
	}
}

/**
 * Just enough WP_Query to see what got set on it.
 */
class WP_Query {
	public $vars = array();

	public function __construct( array $vars = array() ) { $this->vars = $vars; }
	public function get( $key, $default = '' ) { return $this->vars[ $key ] ?? $default; }
	public function set( $key, $value ) { $this->vars[ $key ] = $value; }
	public function is_main_query() { return true; }
}

/* ---------------- the plugin ---------------- */

require_once CFW_DIR . 'includes/class-cfw-settings.php';
require_once CFW_DIR . 'includes/class-cfw-location.php';
require_once CFW_DIR . 'includes/class-cfw-sources.php';
require_once CFW_DIR . 'includes/class-cfw-query.php';

/*
 * The two classes the shop-page bugs lived in. Neither was loaded here
 * before, which is why a filter that did nothing on every WooCommerce shop
 * page passed every test in this file.
 */
require_once CFW_DIR . 'includes/class-cfw-assets.php';
require_once CFW_DIR . 'includes/class-cfw-render.php';
require_once CFW_DIR . 'includes/class-cfw-frontend.php';


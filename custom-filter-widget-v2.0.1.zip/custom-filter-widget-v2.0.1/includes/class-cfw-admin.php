<?php
/**
 * The screen where a filter set is built.
 *
 * Four panels, one per thing the brief asks for: what is in the widget, where
 * it shows, how it applies, and what it looks like.
 *
 * @package Custom_Filter_Widget
 */

defined( 'ABSPATH' ) || exit;

class CFW_Admin {

	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'meta_boxes' ) );
		add_action( 'save_post_' . CFW_Settings::POST_TYPE, array( __CLASS__, 'save' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );

		add_filter( 'manage_' . CFW_Settings::POST_TYPE . '_posts_columns', array( __CLASS__, 'columns' ) );
		add_action( 'manage_' . CFW_Settings::POST_TYPE . '_posts_custom_column', array( __CLASS__, 'column' ), 10, 2 );

		// Cached price bounds are wrong the moment a product's price changes.
		add_action( 'save_post_product', array( __CLASS__, 'clear_price_cache' ) );
		add_action( 'woocommerce_variation_set_stock', array( __CLASS__, 'clear_price_cache' ) );
	}

	public static function clear_price_cache() {
		delete_transient( 'cfw_price_bounds' );
	}

	public static function meta_boxes() {
		add_meta_box( 'cfw-items', __( 'Filter items', 'custom-filter-widget' ), array( __CLASS__, 'panel_items' ), CFW_Settings::POST_TYPE, 'normal', 'high' );
		add_meta_box( 'cfw-where', __( 'Where to show it', 'custom-filter-widget' ), array( __CLASS__, 'panel_where' ), CFW_Settings::POST_TYPE, 'normal', 'default' );
		add_meta_box( 'cfw-method', __( 'How it applies', 'custom-filter-widget' ), array( __CLASS__, 'panel_method' ), CFW_Settings::POST_TYPE, 'normal', 'default' );
		add_meta_box( 'cfw-style', __( 'Styling', 'custom-filter-widget' ), array( __CLASS__, 'panel_style' ), CFW_Settings::POST_TYPE, 'normal', 'default' );
		add_meta_box( 'cfw-usage', __( 'Placement', 'custom-filter-widget' ), array( __CLASS__, 'panel_usage' ), CFW_Settings::POST_TYPE, 'side', 'high' );
	}

	/* ------------------------------------------------------------------ *
	 * Items
	 * ------------------------------------------------------------------ */

	public static function panel_items( $post ) {
		$config = CFW_Settings::get( $post->ID );

		wp_nonce_field( 'cfw_save', 'cfw_nonce' );
		?>
		<p class="cfw-a__lead">
			<?php esc_html_e( 'Each item is one thing a visitor can filter by. Add as many as you like — they appear in the widget in this order, and you can drag them to reorder.', 'custom-filter-widget' ); ?>
		</p>

		<label class="cfw-a__toggle">
			<input type="checkbox" name="cfw[enabled]" value="1" <?php checked( ! empty( $config['enabled'] ) ); ?> />
			<strong><?php esc_html_e( 'This filter set is live', 'custom-filter-widget' ); ?></strong>
		</label>

		<div id="cfw-items" class="cfw-a__items">
			<?php
			foreach ( $config['items'] as $index => $item ) {
				self::item_row( $index, $item );
			}
			?>
		</div>

		<p>
			<button type="button" class="button button-secondary" id="cfw-add-item">
				<?php esc_html_e( '+ Add filter item', 'custom-filter-widget' ); ?>
			</button>
		</p>

		<?php if ( empty( $config['items'] ) ) : ?>
			<div class="notice notice-info inline">
				<p><?php esc_html_e( 'A filter set with no items renders nothing at all. Add at least one before placing it.', 'custom-filter-widget' ); ?></p>
			</div>
		<?php endif; ?>

		<script type="text/html" id="tmpl-cfw-item">
			<?php self::item_row( '__INDEX__', CFW_Settings::item_defaults() ); ?>
		</script>
		<?php
	}

	/**
	 * @param int|string $index Row index, or the template placeholder.
	 * @param array      $item  Item config.
	 */
	private static function item_row( $index, array $item ) {
		$name = 'cfw[items][' . $index . ']';
		?>
		<div class="cfw-a__item" data-index="<?php echo esc_attr( $index ); ?>">
			<div class="cfw-a__item-head">
				<span class="cfw-a__grip dashicons dashicons-menu" aria-hidden="true"></span>

				<select name="<?php echo esc_attr( $name ); ?>[source]" class="cfw-a__source">
					<?php foreach ( CFW_Sources::all() as $group => $sources ) : ?>
						<optgroup label="<?php echo esc_attr( $group ); ?>">
							<?php foreach ( $sources as $key => $label ) : ?>
								<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $item['source'], $key ); ?>>
									<?php echo esc_html( $label ); ?>
								</option>
							<?php endforeach; ?>
						</optgroup>
					<?php endforeach; ?>
				</select>

				<button type="button" class="button-link cfw-a__remove" aria-label="<?php esc_attr_e( 'Remove this item', 'custom-filter-widget' ); ?>">
					<span class="dashicons dashicons-trash" aria-hidden="true"></span>
				</button>
			</div>

			<div class="cfw-a__item-body">
				<p class="cfw-a__f">
					<label><?php esc_html_e( 'Heading', 'custom-filter-widget' ); ?></label>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[heading]"
						value="<?php echo esc_attr( $item['heading'] ); ?>"
						placeholder="<?php echo esc_attr( CFW_Sources::label( $item['source'] ) ); ?>" />
					<span class="description"><?php esc_html_e( 'Left blank, the source\'s own name is used.', 'custom-filter-widget' ); ?></span>
				</p>

				<p class="cfw-a__f">
					<label>
						<input type="checkbox" name="<?php echo esc_attr( $name ); ?>[show_heading]" value="1" <?php checked( ! empty( $item['show_heading'] ) ); ?> />
						<?php esc_html_e( 'Show this heading', 'custom-filter-widget' ); ?>
					</label>
					<span class="description">
						<?php esc_html_e( 'Unticked, the heading is hidden on screen but still read out to screen readers — a group of checkboxes with nothing naming it cannot be used.', 'custom-filter-widget' ); ?>
					</span>
				</p>

				<p class="cfw-a__f">
					<label><?php esc_html_e( 'Style', 'custom-filter-widget' ); ?></label>
					<select name="<?php echo esc_attr( $name ); ?>[style]">
						<option value="checkbox" <?php selected( $item['style'], 'checkbox' ); ?>><?php esc_html_e( 'Checkboxes', 'custom-filter-widget' ); ?></option>
						<option value="radio" <?php selected( $item['style'], 'radio' ); ?>><?php esc_html_e( 'Radio buttons', 'custom-filter-widget' ); ?></option>
						<option value="chips" <?php selected( $item['style'], 'chips' ); ?>><?php esc_html_e( 'Inline chips', 'custom-filter-widget' ); ?></option>
						<option value="dropdown" <?php selected( $item['style'], 'dropdown' ); ?>><?php esc_html_e( 'Dropdown', 'custom-filter-widget' ); ?></option>
					</select>
				</p>

				<p class="cfw-a__f cfw-a__f--inline">
					<label>
						<input type="checkbox" name="<?php echo esc_attr( $name ); ?>[multiple]" value="1" <?php checked( ! empty( $item['multiple'] ) ); ?> />
						<?php esc_html_e( 'Allow several at once', 'custom-filter-widget' ); ?>
					</label>
					<label>
						<input type="checkbox" name="<?php echo esc_attr( $name ); ?>[show_count]" value="1" <?php checked( ! empty( $item['show_count'] ) ); ?> />
						<?php esc_html_e( 'Show counts', 'custom-filter-widget' ); ?>
					</label>
					<label>
						<input type="checkbox" name="<?php echo esc_attr( $name ); ?>[hide_empty]" value="1" <?php checked( ! empty( $item['hide_empty'] ) ); ?> />
						<?php esc_html_e( 'Hide empty terms', 'custom-filter-widget' ); ?>
					</label>
				</p>

				<p class="cfw-a__f">
					<label><?php esc_html_e( 'Collapse after', 'custom-filter-widget' ); ?></label>
					<input type="number" min="0" max="200" class="small-text"
						name="<?php echo esc_attr( $name ); ?>[limit]" value="<?php echo esc_attr( $item['limit'] ); ?>" />
					<span class="description"><?php esc_html_e( 'Choices before a "show more" button. 0 shows them all.', 'custom-filter-widget' ); ?></span>
				</p>
			</div>
		</div>
		<?php
	}

	/* ------------------------------------------------------------------ *
	 * Where
	 * ------------------------------------------------------------------ */

	public static function panel_where( $post ) {
		$config    = CFW_Settings::get( $post->ID );
		$chosen    = (array) $config['where']['locations'];
		$everywhere = ( 'everywhere' === $config['where']['mode'] );
		?>
		<p class="cfw-a__lead">
			<?php esc_html_e( 'The widget only renders where you say. This is checked wherever it is placed — so a filter in a sidebar that appears site-wide still only shows on the pages ticked here.', 'custom-filter-widget' ); ?>
		</p>

		<p>
			<label>
				<input type="radio" name="cfw[where][mode]" value="rules" <?php checked( ! $everywhere ); ?> />
				<?php esc_html_e( 'Only where I tick below', 'custom-filter-widget' ); ?>
			</label>
			<br />
			<label>
				<input type="radio" name="cfw[where][mode]" value="everywhere" <?php checked( $everywhere ); ?> />
				<?php esc_html_e( 'Everywhere on the front end', 'custom-filter-widget' ); ?>
			</label>
		</p>

		<div class="cfw-a__locations">
			<?php foreach ( CFW_Location::choices() as $group => $locations ) : ?>
				<div class="cfw-a__loc-group">
					<h4><?php echo esc_html( $group ); ?></h4>
					<?php foreach ( $locations as $key => $label ) : ?>
						<label>
							<input type="checkbox" name="cfw[where][locations][]"
								value="<?php echo esc_attr( $key ); ?>"
								<?php checked( in_array( $key, $chosen, true ) ); ?> />
							<?php echo esc_html( $label ); ?>
						</label>
					<?php endforeach; ?>
				</div>
			<?php endforeach; ?>
		</div>

		<?php if ( CFW_Sources::woo() ) : ?>
			<div class="notice notice-info inline">
				<p>
					<?php esc_html_e( 'For a shop, tick "Products archive". That covers the Shop page and every product category and tag archive under it — a filter that vanished the moment somebody narrowed to a category would be useless.', 'custom-filter-widget' ); ?>
				</p>
			</div>
		<?php endif; ?>
		<?php
	}

	/* ------------------------------------------------------------------ *
	 * Method, per page
	 * ------------------------------------------------------------------ */

	public static function panel_method( $post ) {
		$config    = CFW_Settings::get( $post->ID );
		$default   = $config['method']['default'];
		$overrides = (array) $config['method']['overrides'];

		/*
		 * Only the locations this set actually shows on are offered an
		 * override. Listing every location on the site would be a wall of rows
		 * that mostly cannot ever apply.
		 */
		$locations = ( 'everywhere' === $config['where']['mode'] )
			? array_keys( $overrides )
			: array_unique( array_merge( (array) $config['where']['locations'], array_keys( $overrides ) ) );
		?>
		<p class="cfw-a__lead">
			<?php esc_html_e( 'Both methods are always built. The server filters the results either way, so a filtered link works when it is shared, bookmarked or opened with JavaScript off — AJAX only saves the page load.', 'custom-filter-widget' ); ?>
		</p>

		<p>
			<strong><?php esc_html_e( 'Default for this filter set', 'custom-filter-widget' ); ?></strong><br />
			<label>
				<input type="radio" name="cfw[method][default]" value="reload" <?php checked( 'reload' === $default ); ?> />
				<?php esc_html_e( 'Page reload', 'custom-filter-widget' ); ?>
			</label>
			<br />
			<label>
				<input type="radio" name="cfw[method][default]" value="ajax" <?php checked( 'ajax' === $default ); ?> />
				<?php esc_html_e( 'AJAX', 'custom-filter-widget' ); ?>
			</label>
		</p>

		<?php $mode = ( 'auto' === $config['apply_mode'] ) ? 'auto' : 'button'; ?>

		<h4><?php esc_html_e( 'The Apply button', 'custom-filter-widget' ); ?></h4>

		<p>
			<label>
				<input type="radio" name="cfw[apply_mode]" value="button" <?php checked( 'button' === $mode ); ?> />
				<?php esc_html_e( 'Show an Apply button', 'custom-filter-widget' ); ?>
			</label>
			<span class="description">
				<?php esc_html_e( 'Nothing is filtered until it is pressed, so three choices cost one request.', 'custom-filter-widget' ); ?>
			</span>
		</p>

		<p>
			<label>
				<input type="radio" name="cfw[apply_mode]" value="auto" <?php checked( 'auto' === $mode ); ?> />
				<?php esc_html_e( 'No button — filter as soon as a choice is made', 'custom-filter-widget' ); ?>
			</label>
			<span class="description">
				<?php esc_html_e( 'Fewer clicks, and one request per choice. Pairs best with AJAX; on a reload page each choice is a page load, and the widget waits a moment first so two quick ticks cost one.', 'custom-filter-widget' ); ?>
			</span>
		</p>

		<p class="description">
			<?php esc_html_e( 'A price range or a search box always waits for Apply, whichever is chosen — otherwise it would fire on every keystroke. The button is still in the page for anyone whose JavaScript did not run, so the form can always be submitted.', 'custom-filter-widget' ); ?>
		</p>

		<?php if ( $locations ) : ?>
			<h4><?php esc_html_e( 'Per-page overrides', 'custom-filter-widget' ); ?></h4>

			<table class="widefat striped cfw-a__methods">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Location', 'custom-filter-widget' ); ?></th>
						<th><?php esc_html_e( 'Method', 'custom-filter-widget' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $locations as $key ) : ?>
						<?php $current = $overrides[ $key ] ?? ''; ?>
						<tr>
							<td><?php echo esc_html( CFW_Location::label( $key ) ); ?></td>
							<td>
								<select name="cfw[method][overrides][<?php echo esc_attr( $key ); ?>]">
									<option value=""><?php esc_html_e( 'Use the default', 'custom-filter-widget' ); ?></option>
									<option value="reload" <?php selected( 'reload', $current ); ?>><?php esc_html_e( 'Page reload', 'custom-filter-widget' ); ?></option>
									<option value="ajax" <?php selected( 'ajax', $current ); ?>><?php esc_html_e( 'AJAX', 'custom-filter-widget' ); ?></option>
								</select>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<p class="description">
				<?php esc_html_e( 'A rule on one specific page beats a rule on the archive it belongs to, and both beat the default.', 'custom-filter-widget' ); ?>
			</p>
		<?php else : ?>
			<p class="description">
				<?php esc_html_e( 'Tick some locations above and save, and they will appear here so you can give each one its own method.', 'custom-filter-widget' ); ?>
			</p>
		<?php endif; ?>

		<div class="notice notice-warning inline">
			<p>
				<strong><?php esc_html_e( 'AJAX needs to know what to replace.', 'custom-filter-widget' ); ?></strong>
				<?php esc_html_e( 'On a WooCommerce shop archive the plugin wraps the product loop itself. Anywhere else, put [cfw_results] where the results should go. Without a target, an AJAX filter falls back to a reload rather than appearing to do nothing.', 'custom-filter-widget' ); ?>
			</p>
		</div>
		<?php
	}

	/* ------------------------------------------------------------------ *
	 * Styling
	 * ------------------------------------------------------------------ */

	public static function panel_style( $post ) {
		$config = CFW_Settings::get( $post->ID );
		$style  = $config['style'];

		$colours = array(
			'heading_color'    => __( 'Heading', 'custom-filter-widget' ),
			'text_color'       => __( 'Text', 'custom-filter-widget' ),
			'accent_color'     => __( 'Accent', 'custom-filter-widget' ),
			'background_color' => __( 'Background', 'custom-filter-widget' ),
			'border_color'     => __( 'Border', 'custom-filter-widget' ),
		);

		$sizes = array(
			'border_width'  => array( __( 'Border width', 'custom-filter-widget' ), 0, 20 ),
			'border_radius' => array( __( 'Corner radius', 'custom-filter-widget' ), 0, 60 ),
			'padding'       => array( __( 'Padding', 'custom-filter-widget' ), 0, 80 ),
			'item_spacing'  => array( __( 'Spacing between choices', 'custom-filter-widget' ), 0, 60 ),
			'heading_size'  => array( __( 'Heading size', 'custom-filter-widget' ), 8, 60 ),
			'font_size'     => array( __( 'Text size', 'custom-filter-widget' ), 8, 40 ),
		);
		?>
		<div class="cfw-a__grid">
			<?php foreach ( $colours as $key => $label ) : ?>
				<p class="cfw-a__f">
					<label for="cfw-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label>
					<input type="color" id="cfw-<?php echo esc_attr( $key ); ?>"
						name="cfw[style][<?php echo esc_attr( $key ); ?>]"
						value="<?php echo esc_attr( $style[ $key ] ); ?>" />
				</p>
			<?php endforeach; ?>

			<?php foreach ( $sizes as $key => $meta ) : ?>
				<p class="cfw-a__f">
					<label for="cfw-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $meta[0] ); ?></label>
					<input type="number" class="small-text" id="cfw-<?php echo esc_attr( $key ); ?>"
						name="cfw[style][<?php echo esc_attr( $key ); ?>]"
						value="<?php echo esc_attr( $style[ $key ] ); ?>"
						min="<?php echo esc_attr( $meta[1] ); ?>" max="<?php echo esc_attr( $meta[2] ); ?>" />
					<span class="description">px</span>
				</p>
			<?php endforeach; ?>

			<p class="cfw-a__f">
				<label for="cfw-layout"><?php esc_html_e( 'Layout', 'custom-filter-widget' ); ?></label>
				<select id="cfw-layout" name="cfw[style][layout]">
					<option value="list" <?php selected( $style['layout'], 'list' ); ?>><?php esc_html_e( 'Stacked list', 'custom-filter-widget' ); ?></option>
					<option value="inline" <?php selected( $style['layout'], 'inline' ); ?>><?php esc_html_e( 'Inline row', 'custom-filter-widget' ); ?></option>
				</select>
			</p>
		</div>

		<h4><?php esc_html_e( 'Button and message wording', 'custom-filter-widget' ); ?></h4>

		<div class="cfw-a__grid">
			<?php
			$labels = array(
				'apply'      => __( 'Apply button', 'custom-filter-widget' ),
				'reset'      => __( 'Reset link', 'custom-filter-widget' ),
				'no_results' => __( 'When nothing matches', 'custom-filter-widget' ),
			);

			foreach ( $labels as $key => $label ) :
				?>
				<p class="cfw-a__f">
					<label for="cfw-label-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label>
					<input type="text" id="cfw-label-<?php echo esc_attr( $key ); ?>"
						name="cfw[labels][<?php echo esc_attr( $key ); ?>]"
						value="<?php echo esc_attr( $config['labels'][ $key ] ); ?>" />
				</p>
			<?php endforeach; ?>
		</div>

		<h4><?php esc_html_e( 'Custom CSS', 'custom-filter-widget' ); ?></h4>

		<p class="description">
			<?php esc_html_e( 'Applies to every filter set on the page it appears on. The wrapper is .cfw, a heading is .cfw__heading and one choice is .cfw__option.', 'custom-filter-widget' ); ?>
		</p>

		<textarea name="cfw[style][custom_css]" rows="6" class="large-text code"
			spellcheck="false"><?php echo esc_textarea( $style['custom_css'] ); ?></textarea>
		<?php
	}

	/* ------------------------------------------------------------------ *
	 * Placement
	 * ------------------------------------------------------------------ */

	public static function panel_usage( $post ) {
		?>
		<p><strong><?php esc_html_e( 'Shortcode', 'custom-filter-widget' ); ?></strong></p>
		<p>
			<input type="text" class="widefat code" readonly onfocus="this.select()"
				value="[cfw_filter id=&quot;<?php echo esc_attr( $post->ID ); ?>&quot;]" />
		</p>

		<p><strong><?php esc_html_e( 'Sidebar', 'custom-filter-widget' ); ?></strong></p>
		<p class="description">
			<?php esc_html_e( 'Appearance → Widgets → Custom Filter, then pick this set.', 'custom-filter-widget' ); ?>
		</p>

		<p><strong><?php esc_html_e( 'Results area', 'custom-filter-widget' ); ?></strong></p>
		<p>
			<input type="text" class="widefat code" readonly onfocus="this.select()"
				value="[cfw_results post_type=&quot;post&quot;]" />
		</p>
		<p class="description">
			<?php esc_html_e( 'Only needed outside a WooCommerce shop archive, where the product loop is wrapped automatically.', 'custom-filter-widget' ); ?>
		</p>
		<?php
	}

	/* ------------------------------------------------------------------ *
	 * Saving
	 * ------------------------------------------------------------------ */

	/**
	 * @param int     $post_id Post being saved.
	 * @param WP_Post $post    The post.
	 */
	public static function save( $post_id, $post ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}

		if ( ! isset( $_POST['cfw_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['cfw_nonce'] ) ), 'cfw_save' ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		/*
		 * Deliberately not sanitised here. Everything below is raw input handed
		 * straight to CFW_Settings::save(), which is the one place that cleans
		 * it — key by key, against what each key is allowed to be. Sanitising
		 * in two places is how one of them ends up weaker than the other.
		 */
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash
		$raw = isset( $_POST['cfw'] ) && is_array( $_POST['cfw'] ) ? wp_unslash( $_POST['cfw'] ) : array();

		CFW_Settings::save( $post_id, $raw );
	}

	/* ------------------------------------------------------------------ *
	 * The list table, and assets
	 * ------------------------------------------------------------------ */

	public static function columns( $columns ) {
		$date = $columns['date'] ?? null;

		unset( $columns['date'] );

		$columns['cfw_items']  = __( 'Items', 'custom-filter-widget' );
		$columns['cfw_where']  = __( 'Shows on', 'custom-filter-widget' );
		$columns['cfw_how']    = __( 'Method', 'custom-filter-widget' );
		$columns['cfw_short']  = __( 'Shortcode', 'custom-filter-widget' );

		if ( $date ) {
			$columns['date'] = $date;
		}

		return $columns;
	}

	public static function column( $column, $post_id ) {
		$config = CFW_Settings::get( $post_id );

		switch ( $column ) {
			case 'cfw_items':
				if ( ! $config['items'] ) {
					echo '<em>' . esc_html__( 'None yet', 'custom-filter-widget' ) . '</em>';
					break;
				}

				$names = array();

				foreach ( $config['items'] as $item ) {
					$names[] = CFW_Sources::label( $item['source'] );
				}

				echo esc_html( implode( ', ', $names ) );
				break;

			case 'cfw_where':
				if ( 'everywhere' === $config['where']['mode'] ) {
					echo esc_html__( 'Everywhere', 'custom-filter-widget' );
					break;
				}

				$count = count( $config['where']['locations'] );

				if ( ! $count ) {
					// Worth flagging: a set with no locations is switched on,
					// looks configured, and renders nowhere.
					echo '<span style="color:#b32d2e">' . esc_html__( 'Nowhere — no locations ticked', 'custom-filter-widget' ) . '</span>';
					break;
				}

				echo esc_html( sprintf( /* translators: %d: number of locations. */ _n( '%d location', '%d locations', $count, 'custom-filter-widget' ), $count ) );
				break;

			case 'cfw_how':
				$how = ( 'ajax' === $config['method']['default'] ) ? __( 'AJAX', 'custom-filter-widget' ) : __( 'Reload', 'custom-filter-widget' );

				$overrides = count( $config['method']['overrides'] );

				echo esc_html( $overrides ? sprintf( /* translators: 1: default method, 2: number of overrides. */ _n( '%1$s, %2$d override', '%1$s, %2$d overrides', $overrides, 'custom-filter-widget' ), $how, $overrides ) : $how );
				break;

			case 'cfw_short':
				echo '<code>[cfw_filter id="' . esc_attr( $post_id ) . '"]</code>';
				break;
		}
	}

	public static function assets( $hook ) {
		if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			return;
		}

		$screen = get_current_screen();

		if ( ! $screen || CFW_Settings::POST_TYPE !== $screen->post_type ) {
			return;
		}

		wp_enqueue_style( 'cfw-admin', CFW_URL . 'admin/css/admin.css', array(), CFW_VERSION );
		wp_enqueue_script( 'cfw-admin', CFW_URL . 'admin/js/admin.js', array( 'jquery', 'jquery-ui-sortable' ), CFW_VERSION, true );
	}
}

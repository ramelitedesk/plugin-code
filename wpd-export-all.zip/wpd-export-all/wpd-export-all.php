<?php
/**
 * Plugin Name:       WPD Export All
 * Plugin URI:        https://webart.technology/
 * Description:       Export everything — posts, pages, products, any custom post type, taxonomies and their terms, form definitions and form leads — with ACF field data resolved rather than dumped raw. Pick what you want in the admin, and it runs in batches so a large site finishes instead of timing out.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Ramakrishna
 * License:           GPL-2.0-or-later
 * Text Domain:       wpd-export-all
 *
 * @package WPD_Export_All
 */

defined( 'ABSPATH' ) || exit;

define( 'WPDEX_VERSION', '1.0.0' );
define( 'WPDEX_FILE', __FILE__ );
define( 'WPDEX_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPDEX_URL', plugin_dir_url( __FILE__ ) );

/**
 * An exporter has two ways to fail, and the quiet one is the expensive one.
 *
 * Falling over is obvious: the page times out, nothing downloads, somebody
 * complains the same afternoon. Producing a file that is *missing things* is
 * not — it downloads, it opens, it has thousands of rows in it, and the gap is
 * found weeks later by whoever imported it somewhere else.
 *
 * So the whole design leans against the quiet one:
 *
 *   • Nothing runs in a single request. A 40,000-product shop will exhaust
 *     memory or hit max_execution_time, and PHP dying mid-write leaves a
 *     truncated file that looks complete. Every source is walked in batches
 *     with a cursor, appending to disk as it goes.
 *   • Rows are counted before and after. The manifest records how many of each
 *     source were expected and how many were written, so a short export is
 *     visible in the file itself rather than being something you have to
 *     notice.
 *   • Serialised meta is unserialised and re-encoded, never written raw. A CSV
 *     cell containing a:3:{i:0;s:5:"green"…} is data nobody can use.
 *   • ACF is asked for its own values where it is installed, so a repeater
 *     comes out as a repeater instead of forty rows of field_5f3a_0_title.
 *
 * And one that is about the reader rather than the data: every CSV cell is
 * checked for formula injection before it is written. A product title of
 * =cmd|'/c calc'!A1 is a live formula the moment the export is opened in Excel,
 * and an exporter is exactly the wrong place to hand one over.
 */
final class WPD_Export_All {

	/** @var WPD_Export_All|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->boot();
		}

		return self::$instance;
	}

	private function boot() {
		require_once WPDEX_DIR . 'includes/class-wpdex-storage.php';
		require_once WPDEX_DIR . 'includes/class-wpdex-sources.php';
		require_once WPDEX_DIR . 'includes/class-wpdex-filters.php';
		require_once WPDEX_DIR . 'includes/class-wpdex-acf.php';
		require_once WPDEX_DIR . 'includes/class-wpdex-writer.php';
		require_once WPDEX_DIR . 'includes/class-wpdex-posts.php';
		require_once WPDEX_DIR . 'includes/class-wpdex-terms.php';
		require_once WPDEX_DIR . 'includes/class-wpdex-forms.php';
		require_once WPDEX_DIR . 'includes/class-wpdex-job.php';
		require_once WPDEX_DIR . 'includes/class-wpdex-import.php';

		if ( is_admin() ) {
			require_once WPDEX_DIR . 'includes/class-wpdex-admin.php';
		}

		add_action( 'init', array( $this, 'load_textdomain' ), 1 );

		/*
		 * Priority 20, so WooCommerce, ACF and every form plugin have registered
		 * their post types and declared themselves before anything asks what
		 * this site contains. Earlier means the source list is missing exactly
		 * the things somebody installed this to export.
		 */
		add_action( 'plugins_loaded', array( $this, 'init' ), 20 );

		add_action( 'wpdex_cleanup', array( 'WPDEX_Storage', 'purge_expired' ) );

		register_activation_hook( WPDEX_FILE, array( __CLASS__, 'activate' ) );
		register_deactivation_hook( WPDEX_FILE, array( __CLASS__, 'deactivate' ) );
	}

	public function load_textdomain() {
		load_plugin_textdomain( 'wpd-export-all', false, dirname( plugin_basename( WPDEX_FILE ) ) . '/languages' );
	}

	public function init() {
		WPDEX_Job::init();
		WPDEX_Import::init();

		if ( is_admin() && class_exists( 'WPDEX_Admin' ) ) {
			WPDEX_Admin::init();
		}

		do_action( 'wpdex_loaded', $this );
	}

	public static function activate() {
		WPDEX_Storage::dir();

		/*
		 * Finished exports are the entire contents of the site sitting in a
		 * file. They are deleted after a week whether anybody comes back for
		 * them or not — an export nobody downloaded is not worth keeping, and
		 * it is worth quite a lot to somebody else.
		 */
		if ( ! wp_next_scheduled( 'wpdex_cleanup' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'wpdex_cleanup' );
		}
	}

	public static function deactivate() {
		$timestamp = wp_next_scheduled( 'wpdex_cleanup' );

		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, 'wpdex_cleanup' );
		}
	}
}

WPD_Export_All::instance();

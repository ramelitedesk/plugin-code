<?php
/**
 * The export screen.
 *
 * @package WPD_Export_All
 *
 * @var array $groups Source groups from WPDEX_Sources::all().
 * @var array $jobs   Past jobs.
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wrap wpdex">
	<h1><?php esc_html_e( 'Export All', 'wpd-export-all' ); ?></h1>

	<?php WPDEX_Admin::tabs( 'export' ); ?>

	<p class="wpdex__lead">
		<?php esc_html_e( 'Tick what you want, choose a format, and press Export. It runs in batches, so a large site finishes rather than timing out — leave this tab open while it works.', 'wpd-export-all' ); ?>
	</p>

	<?php if ( isset( $_GET['deleted'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
		<div class="notice notice-success is-dismissible">
			<p><?php esc_html_e( 'Export deleted.', 'wpd-export-all' ); ?></p>
		</div>
	<?php endif; ?>

	<form id="wpdex-form">
		<div class="wpdex__panel">
			<div class="wpdex__panel-head">
				<h2><?php esc_html_e( 'What to export', 'wpd-export-all' ); ?></h2>

				<p class="wpdex__bulk">
					<button type="button" class="button-link" data-wpdex-all><?php esc_html_e( 'Select all', 'wpd-export-all' ); ?></button>
					<span aria-hidden="true">·</span>
					<button type="button" class="button-link" data-wpdex-none><?php esc_html_e( 'Select none', 'wpd-export-all' ); ?></button>
				</p>
			</div>

			<?php foreach ( $groups as $group => $sources ) : ?>
				<div class="wpdex__group">
					<h3><?php echo esc_html( $group ); ?></h3>

					<div class="wpdex__sources">
						<?php foreach ( $sources as $key => $source ) : ?>
							<label class="wpdex__source<?php echo empty( $source['count'] ) ? ' is-empty' : ''; ?>">
								<input type="checkbox" name="sources[]" value="<?php echo esc_attr( $key ); ?>" />
								<span class="wpdex__source-label"><?php echo esc_html( $source['label'] ); ?></span>
								<span class="wpdex__count"><?php echo esc_html( number_format_i18n( $source['count'] ) ); ?></span>
							</label>
						<?php endforeach; ?>
					</div>
				</div>
			<?php endforeach; ?>

			<?php if ( ! $groups ) : ?>
				<p><?php esc_html_e( 'Nothing exportable was found, which should not happen — a site always has posts and pages.', 'wpd-export-all' ); ?></p>
			<?php endif; ?>
		</div>

		<div class="wpdex__columns">
			<div class="wpdex__panel">
				<h2><?php esc_html_e( 'Format', 'wpd-export-all' ); ?></h2>

				<label class="wpdex__radio">
					<input type="radio" name="format" value="csv" checked="checked" />
					<strong><?php esc_html_e( 'CSV', 'wpd-export-all' ); ?></strong>
					<span><?php esc_html_e( 'One file per thing, opens in Excel, Numbers or Sheets. Nested fields such as an ACF repeater become JSON inside a single cell, because a spreadsheet column cannot hold a list that is a different length on every row.', 'wpd-export-all' ); ?></span>
				</label>

				<label class="wpdex__radio">
					<input type="radio" name="format" value="json" />
					<strong><?php esc_html_e( 'JSON', 'wpd-export-all' ); ?></strong>
					<span><?php esc_html_e( 'Keeps every structure intact — repeaters, flexible content, galleries, relationships. The one to pick if anything is going to be imported somewhere else rather than read by a person.', 'wpd-export-all' ); ?></span>
				</label>
			</div>

			<div class="wpdex__panel">
				<h2><?php esc_html_e( 'What to include', 'wpd-export-all' ); ?></h2>

				<label class="wpdex__check">
					<input type="checkbox" name="opt_content" value="1" checked="checked" />
					<?php esc_html_e( 'Post content', 'wpd-export-all' ); ?>
					<span class="description"><?php esc_html_e( 'The body of each post. Untick for a much smaller file when you only want the fields.', 'wpd-export-all' ); ?></span>
				</label>

				<label class="wpdex__check">
					<input type="checkbox" name="opt_taxonomies" value="1" checked="checked" />
					<?php esc_html_e( 'Categories and tags on each row', 'wpd-export-all' ); ?>
				</label>

				<label class="wpdex__check">
					<input type="checkbox" name="opt_meta" value="1" checked="checked" />
					<?php esc_html_e( 'Custom fields (post meta)', 'wpd-export-all' ); ?>
					<span class="description"><?php esc_html_e( 'Includes WooCommerce prices, SKUs and stock, which live in meta.', 'wpd-export-all' ); ?></span>
				</label>

				<label class="wpdex__check">
					<input type="checkbox" name="opt_acf" value="1" <?php checked( true ); ?> />
					<?php esc_html_e( 'ACF fields, assembled', 'wpd-export-all' ); ?>
					<span class="description">
						<?php if ( WPDEX_ACF::active() ) : ?>
							<?php esc_html_e( 'ACF is active, so repeaters, galleries and relationships come out as real structures rather than rows of field_5f3a_0_title.', 'wpd-export-all' ); ?>
						<?php else : ?>
							<?php esc_html_e( 'ACF is not active. Any ACF data still in the database will be reassembled from the raw rows, which is less faithful but much better than nothing.', 'wpd-export-all' ); ?>
						<?php endif; ?>
					</span>
				</label>

				<label class="wpdex__check">
					<input type="checkbox" name="opt_protected_meta" value="1" />
					<?php esc_html_e( 'Skip hidden meta (keys starting with an underscore)', 'wpd-export-all' ); ?>
					<span class="description"><?php esc_html_e( 'Makes a tidier file — but WooCommerce keeps _price, _sku and _stock there, so leave this unticked for a shop.', 'wpd-export-all' ); ?></span>
				</label>
			</div>
		</div>

		<div class="wpdex__panel wpdex__filters">
			<div class="wpdex__panel-head">
				<h2><?php esc_html_e( 'Narrow it down', 'wpd-export-all' ); ?></h2>
				<p class="wpdex__bulk">
					<button type="button" class="button-link" id="wpdex-toggle-filters" aria-expanded="false">
						<?php esc_html_e( 'Show filters', 'wpd-export-all' ); ?>
					</button>
				</p>
			</div>

			<p class="description">
				<?php esc_html_e( 'Leave all of this alone to export everything. Anything you set here applies to posts, pages, products and custom post types; dates also apply to form leads. Taxonomies and form definitions have no dates or authors, so only the row cap affects them.', 'wpd-export-all' ); ?>
			</p>

			<div class="wpdex__filter-body" id="wpdex-filter-body" hidden>
				<div class="wpdex__filter-grid">

					<div class="wpdex__filter">
						<h4><?php esc_html_e( 'Date', 'wpd-export-all' ); ?></h4>

						<p>
							<label for="wpdex-date-field"><?php esc_html_e( 'Which date', 'wpd-export-all' ); ?></label>
							<select id="wpdex-date-field" name="filters[date_field]">
								<option value="created"><?php esc_html_e( 'Published', 'wpd-export-all' ); ?></option>
								<option value="modified"><?php esc_html_e( 'Last modified', 'wpd-export-all' ); ?></option>
							</select>
						</p>

						<p>
							<label for="wpdex-date-range"><?php esc_html_e( 'Range', 'wpd-export-all' ); ?></label>
							<select id="wpdex-date-range" name="filters[date_range]">
								<?php foreach ( WPDEX_Filters::ranges() as $key => $label ) : ?>
									<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
						</p>

						<p class="wpdex__custom-dates" hidden>
							<label for="wpdex-date-from"><?php esc_html_e( 'From', 'wpd-export-all' ); ?></label>
							<input type="date" id="wpdex-date-from" name="filters[date_from]" />
							<label for="wpdex-date-to"><?php esc_html_e( 'To', 'wpd-export-all' ); ?></label>
							<input type="date" id="wpdex-date-to" name="filters[date_to]" />
						</p>

						<p>
							<label for="wpdex-month"><?php esc_html_e( 'Or one month', 'wpd-export-all' ); ?></label>
							<input type="month" id="wpdex-month" name="filters[month]" />
						</p>
					</div>

					<div class="wpdex__filter">
						<h4><?php esc_html_e( 'Days and hours', 'wpd-export-all' ); ?></h4>

						<p class="description"><?php esc_html_e( 'Only rows created on these days, or in these hours. Useful for "what came in over the weekend".', 'wpd-export-all' ); ?></p>

						<div class="wpdex__days">
							<?php
							global $wp_locale;

							for ( $day = 0; $day <= 6; $day++ ) :
								?>
								<label>
									<input type="checkbox" name="filters[weekdays][]" value="<?php echo esc_attr( $day ); ?>" />
									<?php echo esc_html( $wp_locale->get_weekday_abbrev( $wp_locale->get_weekday( $day ) ) ); ?>
								</label>
							<?php endfor; ?>
						</div>

						<div class="wpdex__hours">
							<?php for ( $hour = 0; $hour <= 23; $hour++ ) : ?>
								<label>
									<input type="checkbox" name="filters[hours][]" value="<?php echo esc_attr( $hour ); ?>" />
									<?php echo esc_html( sprintf( '%02d', $hour ) ); ?>
								</label>
							<?php endfor; ?>
						</div>
					</div>

					<div class="wpdex__filter">
						<h4><?php esc_html_e( 'Status and author', 'wpd-export-all' ); ?></h4>

						<div class="wpdex__checklist">
							<?php foreach ( WPDEX_Admin::statuses() as $key => $label ) : ?>
								<label>
									<input type="checkbox" name="filters[statuses][]" value="<?php echo esc_attr( $key ); ?>" />
									<?php echo esc_html( $label ); ?>
								</label>
							<?php endforeach; ?>
						</div>

						<p class="description"><?php esc_html_e( 'None ticked means every status except auto-drafts.', 'wpd-export-all' ); ?></p>

						<p>
							<label for="wpdex-authors"><?php esc_html_e( 'Author IDs', 'wpd-export-all' ); ?></label>
							<input type="text" id="wpdex-authors" name="filters[authors]" placeholder="1,4,9" />
						</p>

						<p>
							<label for="wpdex-search"><?php esc_html_e( 'Contains the words', 'wpd-export-all' ); ?></label>
							<input type="search" id="wpdex-search" name="filters[search]" />
						</p>
					</div>

					<div class="wpdex__filter">
						<h4><?php esc_html_e( 'How much', 'wpd-export-all' ); ?></h4>

						<p>
							<label for="wpdex-limit"><?php esc_html_e( 'Stop after', 'wpd-export-all' ); ?></label>
							<input type="number" min="0" step="1" class="small-text" id="wpdex-limit" name="filters[limit]" />
							<span class="description"><?php esc_html_e( 'rows per source. 0 for no limit — useful for testing the shape of a file before running the real thing.', 'wpd-export-all' ); ?></span>
						</p>

						<p>
							<label for="wpdex-id-from"><?php esc_html_e( 'ID range', 'wpd-export-all' ); ?></label>
							<input type="number" min="0" step="1" class="small-text" id="wpdex-id-from" name="filters[id_from]" placeholder="<?php esc_attr_e( 'from', 'wpd-export-all' ); ?>" />
							<input type="number" min="0" step="1" class="small-text" name="filters[id_to]" placeholder="<?php esc_attr_e( 'to', 'wpd-export-all' ); ?>" />
						</p>
					</div>

					<?php if ( WPDEX_Sources::woo() ) : ?>
						<div class="wpdex__filter">
							<h4><?php esc_html_e( 'Products', 'wpd-export-all' ); ?></h4>

							<p>
								<label for="wpdex-price-min"><?php esc_html_e( 'Price between', 'wpd-export-all' ); ?></label>
								<input type="number" min="0" step="any" class="small-text" id="wpdex-price-min" name="filters[price_min]" />
								<input type="number" min="0" step="any" class="small-text" name="filters[price_max]" />
							</p>

							<div class="wpdex__checklist">
								<?php
								$stock_labels = array(
									'instock'     => __( 'In stock', 'wpd-export-all' ),
									'outofstock'  => __( 'Out of stock', 'wpd-export-all' ),
									'onbackorder' => __( 'On backorder', 'wpd-export-all' ),
								);

								foreach ( $stock_labels as $key => $label ) :
									?>
									<label>
										<input type="checkbox" name="filters[stock][]" value="<?php echo esc_attr( $key ); ?>" />
										<?php echo esc_html( $label ); ?>
									</label>
								<?php endforeach; ?>
							</div>

							<p>
								<label>
									<input type="checkbox" name="filters[on_sale]" value="1" />
									<?php esc_html_e( 'Only products on sale', 'wpd-export-all' ); ?>
								</label>
							</p>
						</div>

						<?php if ( post_type_exists( 'shop_order' ) ) : ?>
							<div class="wpdex__filter">
								<h4><?php esc_html_e( 'Orders', 'wpd-export-all' ); ?></h4>

								<div class="wpdex__checklist">
									<?php foreach ( wc_get_order_statuses() as $key => $label ) : ?>
										<label>
											<input type="checkbox" name="filters[order_status][]" value="<?php echo esc_attr( $key ); ?>" />
											<?php echo esc_html( $label ); ?>
										</label>
									<?php endforeach; ?>
								</div>
							</div>
						<?php endif; ?>
					<?php endif; ?>

					<?php
					$taxonomies = get_taxonomies( array( 'public' => true ), 'objects' );

					if ( $taxonomies ) :
						?>
						<div class="wpdex__filter wpdex__filter--wide">
							<h4><?php esc_html_e( 'Only items in these terms', 'wpd-export-all' ); ?></h4>

							<p class="description"><?php esc_html_e( 'A term filter is ignored for any post type that does not have that taxonomy, so ticking a product category will not empty your posts export.', 'wpd-export-all' ); ?></p>

							<div class="wpdex__tax-grid">
								<?php
								foreach ( $taxonomies as $taxonomy ) :
									$terms = get_terms(
										array(
											'taxonomy'   => $taxonomy->name,
											'hide_empty' => false,
											'number'     => 100,
										)
									);

									if ( is_wp_error( $terms ) || ! $terms ) {
										continue;
									}
									?>
									<div class="wpdex__tax">
										<strong><?php echo esc_html( $taxonomy->labels->name ); ?></strong>
										<div class="wpdex__checklist">
											<?php foreach ( $terms as $term ) : ?>
												<label>
													<input type="checkbox" name="filters[terms][<?php echo esc_attr( $taxonomy->name ); ?>][]" value="<?php echo esc_attr( $term->term_id ); ?>" />
													<?php echo esc_html( $term->name ); ?>
												</label>
											<?php endforeach; ?>
										</div>
									</div>
								<?php endforeach; ?>
							</div>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>

		<p class="wpdex__actions">
			<button type="submit" class="button button-primary button-hero" id="wpdex-start">
				<?php esc_html_e( 'Export', 'wpd-export-all' ); ?>
			</button>
			<button type="button" class="button" id="wpdex-cancel" hidden><?php esc_html_e( 'Cancel', 'wpd-export-all' ); ?></button>
		</p>
	</form>

	<div class="wpdex__progress" id="wpdex-progress" hidden>
		<h2><?php esc_html_e( 'Working', 'wpd-export-all' ); ?></h2>

		<div class="wpdex__bar"><div class="wpdex__bar-fill" id="wpdex-bar" style="width:0"></div></div>

		<p class="wpdex__status" id="wpdex-status" role="status" aria-live="polite"></p>

		<ul class="wpdex__steps" id="wpdex-steps"></ul>
	</div>

	<div class="wpdex__panel wpdex__notice">
		<h2><?php esc_html_e( 'Before you download one', 'wpd-export-all' ); ?></h2>
		<p>
			<?php esc_html_e( 'A finished export is every post, every price and every form submission on this site in one file. Treat it the way you would treat a database dump: do not email it, do not leave it in a shared folder, and delete it here when you are done with it.', 'wpd-export-all' ); ?>
		</p>
		<p>
			<?php
			printf(
				/* translators: %s: number of days. */
				esc_html__( 'Exports are deleted automatically after %s days. The folder they live in is denied by an .htaccess file and every filename carries 32 random characters — but .htaccess is ignored on Nginx, so if you are on Nginx, treat the random name and the login check as the protection, and delete exports promptly.', 'wpd-export-all' ),
				esc_html( number_format_i18n( WPDEX_Storage::TTL / DAY_IN_SECONDS ) )
			);
			?>
		</p>
	</div>

	<?php if ( $jobs ) : ?>
		<h2><?php esc_html_e( 'Recent exports', 'wpd-export-all' ); ?></h2>

		<table class="widefat striped wpdex__jobs">
			<thead>
				<tr>
					<th><?php esc_html_e( 'When', 'wpd-export-all' ); ?></th>
					<th><?php esc_html_e( 'Contents', 'wpd-export-all' ); ?></th>
					<th><?php esc_html_e( 'Size', 'wpd-export-all' ); ?></th>
					<th><?php esc_html_e( 'Files', 'wpd-export-all' ); ?></th>
					<th></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $jobs as $job ) : ?>
					<?php
					$dir   = WPDEX_Storage::job_dir( $job['id'] );
					$files = $dir ? (array) glob( $dir . '*.{csv,json}', GLOB_BRACE ) : array();
					?>
					<tr>
						<td>
							<?php echo esc_html( wp_date( 'j M Y, H:i', $job['started'] ) ); ?>
							<?php if ( 'running' === $job['status'] ) : ?>
								<br /><em><?php esc_html_e( 'unfinished', 'wpd-export-all' ); ?></em>
							<?php endif; ?>
						</td>
						<td>
							<?php
							$labels = wp_list_pluck( $job['steps'], 'label' );

							echo esc_html( implode( ', ', array_slice( $labels, 0, 6 ) ) );

							if ( count( $labels ) > 6 ) {
								echo esc_html( sprintf( /* translators: %d: how many more. */ __( ' and %d more', 'wpd-export-all' ), count( $labels ) - 6 ) );
							}
							?>
						</td>
						<td><?php echo esc_html( WPDEX_Admin::size( WPDEX_Storage::job_size( $job['id'] ) ) ); ?></td>
						<td class="wpdex__files">
							<?php foreach ( $files as $file ) : ?>
								<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wpdex_download&job=' . rawurlencode( $job['id'] ) . '&file=' . rawurlencode( basename( $file ) ) ), 'wpdex_download_' . $job['id'] ) ); ?>">
									<?php echo esc_html( basename( $file ) ); ?>
								</a>
							<?php endforeach; ?>

							<?php if ( ! $files ) : ?>
								<em><?php esc_html_e( 'nothing written', 'wpd-export-all' ); ?></em>
							<?php endif; ?>
						</td>
						<td>
							<a class="wpdex__delete" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wpdex_delete&job=' . rawurlencode( $job['id'] ) ), 'wpdex_delete_' . $job['id'] ) ); ?>">
								<?php esc_html_e( 'Delete', 'wpd-export-all' ); ?>
							</a>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>
</div>

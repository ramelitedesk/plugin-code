<?php
/**
 * The import screen.
 *
 * @package WPD_Export_All
 */

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.NonceVerification.Recommended
$wpdex_ready = isset( $_GET['ready'] ) ? sanitize_text_field( wp_unslash( $_GET['ready'] ) ) : '';
$wpdex_error = isset( $_GET['error'] ) ? sanitize_key( wp_unslash( $_GET['error'] ) ) : '';
// phpcs:enable

$wpdex_uploads = WPDEX_Import::all();
$wpdex_current = $wpdex_ready ? WPDEX_Import::get( $wpdex_ready ) : ( $wpdex_uploads ? reset( $wpdex_uploads ) : null );
?>
<div class="wrap wpdex">
	<h1><?php esc_html_e( 'Export All', 'wpd-export-all' ); ?></h1>

	<?php WPDEX_Admin::tabs( 'import' ); ?>

	<?php if ( '' !== $wpdex_error ) : ?>
		<?php
		$wpdex_messages = array(
			'nofile'   => __( 'No file was uploaded.', 'wpd-export-all' ),
			'toobig'   => __( 'That file is over 64 MB. An import that large should be run with WP-CLI rather than through a browser.', 'wpd-export-all' ),
			'badjson'  => __( 'That file could not be read as JSON. Only the JSON exports this plugin produces can be imported — CSV cannot be.', 'wpd-export-all' ),
			'manifest' => __( 'That is a manifest.json, which describes an export rather than containing one. Upload one of the other files from the same folder.', 'wpd-export-all' ),
			'nodir'    => __( 'The uploads folder is not writable, so there is nowhere to put the file.', 'wpd-export-all' ),
		);
		?>
		<div class="notice notice-error">
			<p><?php echo esc_html( $wpdex_messages[ $wpdex_error ] ?? __( 'Something went wrong.', 'wpd-export-all' ) ); ?></p>
		</div>
	<?php endif; ?>

	<div class="wpdex__panel wpdex__notice">
		<h2><?php esc_html_e( 'Read this before you import anything', 'wpd-export-all' ); ?></h2>
		<p>
			<strong><?php esc_html_e( 'Importing writes to this site and there is no undo.', 'wpd-export-all' ); ?></strong>
			<?php esc_html_e( 'Exporting is safe — it only reads. Importing is not: a wrong match overwrites a real post, and a second run can double a catalogue. Take a database backup first. Not a file backup, a database one.', 'wpd-export-all' ); ?>
		</p>
		<p>
			<?php esc_html_e( 'The first run is always a dry run. It writes nothing and tells you what it would do. Nothing reaches the database until you untick that box and press the button a second time.', 'wpd-export-all' ); ?>
		</p>
		<p>
			<?php esc_html_e( 'Only JSON can be imported. A CSV loses the difference between the number 007 and the text "007", between an empty cell and nothing at all, and between a nested field and the text that looks like one — differences that do not matter when reading and matter a great deal when writing.', 'wpd-export-all' ); ?>
		</p>
	</div>

	<div class="wpdex__panel">
		<h2><?php esc_html_e( 'Upload a file', 'wpd-export-all' ); ?></h2>

		<form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="wpdex_import_upload" />
			<?php wp_nonce_field( 'wpdex_import_upload' ); ?>

			<p>
				<input type="file" name="wpdex_file" accept=".json,application/json" required="required" />
				<button type="submit" class="button button-secondary"><?php esc_html_e( 'Upload', 'wpd-export-all' ); ?></button>
			</p>

			<p class="description">
				<?php esc_html_e( 'One of the .json files from an export — posts.json, product.json, tax-category.json and so on. Not manifest.json.', 'wpd-export-all' ); ?>
			</p>
		</form>
	</div>

	<?php if ( $wpdex_current ) : ?>
		<div class="wpdex__panel" id="wpdex-import-panel" data-import="<?php echo esc_attr( $wpdex_current['id'] ); ?>">
			<h2><?php esc_html_e( 'Ready to import', 'wpd-export-all' ); ?></h2>

			<table class="widefat striped" style="max-width:640px">
				<tbody>
					<tr>
						<th scope="row"><?php esc_html_e( 'File', 'wpd-export-all' ); ?></th>
						<td><code><?php echo esc_html( $wpdex_current['name'] ); ?></code></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Rows', 'wpd-export-all' ); ?></th>
						<td><?php echo esc_html( number_format_i18n( $wpdex_current['rows'] ) ); ?></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Looks like', 'wpd-export-all' ); ?></th>
						<td>
							<?php
							$wpdex_kinds = array(
								'posts'   => __( 'Posts, pages, products or another post type', 'wpd-export-all' ),
								'terms'   => __( 'Taxonomy terms', 'wpd-export-all' ),
								'unknown' => __( 'Unrecognised — this may not import cleanly', 'wpd-export-all' ),
							);

							echo esc_html( $wpdex_kinds[ $wpdex_current['kind'] ] ?? $wpdex_current['kind'] );
							?>
						</td>
					</tr>
				</tbody>
			</table>

			<h3><?php esc_html_e( 'How to match existing content', 'wpd-export-all' ); ?></h3>

			<p class="description">
				<?php esc_html_e( 'How a row in the file is matched to something already on this site. Anything that does not match is created new.', 'wpd-export-all' ); ?>
			</p>

			<p>
				<label class="wpdex__check">
					<input type="radio" name="wpdex_match" value="slug" checked="checked" />
					<?php esc_html_e( 'By slug', 'wpd-export-all' ); ?>
					<span class="description"><?php esc_html_e( 'The usual choice. Survives moving between sites.', 'wpd-export-all' ); ?></span>
				</label>

				<label class="wpdex__check">
					<input type="radio" name="wpdex_match" value="sku" />
					<?php esc_html_e( 'By SKU', 'wpd-export-all' ); ?>
					<span class="description"><?php esc_html_e( 'Products only, and the right answer for a catalogue update.', 'wpd-export-all' ); ?></span>
				</label>

				<label class="wpdex__check">
					<input type="radio" name="wpdex_match" value="id" />
					<?php esc_html_e( 'By ID', 'wpd-export-all' ); ?>
					<span class="description">
						<?php esc_html_e( 'Only safe when the file came from THIS site. On a different installation, ID 412 is something else entirely — the post type is checked as a guard, but that is a guard, not a guarantee.', 'wpd-export-all' ); ?>
					</span>
				</label>

				<label class="wpdex__check">
					<input type="radio" name="wpdex_match" value="none" />
					<?php esc_html_e( 'Do not match — create everything as new', 'wpd-export-all' ); ?>
					<span class="description"><?php esc_html_e( 'Running this twice gives you two copies of everything.', 'wpd-export-all' ); ?></span>
				</label>
			</p>

			<h3><?php esc_html_e( 'What to do with matches', 'wpd-export-all' ); ?></h3>

			<p>
				<label class="wpdex__check">
					<input type="checkbox" id="wpdex-update-existing" />
					<?php esc_html_e( 'Overwrite content that matches', 'wpd-export-all' ); ?>
					<span class="description"><?php esc_html_e( 'Unticked, matches are left exactly as they are and only new rows are created. This is the safer setting and the one to use if you are unsure.', 'wpd-export-all' ); ?></span>
				</label>
			</p>

			<p>
				<label for="wpdex-import-status"><?php esc_html_e( 'Force every imported item to this status', 'wpd-export-all' ); ?></label>
				<select id="wpdex-import-status">
					<option value=""><?php esc_html_e( 'Keep the status from the file', 'wpd-export-all' ); ?></option>
					<option value="draft"><?php esc_html_e( 'Draft — review before publishing', 'wpd-export-all' ); ?></option>
					<option value="pending"><?php esc_html_e( 'Pending review', 'wpd-export-all' ); ?></option>
					<option value="private"><?php esc_html_e( 'Private', 'wpd-export-all' ); ?></option>
					<option value="publish"><?php esc_html_e( 'Published', 'wpd-export-all' ); ?></option>
				</select>
				<span class="description"><?php esc_html_e( 'Importing straight to Published puts unreviewed content on a live site. Draft is the cautious choice.', 'wpd-export-all' ); ?></span>
			</p>

			<hr />

			<p>
				<label class="wpdex__check">
					<input type="checkbox" id="wpdex-dry-run" checked="checked" />
					<strong><?php esc_html_e( 'Dry run — write nothing, just tell me what would happen', 'wpd-export-all' ); ?></strong>
				</label>
			</p>

			<p class="wpdex__actions">
				<button type="button" class="button button-primary button-hero" id="wpdex-import-run">
					<?php esc_html_e( 'Run', 'wpd-export-all' ); ?>
				</button>

				<a class="wpdex__delete" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wpdex_import_discard&import=' . rawurlencode( $wpdex_current['id'] ) ), 'wpdex_import_discard_' . $wpdex_current['id'] ) ); ?>">
					<?php esc_html_e( 'Discard this upload', 'wpd-export-all' ); ?>
				</a>
			</p>

			<div id="wpdex-import-report" hidden>
				<h3><?php esc_html_e( 'Result', 'wpd-export-all' ); ?></h3>
				<div id="wpdex-import-result"></div>
			</div>
		</div>
	<?php endif; ?>
</div>

# WPD Export All

Export everything on a WordPress site — posts, pages, products, any custom post
type, every taxonomy and its terms, form definitions and the leads people
submitted — with **ACF fields assembled properly** rather than dumped as raw
meta rows.

Tick what you want under **Tools → Export All**, choose CSV or JSON, press
Export.

---

## What it exports

| | |
| --- | --- |
| **Posts, pages, any CPT** | Title, slug, URL, excerpt, content, author, dates, parent, menu order, featured image, comment status |
| **Products** | Everything above plus type, SKU, regular and sale price, stock status and quantity, attributes, gallery URLs, and the variation IDs |
| **Product variations** | A separate post type, offered separately — tick it or the variable products are incomplete |
| **Taxonomies** | Every term with its description, parent, full `Parent > Child > Grandchild` path, count and URL — including terms nothing is filed under yet |
| **Categories and tags per row** | As a column on each post, so you can see what a post is filed under without cross-referencing |
| **Custom fields** | All post meta, with serialised values unserialised and re-encoded as JSON |
| **ACF** | Repeaters, flexible content, galleries, relationships, taxonomy and user fields — assembled, not raw |
| **Forms** | Contact Form 7, WPForms, Fluent Forms, Gravity Forms — the definitions and the field configuration |
| **Form leads** | CF7 (via Flamingo), WPForms, Fluent Forms, Gravity Forms, Elementor Pro |

The source list is built by asking the site, not from a hardcoded list. A
Portfolio post type or a Brand taxonomy appears on its own, with a live count
beside it.

---

## ACF, and why it needs its own handling

ACF stores a field's value in one meta row and a pointer to its definition in
another. A repeater is worse — six rows for two items of a two-field repeater,
named by position:

```
gallery              =>  "2"
gallery_0_caption    =>  "First"
gallery_0_image      =>  "412"
gallery_1_caption    =>  "Second"
gallery_1_image      =>  "418"
_gallery_0_caption   =>  "field_5f3a1c2b4d5e6"
```

An exporter that reads postmeta directly writes all of that out, and the result
is unusable: a `gallery_0_caption` column, a `gallery_1_caption` column, and no
column at all for the third item that only one post has.

This asks ACF for the value instead, so a repeater comes out as a repeater:

```json
"gallery": [
  { "caption": "First",  "image": 412 },
  { "caption": "Second", "image": 418 }
]
```

**Without ACF installed**, the raw rows are reassembled from the same naming
convention — less faithful, and much better than nothing. That is the case where
a database has been handed over without the plugin.

ACF's rich return values are flattened to something a file can hold: a
relationship field becomes `{id, type, title, url}` rather than an entire
serialised `WP_Post`.

---

## Format

**CSV** — one file per source, opens in Excel, Numbers or Sheets. A nested field
becomes JSON inside one cell, because a spreadsheet column cannot hold a list
that is a different length on every row.

**JSON** — keeps every structure intact. Pick this if anything is going to be
imported somewhere else rather than read by a person.

Every export also writes a `manifest.json` recording what was asked for, what
was expected and what was actually written.

---

## It runs in batches

"Export everything" in one request dies on any real site — memory, or
`max_execution_time`, and PHP dying mid-write leaves a truncated file that looks
complete. Every source is walked with a cursor, appending to disk as it goes, so
peak memory is one batch however big the site is.

The browser drives the batches and shows a progress bar. Leave the tab open.

---

## Security

An export is every post, every price and every customer's form submission in one
file. It is treated accordingly.

| | |
| --- | --- |
| **CSV formula injection** | Every cell beginning `=` `+` `-` `@` tab or CR is prefixed with `'`. A product title of `=cmd\|'/c calc'!A1` is a live formula the moment the file opens in Excel, and the person opening it is the site's administrator |
| **Credentials never leave** | Any meta key containing `password`, `secret`, `api_key`, `token`, `private_key` or `auth_key` is dropped. **There is deliberately no option to turn this off** |
| **Capability** | `export` — WordPress's own capability for this, checked on every endpoint |
| **Path traversal** | A job id must match `^[a-f0-9]{32}$` or nothing happens; downloads additionally `realpath()` both sides and check the prefix |
| **No direct links** | Downloads go through an authenticated endpoint with a nonce, never a URL into uploads |
| **Directory** | Denied by `.htaccess`, with `index.php` behind it, and every filename carries 32 random characters |
| **Expiry** | Exports are deleted after 7 days by a daily event, downloaded or not |
| **Uninstall** | Deletes every export. Leaving them would be leaving a database dump on a web server |

**On Nginx the `.htaccess` is ignored.** The random filename and the
authenticated endpoint are the protection there — which is why they exist rather
than the deny rule alone. The admin screen says so plainly.

---

## Install

Copy the folder to `wp-content/plugins/wpd-export-all/` and activate. Then
**Tools → Export All**.

No dependencies, no build step, no outbound calls.

---

## Tests

```bash
php tests/test.php
```

69 assertions, no WordPress and no PHPUnit — the bootstrap stubs enough of it.

The suite is weighted towards the three things that would make this plugin
*harmful* rather than merely disappointing: a CSV cell that executes, a job id
that reaches the filesystem unchecked, and a credential that leaves in an
export.

It has already earned its keep. The "skip hidden meta" option's condition was
the wrong way round, so **every WooCommerce price, SKU and stock level was
silently missing from the default export** — a file that downloads, opens, has
thousands of rows in it, and is wrong. That is precisely the failure this plugin
is written to avoid, and only a test was going to catch it.

---

## Honest limits

- **Media files are not copied.** Attachment URLs and IDs are exported; the
  images themselves are not. Copying gigabytes of uploads is a backup plugin's
  job, not an exporter's.
- **Users are not exported.** Deliberately — a user table export is a different
  decision with different consent implications, and it should not arrive as a
  side effect of ticking "everything".
- **CF7 has no leads of its own.** It mails submissions and forgets them.
  Leads appear only if Flamingo is installed, which is where they are read from.
- **WPForms Lite stores no entries.** The forms export; there is nothing to read
  for the leads.
- **Counts are estimates until the file is written.** `wp_count_posts()` is
  cached and a post can be deleted mid-export, so the manifest records expected
  against actual and flags any difference rather than hiding it.
- **This is an exporter, not an importer.** Nothing here reads a file back in.

## Requirements

WordPress 5.8+, PHP 7.4+.

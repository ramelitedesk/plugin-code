<?php
/**
 * Deleting the plugin's data when it is removed.
 *
 * This one deletes everything, and unlike most uninstall routines that is not
 * a judgement call. What is on disk is a set of files containing the entire
 * contents of the site — every price, every customer's form submission, every
 * private field. Leaving those in uploads after somebody has deleted the plugin
 * that made them is leaving a database dump on a web server for nobody's
 * benefit.
 *
 * @package WPD_Export_All
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'wpdex_jobs' );

$timestamp = wp_next_scheduled( 'wpdex_cleanup' );

if ( $timestamp ) {
	wp_unschedule_event( $timestamp, 'wpdex_cleanup' );
}

$uploads = wp_get_upload_dir();

if ( empty( $uploads['basedir'] ) ) {
	return;
}

$base = rtrim( $uploads['basedir'], '/\\' ) . '/wpd-export-all';

if ( ! is_dir( $base ) ) {
	return;
}

/*
 * One level of folders, one level of files, and nothing recursive.
 *
 * A recursive delete rooted at a path is the most dangerous few lines in any
 * plugin. This one knows the exact shape it created — job folders holding flat
 * files — so it walks that shape literally and cannot wander. Anything it does
 * not recognise is left alone rather than removed.
 */
foreach ( (array) glob( $base . '/*', GLOB_ONLYDIR ) as $dir ) {
	if ( ! preg_match( '#/[a-f0-9]{32}$#', str_replace( '\\', '/', $dir ) ) ) {
		continue;
	}

	foreach ( (array) glob( $dir . '/*' ) as $file ) {
		if ( is_file( $file ) ) {
			wp_delete_file( $file );
		}
	}

	// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
	@rmdir( $dir );
}

foreach ( array( '.htaccess', 'index.php' ) as $guard ) {
	if ( is_file( $base . '/' . $guard ) ) {
		wp_delete_file( $base . '/' . $guard );
	}
}

// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
@rmdir( $base );

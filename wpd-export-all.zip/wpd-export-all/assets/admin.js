/**
 * Driving the export from the browser, one batch at a time.
 *
 * The loop is deliberately sequential — one tick, wait, next tick. Firing them
 * in parallel would be faster and would also have two requests advancing the
 * same cursor, so a batch gets written twice and another never gets written at
 * all. An exporter that duplicates rows is worse than a slow one.
 *
 * @package WPD_Export_All
 */
( function () {
	'use strict';

	var settings = window.WPDEX || {};
	var form = document.getElementById( 'wpdex-form' );

	if ( ! form ) {
		return;
	}

	var startButton = document.getElementById( 'wpdex-start' );
	var cancelButton = document.getElementById( 'wpdex-cancel' );
	var panel = document.getElementById( 'wpdex-progress' );
	var bar = document.getElementById( 'wpdex-bar' );
	var status = document.getElementById( 'wpdex-status' );
	var steps = document.getElementById( 'wpdex-steps' );

	var running = null;
	var stopped = false;

	/**
	 * @param {string} action Ajax action suffix.
	 * @param {Object} extra  Additional fields.
	 * @return {Promise<Object>}
	 */
	function post( action, extra ) {
		var body = new URLSearchParams();

		body.append( 'action', 'wpdex_' + action );
		body.append( 'nonce', settings.nonce );

		Object.keys( extra || {} ).forEach( function ( key ) {
			var value = extra[ key ];

			/*
			 * Pairs already in wire form — the filter fields, whose names are
			 * things like filters[terms][product_cat][]. Rebuilding those from
			 * a nested object would mean writing PHP's array-name encoder in
			 * JavaScript, so the form's own field names are used verbatim.
			 */
			if ( '_pairs' === key ) {
				value.forEach( function ( pair ) {
					body.append( pair[ 0 ], pair[ 1 ] );
				} );

				return;
			}

			if ( Array.isArray( value ) ) {
				value.forEach( function ( one ) {
					body.append( key + '[]', one );
				} );

				return;
			}

			body.append( key, value );
		} );

		return window.fetch( settings.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		} ).then( function ( response ) {
			return response.json();
		} ).then( function ( payload ) {
			if ( ! payload || ! payload.success ) {
				throw new Error( ( payload && payload.data && payload.data.message ) || 'request failed' );
			}

			return payload.data;
		} );
	}

	/**
	 * @param {Object} progress From the server.
	 */
	function render( progress ) {
		bar.style.width = progress.percent + '%';

		if ( progress.status === 'done' ) {
			status.textContent = settings.i18n.done;
		} else if ( progress.current ) {
			status.textContent = settings.i18n.working.replace( '%s', progress.current ) +
				' (' + progress.written.toLocaleString() + ' / ' + progress.expected.toLocaleString() + ')';
		}

		steps.innerHTML = '';

		( progress.steps || [] ).forEach( function ( step ) {
			var item = document.createElement( 'li' );

			item.className = step.done ? 'is-done' : '';
			item.textContent = step.label + ' — ' + step.written.toLocaleString() +
				( step.done ? '' : ' / ' + step.expected.toLocaleString() );

			steps.appendChild( item );
		} );
	}

	/**
	 * Keep ticking until the job says it is finished.
	 *
	 * @param {string} jobId Job.
	 */
	function run( jobId ) {
		if ( stopped ) {
			return;
		}

		post( 'tick', { job: jobId } )
			.then( function ( progress ) {
				render( progress );

				if ( progress.status === 'done' ) {
					finish();

					return;
				}

				run( jobId );
			} )
			.catch( function ( error ) {
				status.textContent = settings.i18n.failed.replace( '%s', error.message );

				finish();
			} );
	}

	function finish() {
		running = null;

		startButton.disabled = false;
		cancelButton.hidden = true;

		// The finished export appears in the table below, which is rendered by
		// PHP — so the page is reloaded rather than the row being built twice,
		// once here and once on the server, and drifting apart.
		window.setTimeout( function () {
			window.location.reload();
		}, 1200 );
	}

	form.addEventListener( 'submit', function ( event ) {
		event.preventDefault();

		var chosen = Array.prototype.map.call(
			form.querySelectorAll( 'input[name="sources[]"]:checked' ),
			function ( input ) {
				return input.value;
			}
		);

		if ( ! chosen.length ) {
			window.alert( settings.i18n.nothing );

			return;
		}

		stopped = false;
		startButton.disabled = true;
		cancelButton.hidden = false;
		panel.hidden = false;
		status.textContent = settings.i18n.starting;
		bar.style.width = '0';

		var options = {};

		[ 'opt_content', 'opt_meta', 'opt_acf', 'opt_taxonomies', 'opt_protected_meta' ].forEach( function ( name ) {
			var field = form.querySelector( '[name="' + name + '"]' );

			if ( field && field.checked ) {
				options[ name ] = '1';
			}
		} );

		options.sources = chosen;
		options.format = ( form.querySelector( '[name="format"]:checked' ) || {} ).value || 'csv';

		/*
		 * Every filter field, exactly as the form names it.
		 *
		 * Empty values are dropped so an untouched filter block sends nothing
		 * at all — the server treats an absent filter set as "export
		 * everything", and a stream of empty strings would look like a filter
		 * that had been set.
		 */
		options._pairs = [];

		form.querySelectorAll( '[name^="filters["]' ).forEach( function ( field ) {
			if ( ( field.type === 'checkbox' || field.type === 'radio' ) && ! field.checked ) {
				return;
			}

			if ( field.value === '' ) {
				return;
			}

			options._pairs.push( [ field.name, field.value ] );
		} );

		post( 'start', options )
			.then( function ( progress ) {
				running = progress.id;

				render( progress );
				run( progress.id );
			} )
			.catch( function ( error ) {
				status.textContent = settings.i18n.failed.replace( '%s', error.message );

				startButton.disabled = false;
				cancelButton.hidden = true;
			} );
	} );

	cancelButton.addEventListener( 'click', function () {
		if ( ! running || ! window.confirm( settings.i18n.confirm ) ) {
			return;
		}

		stopped = true;

		post( 'cancel', { job: running } ).then( function () {
			window.location.reload();
		} );
	} );

	form.querySelector( '[data-wpdex-all]' ).addEventListener( 'click', function () {
		toggleAll( true );
	} );

	form.querySelector( '[data-wpdex-none]' ).addEventListener( 'click', function () {
		toggleAll( false );
	} );

	/**
	 * @param {boolean} on Whether to tick everything.
	 */
	function toggleAll( on ) {
		form.querySelectorAll( 'input[name="sources[]"]' ).forEach( function ( input ) {
			input.checked = on;
		} );
	}

	/*
	 * Leaving mid-export abandons a half-written folder on the server. The
	 * warning is the only thing that can be done about it from here — the
	 * daily cleanup collects the remains either way.
	 */
	window.addEventListener( 'beforeunload', function ( event ) {
		if ( ! running ) {
			return;
		}

		event.preventDefault();
		event.returnValue = settings.i18n.leaving;

		return settings.i18n.leaving;
	} );
}() );

/**
 * The filter block and the import runner.
 *
 * Kept in the same file as the exporter because they share the nonce and the
 * ajax URL, and because a second script tag for forty lines is not worth the
 * request.
 *
 * @package WPD_Export_All
 */
( function () {
	'use strict';

	var settings = window.WPDEX || {};

	/* ---------------- filters ---------------- */

	var toggle = document.getElementById( 'wpdex-toggle-filters' );
	var body = document.getElementById( 'wpdex-filter-body' );

	if ( toggle && body ) {
		toggle.addEventListener( 'click', function () {
			var open = toggle.getAttribute( 'aria-expanded' ) === 'true';

			body.hidden = open;
			toggle.setAttribute( 'aria-expanded', open ? 'false' : 'true' );
			toggle.textContent = open ? toggle.dataset.show || 'Show filters' : ( toggle.dataset.hide || 'Hide filters' );
		} );

		toggle.dataset.show = toggle.textContent;
		toggle.dataset.hide = toggle.textContent.replace( /^Show/, 'Hide' );
	}

	/*
	 * The two date boxes only mean anything for the "custom" range, and leaving
	 * them visible invites somebody to fill them in alongside "last 30 days"
	 * and wonder which won.
	 */
	var range = document.getElementById( 'wpdex-date-range' );

	if ( range ) {
		var syncRange = function () {
			document.querySelectorAll( '.wpdex__custom-dates' ).forEach( function ( node ) {
				node.hidden = ( range.value !== 'custom' );
			} );
		};

		range.addEventListener( 'change', syncRange );
		syncRange();
	}

	/* ---------------- import ---------------- */

	var panel = document.getElementById( 'wpdex-import-panel' );
	var run = document.getElementById( 'wpdex-import-run' );

	if ( ! panel || ! run ) {
		return;
	}

	run.addEventListener( 'click', function () {
		var dry = document.getElementById( 'wpdex-dry-run' );
		var match = panel.querySelector( '[name="wpdex_match"]:checked' );
		var update = document.getElementById( 'wpdex-update-existing' );
		var status = document.getElementById( 'wpdex-import-status' );

		var isDry = ! dry || dry.checked;

		/*
		 * The confirmation only appears for a real run, and it names the
		 * consequence rather than asking "are you sure?" — which everybody
		 * clicks through without reading.
		 */
		if ( ! isDry && ! window.confirm(
			'This will write to your database and cannot be undone. Continue?'
		) ) {
			return;
		}

		var body = new URLSearchParams();

		body.append( 'action', 'wpdex_import_run' );
		body.append( 'nonce', settings.nonce );
		body.append( 'import', panel.dataset.import );
		body.append( 'match', match ? match.value : 'slug' );
		body.append( 'status', status ? status.value : '' );

		if ( isDry ) {
			body.append( 'dry_run', '1' );
		}

		if ( update && update.checked ) {
			body.append( 'update_existing', '1' );
		}

		run.disabled = true;
		run.textContent = 'Working…';

		window.fetch( settings.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		} )
			.then( function ( response ) {
				return response.json();
			} )
			.then( function ( payload ) {
				if ( ! payload || ! payload.success ) {
					throw new Error( ( payload && payload.data && payload.data.message ) || 'failed' );
				}

				render( payload.data );
			} )
			.catch( function ( error ) {
				render( { error: error.message } );
			} )
			.finally( function () {
				run.disabled = false;
				run.textContent = 'Run';
			} );
	} );

	/**
	 * @param {Object} report What the server did, or would do.
	 */
	function render( report ) {
		var target = document.getElementById( 'wpdex-import-result' );
		var wrap = document.getElementById( 'wpdex-import-report' );

		if ( ! target || ! wrap ) {
			return;
		}

		wrap.hidden = false;

		if ( report.error ) {
			target.innerHTML = '<div class="notice notice-error inline"><p></p></div>';
			target.querySelector( 'p' ).textContent = report.error;

			return;
		}

		var lines = [
			[ 'Rows in the file', report.total ],
			[ report.dry_run ? 'Would create' : 'Created', report.created ],
			[ report.dry_run ? 'Would update' : 'Updated', report.updated ],
			[ 'Left alone', report.skipped ],
			[ 'Could not be read', report.failed ]
		];

		var html = '<table class="widefat striped" style="max-width:480px"><tbody>';

		lines.forEach( function ( line ) {
			// textContent everywhere below; nothing from the server is trusted
			// as markup, even though it is all numbers today.
			var row = document.createElement( 'tr' );
			var th = document.createElement( 'th' );
			var td = document.createElement( 'td' );

			th.scope = 'row';
			th.textContent = line[ 0 ];
			td.textContent = String( line[ 1 ] );

			row.appendChild( th );
			row.appendChild( td );

			html += row.outerHTML;
		} );

		html += '</tbody></table>';

		target.innerHTML = html;

		if ( report.dry_run ) {
			var note = document.createElement( 'div' );
			note.className = 'notice notice-info inline';
			note.innerHTML = '<p></p>';
			note.querySelector( 'p' ).textContent =
				'Nothing was written. Untick "Dry run" and press Run again to apply this.';
			target.appendChild( note );
		}

		if ( report.problems && report.problems.length ) {
			var problems = document.createElement( 'div' );
			problems.className = 'notice notice-warning inline';

			var list = document.createElement( 'ul' );

			report.problems.forEach( function ( problem ) {
				var item = document.createElement( 'li' );
				item.textContent = problem;
				list.appendChild( item );
			} );

			problems.appendChild( list );
			target.appendChild( problems );
		}
	}
}() );

<?php
/**
 * Enough of WordPress to exercise the parts worth testing.
 *
 * The writer, the ACF reassembler and the path guards are pure functions over
 * arrays and strings. They need WordPress's function names, not WordPress.
 *
 * @package WPD_Export_All
 */

if ( 'cli' !== PHP_SAPI ) {
	http_response_code( 404 );
	exit;
}

define( 'ABSPATH', __DIR__ );
define( 'HOUR_IN_SECONDS', 3600 );
define( 'DAY_IN_SECONDS', 86400 );
define( 'WEEK_IN_SECONDS', 604800 );

define( 'WPDEX_VERSION', 'test' );
define( 'WPDEX_DIR', dirname( __DIR__ ) . '/' );
define( 'WPDEX_URL', 'http://example.test/wp-content/plugins/wpd-export-all/' );
define( 'WPDEX_FILE', WPDEX_DIR . 'wpd-export-all.php' );

$GLOBALS['wpdex_test'] = array(
	'options' => array(),
	'meta'    => array(),
	'uploads' => sys_get_temp_dir() . '/wpdex-test-uploads',
);

function __( $t, $d = '' ) { return $t; }
function _n( $s, $p, $n, $d = '' ) { return 1 === (int) $n ? $s : $p; }
function esc_html( $t ) { return htmlspecialchars( (string) $t, ENT_QUOTES ); }
function esc_attr( $t ) { return htmlspecialchars( (string) $t, ENT_QUOTES ); }
function esc_html__( $t, $d = '' ) { return $t; }

function absint( $v ) { return abs( (int) $v ); }
function sanitize_key( $v ) { return preg_replace( '/[^a-z0-9_\-]/', '', strtolower( (string) $v ) ); }
function sanitize_text_field( $v ) { return trim( strip_tags( (string) $v ) ); }
function sanitize_file_name( $v ) { return preg_replace( '/[^a-z0-9_\.\-]/i', '', (string) $v ); }
function wp_unslash( $v ) { return is_array( $v ) ? array_map( 'wp_unslash', $v ) : stripslashes( (string) $v ); }

function wp_json_encode( $data, $flags = 0 ) { return json_encode( $data, $flags ); }
function maybe_unserialize( $v ) {
	if ( ! is_string( $v ) ) { return $v; }
	$test = @unserialize( $v );
	return ( false !== $test || 'b:0;' === $v ) ? $test : $v;
}

function apply_filters( $tag, $value ) { return $value; }
function add_action() {}
function add_filter() {}
function do_action() {}

function get_option( $k, $d = false ) { return $GLOBALS['wpdex_test']['options'][ $k ] ?? $d; }
function update_option( $k, $v, $a = null ) { $GLOBALS['wpdex_test']['options'][ $k ] = $v; return true; }
function delete_option( $k ) { unset( $GLOBALS['wpdex_test']['options'][ $k ] ); return true; }

function get_post_meta( $id, $key = '', $single = false ) {
	$all = $GLOBALS['wpdex_test']['meta'][ $id ] ?? array();

	if ( '' === $key ) { return $all; }

	if ( ! isset( $all[ $key ] ) ) { return $single ? '' : array(); }

	return $single ? reset( $all[ $key ] ) : $all[ $key ];
}

function wp_get_upload_dir() {
	$dir = $GLOBALS['wpdex_test']['uploads'];

	if ( ! is_dir( $dir ) ) { mkdir( $dir, 0777, true ); }

	return array( 'basedir' => $dir );
}

function wp_mkdir_p( $dir ) { return is_dir( $dir ) || mkdir( $dir, 0777, true ); }
function wp_delete_file( $file ) { if ( is_file( $file ) ) { unlink( $file ); } }
function home_url( $p = '/' ) { return 'https://example.test' . $p; }
function size_format( $b, $d = 0 ) { return round( $b / 1024, $d ) . ' KB'; }
function get_bloginfo( $s ) { return '6.5'; }
function wp_list_pluck( $list, $field ) {
	return array_map(
		static function ( $row ) use ( $field ) {
			return is_array( $row ) ? ( $row[ $field ] ?? null ) : ( is_object( $row ) ? ( $row->$field ?? null ) : null );
		},
		(array) $list
	);
}

function get_permalink( $p ) { return 'https://example.test/?p=' . ( is_object( $p ) ? $p->ID : $p ); }

class WP_Error {
	private $message;
	public function __construct( $code = '', $message = '' ) { $this->message = $message; }
	public function get_error_message() { return $this->message; }
}

function is_wp_error( $thing ) { return $thing instanceof WP_Error; }

class WP_Post {
	public $ID;
	public $post_type = 'post';
	public $post_title = '';
	public function __construct( $id = 0 ) { $this->ID = $id; }
}

class WP_Term {
	public $term_id;
	public $taxonomy;
	public $name;
	public $slug;
	public function __construct( $id, $tax, $name = '', $slug = '' ) {
		$this->term_id  = $id;
		$this->taxonomy = $tax;
		$this->name     = $name;
		$this->slug     = $slug;
	}
}

class WP_User {
	public $ID;
	public $user_login;
	public $user_email;
	public $display_name;
	public $user_pass = 'HASH-MUST-NEVER-BE-EXPORTED';
	public function __construct( $id, $login, $email, $name ) {
		$this->ID           = $id;
		$this->user_login   = $login;
		$this->user_email   = $email;
		$this->display_name = $name;
	}
}

require_once WPDEX_DIR . 'includes/class-wpdex-storage.php';
require_once WPDEX_DIR . 'includes/class-wpdex-acf.php';
require_once WPDEX_DIR . 'includes/class-wpdex-writer.php';

/**
 * Clear the fake site between runs.
 */
function wpdex_test_reset() {
	$GLOBALS['wpdex_test']['options'] = array();
	$GLOBALS['wpdex_test']['meta']    = array();

	$base = $GLOBALS['wpdex_test']['uploads'] . '/wpd-export-all';

	foreach ( (array) glob( $base . '/*' ) as $path ) {
		if ( is_dir( $path ) ) {
			array_map( 'unlink', (array) glob( $path . '/*' ) );
			rmdir( $path );
		} elseif ( is_file( $path ) ) {
			unlink( $path );
		}
	}
}

/*
 * Loaded last: it references WPDEX_Sources and WP_Query in methods the unit
 * tests do not call, and PHP only resolves those at call time.
 */
require_once WPDEX_DIR . 'includes/class-wpdex-posts.php';

/* ---------------- extra stubs for filters and coverage ---------------- */

if ( ! function_exists( 'current_time' ) ) {
	function current_time( $type ) { return $GLOBALS['wpdex_test']['now'] ?? time(); }
}
if ( ! function_exists( 'wp_date' ) ) {
	function wp_date( $format, $timestamp = null ) { return gmdate( $format, $timestamp ?? time() ); }
}
if ( ! function_exists( 'number_format_i18n' ) ) {
	function number_format_i18n( $n ) { return number_format( $n ); }
}
if ( ! function_exists( 'taxonomy_exists' ) ) {
	function taxonomy_exists( $t ) { return in_array( $t, array( 'category', 'post_tag', 'product_cat' ), true ); }
}
if ( ! function_exists( 'get_object_taxonomies' ) ) {
	function get_object_taxonomies( $type ) {
		return 'product' === $type ? array( 'product_cat' ) : array( 'category', 'post_tag' );
	}
}
if ( ! function_exists( 'get_option' ) ) {
	function get_option( $k, $d = false ) { return $d; }
}

require_once WPDEX_DIR . 'includes/class-wpdex-filters.php';

require_once WPDEX_DIR . 'includes/class-wpdex-terms.php';
require_once WPDEX_DIR . 'includes/class-wpdex-forms.php';

<?php
/**
 * What has to stay true.
 *
 * Weighted towards the three things that would make this plugin harmful rather
 * than merely disappointing:
 *
 *   1. A CSV cell must never be executable. The person opening the file is the
 *      site's administrator, and the content in it was typed by strangers.
 *   2. A job id must never reach the filesystem unchecked. The plugin's whole
 *      job is handing files to a browser.
 *   3. Anything that looks like a credential must never leave in an export,
 *      whatever the options say.
 *
 * @package WPD_Export_All
 */

require __DIR__ . '/bootstrap.php';

$pass = 0;
$fail = 0;

/**
 * @param string $label What is asserted.
 * @param bool   $ok    Whether it holds.
 * @param string $note  Shown on failure.
 */
function check( $label, $ok, $note = '' ) {
	global $pass, $fail;

	if ( $ok ) {
		$pass++;
		printf( "  ok    %s\n", $label );

		return;
	}

	$fail++;
	printf( "  FAIL  %s%s\n", $label, '' !== $note ? ' :: ' . $note : '' );
}

wpdex_test_reset();

/* ================================================================ *
 * CSV injection
 * ================================================================ */

echo "\n=== A spreadsheet must not run what is in the file ===\n";

$attacks = array(
	'=cmd|\'/c calc\'!A1',
	'+1+1',
	'-2+3',
	'@SUM(1+1)',
	"\t=1+1",
	"\r=1+1",
);

foreach ( $attacks as $attack ) {
	$safe = WPDEX_Writer::defuse( $attack );

	check(
		'defused: ' . str_replace( array( "\t", "\r" ), array( '\t', '\r' ), $attack ),
		"'" === $safe[0],
		'a product title or form answer starting with this is a live formula on open'
	);
}

check( 'ordinary text is untouched', 'Blue T-Shirt' === WPDEX_Writer::defuse( 'Blue T-Shirt' ) );
check( 'an empty cell stays empty', '' === WPDEX_Writer::defuse( '' ) );
check( 'a number is untouched', '19.99' === WPDEX_Writer::defuse( '19.99' ) );
check( 'a negative number IS quoted', "'-5" === WPDEX_Writer::defuse( '-5' ), 'a spreadsheet cannot tell -5 from a formula, so correctness loses to safety here' );

/* ================================================================ *
 * Path handling
 * ================================================================ */

echo "\n=== A job id must never reach the filesystem unchecked ===\n";

$bad = array(
	'../../../wp-config.php',
	'..',
	'',
	'abc',
	str_repeat( 'g', 32 ),
	'0123456789abcdef0123456789abcdef/../..',
	'0123456789ABCDEF0123456789ABCDEF',
);

foreach ( $bad as $id ) {
	check( 'rejected: ' . ( '' === $id ? '(empty)' : substr( $id, 0, 32 ) ), ! WPDEX_Storage::valid_id( $id ) );
}

check( 'a real id is accepted', WPDEX_Storage::valid_id( str_repeat( 'a1b2c3d4', 4 ) ) );
check( 'a generated id is accepted by its own validator', WPDEX_Storage::valid_id( WPDEX_Storage::new_id() ) );
check( 'two generated ids differ', WPDEX_Storage::new_id() !== WPDEX_Storage::new_id() );

check( 'a rejected id yields no directory', '' === WPDEX_Storage::job_dir( '../../etc' ) );
check( 'a rejected id yields no file path', '' === WPDEX_Storage::file( '../../etc', 'x', 'csv' ) );

$job = WPDEX_Storage::new_id();

$path = WPDEX_Storage::file( $job, '../../../evil', 'csv' );

check(
	'a traversing source name cannot escape the job folder',
	false === strpos( $path, '..' ),
	'the source key becomes a filename, so it is sanitised too'
);

check( 'an extension is sanitised', false !== strpos( WPDEX_Storage::file( $job, 'x', 'c/sv' ), '.csv' ) );

/* ================================================================ *
 * Writing
 * ================================================================ */

echo "\n=== The files that come out ===\n";

$csv_path = WPDEX_Storage::file( $job, 'posts', 'csv' );

$writer = new WPDEX_Writer( $csv_path, 'csv', array( 'id', 'title', 'price' ) );

check( 'the file opens', $writer->open() );

// Two batches, because that is how a real export writes: the second call has to
// append rather than start again.
$writer->append( array( array( 'id' => 1, 'title' => 'First', 'price' => '10' ) ), true );
$writer->append( array( array( 'id' => 2, 'price' => '20' ) ), false );

$writer->close();

$csv = file_get_contents( $csv_path );

check( 'it starts with a BOM so Excel reads UTF-8', "\xEF\xBB\xBF" === substr( $csv, 0, 3 ) );
check( 'the header is written', false !== strpos( $csv, 'id,title,price' ) );
check( 'the first batch is there', false !== strpos( $csv, 'First' ) );
check( 'the second batch was appended, not overwritten', false !== strpos( $csv, '20' ) );

$lines = array_values( array_filter( explode( "\n", trim( $csv ) ) ) );

check( 'a row missing a column keeps its alignment', '2,,20' === trim( end( $lines ) ), 'writing array_values() would shift every later column left by one' );

/* --- JSON --- */

$json_path = WPDEX_Storage::file( $job, 'posts', 'json' );

$writer = new WPDEX_Writer( $json_path, 'json' );

$writer->open();
$writer->append( array( array( 'id' => 1 ), array( 'id' => 2 ) ), true );
$writer->append( array( array( 'id' => 3 ) ), false );
$writer->close();

$decoded = json_decode( file_get_contents( $json_path ), true );

check( 'the JSON parses', is_array( $decoded ), 'a trailing comma between batches is the classic way this breaks' );
check( 'every row across both batches is present', 3 === count( (array) $decoded ) );
check( 'the order is preserved', array( 1, 2, 3 ) === wp_list_pluck( (array) $decoded, 'id' ) );

/* --- cells --- */

check( 'an array cell becomes JSON, not PHP serialisation', '["a","b"]' === WPDEX_Writer::cell( array( 'a', 'b' ) ) );
check( 'null becomes empty', '' === WPDEX_Writer::cell( null ) );
check( 'a bool becomes 1 or 0', '1' === WPDEX_Writer::cell( true ) && '0' === WPDEX_Writer::cell( false ) );

/* ================================================================ *
 * ACF
 * ================================================================ */

echo "\n=== ACF fields, without ACF installed ===\n";

check( 'ACF is genuinely absent', ! WPDEX_ACF::active(), 'the fallback path is what is being tested' );

$GLOBALS['wpdex_test']['meta'][ 7 ] = array(
	'subtitle'          => array( 'A subtitle' ),
	'_subtitle'         => array( 'field_5f3a1c2b4d5e6' ),
	'gallery'           => array( '2' ),
	'_gallery'          => array( 'field_aaa' ),
	'gallery_0_caption' => array( 'First' ),
	'_gallery_0_caption' => array( 'field_bbb' ),
	'gallery_0_image'   => array( '412' ),
	'_gallery_0_image'  => array( 'field_ccc' ),
	'gallery_1_caption' => array( 'Second' ),
	'_gallery_1_caption' => array( 'field_bbb' ),
	'gallery_1_image'   => array( '418' ),
	'_gallery_1_image'  => array( 'field_ccc' ),
	// Another plugin's meta, with no field_ pointer beside it.
	'_yoast_wpseo_title' => array( 'SEO title' ),
	'unrelated'         => array( 'not acf' ),
);

$fields = WPDEX_ACF::values( 7 );

check( 'a plain field is read', 'A subtitle' === ( $fields['subtitle'] ?? null ) );
check( 'a repeater becomes an array', is_array( $fields['gallery'] ?? null ) );
check( 'with one entry per row', 2 === count( $fields['gallery'] ?? array() ), 'the count row "2" must be replaced by the rows themselves' );
check( 'and the sub-fields inside each row', 'First' === ( $fields['gallery'][0]['caption'] ?? null ) );
check( 'in the right order', 'Second' === ( $fields['gallery'][1]['caption'] ?? null ) );
check( 'another plugin\'s meta is left alone', ! isset( $fields['unrelated'] ), 'the field_ pointer is the only reliable signature' );
check( 'and so is Yoast\'s', ! isset( $fields['_yoast_wpseo_title'] ) );

$owned = WPDEX_ACF::owned_meta_keys( 7 );

check( 'the plain meta exporter is told which keys ACF owns', in_array( 'subtitle', $owned, true ) && in_array( '_subtitle', $owned, true ) );
check( 'so ACF values are not also written as raw meta', in_array( 'gallery_0_caption', $owned, true ) );
check( 'and unrelated meta is not claimed', ! in_array( 'unrelated', $owned, true ) );

/* --- flattening --- */

echo "\n=== ACF's rich objects, flattened ===\n";

$flat = WPDEX_ACF::flatten_objects( new WP_User( 3, 'jo', 'jo@example.test', 'Jo' ) );

check( 'a user keeps its identity', 3 === $flat['id'] && 'jo' === $flat['login'] );
check(
	'and never its password hash',
	! in_array( 'HASH-MUST-NEVER-BE-EXPORTED', (array) $flat, true ),
	'get_object_vars on a WP_User would put the hash in the export'
);

$term = WPDEX_ACF::flatten_objects( new WP_Term( 9, 'category', 'News', 'news' ) );

check( 'a term flattens to id, taxonomy, name and slug', 9 === $term['id'] && 'news' === $term['slug'] );

$post = WPDEX_ACF::flatten_objects( new WP_Post( 12 ) );

check( 'a post flattens to something followable', 12 === $post['id'] && isset( $post['url'] ) );

$nested = WPDEX_ACF::flatten_objects( array( 'rows' => array( array( 'user' => new WP_User( 4, 'sam', 's@e.test', 'Sam' ) ) ) ) );

check( 'objects nested inside a repeater are flattened too', 4 === ( $nested['rows'][0]['user']['id'] ?? null ) );

/*
 * A relationship field pointing back at its own post is a real thing people
 * build, and without the depth guard it recurses until PHP runs out of stack —
 * which on a shutdown is a segfault, not an exception.
 */
$deep = array();
$ref  = &$deep;

for ( $i = 0; $i < 40; $i++ ) {
	$ref['child'] = array();
	$ref          = &$ref['child'];
}

$result = WPDEX_ACF::flatten_objects( $deep );

check( 'a self-referential structure terminates rather than exhausting the stack', is_array( $result ) );

/* ================================================================ *
 * What must never leave the site
 * ================================================================ */

echo "\n=== Credentials are never exported, whatever the options say ===\n";

$everything = array(
	'meta'           => true,
	'skip_protected_meta' => false,
);

$secrets = array(
	'stripe_secret_key',
	'_api_key',
	'mailchimp_apikey',
	'PASSWORD',
	'some_auth_key',
	'_private_key',
	'oauth_token',
);

foreach ( $secrets as $key ) {
	check(
		'never exported: ' . $key,
		WPDEX_Posts::skip_meta_key( $key, $everything ),
		'an export gets emailed and left in Downloads folders'
	);
}

check( 'a WooCommerce price is still exported', ! WPDEX_Posts::skip_meta_key( '_price', $everything ) );
check( 'and a SKU', ! WPDEX_Posts::skip_meta_key( '_sku', $everything ) );
check( 'and stock', ! WPDEX_Posts::skip_meta_key( '_stock', $everything ) );
check( 'an ordinary field is exported', ! WPDEX_Posts::skip_meta_key( 'subtitle', $everything ) );

check( 'editor bookkeeping is dropped', WPDEX_Posts::skip_meta_key( '_edit_lock', $everything ) );
check( 'oEmbed caches are dropped', WPDEX_Posts::skip_meta_key( '_oembed_a1b2c3', $everything ) );

$tidy = array(
	'meta'           => true,
	'skip_protected_meta' => true,
);

check( 'ticking "skip hidden meta" drops underscored keys', WPDEX_Posts::skip_meta_key( '_price', $tidy ) );
check( 'but leaves ordinary ones', ! WPDEX_Posts::skip_meta_key( 'subtitle', $tidy ) );

check(
	'the credential filter cannot be turned off',
	WPDEX_Posts::skip_meta_key( 'api_key', $tidy ) && WPDEX_Posts::skip_meta_key( 'api_key', $everything ),
	'there is deliberately no option for this'
);

/* ================================================================ *
 * Filters
 * ================================================================ */

echo "\n=== Named date ranges ===\n";

// A Wednesday, so the weekday maths is visible rather than accidental.
$noon = strtotime( '2026-08-12 12:00:00' );

/**
 * @param string $range Range key.
 * @param array  $extra Other filter keys.
 * @return array
 */
function span( $range, array $extra = array() ) {
	return WPDEX_Filters::resolve_range(
		array_merge( WPDEX_Filters::defaults(), array( 'date_range' => $range ), $extra ),
		strtotime( '2026-08-12 12:00:00' )
	);
}

check( 'no range means no bounds', array( 'after' => '', 'before' => '' ) === span( '' ) );

check( 'today starts at midnight', '2026-08-12 00:00:00' === span( 'today' )['after'] );
check( 'and ends at the end of the day', '2026-08-12 23:59:59' === span( 'today' )['before'] );

check( 'yesterday is the whole of the previous day', '2026-08-11 00:00:00' === span( 'yesterday' )['after'] && '2026-08-11 23:59:59' === span( 'yesterday' )['before'] );

check(
	'last 7 days includes today, so it spans 7 days not 8',
	'2026-08-06 00:00:00' === span( 'last_7' )['after'],
	'counting back a full 7 from today gives 8 days of results'
);

check( 'last 30 days likewise', '2026-07-14 00:00:00' === span( 'last_30' )['after'] );
check( 'this month starts on the 1st', '2026-08-01 00:00:00' === span( 'this_month' )['after'] );

check( 'last month is the whole of it', '2026-07-01 00:00:00' === span( 'last_month' )['after'] && '2026-07-31 23:59:59' === span( 'last_month' )['before'] );

check( 'this quarter starts in July', '2026-07-01 00:00:00' === span( 'this_quarter' )['after'], 'August is in Q3, which begins on 1 July' );
check( 'this year starts in January', '2026-01-01 00:00:00' === span( 'this_year' )['after'] );
check( 'last year is the whole of it', '2025-01-01 00:00:00' === span( 'last_year' )['after'] && '2025-12-31 23:59:59' === span( 'last_year' )['before'] );

$custom = span( 'custom', array( 'date_from' => '2026-03-01', 'date_to' => '2026-03-31' ) );

check( 'a custom range starts at the beginning of the from date', '2026-03-01 00:00:00' === $custom['after'] );
check(
	'and includes the whole of the to date',
	'2026-03-31 23:59:59' === $custom['before'],
	'treating the to-date as midnight drops a day off every export'
);

echo "\n=== Filter sanitising ===\n";

$clean = WPDEX_Filters::sanitize(
	array(
		'date_range' => 'not_a_range',
		'date_from'  => '2026-12-31',
		'date_to'    => '2026-01-01',
		'month'      => '2026-13',
		'weekdays'   => array( 0, 6, 99, -1, 6 ),
		'hours'      => array( 0, 23, 24 ),
		'statuses'   => array( 'publish', '<script>', 'draft' ),
		'authors'    => '3,7,0,abc',
		'limit'      => 999999999,
		'price_min'  => '80',
		'price_max'  => '20',
		'terms'      => array( 'category' => array( 4, 5 ), 'not_a_tax' => array( 9 ) ),
	)
);

check( 'an invented range is dropped', '' === $clean['date_range'] );
check( 'dates the wrong way round are swapped', '2026-01-01' === $clean['date_from'] && '2026-12-31' === $clean['date_to'] );
check( 'an impossible month is dropped', '' === $clean['month'] );
check( 'weekdays are clamped and deduplicated', array( 0, 6 ) === $clean['weekdays'] );
check( 'hour 24 does not exist', array( 0, 23 ) === $clean['hours'] );
check( 'statuses are keyed', array( 'publish', 'script', 'draft' ) === $clean['statuses'] );
check( 'author ids drop zero and rubbish', array( 3, 7 ) === $clean['authors'] );
check( 'the row cap is capped', 1000000 === $clean['limit'] );
check( 'prices the wrong way round are swapped', '20' === $clean['price_min'] && '80' === $clean['price_max'] );
check( 'a taxonomy this site lacks is dropped', ! isset( $clean['terms']['not_a_tax'] ) );
check( 'and a real one is kept', array( 4, 5 ) === $clean['terms']['category'] );

check( 'an empty filter set is not "active"', ! WPDEX_Filters::active( WPDEX_Filters::defaults() ) );
check( 'one with a range is', WPDEX_Filters::active( array_merge( WPDEX_Filters::defaults(), array( 'date_range' => 'today' ) ) ) );

echo "\n=== Filters become query arguments ===\n";

$args = WPDEX_Filters::to_query_args(
	array_merge(
		WPDEX_Filters::defaults(),
		array(
			'date_range' => 'this_month',
			'date_field' => 'modified',
			'statuses'   => array( 'publish' ),
			'authors'    => array( 4 ),
			'search'     => 'shoes',
			'terms'      => array( 'category' => array( 7 ) ),
		)
	),
	'post'
);

check( 'the date column follows the chosen field', 'post_modified' === $args['date_query'][0]['column'] );
check( 'statuses come through', array( 'publish' ) === $args['post_status'] );
check( 'authors come through', array( 4 ) === $args['author__in'] );
check( 'the keyword comes through', 'shoes' === $args['s'] );
check( 'a matching taxonomy becomes a tax_query', 'category' === $args['tax_query'][0]['taxonomy'] );

$product_args = WPDEX_Filters::to_query_args(
	array_merge( WPDEX_Filters::defaults(), array( 'terms' => array( 'category' => array( 7 ) ) ) ),
	'product'
);

check(
	'a taxonomy the post type does not have is ignored',
	! isset( $product_args['tax_query'] ),
	'otherwise a leftover category filter empties the products export and looks like a broken plugin'
);

check(
	'weekdays are converted to WP_Date_Query numbering',
	array( 1, 7 ) === WPDEX_Filters::date_query( array_merge( WPDEX_Filters::defaults(), array( 'weekdays' => array( 0, 6 ) ) ) )[0]['dayofweek'],
	'WP_Date_Query counts Sunday as 1; everything else in WordPress counts it as 0'
);

check(
	'a filter set with only a column produces no date_query',
	array() === WPDEX_Filters::date_query( WPDEX_Filters::defaults() )
);

echo "\n=== Filtering rows that SQL cannot reach ===\n";

$august = array_merge( WPDEX_Filters::defaults(), array( 'date_range' => 'custom', 'date_from' => '2026-08-01', 'date_to' => '2026-08-31' ) );

check( 'a lead inside the span is kept', WPDEX_Filters::date_passes( '2026-08-15 09:00:00', $august ) );
check( 'one before it is dropped', ! WPDEX_Filters::date_passes( '2026-07-31 23:00:00', $august ) );
check( 'one after it is dropped', ! WPDEX_Filters::date_passes( '2026-09-01 00:30:00', $august ) );
check( 'one on the last day is kept', WPDEX_Filters::date_passes( '2026-08-31 22:00:00', $august ) );

check(
	'a row with no date at all is kept, not dropped',
	WPDEX_Filters::date_passes( '', $august ),
	'losing a lead because its table stored an empty timestamp is worse than including one'
);

check( 'an unparseable date is kept', WPDEX_Filters::date_passes( 'not a date', $august ) );

/* ================================================================ *
 * Everything is actually in the export
 * ================================================================ */

echo "\n=== Nothing is quietly left out ===\n";

/*
 * The claim on the tin is "exports everything". This is the check on it: a row
 * built from a post carrying one of each kind of thing, asserted field by
 * field. Without it, "everything" is a word in a README.
 */
$columns = WPDEX_Posts::base_columns();

foreach ( array( 'id', 'post_type', 'status', 'title', 'slug', 'url', 'excerpt', 'content', 'parent_id', 'menu_order', 'author_id', 'author_login', 'date', 'modified', 'featured_image_id', 'featured_image_url' ) as $field ) {
	check( 'a post exports its ' . $field, in_array( $field, $columns, true ) );
}

$woo = WPDEX_Posts::woo_columns();

foreach ( array( 'product_type', 'sku', 'regular_price', 'sale_price', 'stock_status', 'stock_quantity', 'attributes', 'variation_ids', 'gallery_image_urls' ) as $field ) {
	check( 'a product exports its ' . $field, in_array( $field, $woo, true ) );
}

$term_columns = WPDEX_Terms::columns( array( 'meta' => true ) );

foreach ( array( 'term_id', 'taxonomy', 'name', 'slug', 'description', 'parent_id', 'hierarchy', 'count', 'url', 'meta' ) as $field ) {
	check( 'a term exports its ' . $field, in_array( $field, $term_columns, true ) );
}

$lead_columns = WPDEX_Forms::columns( 'leads' );

foreach ( array( 'id', 'form_id', 'form_title', 'submitted', 'from_name', 'from_email', 'ip', 'fields' ) as $field ) {
	check( 'a lead exports its ' . $field, in_array( $field, $lead_columns, true ) );
}

printf( "\n----\npassed: %d   failed: %d\n", $pass, $fail );

exit( $fail > 0 ? 1 : 0 );

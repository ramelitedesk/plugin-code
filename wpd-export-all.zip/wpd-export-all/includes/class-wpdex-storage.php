<?php
/**
 * Where exports are written, and why they are hard to reach.
 *
 * A finished export is every post, every price, every customer's form
 * submission and every private field on the site, in one file. It is the most
 * valuable thing this plugin will ever produce and the most dangerous thing to
 * leave lying around.
 *
 * It lives under uploads because that is the only directory a WordPress plugin
 * can rely on being writable. Uploads is web-readable, so:
 *
 *   • The directory is denied at the server level by .htaccess, with an
 *     index.php behind it so a misconfigured server cannot list it.
 *   • Every file name carries 32 random hex characters, so a guess is not worth
 *     attempting even where the deny rule is not honoured.
 *   • Downloads go through an authenticated PHP endpoint that checks a
 *     capability and a nonce, never a direct link.
 *   • Anything older than a week is deleted by a daily event.
 *
 * The .htaccess is ignored by Nginx, which is why the random name and the
 * authenticated endpoint are there rather than the deny rule alone. The admin
 * screen says so plainly instead of implying a protection that may not be
 * running.
 *
 * @package WPD_Export_All
 */

defined( 'ABSPATH' ) || exit;

class WPDEX_Storage {

	/** Folder inside uploads. */
	const FOLDER = 'wpd-export-all';

	/** How long a finished export is kept. */
	const TTL = WEEK_IN_SECONDS;

	/**
	 * @return string Absolute path with a trailing slash, or ''.
	 */
	public static function dir() {
		$uploads = wp_get_upload_dir();

		if ( empty( $uploads['basedir'] ) ) {
			return '';
		}

		$dir = rtrim( $uploads['basedir'], '/\\' ) . '/' . self::FOLDER;

		if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
			return '';
		}

		self::protect( $dir );

		return $dir . '/';
	}

	/**
	 * Deny the directory, and leave nothing browsable behind the denial.
	 *
	 * @param string $dir Directory.
	 */
	private static function protect( $dir ) {
		$files = array(
			'.htaccess' => "Require all denied\n<IfModule !mod_authz_core.c>\n\tDeny from all\n</IfModule>\n",
			'index.php' => "<?php\n// Silence is golden.\n",
		);

		foreach ( $files as $name => $contents ) {
			$path = $dir . '/' . $name;

			if ( ! file_exists( $path ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
				@file_put_contents( $path, $contents ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			}
		}
	}

	/**
	 * A new export's own folder.
	 *
	 * One folder per job, because an export is several files — one per source,
	 * plus a manifest — and mixing two runs together makes it impossible to
	 * tell which CSV belongs to which export.
	 *
	 * @param string $job_id Job id.
	 * @return string Path with a trailing slash, or ''.
	 */
	public static function job_dir( $job_id ) {
		$base = self::dir();

		if ( '' === $base || ! self::valid_id( $job_id ) ) {
			return '';
		}

		$dir = $base . $job_id;

		if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
			return '';
		}

		return $dir . '/';
	}

	/**
	 * A job id is 32 hex characters, and nothing else is ever accepted.
	 *
	 * This is the only thing standing between a request parameter and a path.
	 * Without it, a job id of '../../../wp-config.php' is a file read — the
	 * plugin's whole job being to hand files to a browser, that would be the
	 * end of the site.
	 *
	 * @param mixed $job_id Untrusted.
	 * @return bool
	 */
	public static function valid_id( $job_id ) {
		return is_string( $job_id ) && (bool) preg_match( '/^[a-f0-9]{32}$/', $job_id );
	}

	/**
	 * @return string A fresh job id.
	 */
	public static function new_id() {
		return bin2hex( random_bytes( 16 ) );
	}

	/**
	 * A safe filename for one source inside a job folder.
	 *
	 * @param string $job_id Job.
	 * @param string $name   Source key.
	 * @param string $ext    Extension.
	 * @return string Absolute path, or ''.
	 */
	public static function file( $job_id, $name, $ext ) {
		$dir = self::job_dir( $job_id );

		if ( '' === $dir ) {
			return '';
		}

		$name = preg_replace( '/[^a-z0-9_\-]/i', '-', (string) $name );
		$ext  = preg_replace( '/[^a-z0-9]/i', '', (string) $ext );

		return $dir . substr( $name, 0, 60 ) . '.' . $ext;
	}

	/**
	 * Delete one job's folder and everything in it.
	 *
	 * @param string $job_id Job.
	 * @return bool
	 */
	public static function delete( $job_id ) {
		$dir = self::job_dir( $job_id );

		if ( '' === $dir ) {
			return false;
		}

		foreach ( (array) glob( $dir . '*' ) as $file ) {
			if ( is_file( $file ) ) {
				wp_delete_file( $file );
			}
		}

		// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		return @rmdir( $dir );
	}

	/**
	 * Throw away exports nobody came back for.
	 */
	public static function purge_expired() {
		$base = self::dir();

		if ( '' === $base ) {
			return;
		}

		$cutoff = time() - self::TTL;

		foreach ( (array) glob( $base . '*', GLOB_ONLYDIR ) as $dir ) {
			$id = basename( $dir );

			if ( ! self::valid_id( $id ) ) {
				continue;
			}

			/*
			 * Judged by the newest file inside, not the folder's own mtime.
			 * A folder's timestamp does not always move when a file inside it
			 * is appended to, so a long-running export could be deleted while
			 * it was still being written.
			 */
			$newest = 0;

			foreach ( (array) glob( $dir . '/*' ) as $file ) {
				$newest = max( $newest, (int) filemtime( $file ) );
			}

			if ( $newest && $newest < $cutoff ) {
				self::delete( $id );

				WPDEX_Job::forget( $id );
			}
		}
	}

	/**
	 * Every finished export still on disk, newest first.
	 *
	 * @return array[]
	 */
	public static function all_jobs() {
		$jobs = get_option( WPDEX_Job::OPTION, array() );

		if ( ! is_array( $jobs ) ) {
			return array();
		}

		uasort(
			$jobs,
			static function ( $a, $b ) {
				return ( $b['started'] ?? 0 ) <=> ( $a['started'] ?? 0 );
			}
		);

		return $jobs;
	}

	/**
	 * Human-readable size of a job's output.
	 *
	 * @param string $job_id Job.
	 * @return int Bytes.
	 */
	public static function job_size( $job_id ) {
		$dir = self::job_dir( $job_id );

		if ( '' === $dir ) {
			return 0;
		}

		$bytes = 0;

		foreach ( (array) glob( $dir . '*' ) as $file ) {
			if ( is_file( $file ) ) {
				$bytes += (int) filesize( $file );
			}
		}

		return $bytes;
	}
}

<?php
/**
 * Reading an export back in.
 *
 * IMPORTING IS NOT THE MIRROR OF EXPORTING, and pretending it is produces the
 * worst plugin in this folder. Exporting reads; the site is exactly as it was
 * afterwards. Importing writes, into a live site, and its mistakes are
 * permanent: a wrong match overwrites a real post, a wrong parent orphans a
 * page tree, a second run doubles the catalogue.
 *
 * So the design is defensive in four specific ways:
 *
 *   1. IT DRY RUNS BY DEFAULT. The first pass writes nothing and reports what
 *      it would do — how many new, how many matched, which rows it could not
 *      read. Nothing is written until somebody has seen that and pressed the
 *      second button.
 *   2. MATCHING IS EXPLICIT. An imported row is matched to an existing post by
 *      a key you choose — the exported ID, the slug, or the SKU — and "no
 *      match" means "create". Guessing across several keys at once is how a
 *      product ends up merged with an unrelated one.
 *   3. IDs ARE NEVER TRUSTED AS IDs. The exported id is a *lookup value*, never
 *      the id a row is written to. Writing to post 412 because the file says
 *      412 overwrites whatever post 412 is on this site, which on a different
 *      installation is something else entirely.
 *   4. RELATIONSHIPS ARE REMAPPED. Parent ids, and ACF relationship values, are
 *      translated through a map built during the run. An untranslated parent id
 *      points at a random post on the destination site.
 *
 * Only the JSON format can be imported. CSV loses the difference between the
 * number 007 and the string "007", between an empty cell and a null, and
 * between a nested array and the text that looks like one — all of which matter
 * when writing rather than reading.
 *
 * @package WPD_Export_All
 */

defined( 'ABSPATH' ) || exit;

class WPDEX_Import {

	/** Where an uploaded file waits between the dry run and the real one. */
	const OPTION = 'wpdex_imports';

	/** How a row is matched to something already here. */
	const MATCH_ID   = 'id';
	const MATCH_SLUG = 'slug';
	const MATCH_SKU  = 'sku';
	const MATCH_NONE = 'none';

	public static function init() {
		add_action( 'wp_ajax_wpdex_import_run', array( __CLASS__, 'ajax_run' ) );
		add_action( 'admin_post_wpdex_import_upload', array( __CLASS__, 'upload' ) );
		add_action( 'admin_post_wpdex_import_discard', array( __CLASS__, 'discard' ) );
	}

	/* ------------------------------------------------------------------ *
	 * Uploading
	 * ------------------------------------------------------------------ */

	/**
	 * Take a JSON export and park it, without touching the site.
	 */
	public static function upload() {
		if ( ! current_user_can( 'import' ) ) {
			wp_die( esc_html__( 'You do not have permission to import.', 'wpd-export-all' ), '', array( 'response' => 403 ) );
		}

		check_admin_referer( 'wpdex_import_upload' );

		if ( empty( $_FILES['wpdex_file']['tmp_name'] ) ) {
			self::back( 'nofile' );
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$tmp  = $_FILES['wpdex_file']['tmp_name'];
		$name = isset( $_FILES['wpdex_file']['name'] ) ? sanitize_file_name( wp_unslash( $_FILES['wpdex_file']['name'] ) ) : 'import.json';
		$size = isset( $_FILES['wpdex_file']['size'] ) ? (int) $_FILES['wpdex_file']['size'] : 0;

		if ( ! is_uploaded_file( $tmp ) ) {
			self::back( 'nofile' );
		}

		/*
		 * Read and decoded in full, on purpose, and capped because of it.
		 *
		 * A streaming JSON parser would lift the cap, but the import has to
		 * hold a full ID map anyway to remap parents, so the memory is spent
		 * either way. 64MB of JSON is somewhere around 200,000 posts, which is
		 * far past the point where this should be a WP-CLI job instead.
		 */
		if ( $size > 64 * MB_IN_BYTES ) {
			self::back( 'toobig' );
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_get_contents
		$raw = file_get_contents( $tmp );

		$rows = json_decode( (string) $raw, true );

		if ( ! is_array( $rows ) || ! $rows ) {
			self::back( 'badjson' );
		}

		// A manifest is not importable content, and somebody will upload one.
		if ( isset( $rows['plugin'] ) && isset( $rows['sources'] ) ) {
			self::back( 'manifest' );
		}

		$import_id = WPDEX_Storage::new_id();

		$path = WPDEX_Storage::file( $import_id, 'import', 'json' );

		if ( '' === $path ) {
			self::back( 'nodir' );
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		file_put_contents( $path, wp_json_encode( $rows ) );

		self::remember(
			array(
				'id'       => $import_id,
				'file'     => basename( $path ),
				'name'     => $name,
				'rows'     => count( $rows ),
				'uploaded' => time(),
				'kind'     => self::guess_kind( $rows ),
			)
		);

		wp_safe_redirect( admin_url( 'tools.php?page=wpd-export-all&tab=import&ready=' . rawurlencode( $import_id ) ) );

		exit;
	}

	/**
	 * What sort of export is this?
	 *
	 * Read from the rows rather than the filename, because a file called
	 * products.json is not necessarily products and the consequence of being
	 * wrong is writing terms into the posts table.
	 *
	 * @param array $rows Decoded rows.
	 * @return string posts|terms|unknown
	 */
	public static function guess_kind( array $rows ) {
		$first = reset( $rows );

		if ( ! is_array( $first ) ) {
			return 'unknown';
		}

		if ( isset( $first['term_id'] ) && isset( $first['taxonomy'] ) ) {
			return 'terms';
		}

		if ( isset( $first['id'] ) && isset( $first['post_type'] ) ) {
			return 'posts';
		}

		return 'unknown';
	}

	/* ------------------------------------------------------------------ *
	 * Running
	 * ------------------------------------------------------------------ */

	/**
	 * Import — or, by default, only say what importing would do.
	 *
	 * @param string $import_id Parked file.
	 * @param array  $settings  match, dry_run, update_existing, post_type, status.
	 * @return array|WP_Error
	 */
	public static function run( $import_id, array $settings ) {
		$record = self::get( $import_id );

		if ( ! $record ) {
			return new WP_Error( 'wpdex_no_import', __( 'That upload is no longer available. Upload the file again.', 'wpd-export-all' ) );
		}

		$path = WPDEX_Storage::job_dir( $import_id ) . $record['file'];

		if ( ! is_file( $path ) ) {
			return new WP_Error( 'wpdex_no_import', __( 'The uploaded file has gone. Upload it again.', 'wpd-export-all' ) );
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_get_contents
		$rows = json_decode( (string) file_get_contents( $path ), true );

		if ( ! is_array( $rows ) ) {
			return new WP_Error( 'wpdex_badjson', __( 'The uploaded file could not be read as JSON.', 'wpd-export-all' ) );
		}

		$settings = self::settings( $settings );

		$report = array(
			'dry_run'  => $settings['dry_run'],
			'total'    => count( $rows ),
			'created'  => 0,
			'updated'  => 0,
			'skipped'  => 0,
			'failed'   => 0,
			'problems' => array(),
			'map'      => array(),
		);

		$kind = $record['kind'];

		foreach ( $rows as $index => $row ) {
			if ( ! is_array( $row ) ) {
				$report['failed']++;
				self::note( $report, sprintf( /* translators: %d: row number. */ __( 'Row %d is not an object and was skipped.', 'wpd-export-all' ), $index + 1 ) );

				continue;
			}

			$result = ( 'terms' === $kind )
				? self::import_term( $row, $settings, $report )
				: self::import_post( $row, $settings, $report );

			if ( is_wp_error( $result ) ) {
				$report['failed']++;
				self::note( $report, $result->get_error_message() );

				continue;
			}

			$report[ $result['action'] ]++;

			if ( ! empty( $result['old_id'] ) && ! empty( $result['new_id'] ) ) {
				$report['map'][ (int) $result['old_id'] ] = (int) $result['new_id'];
			}
		}

		/*
		 * Second pass: parents and relationships.
		 *
		 * They cannot be set on the way in, because a post's parent may not
		 * have been created yet when the child is read. Everything is written
		 * first, then the references are translated through the map built while
		 * doing it.
		 */
		if ( ! $settings['dry_run'] && 'posts' === $kind && $report['map'] ) {
			self::remap( $rows, $report );
		}

		return $report;
	}

	/**
	 * @param array $raw Settings.
	 * @return array
	 */
	public static function settings( array $raw ) {
		return array(
			'match'           => in_array( $raw['match'] ?? '', array( self::MATCH_ID, self::MATCH_SLUG, self::MATCH_SKU, self::MATCH_NONE ), true )
				? $raw['match']
				: self::MATCH_SLUG,
			/*
			 * Defaults to TRUE, and that is the most important default here.
			 * An import that writes on the first press is one misclick from
			 * overwriting a catalogue, and there is no undo.
			 */
			'dry_run'         => ! isset( $raw['dry_run'] ) || ! empty( $raw['dry_run'] ),
			'update_existing' => ! empty( $raw['update_existing'] ),
			'status'          => sanitize_key( $raw['status'] ?? '' ),
			'post_type'       => sanitize_key( $raw['post_type'] ?? '' ),
		);
	}

	/* ------------------------------------------------------------------ *
	 * Posts
	 * ------------------------------------------------------------------ */

	/**
	 * @param array $row      One exported post.
	 * @param array $settings Settings.
	 * @param array $report   Report, by reference.
	 * @return array|WP_Error action, old_id, new_id.
	 */
	private static function import_post( array $row, array $settings, array &$report ) {
		$type = $settings['post_type'] ? $settings['post_type'] : sanitize_key( $row['post_type'] ?? 'post' );

		if ( ! post_type_exists( $type ) ) {
			return new WP_Error(
				'wpdex_no_type',
				sprintf(
					/* translators: %s: post type. */
					__( 'The post type "%s" is not registered on this site, so those rows were skipped.', 'wpd-export-all' ),
					$type
				)
			);
		}

		$existing = self::find_existing( $row, $type, $settings['match'] );

		if ( $existing && ! $settings['update_existing'] ) {
			return array(
				'action' => 'skipped',
				'old_id' => (int) ( $row['id'] ?? 0 ),
				'new_id' => $existing,
			);
		}

		$postarr = array(
			'post_type'      => $type,
			'post_title'     => (string) ( $row['title'] ?? '' ),
			'post_name'      => (string) ( $row['slug'] ?? '' ),
			'post_content'   => (string) ( $row['content'] ?? '' ),
			'post_excerpt'   => (string) ( $row['excerpt'] ?? '' ),
			'menu_order'     => (int) ( $row['menu_order'] ?? 0 ),
			'comment_status' => (string) ( $row['comment_status'] ?? 'closed' ),
			/*
			 * The parent is deliberately left off here and fixed in the second
			 * pass. Setting it now would point at whatever holds that id on
			 * THIS site, which is somebody else's page.
			 */
		);

		$status = $settings['status'] ? $settings['status'] : sanitize_key( $row['status'] ?? 'draft' );

		// A status this site does not have would make the post invisible with
		// no way to find it in the admin.
		$postarr['post_status'] = get_post_status_object( $status ) ? $status : 'draft';

		if ( ! empty( $row['date'] ) && strtotime( (string) $row['date'] ) ) {
			$postarr['post_date'] = (string) $row['date'];
		}

		$author = self::resolve_author( $row );

		if ( $author ) {
			$postarr['post_author'] = $author;
		}

		if ( $settings['dry_run'] ) {
			return array(
				'action' => $existing ? 'updated' : 'created',
				'old_id' => (int) ( $row['id'] ?? 0 ),
				'new_id' => $existing,
			);
		}

		if ( $existing ) {
			$postarr['ID'] = $existing;
		}

		$new_id = wp_insert_post( wp_slash( $postarr ), true );

		if ( is_wp_error( $new_id ) ) {
			return $new_id;
		}

		self::write_terms( $new_id, $row, $type );
		self::write_meta( $new_id, $row );

		return array(
			'action' => $existing ? 'updated' : 'created',
			'old_id' => (int) ( $row['id'] ?? 0 ),
			'new_id' => (int) $new_id,
		);
	}

	/**
	 * Find the post this row should update, if any.
	 *
	 * @param array  $row   Row.
	 * @param string $type  Post type.
	 * @param string $match Matching strategy.
	 * @return int 0 if nothing matches.
	 */
	public static function find_existing( array $row, $type, $match ) {
		if ( self::MATCH_NONE === $match ) {
			return 0;
		}

		if ( self::MATCH_ID === $match ) {
			$id = absint( $row['id'] ?? 0 );

			if ( ! $id ) {
				return 0;
			}

			$post = get_post( $id );

			/*
			 * The type must agree. Post 412 on the source site being a product
			 * and post 412 here being an About page is not a match — it is the
			 * accident this check exists to prevent.
			 */
			return ( $post && $post->post_type === $type ) ? (int) $post->ID : 0;
		}

		if ( self::MATCH_SKU === $match ) {
			$sku = trim( (string) ( $row['sku'] ?? '' ) );

			if ( '' === $sku || ! function_exists( 'wc_get_product_id_by_sku' ) ) {
				return 0;
			}

			return (int) wc_get_product_id_by_sku( $sku );
		}

		$slug = sanitize_title( (string) ( $row['slug'] ?? '' ) );

		if ( '' === $slug ) {
			return 0;
		}

		$found = get_posts(
			array(
				'post_type'        => $type,
				'name'             => $slug,
				'post_status'      => 'any',
				'numberposts'      => 1,
				'fields'           => 'ids',
				'suppress_filters' => false,
			)
		);

		return $found ? (int) $found[0] : 0;
	}

	/**
	 * @param array $row Row.
	 * @return int User id, or 0.
	 */
	private static function resolve_author( array $row ) {
		/*
		 * By login, not by id. User 3 on the source site is a different person
		 * from user 3 here, and attributing a post to the wrong author is both
		 * wrong and, on a site with author archives, public.
		 */
		$login = trim( (string) ( $row['author_login'] ?? '' ) );

		if ( '' !== $login ) {
			$user = get_user_by( 'login', $login );

			if ( $user ) {
				return (int) $user->ID;
			}
		}

		return 0;
	}

	/**
	 * @param int    $post_id Post.
	 * @param array  $row     Row.
	 * @param string $type    Post type.
	 */
	private static function write_terms( $post_id, array $row, $type ) {
		foreach ( $row as $key => $value ) {
			if ( 0 !== strpos( (string) $key, 'tax:' ) ) {
				continue;
			}

			$taxonomy = substr( $key, 4 );

			if ( ! taxonomy_exists( $taxonomy ) || ! in_array( $taxonomy, get_object_taxonomies( $type ), true ) ) {
				continue;
			}

			$names = is_array( $value ) ? $value : array_filter( array_map( 'trim', explode( ',', (string) $value ) ) );

			if ( ! $names ) {
				continue;
			}

			/*
			 * By name, and created if missing.
			 *
			 * Term ids do not survive a move between sites any better than post
			 * ids do. Names do, and a category that does not exist yet on the
			 * destination is one that should.
			 */
			wp_set_object_terms( $post_id, array_map( 'strval', $names ), $taxonomy, false );
		}
	}

	/**
	 * @param int   $post_id Post.
	 * @param array $row     Row.
	 */
	private static function write_meta( $post_id, array $row ) {
		foreach ( $row as $key => $value ) {
			if ( 0 !== strpos( (string) $key, 'meta:' ) ) {
				continue;
			}

			$meta_key = substr( $key, 5 );

			/*
			 * The same list the exporter refuses to write is refused on the way
			 * back in. A file that has been edited by hand — or built by
			 * somebody else entirely — must not be able to set an API key on a
			 * post by naming it in a column.
			 */
			if ( WPDEX_Posts::skip_meta_key( $meta_key, array( 'meta' => true ) ) ) {
				continue;
			}

			update_post_meta( $post_id, $meta_key, wp_slash( $value ) );
		}

		if ( isset( $row['acf'] ) && is_array( $row['acf'] ) && function_exists( 'update_field' ) ) {
			foreach ( $row['acf'] as $field => $value ) {
				update_field( $field, $value, $post_id );
			}
		}
	}

	/* ------------------------------------------------------------------ *
	 * Terms
	 * ------------------------------------------------------------------ */

	/**
	 * @param array $row      Row.
	 * @param array $settings Settings.
	 * @param array $report   Report.
	 * @return array|WP_Error
	 */
	private static function import_term( array $row, array $settings, array &$report ) {
		$taxonomy = sanitize_key( $row['taxonomy'] ?? '' );

		if ( ! taxonomy_exists( $taxonomy ) ) {
			return new WP_Error(
				'wpdex_no_tax',
				sprintf(
					/* translators: %s: taxonomy. */
					__( 'The taxonomy "%s" is not registered here, so those terms were skipped.', 'wpd-export-all' ),
					$taxonomy
				)
			);
		}

		$slug = sanitize_title( (string) ( $row['slug'] ?? '' ) );
		$name = (string) ( $row['name'] ?? '' );

		if ( '' === $name ) {
			return new WP_Error( 'wpdex_no_name', __( 'A term row had no name and was skipped.', 'wpd-export-all' ) );
		}

		$existing = $slug ? get_term_by( 'slug', $slug, $taxonomy ) : null;

		if ( $existing && ! $settings['update_existing'] ) {
			return array(
				'action' => 'skipped',
				'old_id' => (int) ( $row['term_id'] ?? 0 ),
				'new_id' => (int) $existing->term_id,
			);
		}

		if ( $settings['dry_run'] ) {
			return array(
				'action' => $existing ? 'updated' : 'created',
				'old_id' => (int) ( $row['term_id'] ?? 0 ),
				'new_id' => $existing ? (int) $existing->term_id : 0,
			);
		}

		$args = array(
			'description' => (string) ( $row['description'] ?? '' ),
			'slug'        => $slug,
		);

		if ( $existing ) {
			$result = wp_update_term( (int) $existing->term_id, $taxonomy, array_merge( $args, array( 'name' => $name ) ) );
		} else {
			$result = wp_insert_term( $name, $taxonomy, $args );
		}

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$term_id = (int) $result['term_id'];

		if ( isset( $row['meta'] ) && is_array( $row['meta'] ) ) {
			foreach ( $row['meta'] as $key => $value ) {
				if ( ! WPDEX_Posts::skip_meta_key( $key, array( 'meta' => true ) ) ) {
					update_term_meta( $term_id, $key, wp_slash( $value ) );
				}
			}
		}

		return array(
			'action' => $existing ? 'updated' : 'created',
			'old_id' => (int) ( $row['term_id'] ?? 0 ),
			'new_id' => $term_id,
		);
	}

	/* ------------------------------------------------------------------ *
	 * The second pass
	 * ------------------------------------------------------------------ */

	/**
	 * Translate parent ids through the map built during the first pass.
	 *
	 * @param array $rows   All rows.
	 * @param array $report Report holding the map.
	 */
	private static function remap( array $rows, array $report ) {
		$map = $report['map'];

		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$old_id     = (int) ( $row['id'] ?? 0 );
			$old_parent = (int) ( $row['parent_id'] ?? 0 );

			if ( ! $old_id || ! $old_parent || ! isset( $map[ $old_id ] ) ) {
				continue;
			}

			/*
			 * A parent that was not itself imported is left alone rather than
			 * guessed at. Pointing a child at "whatever holds that id here"
			 * moves a page into a tree it has nothing to do with, and that is
			 * worse than an orphan somebody can see and fix.
			 */
			if ( ! isset( $map[ $old_parent ] ) ) {
				continue;
			}

			wp_update_post(
				array(
					'ID'          => $map[ $old_id ],
					'post_parent' => $map[ $old_parent ],
				)
			);
		}
	}

	/* ------------------------------------------------------------------ *
	 * Bookkeeping
	 * ------------------------------------------------------------------ */

	/**
	 * @param array  $report Report.
	 * @param string $note   Problem.
	 */
	private static function note( array &$report, $note ) {
		// Deduplicated and capped. Four thousand copies of "the taxonomy brand
		// is not registered here" is less informative than one.
		if ( count( $report['problems'] ) < 25 && ! in_array( $note, $report['problems'], true ) ) {
			$report['problems'][] = $note;
		}
	}

	/**
	 * @param string $id Import id.
	 * @return array|null
	 */
	public static function get( $id ) {
		if ( ! WPDEX_Storage::valid_id( $id ) ) {
			return null;
		}

		$all = get_option( self::OPTION, array() );

		return is_array( $all ) && isset( $all[ $id ] ) ? $all[ $id ] : null;
	}

	/**
	 * @return array[]
	 */
	public static function all() {
		$all = get_option( self::OPTION, array() );

		return is_array( $all ) ? $all : array();
	}

	/**
	 * @param array $record Import record.
	 */
	private static function remember( array $record ) {
		$all = self::all();

		$all[ $record['id'] ] = $record;

		// Only a handful are kept; an uploaded export is as sensitive as an
		// exported one and there is no reason to hoard them.
		if ( count( $all ) > 5 ) {
			uasort(
				$all,
				static function ( $a, $b ) {
					return ( $b['uploaded'] ?? 0 ) <=> ( $a['uploaded'] ?? 0 );
				}
			);

			foreach ( array_slice( array_keys( $all ), 5 ) as $old ) {
				WPDEX_Storage::delete( $old );

				unset( $all[ $old ] );
			}
		}

		update_option( self::OPTION, $all, false );
	}

	public static function discard() {
		if ( ! current_user_can( 'import' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'wpd-export-all' ), '', array( 'response' => 403 ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$id = isset( $_GET['import'] ) ? sanitize_text_field( wp_unslash( $_GET['import'] ) ) : '';

		check_admin_referer( 'wpdex_import_discard_' . $id );

		if ( WPDEX_Storage::valid_id( $id ) ) {
			WPDEX_Storage::delete( $id );

			$all = self::all();

			unset( $all[ $id ] );

			update_option( self::OPTION, $all, false );
		}

		wp_safe_redirect( admin_url( 'tools.php?page=wpd-export-all&tab=import' ) );

		exit;
	}

	/**
	 * @param string $code Error code.
	 */
	private static function back( $code ) {
		wp_safe_redirect( admin_url( 'tools.php?page=wpd-export-all&tab=import&error=' . rawurlencode( $code ) ) );

		exit;
	}

	/* ------------------------------------------------------------------ *
	 * AJAX
	 * ------------------------------------------------------------------ */

	public static function ajax_run() {
		if ( ! current_user_can( 'import' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to import.', 'wpd-export-all' ) ), 403 );
		}

		check_ajax_referer( 'wpdex', 'nonce' );

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- checked above.
		$import_id = isset( $_POST['import'] ) ? sanitize_text_field( wp_unslash( $_POST['import'] ) ) : '';

		$settings = array(
			'match'           => isset( $_POST['match'] ) ? sanitize_key( wp_unslash( $_POST['match'] ) ) : self::MATCH_SLUG,
			'dry_run'         => ! empty( $_POST['dry_run'] ),
			'update_existing' => ! empty( $_POST['update_existing'] ),
			'status'          => isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : '',
			'post_type'       => isset( $_POST['post_type'] ) ? sanitize_key( wp_unslash( $_POST['post_type'] ) ) : '',
		);
		// phpcs:enable

		$report = self::run( $import_id, $settings );

		if ( is_wp_error( $report ) ) {
			wp_send_json_error( array( 'message' => $report->get_error_message() ), 400 );
		}

		// The map can hold tens of thousands of pairs and the browser has no
		// use for it.
		unset( $report['map'] );

		wp_send_json_success( $report );
	}
}

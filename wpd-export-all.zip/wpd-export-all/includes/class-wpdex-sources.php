<?php
/**
 * What this site actually contains.
 *
 * Built by asking WordPress rather than by listing things. A hardcoded list is
 * wrong on the first site that has a Portfolio post type or a Brand taxonomy,
 * and those sites are the reason somebody installs an exporter — the built-in
 * WordPress export tool already handles posts and pages.
 *
 * @package WPD_Export_All
 */

defined( 'ABSPATH' ) || exit;

class WPDEX_Sources {

	/**
	 * Everything exportable, grouped for the screen.
	 *
	 * @return array<string,array> group label => key => spec.
	 */
	public static function all() {
		$groups = array();

		$content = self::post_types();
		$shop    = array();

		/*
		 * WooCommerce is split out because a shop owner thinks of products as a
		 * different kind of thing from posts, and because products bring their
		 * own extras — variations, attributes, stock — that nothing else has.
		 */
		foreach ( array( 'product', 'product_variation', 'shop_order', 'shop_coupon' ) as $woo ) {
			if ( isset( $content[ $woo ] ) ) {
				$shop[ $woo ] = $content[ $woo ];

				unset( $content[ $woo ] );
			}
		}

		if ( $content ) {
			$groups[ __( 'Content', 'wpd-export-all' ) ] = $content;
		}

		if ( $shop ) {
			$groups[ __( 'WooCommerce', 'wpd-export-all' ) ] = $shop;
		}

		$taxonomies = self::taxonomies();

		if ( $taxonomies ) {
			$groups[ __( 'Taxonomies, categories and tags', 'wpd-export-all' ) ] = $taxonomies;
		}

		$forms = WPDEX_Forms::sources();

		if ( $forms ) {
			$groups[ __( 'Forms and leads', 'wpd-export-all' ) ] = $forms;
		}

		/**
		 * Add or remove exportable sources.
		 *
		 * @param array $groups group label => key => spec.
		 */
		return apply_filters( 'wpdex_sources', $groups );
	}

	/**
	 * Every post type worth offering, with a live count.
	 *
	 * @return array<string,array>
	 */
	public static function post_types() {
		$out = array();

		foreach ( get_post_types( array(), 'objects' ) as $type ) {
			if ( self::skip_post_type( $type->name ) ) {
				continue;
			}

			$out[ $type->name ] = array(
				'kind'  => 'post_type',
				'name'  => $type->name,
				'label' => $type->labels->name ? $type->labels->name : $type->name,
				'count' => self::count_posts( $type->name ),
			);
		}

		uasort(
			$out,
			static function ( $a, $b ) {
				return strcasecmp( $a['label'], $b['label'] );
			}
		);

		return $out;
	}

	/**
	 * Post types nobody wants in an export of their content.
	 *
	 * @param string $name Post type.
	 * @return bool
	 */
	private static function skip_post_type( $name ) {
		$skip = array(
			// WordPress's own plumbing. Revisions alone can be ten times the
			// row count of the posts they belong to, and none of it is content.
			'revision',
			'nav_menu_item',
			'custom_css',
			'customize_changeset',
			'oembed_cache',
			'user_request',
			'wp_block',
			'wp_template',
			'wp_template_part',
			'wp_global_styles',
			'wp_navigation',
			'wp_font_family',
			'wp_font_face',

			// ACF's own field group storage. Exporting it as content produces
			// rows of serialised field definitions; ACF has its own exporter
			// for the definitions, and this plugin exports the *values*.
			'acf-field',
			'acf-field-group',
			'acf-post-type',
			'acf-taxonomy',

			// This plugin's own bookkeeping, and other exporters' scheduled
			// action rows, which are logs rather than content.
			'scheduled-action',
		);

		/**
		 * @param string[] $skip Post types never offered.
		 */
		$skip = (array) apply_filters( 'wpdex_skip_post_types', $skip );

		return in_array( $name, $skip, true );
	}

	/**
	 * @param string $type Post type.
	 * @return int Published + drafted + private, excluding auto-drafts.
	 */
	public static function count_posts( $type ) {
		$counts = (array) wp_count_posts( $type );
		$total  = 0;

		foreach ( $counts as $status => $count ) {
			// auto-draft is a row WordPress created when somebody clicked "Add
			// New" and wandered off. It has no title and no content.
			if ( 'auto-draft' === $status ) {
				continue;
			}

			$total += (int) $count;
		}

		return $total;
	}

	/**
	 * Every taxonomy, with its term count.
	 *
	 * @return array<string,array>
	 */
	public static function taxonomies() {
		$out = array();

		$skip = array( 'nav_menu', 'link_category', 'post_format', 'wp_theme', 'wp_template_part_area', 'wp_pattern_category' );

		foreach ( get_taxonomies( array(), 'objects' ) as $tax ) {
			if ( in_array( $tax->name, $skip, true ) ) {
				continue;
			}

			$count = wp_count_terms(
				array(
					'taxonomy'   => $tax->name,
					'hide_empty' => false,
				)
			);

			$out[ 'tax:' . $tax->name ] = array(
				'kind'  => 'taxonomy',
				'name'  => $tax->name,
				'label' => $tax->labels->name ? $tax->labels->name : $tax->name,
				'count' => is_wp_error( $count ) ? 0 : (int) $count,
			);
		}

		uasort(
			$out,
			static function ( $a, $b ) {
				return strcasecmp( $a['label'], $b['label'] );
			}
		);

		return $out;
	}

	/**
	 * Look one source key up.
	 *
	 * @param string $key Source key.
	 * @return array|null
	 */
	public static function get( $key ) {
		foreach ( self::all() as $sources ) {
			if ( isset( $sources[ $key ] ) ) {
				return $sources[ $key ];
			}
		}

		return null;
	}

	/**
	 * Drop anything from a submitted selection that is not really a source.
	 *
	 * @param array $keys Untrusted.
	 * @return string[]
	 */
	public static function filter_valid( array $keys ) {
		$known = array();

		foreach ( self::all() as $sources ) {
			$known = array_merge( $known, array_keys( $sources ) );
		}

		$clean = array();

		foreach ( $keys as $key ) {
			if ( is_string( $key ) && in_array( $key, $known, true ) ) {
				$clean[] = $key;
			}
		}

		return array_values( array_unique( $clean ) );
	}

	/**
	 * Is WooCommerce here?
	 *
	 * @return bool
	 */
	public static function woo() {
		return class_exists( 'WooCommerce' );
	}
}

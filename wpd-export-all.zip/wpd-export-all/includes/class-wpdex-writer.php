<?php
/**
 * Writing rows to disk, a few at a time.
 *
 * Never "build the export then save it". A 40,000-row export held in a PHP
 * array is hundreds of megabytes before it is encoded, and the encoding doubles
 * it — so the machine that most needs an exporter is the one it dies on. Every
 * writer here opens the file, appends, and closes, so peak memory is one batch
 * regardless of how big the site is.
 *
 * @package WPD_Export_All
 */

defined( 'ABSPATH' ) || exit;

class WPDEX_Writer {

	/** @var string Absolute path being written. */
	private $path;

	/** @var string csv|json */
	private $format;

	/** @var string[] Column order, CSV only. */
	private $columns = array();

	/**
	 * @param string $path    File to append to.
	 * @param string $format  csv|json.
	 * @param array  $columns Column order, CSV only.
	 */
	public function __construct( $path, $format, array $columns = array() ) {
		$this->path    = $path;
		$this->format  = ( 'json' === $format ) ? 'json' : 'csv';
		$this->columns = $columns;
	}

	/**
	 * Start the file. Called once, before any rows.
	 *
	 * @return bool
	 */
	public function open() {
		$handle = fopen( $this->path, 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen

		if ( ! $handle ) {
			return false;
		}

		if ( 'json' === $this->format ) {
			fwrite( $handle, "[\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
		} else {
			/*
			 * A UTF-8 byte order mark, purely for Excel.
			 *
			 * Without it Excel on Windows reads a UTF-8 CSV as the system code
			 * page, and every accented character in the site's content comes
			 * out as mojibake. The file is correct either way; the BOM is what
			 * makes the program most people open it in agree.
			 */
			fwrite( $handle, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite

			if ( $this->columns ) {
				$this->put_csv_row( $handle, $this->columns );
			}
		}

		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose

		return true;
	}

	/**
	 * Append a batch of rows.
	 *
	 * @param array[] $rows      Rows.
	 * @param bool    $is_first  Whether these are the first rows in the file.
	 * @return int How many were written.
	 */
	public function append( array $rows, $is_first ) {
		if ( ! $rows ) {
			return 0;
		}

		$handle = fopen( $this->path, 'ab' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen

		if ( ! $handle ) {
			return 0;
		}

		$written = 0;

		foreach ( $rows as $row ) {
			if ( 'json' === $this->format ) {
				/*
				 * The comma goes BEFORE each row except the first, rather than
				 * after each row except the last. Written the other way round,
				 * the last row of a batch does not know it is the last row of
				 * the file — the job is resumed in a separate request — and the
				 * file ends with a trailing comma that no JSON parser accepts.
				 */
				$prefix = ( $is_first && 0 === $written ) ? "\t" : ",\n\t";

				$encoded = wp_json_encode( $row, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR );

				if ( false === $encoded ) {
					// Almost always invalid UTF-8 from an old database. Losing
					// one row is better than losing the export.
					continue;
				}

				fwrite( $handle, $prefix . $encoded ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
			} else {
				$this->put_csv_row( $handle, $this->order_row( $row ) );
			}

			$written++;
		}

		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose

		return $written;
	}

	/**
	 * Finish the file.
	 */
	public function close() {
		if ( 'json' !== $this->format ) {
			return;
		}

		$handle = fopen( $this->path, 'ab' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen

		if ( $handle ) {
			fwrite( $handle, "\n]\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
			fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		}
	}

	/**
	 * Put a row's cells in the header's order.
	 *
	 * A row missing a column gets an empty cell rather than shifting everything
	 * after it left by one — which is what happens if you just write
	 * array_values(), and it silently corrupts every column after the gap.
	 *
	 * @param array $row Row keyed by column name.
	 * @return array
	 */
	private function order_row( array $row ) {
		$out = array();

		foreach ( $this->columns as $column ) {
			$out[] = self::cell( $row[ $column ] ?? '' );
		}

		return $out;
	}

	/**
	 * One value, flattened to something a CSV cell can hold.
	 *
	 * @param mixed $value Anything.
	 * @return string
	 */
	public static function cell( $value ) {
		if ( is_null( $value ) ) {
			return '';
		}

		if ( is_bool( $value ) ) {
			return $value ? '1' : '0';
		}

		if ( is_scalar( $value ) ) {
			return (string) $value;
		}

		/*
		 * Arrays and objects become JSON rather than PHP serialisation.
		 *
		 * A cell reading a:2:{i:0;s:5:"green";} is data nobody can use without
		 * writing a PHP script, which defeats the point of a CSV. JSON is read
		 * by every spreadsheet's own tooling and by every scripting language.
		 */
		$encoded = wp_json_encode( $value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR );

		return false === $encoded ? '' : $encoded;
	}

	/**
	 * Write one CSV row, defusing anything a spreadsheet would run.
	 *
	 * @param resource $handle Open file.
	 * @param array    $cells  Cells.
	 */
	private function put_csv_row( $handle, array $cells ) {
		fputcsv( $handle, array_map( array( __CLASS__, 'defuse' ), $cells ) );
	}

	/**
	 * Stop a cell being executed as a formula when the file is opened.
	 *
	 * THIS IS NOT COSMETIC. Excel, LibreOffice and Google Sheets all treat a
	 * cell beginning with = + - @ or a control character as a formula, and they
	 * evaluate it on open. A product title, a form submission, a comment — any
	 * field a stranger can type into — becomes code running on the machine of
	 * whoever opens the export. It is the classic CSV injection, it has a CVE
	 * against half the export plugins ever written, and the person who opens the
	 * file is by definition the site's administrator.
	 *
	 * A leading apostrophe makes the cell a literal string. Spreadsheets do not
	 * display it, so the value still reads correctly.
	 *
	 * @param string $cell Cell value.
	 * @return string
	 */
	public static function defuse( $cell ) {
		$cell = (string) $cell;

		if ( '' === $cell ) {
			return $cell;
		}

		// Tab and carriage return are in the list because a leading one is
		// stripped by the parser, exposing whatever follows it.
		if ( in_array( $cell[0], array( '=', '+', '-', '@', "\t", "\r" ), true ) ) {
			return "'" . $cell;
		}

		return $cell;
	}

	/**
	 * @return string The file being written.
	 */
	public function path() {
		return $this->path;
	}
}

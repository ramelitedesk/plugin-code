<?php
/**
 * ACF field values, resolved rather than dumped.
 *
 * ACF keeps a field's value in an ordinary meta row under the field's name, and
 * a pointer to the field definition in a second row under an underscored name:
 *
 *     subtitle        =>  "A subtitle"
 *     _subtitle       =>  "field_5f3a1c2b4d5e6"
 *
 * A repeater is worse. Six rows for two items of a two-field repeater, named by
 * position, plus a count and six pointers:
 *
 *     gallery              =>  "2"
 *     gallery_0_caption    =>  "First"
 *     gallery_0_image      =>  "412"
 *     gallery_1_caption    =>  "Second"
 *     gallery_1_image      =>  "418"
 *     _gallery_0_caption   =>  "field_…"
 *
 * An exporter that reads postmeta directly writes all of that out, and the
 * result is unusable: a spreadsheet with a gallery_0_caption column, a
 * gallery_1_caption column, and no column at all for the third item that only
 * one post has.
 *
 * So where ACF is installed it is asked for the value, because it is the only
 * thing that knows how to reassemble one. get_fields() returns the repeater as
 * an array of rows, the image as an attachment array, the relationship as
 * posts. That is the shape worth exporting.
 *
 * Where ACF is NOT installed but its data is still in the database — a site
 * that deactivated it, or a database handed over without the plugin — the raw
 * rows are reassembled here instead, from the same naming convention. Less
 * faithful, and much better than nothing.
 *
 * @package WPD_Export_All
 */

defined( 'ABSPATH' ) || exit;

class WPDEX_ACF {

	/**
	 * @return bool Whether ACF is active and usable.
	 */
	public static function active() {
		return function_exists( 'get_fields' ) && function_exists( 'get_field_objects' );
	}

	/**
	 * Every ACF value on one post.
	 *
	 * @param int  $post_id  Post.
	 * @param bool $formatted Whether to let ACF format values.
	 * @return array Field name => value.
	 */
	public static function values( $post_id, $formatted = true ) {
		if ( self::active() ) {
			return self::from_acf( $post_id, $formatted );
		}

		return self::from_meta( $post_id );
	}

	/**
	 * Ask ACF.
	 *
	 * @param int  $post_id   Post.
	 * @param bool $formatted Whether to let ACF format values.
	 * @return array
	 */
	private static function from_acf( $post_id, $formatted ) {
		/*
		 * Wrapped, because get_fields() runs every registered load_value filter
		 * — including ones from other plugins and from the theme's functions.php
		 * — and one of those throwing would otherwise take the whole export down
		 * on a single bad post. A post with unreadable fields is worth losing;
		 * the export is not.
		 */
		try {
			$fields = get_fields( $post_id, $formatted );
		} catch ( Throwable $e ) {
			return array( '_acf_error' => $e->getMessage() );
		}

		if ( ! is_array( $fields ) ) {
			return array();
		}

		return self::flatten_objects( $fields );
	}

	/**
	 * Turn ACF's rich return values into something a file can hold.
	 *
	 * ACF returns WP_Post objects for relationship and post-object fields,
	 * WP_Term for taxonomy fields, WP_User for user fields, and a large
	 * attachment array for images. Serialising those whole would put an entire
	 * post's content inside another post's cell.
	 *
	 * What is kept is the identity plus the one or two human-readable fields
	 * that make the identity checkable by eye — an id alone is correct and
	 * unreadable.
	 *
	 * @param mixed $value Anything ACF returned.
	 * @param int   $depth Recursion guard.
	 * @return mixed
	 */
	public static function flatten_objects( $value, $depth = 0 ) {
		// ACF fields can nest — a repeater inside a flexible layout inside a
		// group — but not forty deep. The guard is against a relationship field
		// pointing back at its own post, which is a real thing people build.
		if ( $depth > 10 ) {
			return null;
		}

		if ( is_array( $value ) ) {
			$out = array();

			foreach ( $value as $key => $one ) {
				$out[ $key ] = self::flatten_objects( $one, $depth + 1 );
			}

			return $out;
		}

		if ( $value instanceof WP_Post ) {
			return array(
				'id'    => $value->ID,
				'type'  => $value->post_type,
				'title' => $value->post_title,
				'url'   => get_permalink( $value ),
			);
		}

		if ( $value instanceof WP_Term ) {
			return array(
				'id'       => $value->term_id,
				'taxonomy' => $value->taxonomy,
				'name'     => $value->name,
				'slug'     => $value->slug,
			);
		}

		if ( $value instanceof WP_User ) {
			// Never the password hash, the session tokens or the capabilities
			// blob, all of which sit on the user object's data property.
			return array(
				'id'    => $value->ID,
				'login' => $value->user_login,
				'email' => $value->user_email,
				'name'  => $value->display_name,
			);
		}

		if ( is_object( $value ) ) {
			return method_exists( $value, '__toString' ) ? (string) $value : get_object_vars( $value );
		}

		return $value;
	}

	/**
	 * Reassemble ACF values from raw meta, for a site without ACF installed.
	 *
	 * @param int $post_id Post.
	 * @return array
	 */
	private static function from_meta( $post_id ) {
		$meta = get_post_meta( $post_id );

		if ( ! is_array( $meta ) ) {
			return array();
		}

		/*
		 * A row is ACF's if there is a matching underscored row holding a
		 * field key. That pairing is the whole signature — it is what
		 * distinguishes ACF's 'subtitle' from any other plugin's 'subtitle',
		 * and guessing by name alone would drag unrelated meta in.
		 */
		$owned = array();

		foreach ( $meta as $key => $values ) {
			if ( 0 !== strpos( $key, '_' ) ) {
				continue;
			}

			$pointer = is_array( $values ) ? reset( $values ) : $values;

			if ( is_string( $pointer ) && 0 === strpos( $pointer, 'field_' ) ) {
				$owned[ substr( $key, 1 ) ] = true;
			}
		}

		$flat = array();

		foreach ( $owned as $key => $unused ) {
			if ( isset( $meta[ $key ] ) ) {
				$raw = is_array( $meta[ $key ] ) ? reset( $meta[ $key ] ) : $meta[ $key ];

				$flat[ $key ] = maybe_unserialize( $raw );
			}
		}

		return self::nest( $flat );
	}

	/**
	 * Fold name_0_subname rows back into arrays.
	 *
	 * @param array $flat Field name => value.
	 * @return array
	 */
	private static function nest( array $flat ) {
		$out = array();

		// Longest keys first, so a repeater's rows are placed before the
		// parent count row is considered — otherwise the scalar "2" is written
		// first and then overwritten, or worse, blocks the array.
		uksort(
			$flat,
			static function ( $a, $b ) {
				return strlen( $b ) <=> strlen( $a );
			}
		);

		$rows = array();

		foreach ( $flat as $key => $value ) {
			if ( preg_match( '/^(.+?)_(\d+)_(.+)$/', $key, $m ) ) {
				$rows[ $m[1] ][ (int) $m[2] ][ $m[3] ] = $value;

				continue;
			}

			$out[ $key ] = $value;
		}

		foreach ( $rows as $parent => $items ) {
			ksort( $items );

			// The parent row holds the row count, which the reassembled array
			// makes redundant. Replacing it is what turns "gallery => 2" into
			// the actual gallery.
			$out[ $parent ] = array_values( $items );
		}

		ksort( $out );

		return $out;
	}

	/**
	 * Meta keys that ACF owns, so the plain meta exporter can leave them alone.
	 *
	 * Without this every ACF value appears twice in the output: once properly
	 * assembled in the acf column, and once as a raw postmeta row — plus a
	 * useless _fieldname column holding field_5f3a1c2b4d5e6.
	 *
	 * @param int $post_id Post.
	 * @return string[]
	 */
	public static function owned_meta_keys( $post_id ) {
		$meta = get_post_meta( $post_id );

		if ( ! is_array( $meta ) ) {
			return array();
		}

		$keys = array();

		foreach ( $meta as $key => $values ) {
			if ( 0 !== strpos( $key, '_' ) ) {
				continue;
			}

			$pointer = is_array( $values ) ? reset( $values ) : $values;

			if ( is_string( $pointer ) && 0 === strpos( $pointer, 'field_' ) ) {
				$keys[] = $key;
				$keys[] = substr( $key, 1 );
			}
		}

		return array_values( array_unique( $keys ) );
	}
}

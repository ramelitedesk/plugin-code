<?php
/**
 * Tools → Export All.
 *
 * @package WPD_Export_All
 */

defined( 'ABSPATH' ) || exit;

class WPDEX_Admin {

	const PAGE = 'wpd-export-all';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
	}

	public static function menu() {
		add_management_page(
			__( 'Export All', 'wpd-export-all' ),
			__( 'Export All', 'wpd-export-all' ),
			WPDEX_Job::CAP,
			self::PAGE,
			array( __CLASS__, 'render' )
		);
	}

	/**
	 * @param string $hook Current screen.
	 */
	public static function assets( $hook ) {
		if ( 'tools_page_' . self::PAGE !== $hook ) {
			return;
		}

		wp_enqueue_style( 'wpdex-admin', WPDEX_URL . 'assets/admin.css', array(), WPDEX_VERSION );
		wp_enqueue_script( 'wpdex-admin', WPDEX_URL . 'assets/admin.js', array(), WPDEX_VERSION, true );

		wp_localize_script(
			'wpdex-admin',
			'WPDEX',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'wpdex' ),
				'i18n'    => array(
					'starting'  => __( 'Starting…', 'wpd-export-all' ),
					'working'   => __( 'Exporting %s…', 'wpd-export-all' ),
					'done'      => __( 'Finished.', 'wpd-export-all' ),
					'failed'    => __( 'The export stopped: %s', 'wpd-export-all' ),
					'nothing'   => __( 'Tick at least one thing to export.', 'wpd-export-all' ),
					'confirm'   => __( 'Cancel this export and delete what has been written so far?', 'wpd-export-all' ),
					'leaving'   => __( 'An export is still running. Leaving now will stop it.', 'wpd-export-all' ),
				),
			)
		);
	}

	public static function render() {
		if ( ! current_user_can( WPDEX_Job::CAP ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'wpd-export-all' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$tab = ( isset( $_GET['tab'] ) && 'import' === $_GET['tab'] ) ? 'import' : 'export';

		$groups = WPDEX_Sources::all();
		$jobs   = WPDEX_Storage::all_jobs();

		if ( 'import' === $tab ) {
			require WPDEX_DIR . 'views/import.php';

			return;
		}

		require WPDEX_DIR . 'views/screen.php';
	}

	/**
	 * The tabs, printed by both views.
	 *
	 * @param string $current Active tab.
	 */
	public static function tabs( $current ) {
		$tabs = array(
			'export' => __( 'Export', 'wpd-export-all' ),
			'import' => __( 'Import', 'wpd-export-all' ),
		);

		echo '<h2 class="nav-tab-wrapper">';

		foreach ( $tabs as $key => $label ) {
			printf(
				'<a href="%1$s" class="nav-tab%2$s">%3$s</a>',
				esc_url( admin_url( 'tools.php?page=' . self::PAGE . ( 'export' === $key ? '' : '&tab=' . $key ) ) ),
				$current === $key ? ' nav-tab-active' : '',
				esc_html( $label )
			);
		}

		echo '</h2>';
	}

	/**
	 * Statuses worth offering as a filter, with their labels.
	 *
	 * @return array<string,string>
	 */
	public static function statuses() {
		$out = array();

		foreach ( get_post_stati( array(), 'objects' ) as $status ) {
			// auto-draft is a row somebody created by clicking "Add New" and
			// wandering off. Offering it as a filter offers nothing.
			if ( in_array( $status->name, array( 'auto-draft', 'inherit' ), true ) ) {
				continue;
			}

			$out[ $status->name ] = $status->label ? $status->label : $status->name;
		}

		return $out;
	}

	/**
	 * @param int $bytes Size.
	 * @return string
	 */
	public static function size( $bytes ) {
		return size_format( max( 0, (int) $bytes ), 1 );
	}
}

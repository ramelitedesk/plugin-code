<?php
/**
 * Exporting a taxonomy's terms — categories, tags, product attributes, anything.
 *
 * Terms are exported as their own file rather than only as a column on the
 * posts that use them. Both are wanted, and for different reasons: the column
 * tells you what a post is filed under, and this tells you the full tree,
 * including the descriptions, the parents, and the terms nothing is filed under
 * yet — none of which survives being flattened into a comma-separated cell.
 *
 * @package WPD_Export_All
 */

defined( 'ABSPATH' ) || exit;

class WPDEX_Terms {

	/**
	 * @param array $options Export options.
	 * @return string[]
	 */
	public static function columns( array $options ) {
		$columns = array(
			'term_id',
			'taxonomy',
			'name',
			'slug',
			'description',
			'parent_id',
			'parent_slug',
			// The full path, so a nested tree can be read and rebuilt without
			// resolving parent ids by hand.
			'hierarchy',
			'count',
			'url',
		);

		if ( ! empty( $options['meta'] ) ) {
			$columns[] = 'meta';
		}

		if ( ! empty( $options['acf'] ) && WPDEX_ACF::active() ) {
			// ACF fields can be attached to terms as well as posts, and a shop
			// with a banner image per category has all of it here.
			$columns[] = 'acf';
		}

		return $columns;
	}

	/**
	 * One batch of terms.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @param int    $offset   Where to resume.
	 * @param int    $limit    How many.
	 * @param array  $options  Export options.
	 * @return array[]
	 */
	public static function batch( $taxonomy, $offset, $limit, array $options ) {
		$terms = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
				'offset'     => $offset,
				'number'     => $limit,
				'orderby'    => 'term_id',
				'order'      => 'ASC',
			)
		);

		if ( is_wp_error( $terms ) || ! is_array( $terms ) ) {
			return array();
		}

		$rows = array();

		foreach ( $terms as $term ) {
			$rows[] = self::row( $term, $options );
		}

		return $rows;
	}

	/**
	 * @param WP_Term $term    Term.
	 * @param array   $options Export options.
	 * @return array
	 */
	public static function row( WP_Term $term, array $options ) {
		$parent = $term->parent ? get_term( $term->parent, $term->taxonomy ) : null;
		$link   = get_term_link( $term );

		$row = array(
			'term_id'     => (int) $term->term_id,
			'taxonomy'    => $term->taxonomy,
			'name'        => $term->name,
			'slug'        => $term->slug,
			'description' => $term->description,
			'parent_id'   => (int) $term->parent,
			'parent_slug' => ( $parent instanceof WP_Term ) ? $parent->slug : '',
			'hierarchy'   => self::path( $term ),
			'count'       => (int) $term->count,
			'url'         => is_wp_error( $link ) ? '' : $link,
		);

		if ( ! empty( $options['meta'] ) ) {
			$meta = array();

			foreach ( (array) get_term_meta( $term->term_id ) as $key => $values ) {
				if ( WPDEX_Posts::skip_meta_key( $key, $options ) ) {
					continue;
				}

				$decoded = array_map( 'maybe_unserialize', (array) $values );

				$meta[ $key ] = ( 1 === count( $decoded ) ) ? reset( $decoded ) : $decoded;
			}

			$row['meta'] = $meta;
		}

		if ( ! empty( $options['acf'] ) && WPDEX_ACF::active() ) {
			try {
				// ACF addresses a term as "term_123", not as a bare id — passing
				// the id alone reads the fields of the POST with that id, which
				// is a wrong answer rather than an empty one.
				$fields = get_fields( $term->taxonomy . '_' . $term->term_id );

				if ( ! is_array( $fields ) || ! $fields ) {
					$fields = get_fields( 'term_' . $term->term_id );
				}

				$row['acf'] = is_array( $fields ) ? WPDEX_ACF::flatten_objects( $fields ) : array();
			} catch ( Throwable $e ) {
				$row['acf'] = array();
			}
		}

		return $row;
	}

	/**
	 * A term's ancestors, as a readable path.
	 *
	 * @param WP_Term $term Term.
	 * @return string
	 */
	private static function path( WP_Term $term ) {
		if ( ! $term->parent ) {
			return $term->name;
		}

		$names     = array( $term->name );
		$ancestors = get_ancestors( $term->term_id, $term->taxonomy, 'taxonomy' );

		foreach ( $ancestors as $ancestor_id ) {
			$ancestor = get_term( $ancestor_id, $term->taxonomy );

			if ( $ancestor instanceof WP_Term ) {
				array_unshift( $names, $ancestor->name );
			}
		}

		return implode( ' > ', $names );
	}
}

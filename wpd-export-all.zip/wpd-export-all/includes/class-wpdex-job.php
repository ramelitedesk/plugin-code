<?php
/**
 * One export, run a batch at a time.
 *
 * The job holds a cursor — which source, how far into it — and each tick
 * processes a batch and moves the cursor on. The browser drives the ticks over
 * AJAX so the user gets a progress bar, and because a browser will happily make
 * forty sequential requests where one long one would have been killed by the
 * server at thirty seconds.
 *
 * @package WPD_Export_All
 */

defined( 'ABSPATH' ) || exit;

class WPDEX_Job {

	/** Where job records live. */
	const OPTION = 'wpdex_jobs';

	/** How many jobs are remembered before the oldest is dropped. */
	const KEEP = 20;

	/** The capability required to export, or to read an export. */
	const CAP = 'export';

	public static function init() {
		add_action( 'wp_ajax_wpdex_start', array( __CLASS__, 'ajax_start' ) );
		add_action( 'wp_ajax_wpdex_tick', array( __CLASS__, 'ajax_tick' ) );
		add_action( 'wp_ajax_wpdex_cancel', array( __CLASS__, 'ajax_cancel' ) );
		add_action( 'admin_post_wpdex_download', array( __CLASS__, 'download' ) );
		add_action( 'admin_post_wpdex_delete', array( __CLASS__, 'delete' ) );
	}

	/* ------------------------------------------------------------------ *
	 * Job records
	 * ------------------------------------------------------------------ */

	/**
	 * @param string $job_id Job.
	 * @return array|null
	 */
	public static function get( $job_id ) {
		if ( ! WPDEX_Storage::valid_id( $job_id ) ) {
			return null;
		}

		$jobs = get_option( self::OPTION, array() );

		return is_array( $jobs ) && isset( $jobs[ $job_id ] ) ? $jobs[ $job_id ] : null;
	}

	/**
	 * @param array $job Job record.
	 */
	public static function save( array $job ) {
		$jobs = get_option( self::OPTION, array() );

		if ( ! is_array( $jobs ) ) {
			$jobs = array();
		}

		$jobs[ $job['id'] ] = $job;

		if ( count( $jobs ) > self::KEEP ) {
			uasort(
				$jobs,
				static function ( $a, $b ) {
					return ( $b['started'] ?? 0 ) <=> ( $a['started'] ?? 0 );
				}
			);

			foreach ( array_slice( array_keys( $jobs ), self::KEEP ) as $old ) {
				WPDEX_Storage::delete( $old );

				unset( $jobs[ $old ] );
			}
		}

		// autoload off: this can hold twenty manifests and is read on one screen.
		update_option( self::OPTION, $jobs, false );
	}

	/**
	 * @param string $job_id Job.
	 */
	public static function forget( $job_id ) {
		$jobs = get_option( self::OPTION, array() );

		if ( is_array( $jobs ) && isset( $jobs[ $job_id ] ) ) {
			unset( $jobs[ $job_id ] );

			update_option( self::OPTION, $jobs, false );
		}
	}

	/* ------------------------------------------------------------------ *
	 * Starting
	 * ------------------------------------------------------------------ */

	/**
	 * Build a job from a selection.
	 *
	 * @param string[] $keys    Source keys.
	 * @param string   $format  csv|json.
	 * @param array    $options Export options.
	 * @return array|WP_Error
	 */
	public static function create( array $keys, $format, array $options, array $filters = array() ) {
		$keys = WPDEX_Sources::filter_valid( $keys );

		if ( ! $keys ) {
			return new WP_Error( 'wpdex_nothing', __( 'Nothing was selected to export.', 'wpd-export-all' ) );
		}

		$job_id = WPDEX_Storage::new_id();

		if ( '' === WPDEX_Storage::job_dir( $job_id ) ) {
			return new WP_Error( 'wpdex_no_dir', __( 'The uploads folder is not writable, so there is nowhere to put the export.', 'wpd-export-all' ) );
		}

		$steps = array();

		foreach ( $keys as $key ) {
			$source = WPDEX_Sources::get( $key );

			if ( ! $source ) {
				continue;
			}

			/*
			 * With a filter on, the expected count is a real query rather than
			 * wp_count_posts(). The progress bar reads against this, and an
			 * estimate of 4,000 for an export of 12 shows a bar that never
			 * moves and then jumps to done — which looks exactly like a
			 * failure.
			 */
			$expected = ( 'post_type' === $source['kind'] )
				? WPDEX_Filters::count_posts( $source['name'], $filters )
				: (int) $source['count'];

			$steps[] = array(
				'key'      => $key,
				'kind'     => $source['kind'],
				'name'     => $source['name'],
				'label'    => $source['label'],
				// What we believe is there, recorded now. Comparing it with
				// what actually got written is how a short export becomes
				// visible instead of being something you have to notice.
				'expected' => $expected,
				'written'  => 0,
				'offset'   => 0,
				'done'     => false,
				'file'     => '',
			);
		}

		$job = array(
			'id'      => $job_id,
			'format'  => ( 'json' === $format ) ? 'json' : 'csv',
			'options' => $options,
			'filters' => $filters,
			'steps'   => $steps,
			'step'    => 0,
			'status'  => 'running',
			'started' => time(),
			'finished' => 0,
			'site'    => home_url(),
			'notes'   => array(),
		);

		self::save( $job );

		return $job;
	}

	/* ------------------------------------------------------------------ *
	 * Running
	 * ------------------------------------------------------------------ */

	/**
	 * How many rows one tick processes.
	 *
	 * Posts carry meta, terms and ACF, so a batch of them is far more work than
	 * a batch of terms. The numbers are deliberately modest: a tick that takes
	 * two seconds and always finishes beats a tick that takes twenty and
	 * sometimes does not.
	 *
	 * @param string $kind Source kind.
	 * @return int
	 */
	public static function batch_size( $kind ) {
		$sizes = array(
			'post_type' => 100,
			'taxonomy'  => 400,
			'forms'     => 50,
			'leads'     => 200,
		);

		/**
		 * @param int    $size How many rows per tick.
		 * @param string $kind Source kind.
		 */
		return (int) apply_filters( 'wpdex_batch_size', $sizes[ $kind ] ?? 100, $kind );
	}

	/**
	 * Advance one job by one batch.
	 *
	 * @param string $job_id Job.
	 * @return array|WP_Error Progress.
	 */
	public static function tick( $job_id ) {
		$job = self::get( $job_id );

		if ( ! $job ) {
			return new WP_Error( 'wpdex_unknown', __( 'That export is no longer available.', 'wpd-export-all' ) );
		}

		if ( 'running' !== $job['status'] ) {
			return self::progress( $job );
		}

		$index = (int) $job['step'];

		if ( ! isset( $job['steps'][ $index ] ) ) {
			return self::finish( $job );
		}

		$step = $job['steps'][ $index ];

		$writer = self::writer_for( $job, $step );

		if ( ! $writer ) {
			$job['notes'][] = sprintf(
				/* translators: %s: source name. */
				__( 'Could not open a file for %s, so it was skipped.', 'wpd-export-all' ),
				$step['label']
			);

			$job['steps'][ $index ]['done'] = true;
			$job['step']                    = $index + 1;

			self::save( $job );

			return self::progress( $job );
		}

		if ( 0 === (int) $step['offset'] ) {
			$writer->open();
		}

		$limit = self::batch_size( $step['kind'] );
		$batch = self::read( $step, (int) $step['offset'], $limit, $job['options'], $job['filters'] ?? array() );

		$rows = $batch['rows'];

		$written = $writer->append( $rows, 0 === (int) $step['written'] );

		/*
		 * The cursor moves by rows CONSUMED, not by rows written.
		 *
		 * Leads come from custom tables that WP_Query cannot filter, so their
		 * date filter is applied in PHP after the read. If the cursor moved by
		 * the number of rows kept, every dropped row would be read again on the
		 * next tick — and a batch that filtered everything out would leave the
		 * cursor still and loop forever.
		 */
		$job['steps'][ $index ]['offset']  = (int) $step['offset'] + (int) $batch['consumed'];
		$job['steps'][ $index ]['written'] = (int) $step['written'] + $written;
		$job['steps'][ $index ]['file']    = basename( $writer->path() );

		/*
		 * A batch that comes back short of the limit is the end of the source.
		 * Counting against 'expected' instead would loop forever whenever the
		 * count and the reality disagree — which they do, constantly: a post
		 * gets deleted mid-export, wp_count_posts is cached, a query filter
		 * quietly excludes something.
		 */
		if ( (int) $batch['consumed'] < $limit ) {
			$writer->close();

			$job['steps'][ $index ]['done'] = true;
			$job['step']                    = $index + 1;
		}

		if ( ! isset( $job['steps'][ $job['step'] ] ) ) {
			return self::finish( $job );
		}

		self::save( $job );

		return self::progress( $job );
	}

	/**
	 * @param array $job  Job.
	 * @param array $step Step.
	 * @return WPDEX_Writer|null
	 */
	private static function writer_for( array $job, array $step ) {
		$path = WPDEX_Storage::file( $job['id'], $step['key'], $job['format'] );

		if ( '' === $path ) {
			return null;
		}

		$columns = array();

		if ( 'csv' === $job['format'] ) {
			$columns = self::columns( $step, $job['options'] );
		}

		return new WPDEX_Writer( $path, $job['format'], $columns );
	}

	/**
	 * @param array $step    Step.
	 * @param array $options Options.
	 * @return string[]
	 */
	public static function columns( array $step, array $options ) {
		switch ( $step['kind'] ) {
			case 'post_type':
				return WPDEX_Posts::columns( $step['name'], $options );

			case 'taxonomy':
				return WPDEX_Terms::columns( $options );

			case 'forms':
			case 'leads':
				return WPDEX_Forms::columns( $step['kind'] );
		}

		return array();
	}

	/**
	 * @param array $step    Step.
	 * @param int   $offset  Offset.
	 * @param int   $limit   Limit.
	 * @param array $options Options.
	 * @return array[]
	 */
	private static function read( array $step, $offset, $limit, array $options, array $filters = array() ) {
		switch ( $step['kind'] ) {
			case 'post_type':
				$rows = WPDEX_Posts::batch( $step['name'], $offset, $limit, $options, $filters );

				// WP_Query did the filtering, so everything read is kept.
				return array(
					'rows'     => $rows,
					'consumed' => count( $rows ),
				);

			case 'taxonomy':
				$rows = WPDEX_Terms::batch( $step['name'], $offset, $limit, $options );

				return array(
					'rows'     => $rows,
					'consumed' => count( $rows ),
				);

			case 'forms':
			case 'leads':
				// This one really can keep fewer than it read.
				return WPDEX_Forms::batch( $step['kind'], $step['name'], $offset, $limit, $filters );
		}

		return array(
			'rows'     => array(),
			'consumed' => 0,
		);
	}

	/**
	 * Close the job and write the manifest.
	 *
	 * @param array $job Job.
	 * @return array
	 */
	private static function finish( array $job ) {
		$job['status']   = 'done';
		$job['finished'] = time();

		$manifest = array(
			'plugin'    => 'WPD Export All ' . WPDEX_VERSION,
			'site'      => $job['site'],
			'exported'  => gmdate( 'c', $job['finished'] ),
			'format'    => $job['format'],
			'options'   => $job['options'],
			/*
			 * The filters go in the manifest as data AND as a sentence.
			 *
			 * Six months later somebody has a CSV with 412 rows in it and no
			 * memory of whether that is the whole catalogue or one month of it.
			 * The manifest is the only thing that can answer, so it says both
			 * exactly what was asked for and what that meant.
			 */
			'filters'   => $job['filters'] ?? array(),
			'filtered'  => WPDEX_Filters::describe( $job['filters'] ?? array() ),
			'wordpress' => get_bloginfo( 'version' ),
			'php'       => PHP_VERSION,
			'sources'   => array(),
			'notes'     => $job['notes'],
		);

		foreach ( $job['steps'] as $step ) {
			$row = array(
				'source'   => $step['key'],
				'label'    => $step['label'],
				'file'     => $step['file'],
				'expected' => (int) $step['expected'],
				'written'  => (int) $step['written'],
			);

			/*
			 * Stated in the manifest rather than left to be noticed. "Expected
			 * 812, wrote 806" is the single most useful line in an export
			 * nobody has checked yet, and an exporter that quietly hands over
			 * 806 rows is how a migration loses six products.
			 */
			if ( $row['expected'] !== $row['written'] ) {
				$row['note'] = __( 'Count differs from the estimate. Drafts, deletions during the export, or a plugin filtering the query can all explain a small difference.', 'wpd-export-all' );
			}

			$manifest['sources'][] = $row;
		}

		$path = WPDEX_Storage::file( $job['id'], 'manifest', 'json' );

		if ( '' !== $path ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			file_put_contents( $path, wp_json_encode( $manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) );
		}

		$job['manifest'] = $manifest;

		self::save( $job );

		return self::progress( $job );
	}

	/**
	 * @param array $job Job.
	 * @return array
	 */
	public static function progress( array $job ) {
		$expected = 0;
		$written  = 0;

		foreach ( $job['steps'] as $step ) {
			$expected += max( (int) $step['expected'], (int) $step['written'] );
			$written  += (int) $step['written'];
		}

		$current = $job['steps'][ $job['step'] ] ?? null;

		return array(
			'id'       => $job['id'],
			'status'   => $job['status'],
			'percent'  => $expected > 0 ? min( 100, (int) round( ( $written / $expected ) * 100 ) ) : ( 'done' === $job['status'] ? 100 : 0 ),
			'written'  => $written,
			'expected' => $expected,
			'current'  => $current ? $current['label'] : '',
			'steps'    => array_map(
				static function ( $step ) {
					return array(
						'label'    => $step['label'],
						'written'  => (int) $step['written'],
						'expected' => (int) $step['expected'],
						'done'     => (bool) $step['done'],
					);
				},
				$job['steps']
			),
			'notes'    => $job['notes'],
		);
	}

	/* ------------------------------------------------------------------ *
	 * AJAX
	 * ------------------------------------------------------------------ */

	/**
	 * Every endpoint below writes files containing the whole site, so each one
	 * checks the capability AND the nonce. Neither alone is enough: the nonce
	 * stops a request being made on an admin's behalf from elsewhere, and the
	 * capability stops a logged-in subscriber calling it directly.
	 */
	private static function guard() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to export.', 'wpd-export-all' ) ), 403 );
		}

		check_ajax_referer( 'wpdex', 'nonce' );
	}

	public static function ajax_start() {
		self::guard();

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- checked in guard().
		$keys   = isset( $_POST['sources'] ) ? array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['sources'] ) ) : array();
		$format = isset( $_POST['format'] ) ? sanitize_key( wp_unslash( $_POST['format'] ) ) : 'csv';

		$options = array(
			'content'        => ! empty( $_POST['opt_content'] ),
			'meta'           => ! empty( $_POST['opt_meta'] ),
			'acf'            => ! empty( $_POST['opt_acf'] ),
			'taxonomies'     => ! empty( $_POST['opt_taxonomies'] ),
			'skip_protected_meta' => ! empty( $_POST['opt_protected_meta'] ),
		);
		// phpcs:enable

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked in guard().
		$filters = ( isset( $_POST['filters'] ) && is_array( $_POST['filters'] ) )
			? WPDEX_Filters::sanitize( wp_unslash( $_POST['filters'] ) ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing
			: array();

		$job = self::create( $keys, $format, $options, $filters );

		if ( is_wp_error( $job ) ) {
			wp_send_json_error( array( 'message' => $job->get_error_message() ), 400 );
		}

		wp_send_json_success( self::progress( $job ) );
	}

	public static function ajax_tick() {
		self::guard();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked in guard().
		$job_id = isset( $_POST['job'] ) ? sanitize_text_field( wp_unslash( $_POST['job'] ) ) : '';

		$progress = self::tick( $job_id );

		if ( is_wp_error( $progress ) ) {
			wp_send_json_error( array( 'message' => $progress->get_error_message() ), 400 );
		}

		wp_send_json_success( $progress );
	}

	public static function ajax_cancel() {
		self::guard();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked in guard().
		$job_id = isset( $_POST['job'] ) ? sanitize_text_field( wp_unslash( $_POST['job'] ) ) : '';

		if ( WPDEX_Storage::valid_id( $job_id ) ) {
			WPDEX_Storage::delete( $job_id );

			self::forget( $job_id );
		}

		wp_send_json_success();
	}

	/* ------------------------------------------------------------------ *
	 * Download and delete
	 * ------------------------------------------------------------------ */

	/**
	 * Hand one file to the browser.
	 *
	 * Never a direct link into uploads. The file is the entire site, and a
	 * direct link is a URL that leaks into browser history, into a proxy log,
	 * and into whoever the admin last shared their screen with.
	 */
	public static function download() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'You do not have permission to download exports.', 'wpd-export-all' ), '', array( 'response' => 403 ) );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$job_id = isset( $_GET['job'] ) ? sanitize_text_field( wp_unslash( $_GET['job'] ) ) : '';
		$file   = isset( $_GET['file'] ) ? sanitize_file_name( wp_unslash( $_GET['file'] ) ) : '';
		// phpcs:enable

		check_admin_referer( 'wpdex_download_' . $job_id );

		$dir = WPDEX_Storage::job_dir( $job_id );

		if ( '' === $dir || '' === $file ) {
			wp_die( esc_html__( 'That export could not be found.', 'wpd-export-all' ), '', array( 'response' => 404 ) );
		}

		$path = $dir . $file;

		/*
		 * realpath() on both sides, then a prefix check.
		 *
		 * sanitize_file_name() already removes slashes, so this is the second
		 * lock rather than the first — but a download endpoint is exactly the
		 * place to have two. If either path cannot be resolved, or the resolved
		 * file is not inside the resolved job folder, nothing is sent.
		 */
		$real_path = realpath( $path );
		$real_dir  = realpath( $dir );

		if ( ! $real_path || ! $real_dir || 0 !== strpos( $real_path, $real_dir ) || ! is_file( $real_path ) ) {
			wp_die( esc_html__( 'That export could not be found.', 'wpd-export-all' ), '', array( 'response' => 404 ) );
		}

		nocache_headers();

		header( 'Content-Type: application/octet-stream' );
		header( 'Content-Disposition: attachment; filename="' . basename( $real_path ) . '"' );
		header( 'Content-Length: ' . filesize( $real_path ) );
		header( 'X-Content-Type-Options: nosniff' );

		// Any buffering still open would be prepended to the file and corrupt
		// it — a stray newline from a theme is enough to break a CSV.
		while ( ob_get_level() ) {
			ob_end_clean();
		}

		readfile( $real_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile

		exit;
	}

	public static function delete() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'wpd-export-all' ), '', array( 'response' => 403 ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$job_id = isset( $_GET['job'] ) ? sanitize_text_field( wp_unslash( $_GET['job'] ) ) : '';

		check_admin_referer( 'wpdex_delete_' . $job_id );

		if ( WPDEX_Storage::valid_id( $job_id ) ) {
			WPDEX_Storage::delete( $job_id );

			self::forget( $job_id );
		}

		wp_safe_redirect( admin_url( 'tools.php?page=wpd-export-all&deleted=1' ) );

		exit;
	}
}

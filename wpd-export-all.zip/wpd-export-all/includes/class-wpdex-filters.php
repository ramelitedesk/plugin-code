<?php
/**
 * Narrowing an export down to the rows you actually want.
 *
 * "Export everything" is the common case and the reason this plugin exists, but
 * it is not the only one. "The orders from last month", "the products added
 * since we imported the new catalogue", "everything this one author wrote" —
 * those are the exports somebody actually needs on a Tuesday afternoon, and
 * making them means exporting the lot and then deleting rows in a spreadsheet.
 *
 * ONE THING TO BE CAREFUL OF, and it is the reason the count is recomputed
 * rather than reused: a filtered export has a different total from an
 * unfiltered one. The progress bar reads against wp_count_posts() by default,
 * which counts everything. Left alone, a filter that matches 12 of 4,000 posts
 * shows a bar that reaches 0% and then jumps to done — or worse, one that says
 * "12 of 4000" and looks like it failed.
 *
 * @package WPD_Export_All
 */

defined( 'ABSPATH' ) || exit;

class WPDEX_Filters {

	/**
	 * A filter set with nothing switched on.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			// Which date field the range applies to: created | modified.
			'date_field'  => 'created',

			/*
			 * A named span, or 'custom' to use from/to, or '' for no date
			 * filter at all.
			 *
			 * The named spans exist because "last 30 days" typed as two dates
			 * is wrong the next morning, and an export people run monthly
			 * should not need its dates editing every time.
			 */
			'date_range'  => '',

			'date_from'   => '',
			'date_to'     => '',

			// A specific month, as YYYY-MM. Independent of the range above.
			'month'       => '',

			// Days of the week, 0 = Sunday. Empty means any.
			'weekdays'    => array(),

			// Hours of the day, 0-23. Empty means any.
			'hours'       => array(),

			'statuses'    => array(),
			'authors'     => array(),

			// taxonomy => term ids.
			'terms'       => array(),

			'search'      => '',

			// Only rows with an ID at or above / below these.
			'id_from'     => 0,
			'id_to'       => 0,

			// Stop after this many rows per source. 0 means no cap.
			'limit'       => 0,

			/* ---------------- WooCommerce ---------------- */

			'price_min'   => '',
			'price_max'   => '',
			'stock'       => array(),
			'on_sale'     => 0,
			'product_type' => array(),

			// Order statuses, for shop_order exports.
			'order_status' => array(),
		);
	}

	/**
	 * The named date spans on offer.
	 *
	 * @return array<string,string>
	 */
	public static function ranges() {
		return array(
			''             => __( 'Any date', 'wpd-export-all' ),
			'today'        => __( 'Today', 'wpd-export-all' ),
			'yesterday'    => __( 'Yesterday', 'wpd-export-all' ),
			'last_7'       => __( 'Last 7 days', 'wpd-export-all' ),
			'last_30'      => __( 'Last 30 days', 'wpd-export-all' ),
			'last_90'      => __( 'Last 90 days', 'wpd-export-all' ),
			'this_week'    => __( 'This week', 'wpd-export-all' ),
			'last_week'    => __( 'Last week', 'wpd-export-all' ),
			'this_month'   => __( 'This month', 'wpd-export-all' ),
			'last_month'   => __( 'Last month', 'wpd-export-all' ),
			'this_quarter' => __( 'This quarter', 'wpd-export-all' ),
			'this_year'    => __( 'This year', 'wpd-export-all' ),
			'last_year'    => __( 'Last year', 'wpd-export-all' ),
			'custom'       => __( 'Between two dates…', 'wpd-export-all' ),
		);
	}

	/**
	 * Clean a submitted filter set.
	 *
	 * @param array $raw Untrusted.
	 * @return array
	 */
	public static function sanitize( array $raw ) {
		$clean = self::defaults();

		$clean['date_field'] = ( 'modified' === ( $raw['date_field'] ?? '' ) ) ? 'modified' : 'created';

		$range = (string) ( $raw['date_range'] ?? '' );

		$clean['date_range'] = array_key_exists( $range, self::ranges() ) ? $range : '';

		foreach ( array( 'date_from', 'date_to' ) as $bound ) {
			$value = trim( (string) ( $raw[ $bound ] ?? '' ) );

			$clean[ $bound ] = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ? $value : '';
		}

		/*
		 * From and to the wrong way round is swapped rather than rejected.
		 * Somebody who types them backwards means the span between them, and
		 * returning nothing would look like the filter matching nothing.
		 */
		if ( '' !== $clean['date_from'] && '' !== $clean['date_to'] && $clean['date_from'] > $clean['date_to'] ) {
			list( $clean['date_from'], $clean['date_to'] ) = array( $clean['date_to'], $clean['date_from'] );
		}

		$month = trim( (string) ( $raw['month'] ?? '' ) );

		$clean['month'] = preg_match( '/^\d{4}-(0[1-9]|1[0-2])$/', $month ) ? $month : '';

		$clean['weekdays'] = self::ints( $raw['weekdays'] ?? array(), 0, 6 );
		$clean['hours']    = self::ints( $raw['hours'] ?? array(), 0, 23 );

		foreach ( (array) ( $raw['statuses'] ?? array() ) as $status ) {
			$status = sanitize_key( $status );

			if ( '' !== $status ) {
				$clean['statuses'][] = $status;
			}
		}

		$clean['statuses'] = array_values( array_unique( $clean['statuses'] ) );
		$clean['authors']  = self::ids( $raw['authors'] ?? array() );

		if ( ! empty( $raw['terms'] ) && is_array( $raw['terms'] ) ) {
			foreach ( $raw['terms'] as $taxonomy => $ids ) {
				$taxonomy = sanitize_key( $taxonomy );

				if ( '' === $taxonomy || ! taxonomy_exists( $taxonomy ) ) {
					continue;
				}

				$ids = self::ids( $ids );

				if ( $ids ) {
					$clean['terms'][ $taxonomy ] = $ids;
				}
			}
		}

		$clean['search'] = sanitize_text_field( $raw['search'] ?? '' );

		$clean['id_from'] = absint( $raw['id_from'] ?? 0 );
		$clean['id_to']   = absint( $raw['id_to'] ?? 0 );

		if ( $clean['id_from'] && $clean['id_to'] && $clean['id_from'] > $clean['id_to'] ) {
			list( $clean['id_from'], $clean['id_to'] ) = array( $clean['id_to'], $clean['id_from'] );
		}

		// Capped, because the cap exists to make an export smaller and a
		// limit of two billion is not a smaller export.
		$clean['limit'] = min( 1000000, absint( $raw['limit'] ?? 0 ) );

		/* ---------------- WooCommerce ---------------- */

		foreach ( array( 'price_min', 'price_max' ) as $bound ) {
			$value = trim( (string) ( $raw[ $bound ] ?? '' ) );

			$clean[ $bound ] = ( '' !== $value && is_numeric( $value ) && (float) $value >= 0 ) ? (string) (float) $value : '';
		}

		if ( '' !== $clean['price_min'] && '' !== $clean['price_max'] && (float) $clean['price_min'] > (float) $clean['price_max'] ) {
			list( $clean['price_min'], $clean['price_max'] ) = array( $clean['price_max'], $clean['price_min'] );
		}

		foreach ( array( 'stock', 'product_type', 'order_status' ) as $list ) {
			foreach ( (array) ( $raw[ $list ] ?? array() ) as $value ) {
				$value = sanitize_key( $value );

				if ( '' !== $value ) {
					$clean[ $list ][] = $value;
				}
			}

			$clean[ $list ] = array_values( array_unique( $clean[ $list ] ) );
		}

		$clean['on_sale'] = empty( $raw['on_sale'] ) ? 0 : 1;

		return $clean;
	}

	/**
	 * Is anything actually switched on?
	 *
	 * @param array $filters Filters.
	 * @return bool
	 */
	public static function active( array $filters ) {
		$defaults = self::defaults();

		foreach ( $defaults as $key => $default ) {
			if ( ( $filters[ $key ] ?? $default ) !== $default ) {
				return true;
			}
		}

		return false;
	}

	/* ------------------------------------------------------------------ *
	 * Turning a filter set into query arguments
	 * ------------------------------------------------------------------ */

	/**
	 * @param array  $filters Filters.
	 * @param string $type    Post type being exported.
	 * @return array WP_Query arguments to merge in.
	 */
	public static function to_query_args( array $filters, $type ) {
		$filters = array_merge( self::defaults(), $filters );

		$args = array();

		/* ---------------- dates ---------------- */

		$date_query = self::date_query( $filters );

		if ( $date_query ) {
			$args['date_query'] = $date_query;
		}

		/* ---------------- status ---------------- */

		if ( $filters['statuses'] ) {
			$args['post_status'] = $filters['statuses'];
		}

		/*
		 * An order's status is a post status prefixed with wc-, which is not
		 * something anybody should have to know to use a filter. The UI offers
		 * the names WooCommerce shows and they are translated here.
		 */
		if ( 'shop_order' === $type && $filters['order_status'] ) {
			$statuses = array();

			foreach ( $filters['order_status'] as $status ) {
				$statuses[] = ( 0 === strpos( $status, 'wc-' ) ) ? $status : 'wc-' . $status;
			}

			$args['post_status'] = $statuses;
		}

		/* ---------------- author ---------------- */

		if ( $filters['authors'] ) {
			$args['author__in'] = $filters['authors'];
		}

		/* ---------------- taxonomies ---------------- */

		$tax_query = array();

		foreach ( $filters['terms'] as $taxonomy => $ids ) {
			// Only taxonomies this post type actually has. A category filter
			// left over from a posts export would otherwise match no products
			// and look like the export is broken.
			if ( ! in_array( $taxonomy, get_object_taxonomies( $type ), true ) ) {
				continue;
			}

			$tax_query[] = array(
				'taxonomy' => $taxonomy,
				'field'    => 'term_id',
				'terms'    => $ids,
				'operator' => 'IN',
			);
		}

		if ( $tax_query ) {
			$args['tax_query'] = count( $tax_query ) > 1
				? array_merge( array( 'relation' => 'AND' ), $tax_query )
				: $tax_query;
		}

		/* ---------------- search ---------------- */

		if ( '' !== $filters['search'] ) {
			$args['s'] = $filters['search'];
		}

		/* ---------------- WooCommerce ---------------- */

		$meta_query = array();

		if ( in_array( $type, array( 'product', 'product_variation' ), true ) ) {
			if ( '' !== $filters['price_min'] || '' !== $filters['price_max'] ) {
				$meta_query[] = array(
					'key'     => '_price',
					'value'   => array(
						'' !== $filters['price_min'] ? (float) $filters['price_min'] : 0,
						'' !== $filters['price_max'] ? (float) $filters['price_max'] : PHP_INT_MAX,
					),
					'type'    => 'DECIMAL(20,4)',
					'compare' => 'BETWEEN',
				);
			}

			if ( $filters['stock'] ) {
				$meta_query[] = array(
					'key'     => '_stock_status',
					'value'   => $filters['stock'],
					'compare' => 'IN',
				);
			}

			if ( $filters['product_type'] ) {
				$args['tax_query'] = array_merge(
					isset( $args['tax_query'] ) ? array_filter( $args['tax_query'], 'is_array' ) : array(),
					array(
						array(
							'taxonomy' => 'product_type',
							'field'    => 'slug',
							'terms'    => $filters['product_type'],
						),
					)
				);
			}

			if ( $filters['on_sale'] && function_exists( 'wc_get_product_ids_on_sale' ) ) {
				$ids = wc_get_product_ids_on_sale();

				/*
				 * An empty sale list must become an impossible id, not an empty
				 * post__in — WP_Query reads an empty post__in as "no
				 * restriction" and would export the entire catalogue, which is
				 * the exact opposite of what was asked.
				 */
				$args['post__in'] = $ids ? array_map( 'absint', $ids ) : array( 0 );
			}
		}

		if ( $meta_query ) {
			$args['meta_query'] = count( $meta_query ) > 1
				? array_merge( array( 'relation' => 'AND' ), $meta_query )
				: $meta_query;
		}

		return $args;
	}

	/**
	 * The date_query for a filter set.
	 *
	 * @param array $filters Filters.
	 * @return array
	 */
	public static function date_query( array $filters ) {
		$filters = array_merge( self::defaults(), $filters );

		$clause = array();

		// post_date or post_modified. Exporting "everything changed since the
		// migration" needs the second, and it is a different question from
		// "everything written since".
		$clause['column'] = ( 'modified' === $filters['date_field'] ) ? 'post_modified' : 'post_date';

		$span = self::resolve_range( $filters );

		if ( $span['after'] ) {
			$clause['after']     = $span['after'];
			$clause['inclusive'] = true;
		}

		if ( $span['before'] ) {
			$clause['before']    = $span['before'];
			$clause['inclusive'] = true;
		}

		if ( '' !== $filters['month'] ) {
			list( $year, $month ) = explode( '-', $filters['month'] );

			$clause['year']  = (int) $year;
			$clause['month'] = (int) $month;
		}

		if ( $filters['weekdays'] ) {
			/*
			 * WP_Date_Query's dayofweek is 1 = Sunday through 7 = Saturday,
			 * while every other day-of-week value in WordPress and PHP is
			 * 0 = Sunday. The UI uses the familiar one and it is converted
			 * here — getting this wrong shifts every "weekends only" export by
			 * a day, which is the kind of thing nobody checks.
			 */
			$clause['dayofweek'] = array_map(
				static function ( $day ) {
					return $day + 1;
				},
				$filters['weekdays']
			);
		}

		if ( $filters['hours'] ) {
			$clause['hour'] = $filters['hours'];
		}

		// Only the column was set, so there is nothing to filter on.
		if ( 1 === count( $clause ) ) {
			return array();
		}

		return array( $clause );
	}

	/**
	 * Turn a named range into two dates.
	 *
	 * Worked out against the site's timezone, not the server's. An export of
	 * "today" run at 1am in a shop eight hours away is otherwise yesterday's.
	 *
	 * @param array    $filters Filters.
	 * @param int|null $now     Timestamp, for tests.
	 * @return array{after:string,before:string}
	 */
	public static function resolve_range( array $filters, $now = null ) {
		$now = ( null === $now ) ? (int) current_time( 'timestamp' ) : (int) $now;

		$today = wp_date( 'Y-m-d', $now );

		$out = array(
			'after'  => '',
			'before' => '',
		);

		switch ( $filters['date_range'] ?? '' ) {
			case 'today':
				$out['after']  = $today . ' 00:00:00';
				$out['before'] = $today . ' 23:59:59';
				break;

			case 'yesterday':
				$day           = wp_date( 'Y-m-d', $now - DAY_IN_SECONDS );
				$out['after']  = $day . ' 00:00:00';
				$out['before'] = $day . ' 23:59:59';
				break;

			case 'last_7':
				$out['after']  = wp_date( 'Y-m-d', $now - ( 6 * DAY_IN_SECONDS ) ) . ' 00:00:00';
				$out['before'] = $today . ' 23:59:59';
				break;

			case 'last_30':
				$out['after']  = wp_date( 'Y-m-d', $now - ( 29 * DAY_IN_SECONDS ) ) . ' 00:00:00';
				$out['before'] = $today . ' 23:59:59';
				break;

			case 'last_90':
				$out['after']  = wp_date( 'Y-m-d', $now - ( 89 * DAY_IN_SECONDS ) ) . ' 00:00:00';
				$out['before'] = $today . ' 23:59:59';
				break;

			case 'this_week':
				$out['after']  = wp_date( 'Y-m-d', self::week_start( $now ) ) . ' 00:00:00';
				$out['before'] = $today . ' 23:59:59';
				break;

			case 'last_week':
				$start         = self::week_start( $now ) - ( 7 * DAY_IN_SECONDS );
				$out['after']  = wp_date( 'Y-m-d', $start ) . ' 00:00:00';
				$out['before'] = wp_date( 'Y-m-d', $start + ( 6 * DAY_IN_SECONDS ) ) . ' 23:59:59';
				break;

			case 'this_month':
				$out['after']  = wp_date( 'Y-m-01', $now ) . ' 00:00:00';
				$out['before'] = $today . ' 23:59:59';
				break;

			case 'last_month':
				$first         = strtotime( wp_date( 'Y-m-01', $now ) );
				$last_month    = $first - DAY_IN_SECONDS;
				$out['after']  = wp_date( 'Y-m-01', $last_month ) . ' 00:00:00';
				$out['before'] = wp_date( 'Y-m-t', $last_month ) . ' 23:59:59';
				break;

			case 'this_quarter':
				$month         = (int) wp_date( 'n', $now );
				$first_month   = ( (int) floor( ( $month - 1 ) / 3 ) * 3 ) + 1;
				$out['after']  = sprintf( '%s-%02d-01 00:00:00', wp_date( 'Y', $now ), $first_month );
				$out['before'] = $today . ' 23:59:59';
				break;

			case 'this_year':
				$out['after']  = wp_date( 'Y-01-01', $now ) . ' 00:00:00';
				$out['before'] = $today . ' 23:59:59';
				break;

			case 'last_year':
				$year          = (int) wp_date( 'Y', $now ) - 1;
				$out['after']  = $year . '-01-01 00:00:00';
				$out['before'] = $year . '-12-31 23:59:59';
				break;

			case 'custom':
				if ( '' !== ( $filters['date_from'] ?? '' ) ) {
					$out['after'] = $filters['date_from'] . ' 00:00:00';
				}

				if ( '' !== ( $filters['date_to'] ?? '' ) ) {
					/*
					 * The "to" date includes the whole of that day. Somebody
					 * exporting 1st to 31st means the 31st, and treating it as
					 * midnight at its start drops a day off every export.
					 */
					$out['before'] = $filters['date_to'] . ' 23:59:59';
				}
				break;
		}

		return $out;
	}

	/**
	 * Midnight on the first day of the week containing this timestamp.
	 *
	 * @param int $now Timestamp.
	 * @return int
	 */
	private static function week_start( $now ) {
		$starts_on = (int) get_option( 'start_of_week', 1 );
		$weekday   = (int) wp_date( 'w', $now );

		$back = ( $weekday - $starts_on + 7 ) % 7;

		return strtotime( wp_date( 'Y-m-d', $now - ( $back * DAY_IN_SECONDS ) ) );
	}

	/* ------------------------------------------------------------------ *
	 * Counting, and non-post sources
	 * ------------------------------------------------------------------ */

	/**
	 * How many rows this filter set will actually produce for a post type.
	 *
	 * Run once when the job is created. It is a real query rather than an
	 * estimate, because the progress bar reads against it — an estimate from
	 * wp_count_posts() would say 4,000 for an export of 12 and look like a
	 * failure.
	 *
	 * @param string $type    Post type.
	 * @param array  $filters Filters.
	 * @return int
	 */
	public static function count_posts( $type, array $filters ) {
		if ( ! self::active( $filters ) ) {
			return WPDEX_Sources::count_posts( $type );
		}

		$args = array_merge(
			WPDEX_Posts::query_args( $type, $filters ),
			array(
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => false,
			)
		);

		$query = new WP_Query( $args );

		$found = (int) $query->found_posts;

		if ( ! empty( $filters['limit'] ) ) {
			$found = min( $found, (int) $filters['limit'] );
		}

		return $found;
	}

	/**
	 * Which filters mean anything for a source that is not a post type.
	 *
	 * Terms have no author, no status and no date — a taxonomy export is the
	 * same whatever the date filter says. Saying so on screen is better than
	 * letting somebody set a date range and wonder why their categories export
	 * is unchanged.
	 *
	 * @param string $kind Source kind.
	 * @return string[] Filter keys that apply.
	 */
	public static function supported_for( $kind ) {
		switch ( $kind ) {
			case 'post_type':
				return array_keys( self::defaults() );

			case 'leads':
				// Leads are dated, so the whole date block works. Nothing else
				// does.
				return array( 'date_field', 'date_range', 'date_from', 'date_to', 'month', 'weekdays', 'hours', 'limit' );

			case 'taxonomy':
			case 'forms':
			default:
				return array( 'limit' );
		}
	}

	/**
	 * Does a dated row fall inside the filter's span?
	 *
	 * Used for leads, which come from custom tables that WP_Query cannot reach,
	 * so their dates are compared in PHP instead.
	 *
	 * @param string $date    A date string from a row.
	 * @param array  $filters Filters.
	 * @return bool
	 */
	public static function date_passes( $date, array $filters ) {
		$filters = array_merge( self::defaults(), $filters );

		if ( '' === trim( (string) $date ) ) {
			// No date on the row. Kept rather than dropped: losing a lead
			// because its table stored an empty timestamp is worse than
			// including one that may be outside the span.
			return true;
		}

		$stamp = strtotime( $date );

		if ( ! $stamp ) {
			return true;
		}

		$span = self::resolve_range( $filters );

		if ( $span['after'] && $stamp < strtotime( $span['after'] ) ) {
			return false;
		}

		if ( $span['before'] && $stamp > strtotime( $span['before'] ) ) {
			return false;
		}

		if ( '' !== $filters['month'] && wp_date( 'Y-m', $stamp ) !== $filters['month'] ) {
			return false;
		}

		if ( $filters['weekdays'] && ! in_array( (int) wp_date( 'w', $stamp ), $filters['weekdays'], true ) ) {
			return false;
		}

		if ( $filters['hours'] && ! in_array( (int) wp_date( 'G', $stamp ), $filters['hours'], true ) ) {
			return false;
		}

		return true;
	}

	/* ------------------------------------------------------------------ *
	 * Helpers
	 * ------------------------------------------------------------------ */

	/**
	 * @param mixed $value Untrusted.
	 * @param int   $min   Lowest allowed.
	 * @param int   $max   Highest allowed.
	 * @return int[]
	 */
	private static function ints( $value, $min, $max ) {
		$out = array();

		foreach ( (array) $value as $one ) {
			$one = (int) $one;

			if ( $one >= $min && $one <= $max ) {
				$out[] = $one;
			}
		}

		sort( $out );

		return array_values( array_unique( $out ) );
	}

	/**
	 * @param mixed $value Untrusted.
	 * @return int[]
	 */
	private static function ids( $value ) {
		if ( is_string( $value ) ) {
			$value = explode( ',', $value );
		}

		$out = array();

		foreach ( (array) $value as $id ) {
			$id = absint( $id );

			if ( $id ) {
				$out[] = $id;
			}
		}

		return array_values( array_unique( $out ) );
	}

	/**
	 * A filter set written out for the manifest and the screen.
	 *
	 * @param array $filters Filters.
	 * @return string[]
	 */
	public static function describe( array $filters ) {
		$filters = array_merge( self::defaults(), $filters );

		$out    = array();
		$ranges = self::ranges();

		if ( '' !== $filters['date_range'] ) {
			$label = $ranges[ $filters['date_range'] ] ?? $filters['date_range'];

			if ( 'custom' === $filters['date_range'] ) {
				$label = trim( $filters['date_from'] . ' — ' . $filters['date_to'], ' —' );
			}

			$field = ( 'modified' === $filters['date_field'] )
				? __( 'modified', 'wpd-export-all' )
				: __( 'published', 'wpd-export-all' );

			$out[] = sprintf( '%s: %s', $field, $label );
		}

		if ( '' !== $filters['month'] ) {
			$out[] = $filters['month'];
		}

		if ( $filters['weekdays'] ) {
			$out[] = sprintf(
				/* translators: %d: how many days of the week. */
				_n( '%d weekday', '%d weekdays', count( $filters['weekdays'] ), 'wpd-export-all' ),
				count( $filters['weekdays'] )
			);
		}

		if ( $filters['statuses'] ) {
			$out[] = implode( ', ', $filters['statuses'] );
		}

		if ( $filters['authors'] ) {
			$out[] = sprintf(
				/* translators: %d: how many authors. */
				_n( '%d author', '%d authors', count( $filters['authors'] ), 'wpd-export-all' ),
				count( $filters['authors'] )
			);
		}

		foreach ( $filters['terms'] as $taxonomy => $ids ) {
			$out[] = $taxonomy . ' (' . count( $ids ) . ')';
		}

		if ( '' !== $filters['search'] ) {
			$out[] = sprintf( '"%s"', $filters['search'] );
		}

		if ( '' !== $filters['price_min'] || '' !== $filters['price_max'] ) {
			$out[] = trim( $filters['price_min'] . '–' . $filters['price_max'], '–' );
		}

		if ( $filters['stock'] ) {
			$out[] = implode( ', ', $filters['stock'] );
		}

		if ( $filters['on_sale'] ) {
			$out[] = __( 'on sale only', 'wpd-export-all' );
		}

		if ( $filters['limit'] ) {
			$out[] = sprintf(
				/* translators: %s: row cap. */
				__( 'first %s', 'wpd-export-all' ),
				number_format_i18n( $filters['limit'] )
			);
		}

		return $out;
	}
}

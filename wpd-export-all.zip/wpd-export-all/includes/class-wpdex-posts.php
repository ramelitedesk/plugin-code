<?php
/**
 * Exporting one post type: posts, pages, products, anything registered.
 *
 * @package WPD_Export_All
 */

defined( 'ABSPATH' ) || exit;

class WPDEX_Posts {

	/**
	 * The columns every post type has, before meta and taxonomies.
	 *
	 * @return string[]
	 */
	public static function base_columns() {
		return array(
			'id',
			'post_type',
			'status',
			'title',
			'slug',
			'url',
			'excerpt',
			'content',
			'parent_id',
			'menu_order',
			'author_id',
			'author_login',
			'author_name',
			'date',
			'date_gmt',
			'modified',
			'comment_status',
			'featured_image_id',
			'featured_image_url',
		);
	}

	/**
	 * Work out the full column list for a post type, in one pass.
	 *
	 * A CSV needs its header before the first row is written, and the columns
	 * depend on every row — post 1 may have a meta key post 2 does not. Sampling
	 * the first hundred posts and hoping is how an exporter silently drops a
	 * field that only appears on older content.
	 *
	 * So the meta keys are asked for directly. One indexed query over postmeta
	 * gives the exact set, however many posts there are.
	 *
	 * @param string $type    Post type.
	 * @param array  $options Export options.
	 * @return string[]
	 */
	public static function columns( $type, array $options ) {
		global $wpdb;

		$columns = self::base_columns();

		if ( ! empty( $options['taxonomies'] ) ) {
			foreach ( get_object_taxonomies( $type ) as $taxonomy ) {
				$columns[] = 'tax:' . $taxonomy;
			}
		}

		if ( WPDEX_Sources::woo() && 'product' === $type ) {
			$columns = array_merge( $columns, WPDEX_Posts::woo_columns() );
		}

		if ( empty( $options['meta'] ) ) {
			return $columns;
		}

		$keys = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT pm.meta_key
				   FROM {$wpdb->postmeta} pm
				   JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				  WHERE p.post_type = %s
				    AND p.post_status != 'auto-draft'
				  ORDER BY pm.meta_key
				  LIMIT 2000",
				$type
			)
		);

		$acf_names = array();

		foreach ( (array) $keys as $key ) {
			if ( self::skip_meta_key( $key, $options ) ) {
				continue;
			}

			/*
			 * ACF's rows are recognised here by name and handled by the ACF
			 * exporter instead, so they do not appear twice — once assembled
			 * and once as forty gallery_0_caption columns.
			 */
			if ( ! empty( $options['acf'] ) && self::looks_like_acf( $key, $keys ) ) {
				$acf_names[] = $key;

				continue;
			}

			$columns[] = 'meta:' . $key;
		}

		if ( ! empty( $options['acf'] ) && $acf_names ) {
			// One column holding the assembled fields, because a repeater has
			// no fixed number of columns and never will have.
			$columns[] = 'acf';
		}

		return array_values( array_unique( $columns ) );
	}

	/**
	 * @param string   $key      Meta key.
	 * @param string[] $all_keys Every key on this post type.
	 * @return bool
	 */
	private static function looks_like_acf( $key, $all_keys ) {
		if ( 0 === strpos( $key, '_' ) ) {
			// The pointer row itself. It holds field_5f3a…, which is of no use
			// to anybody reading the export.
			return in_array( substr( $key, 1 ), (array) $all_keys, true );
		}

		return in_array( '_' . $key, (array) $all_keys, true );
	}

	/**
	 * Meta nobody wants, and meta nobody should be handed.
	 *
	 * @param string $key     Meta key.
	 * @param array  $options Export options.
	 * @return bool
	 */
	public static function skip_meta_key( $key, array $options ) {
		$key = (string) $key;

		// Editor bookkeeping. _edit_lock is who had the post open at 3pm on a
		// Tuesday in 2019; it is not content.
		$noise = array( '_edit_lock', '_edit_last', '_wp_old_slug', '_wp_old_date', '_oembed_time', '_pingme', '_encloseme' );

		if ( in_array( $key, $noise, true ) ) {
			return true;
		}

		if ( 0 === strpos( $key, '_oembed_' ) ) {
			return true;
		}

		/*
		 * Anything that looks like a credential is never exported, whatever the
		 * options say.
		 *
		 * An export is a file that gets emailed, dropped in Slack and left in a
		 * Downloads folder. A plugin storing an API key in postmeta — and many
		 * do — should not have that key leave the site because somebody ticked
		 * "include meta". There is no option to turn this off, deliberately.
		 */
		foreach ( array( 'password', 'secret', 'api_key', 'apikey', 'token', 'private_key', 'auth_key', 'nonce_salt' ) as $dangerous ) {
			if ( false !== stripos( $key, $dangerous ) ) {
				return true;
			}
		}

		/*
		 * Underscored meta is "protected" and hidden from the editor, but a
		 * great deal of real data lives there — every WooCommerce price, SKU
		 * and stock level is _price, _sku, _stock. So the default is to INCLUDE
		 * it, and this branch only runs when somebody has deliberately ticked
		 * the box asking for a tidier file.
		 *
		 * The option is named for what ticking it DOES. It was once named
		 * 'protected_meta', which read as "include protected meta" in one place
		 * and "skip protected meta" in another; the condition ended up the
		 * wrong way round and every price, SKU and stock level was silently
		 * missing from the default export. That is the exact failure this
		 * plugin is written to avoid — a file that downloads, opens, looks
		 * complete, and is not.
		 */
		if ( ! empty( $options['skip_protected_meta'] ) && 0 === strpos( $key, '_' ) ) {
			return true;
		}

		return false;
	}

	/**
	 * WooCommerce columns worth naming rather than leaving as raw meta.
	 *
	 * @return string[]
	 */
	public static function woo_columns() {
		return array(
			'product_type',
			'sku',
			'regular_price',
			'sale_price',
			'stock_status',
			'stock_quantity',
			'attributes',
			'variation_ids',
			'gallery_image_urls',
		);
	}

	/**
	 * The query arguments for a post type, with any filters folded in.
	 *
	 * Shared by the batch reader and the counter on purpose. If the two built
	 * their arguments separately the progress bar would count one set of rows
	 * and the export would write another — and the manifest's "expected 812,
	 * wrote 40" would be reporting a bug in this plugin rather than in the data.
	 *
	 * @param string $type    Post type.
	 * @param array  $filters Filters.
	 * @return array
	 */
	public static function query_args( $type, array $filters = array() ) {
		$args = array(
			'post_type'           => $type,
			/*
			 * Every status a human would call content. 'inherit' is in there
			 * because that is what an attachment and a product variation use,
			 * and leaving it out silently exports no variations at all.
			 *
			 * Overridden by the status filter when one is set.
			 */
			'post_status'         => array( 'publish', 'draft', 'pending', 'private', 'future', 'inherit' ),
			'orderby'             => 'ID',
			'order'               => 'ASC',
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
			'suppress_filters'    => false,
		);

		if ( $filters ) {
			$args = array_merge( $args, WPDEX_Filters::to_query_args( $filters, $type ) );
		}

		return $args;
	}

	/**
	 * One batch of posts.
	 *
	 * @param string $type   Post type.
	 * @param int    $offset Where to resume.
	 * @param int    $limit  How many.
	 * @param array  $options Export options.
	 * @return array[] Rows.
	 */
	public static function batch( $type, $offset, $limit, array $options, array $filters = array() ) {
		/*
		 * A row cap has to be applied to the batch, not just to the count.
		 * Capping only the expected total would leave the cursor walking past
		 * it — the progress bar would say 100% and the file would keep growing.
		 */
		if ( ! empty( $filters['limit'] ) ) {
			$remaining = (int) $filters['limit'] - (int) $offset;

			if ( $remaining <= 0 ) {
				return array();
			}

			$limit = min( $limit, $remaining );
		}

		$args = array_merge(
			self::query_args( $type, $filters ),
			array(
				'posts_per_page'         => $limit,
				'offset'                 => $offset,
				/*
				 * Caches primed in one query each rather than one per post.
				 * Without this a batch of 200 posts is 400 extra queries, and
				 * the export takes longer than the timeout it was batched to
				 * avoid.
				 */
				'update_post_meta_cache' => true,
				'update_post_term_cache' => ! empty( $options['taxonomies'] ),
			)
		);

		$query = new WP_Query( $args );

		$rows = array();

		foreach ( $query->posts as $post ) {
			$rows[] = self::row( $post, $options );
		}

		wp_reset_postdata();

		return $rows;
	}

	/**
	 * One post, as a row.
	 *
	 * @param WP_Post $post    Post.
	 * @param array   $options Export options.
	 * @return array
	 */
	public static function row( WP_Post $post, array $options ) {
		$author = $post->post_author ? get_userdata( $post->post_author ) : null;
		$thumb  = get_post_thumbnail_id( $post );

		$row = array(
			'id'                 => (int) $post->ID,
			'post_type'          => $post->post_type,
			'status'             => $post->post_status,
			'title'              => $post->post_title,
			'slug'               => $post->post_name,
			'url'                => get_permalink( $post ),
			'excerpt'            => $post->post_excerpt,
			'content'            => empty( $options['content'] ) ? '' : $post->post_content,
			'parent_id'          => (int) $post->post_parent,
			'menu_order'         => (int) $post->menu_order,
			'author_id'          => (int) $post->post_author,
			'author_login'       => $author ? $author->user_login : '',
			'author_name'        => $author ? $author->display_name : '',
			'date'               => $post->post_date,
			'date_gmt'           => $post->post_date_gmt,
			'modified'           => $post->post_modified,
			'comment_status'     => $post->comment_status,
			'featured_image_id'  => $thumb ? (int) $thumb : '',
			'featured_image_url' => $thumb ? wp_get_attachment_url( $thumb ) : '',
		);

		if ( ! empty( $options['taxonomies'] ) ) {
			foreach ( get_object_taxonomies( $post->post_type ) as $taxonomy ) {
				$terms = get_the_terms( $post, $taxonomy );

				$row[ 'tax:' . $taxonomy ] = ( is_array( $terms ) && $terms )
					? implode( ', ', wp_list_pluck( $terms, 'name' ) )
					: '';
			}
		}

		if ( WPDEX_Sources::woo() && 'product' === $post->post_type ) {
			$row = array_merge( $row, self::woo_row( $post ) );
		}

		$acf_keys = array();

		if ( ! empty( $options['acf'] ) ) {
			$fields = WPDEX_ACF::values( $post->ID );

			if ( $fields ) {
				$row['acf'] = $fields;
			}

			$acf_keys = WPDEX_ACF::owned_meta_keys( $post->ID );
		}

		if ( ! empty( $options['meta'] ) ) {
			foreach ( (array) get_post_meta( $post->ID ) as $key => $values ) {
				if ( self::skip_meta_key( $key, $options ) || in_array( $key, $acf_keys, true ) ) {
					continue;
				}

				$decoded = array_map( 'maybe_unserialize', (array) $values );

				// A single-valued key is by far the common case, and wrapping
				// every one of them in a one-element array would make the whole
				// file harder to read for the sake of the rare repeated key.
				$row[ 'meta:' . $key ] = ( 1 === count( $decoded ) ) ? reset( $decoded ) : $decoded;
			}
		}

		return $row;
	}

	/**
	 * The product-shaped extras.
	 *
	 * Read through WooCommerce's own API rather than from meta, because a
	 * variable product's price is not in _price in any useful sense — it is
	 * derived from its variations, and reading the meta row gives whatever was
	 * last cached there.
	 *
	 * @param WP_Post $post Product.
	 * @return array
	 */
	private static function woo_row( WP_Post $post ) {
		$empty = array_fill_keys( self::woo_columns(), '' );

		if ( ! function_exists( 'wc_get_product' ) ) {
			return $empty;
		}

		try {
			$product = wc_get_product( $post->ID );
		} catch ( Throwable $e ) {
			return $empty;
		}

		if ( ! $product ) {
			return $empty;
		}

		$attributes = array();

		foreach ( $product->get_attributes() as $name => $attribute ) {
			if ( is_object( $attribute ) && method_exists( $attribute, 'get_options' ) ) {
				$options = $attribute->is_taxonomy()
					? wp_list_pluck( (array) $attribute->get_terms(), 'name' )
					: (array) $attribute->get_options();

				$attributes[ wc_attribute_label( $name ) ] = array_values( $options );
			}
		}

		$gallery = array();

		foreach ( (array) $product->get_gallery_image_ids() as $image_id ) {
			$url = wp_get_attachment_url( $image_id );

			if ( $url ) {
				$gallery[] = $url;
			}
		}

		return array(
			'product_type'       => $product->get_type(),
			'sku'                => $product->get_sku(),
			'regular_price'      => $product->get_regular_price(),
			'sale_price'         => $product->get_sale_price(),
			'stock_status'       => $product->get_stock_status(),
			'stock_quantity'     => $product->get_stock_quantity(),
			'attributes'         => $attributes,
			// Variations are separate posts of type product_variation. They are
			// listed here so a reader can follow them, and exported in full if
			// that post type was also ticked.
			'variation_ids'      => $product->is_type( 'variable' ) ? $product->get_children() : array(),
			'gallery_image_urls' => $gallery,
		);
	}
}

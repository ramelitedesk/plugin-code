<?php
/**
 * Form definitions and the leads people submitted through them.
 *
 * There is no shared way WordPress stores a form submission, so there is no
 * shared way to export one. Each plugin gets its own reader:
 *
 *   Contact Form 7   Forms are a post type. CF7 STORES NO LEADS AT ALL — it
 *                    mails them and forgets. Leads exist only if Flamingo is
 *                    installed, which is where they are read from.
 *   WPForms          Forms are a post type; entries live in a custom table that
 *                    only exists in the paid version. Lite users have forms and
 *                    no entries, and saying so is better than an empty file.
 *   Fluent Forms     Two custom tables, forms and submissions.
 *   Gravity Forms    Custom tables, read through its API because the entry
 *                    values are split across two of them.
 *   Elementor Pro    Two custom tables, submissions and their values.
 *
 * Every one is guarded on the plugin actually being present, and every custom
 * table is checked for existence before it is queried — a plugin can be active
 * with its tables missing after a partial restore, and a query against a table
 * that is not there is a fatal on the export screen.
 *
 * @package WPD_Export_All
 */

defined( 'ABSPATH' ) || exit;

class WPDEX_Forms {

	/**
	 * Which form sources this site can offer.
	 *
	 * @return array<string,array>
	 */
	public static function sources() {
		$out = array();

		/* ---------------- Contact Form 7 ---------------- */

		if ( defined( 'WPCF7_VERSION' ) || class_exists( 'WPCF7' ) ) {
			$out['forms:cf7'] = array(
				'kind'  => 'forms',
				'name'  => 'cf7',
				'label' => __( 'Contact Form 7 — forms', 'wpd-export-all' ),
				'count' => WPDEX_Sources::count_posts( 'wpcf7_contact_form' ),
			);

			if ( post_type_exists( 'flamingo_inbound' ) ) {
				$out['leads:cf7'] = array(
					'kind'  => 'leads',
					'name'  => 'cf7',
					'label' => __( 'Contact Form 7 leads (via Flamingo)', 'wpd-export-all' ),
					'count' => WPDEX_Sources::count_posts( 'flamingo_inbound' ),
				);
			}
		}

		/* ---------------- WPForms ---------------- */

		if ( function_exists( 'wpforms' ) || defined( 'WPFORMS_VERSION' ) ) {
			$out['forms:wpforms'] = array(
				'kind'  => 'forms',
				'name'  => 'wpforms',
				'label' => __( 'WPForms — forms', 'wpd-export-all' ),
				'count' => WPDEX_Sources::count_posts( 'wpforms' ),
			);

			if ( self::table_exists( 'wpforms_entries' ) ) {
				$out['leads:wpforms'] = array(
					'kind'  => 'leads',
					'name'  => 'wpforms',
					'label' => __( 'WPForms leads', 'wpd-export-all' ),
					'count' => self::count_table( 'wpforms_entries' ),
				);
			}
		}

		/* ---------------- Fluent Forms ---------------- */

		if ( defined( 'FLUENTFORM' ) && self::table_exists( 'fluentform_forms' ) ) {
			$out['forms:fluent'] = array(
				'kind'  => 'forms',
				'name'  => 'fluent',
				'label' => __( 'Fluent Forms — forms', 'wpd-export-all' ),
				'count' => self::count_table( 'fluentform_forms' ),
			);

			if ( self::table_exists( 'fluentform_submissions' ) ) {
				$out['leads:fluent'] = array(
					'kind'  => 'leads',
					'name'  => 'fluent',
					'label' => __( 'Fluent Forms leads', 'wpd-export-all' ),
					'count' => self::count_table( 'fluentform_submissions' ),
				);
			}
		}

		/* ---------------- Gravity Forms ---------------- */

		if ( class_exists( 'GFAPI' ) ) {
			$out['forms:gravity'] = array(
				'kind'  => 'forms',
				'name'  => 'gravity',
				'label' => __( 'Gravity Forms — forms', 'wpd-export-all' ),
				'count' => count( (array) GFAPI::get_forms() ),
			);

			$out['leads:gravity'] = array(
				'kind'  => 'leads',
				'name'  => 'gravity',
				'label' => __( 'Gravity Forms leads', 'wpd-export-all' ),
				'count' => self::gravity_entry_count(),
			);
		}

		/* ---------------- Elementor Pro ---------------- */

		if ( defined( 'ELEMENTOR_PRO_VERSION' ) && self::table_exists( 'e_submissions' ) ) {
			$out['leads:elementor'] = array(
				'kind'  => 'leads',
				'name'  => 'elementor',
				'label' => __( 'Elementor Pro form leads', 'wpd-export-all' ),
				'count' => self::count_table( 'e_submissions' ),
			);
		}

		return $out;
	}

	/**
	 * Does a table with this prefix-relative name exist?
	 *
	 * @param string $name Table name without the prefix.
	 * @return bool
	 */
	public static function table_exists( $name ) {
		global $wpdb;

		static $checked = array();

		if ( isset( $checked[ $name ] ) ) {
			return $checked[ $name ];
		}

		$table = $wpdb->prefix . preg_replace( '/[^a-z0-9_]/i', '', $name );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );

		$checked[ $name ] = ( $found === $table );

		return $checked[ $name ];
	}

	/**
	 * @param string $name Table name without the prefix.
	 * @return int
	 */
	private static function count_table( $name ) {
		global $wpdb;

		if ( ! self::table_exists( $name ) ) {
			return 0;
		}

		$table = $wpdb->prefix . preg_replace( '/[^a-z0-9_]/i', '', $name );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$table}`" );
	}

	/**
	 * @return int
	 */
	private static function gravity_entry_count() {
		if ( ! class_exists( 'GFAPI' ) ) {
			return 0;
		}

		$total = 0;

		foreach ( (array) GFAPI::get_forms() as $form ) {
			$count = GFAPI::count_entries( $form['id'] );

			$total += is_wp_error( $count ) ? 0 : (int) $count;
		}

		return $total;
	}

	/* ------------------------------------------------------------------ *
	 * Columns
	 * ------------------------------------------------------------------ */

	/**
	 * @param string $kind forms|leads.
	 * @return string[]
	 */
	public static function columns( $kind ) {
		if ( 'forms' === $kind ) {
			return array( 'id', 'title', 'status', 'created', 'fields', 'settings' );
		}

		return array( 'id', 'form_id', 'form_title', 'submitted', 'status', 'from_name', 'from_email', 'ip', 'fields' );
	}

	/* ------------------------------------------------------------------ *
	 * Reading
	 * ------------------------------------------------------------------ */

	/**
	 * One batch of forms or leads.
	 *
	 * @param string $kind   forms|leads.
	 * @param string $plugin cf7|wpforms|fluent|gravity|elementor.
	 * @param int    $offset Where to resume.
	 * @param int    $limit  How many.
	 * @return array[]
	 */
	public static function batch( $kind, $plugin, $offset, $limit, array $filters = array() ) {
		$empty = array(
			'rows'     => array(),
			'consumed' => 0,
		);

		$method = 'read_' . $plugin . '_' . $kind;

		if ( ! method_exists( __CLASS__, $method ) ) {
			return $empty;
		}

		try {
			$rows = (array) self::$method( $offset, $limit );
		} catch ( Throwable $e ) {
			/*
			 * One unreadable form plugin must not end the export. The other
			 * sources are still worth having, and the manifest records that
			 * this one came up short.
			 */
			return $empty;
		}

		$consumed = count( $rows );

		/*
		 * Leads live in custom tables that WP_Query cannot reach, so their date
		 * filter is applied here rather than in SQL. 'consumed' is reported
		 * separately from the rows kept so the cursor still moves over the ones
		 * dropped — otherwise a batch that filtered everything out would leave
		 * the cursor where it was and the export would never finish.
		 */
		if ( 'leads' === $kind && $filters && WPDEX_Filters::active( $filters ) ) {
			$kept = array();

			foreach ( $rows as $row ) {
				if ( WPDEX_Filters::date_passes( $row['submitted'] ?? '', $filters ) ) {
					$kept[] = $row;
				}
			}

			$rows = $kept;
		}

		return array(
			'rows'     => $rows,
			'consumed' => $consumed,
		);
	}

	/* ---------------- Contact Form 7 ---------------- */

	private static function read_cf7_forms( $offset, $limit ) {
		$rows = array();

		foreach ( self::posts( 'wpcf7_contact_form', $offset, $limit ) as $post ) {
			$rows[] = array(
				'id'       => (int) $post->ID,
				'title'    => $post->post_title,
				'status'   => $post->post_status,
				'created'  => $post->post_date,
				// CF7 keeps the form body, the mail templates and the messages
				// in separate meta rows rather than in post_content.
				'fields'   => get_post_meta( $post->ID, '_form', true ),
				'settings' => array(
					'mail'      => get_post_meta( $post->ID, '_mail', true ),
					'mail_2'    => get_post_meta( $post->ID, '_mail_2', true ),
					'messages'  => get_post_meta( $post->ID, '_messages', true ),
					'additional' => get_post_meta( $post->ID, '_additional_settings', true ),
				),
			);
		}

		return $rows;
	}

	private static function read_cf7_leads( $offset, $limit ) {
		$rows = array();

		foreach ( self::posts( 'flamingo_inbound', $offset, $limit ) as $post ) {
			$meta = get_post_meta( $post->ID );

			$fields = array();

			// Flamingo stores each submitted field as _field_<name>.
			foreach ( (array) $meta as $key => $values ) {
				if ( 0 === strpos( $key, '_field_' ) ) {
					$fields[ substr( $key, 7 ) ] = maybe_unserialize( reset( $values ) );
				}
			}

			$rows[] = array(
				'id'         => (int) $post->ID,
				'form_id'    => self::first_meta( $meta, '_channel_id' ),
				'form_title' => $post->post_title,
				'submitted'  => $post->post_date,
				'status'     => $post->post_status,
				'from_name'  => self::first_meta( $meta, '_from_name' ),
				'from_email' => self::first_meta( $meta, '_from_email' ),
				'ip'         => self::first_meta( $meta, '_meta_remote_ip' ),
				'fields'     => $fields,
			);
		}

		return $rows;
	}

	/* ---------------- WPForms ---------------- */

	private static function read_wpforms_forms( $offset, $limit ) {
		$rows = array();

		foreach ( self::posts( 'wpforms', $offset, $limit ) as $post ) {
			$config = json_decode( $post->post_content, true );

			$rows[] = array(
				'id'       => (int) $post->ID,
				'title'    => $post->post_title,
				'status'   => $post->post_status,
				'created'  => $post->post_date,
				'fields'   => is_array( $config ) ? ( $config['fields'] ?? array() ) : array(),
				'settings' => is_array( $config ) ? ( $config['settings'] ?? array() ) : array(),
			);
		}

		return $rows;
	}

	private static function read_wpforms_leads( $offset, $limit ) {
		global $wpdb;

		if ( ! self::table_exists( 'wpforms_entries' ) ) {
			return array();
		}

		$table = $wpdb->prefix . 'wpforms_entries';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
		$entries = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM `{$table}` ORDER BY entry_id ASC LIMIT %d OFFSET %d", $limit, $offset )
		);

		$rows = array();

		foreach ( (array) $entries as $entry ) {
			$fields = json_decode( $entry->fields ?? '', true );

			$rows[] = array(
				'id'         => (int) $entry->entry_id,
				'form_id'    => (int) $entry->form_id,
				'form_title' => get_the_title( $entry->form_id ),
				'submitted'  => $entry->date ?? '',
				'status'     => $entry->status ?? '',
				'from_name'  => '',
				'from_email' => $entry->user_uuid ?? '',
				'ip'         => $entry->ip_address ?? '',
				'fields'     => self::simplify_wpforms( $fields ),
			);
		}

		return $rows;
	}

	/**
	 * WPForms stores each field as an object with id, name, value and type.
	 * The label and the value are what anybody reading a lead wants.
	 *
	 * @param mixed $fields Decoded entry fields.
	 * @return array
	 */
	private static function simplify_wpforms( $fields ) {
		if ( ! is_array( $fields ) ) {
			return array();
		}

		$out = array();

		foreach ( $fields as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			$label = $field['name'] ?? ( 'field_' . ( $field['id'] ?? '' ) );

			$out[ $label ] = $field['value'] ?? '';
		}

		return $out;
	}

	/* ---------------- Fluent Forms ---------------- */

	private static function read_fluent_forms( $offset, $limit ) {
		global $wpdb;

		$table = $wpdb->prefix . 'fluentform_forms';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
		$forms = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM `{$table}` ORDER BY id ASC LIMIT %d OFFSET %d", $limit, $offset )
		);

		$rows = array();

		foreach ( (array) $forms as $form ) {
			$rows[] = array(
				'id'       => (int) $form->id,
				'title'    => $form->title ?? '',
				'status'   => $form->status ?? '',
				'created'  => $form->created_at ?? '',
				'fields'   => json_decode( $form->form_fields ?? '', true ),
				'settings' => array( 'type' => $form->type ?? '' ),
			);
		}

		return $rows;
	}

	private static function read_fluent_leads( $offset, $limit ) {
		global $wpdb;

		$table = $wpdb->prefix . 'fluentform_submissions';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
		$entries = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM `{$table}` ORDER BY id ASC LIMIT %d OFFSET %d", $limit, $offset )
		);

		$rows = array();

		foreach ( (array) $entries as $entry ) {
			$rows[] = array(
				'id'         => (int) $entry->id,
				'form_id'    => (int) ( $entry->form_id ?? 0 ),
				'form_title' => '',
				'submitted'  => $entry->created_at ?? '',
				'status'     => $entry->status ?? '',
				'from_name'  => '',
				'from_email' => '',
				'ip'         => $entry->ip ?? '',
				'fields'     => json_decode( $entry->response ?? '', true ),
			);
		}

		return $rows;
	}

	/* ---------------- Gravity Forms ---------------- */

	private static function read_gravity_forms( $offset, $limit ) {
		$forms = array_slice( (array) GFAPI::get_forms(), $offset, $limit );

		$rows = array();

		foreach ( $forms as $form ) {
			$rows[] = array(
				'id'       => (int) $form['id'],
				'title'    => $form['title'] ?? '',
				'status'   => empty( $form['is_active'] ) ? 'inactive' : 'active',
				'created'  => $form['date_created'] ?? '',
				'fields'   => $form['fields'] ?? array(),
				'settings' => array(
					'confirmations' => $form['confirmations'] ?? array(),
					'notifications' => $form['notifications'] ?? array(),
				),
			);
		}

		return $rows;
	}

	private static function read_gravity_leads( $offset, $limit ) {
		$entries = GFAPI::get_entries( 0, array(), null, array( 'offset' => $offset, 'page_size' => $limit ) );

		if ( is_wp_error( $entries ) ) {
			return array();
		}

		$rows = array();

		foreach ( (array) $entries as $entry ) {
			$form = GFAPI::get_form( $entry['form_id'] ?? 0 );

			/*
			 * Gravity keys entry values by field id — "1", "2.3" — which is
			 * meaningless in an export. The form definition is what turns those
			 * back into the labels the person filling the form actually saw.
			 */
			$fields = array();

			if ( is_array( $form ) && ! empty( $form['fields'] ) ) {
				foreach ( $form['fields'] as $field ) {
					$id    = $field['id'] ?? null;
					$label = $field['label'] ?? ( 'field_' . $id );

					if ( null === $id ) {
						continue;
					}

					if ( isset( $entry[ (string) $id ] ) ) {
						$fields[ $label ] = $entry[ (string) $id ];

						continue;
					}

					// Composite fields (name, address) store their parts as
					// 1.3, 1.6 and so on.
					$parts = array();

					foreach ( $entry as $key => $value ) {
						if ( 0 === strpos( (string) $key, $id . '.' ) && '' !== $value ) {
							$parts[] = $value;
						}
					}

					if ( $parts ) {
						$fields[ $label ] = implode( ' ', $parts );
					}
				}
			}

			$rows[] = array(
				'id'         => (int) ( $entry['id'] ?? 0 ),
				'form_id'    => (int) ( $entry['form_id'] ?? 0 ),
				'form_title' => is_array( $form ) ? ( $form['title'] ?? '' ) : '',
				'submitted'  => $entry['date_created'] ?? '',
				'status'     => $entry['status'] ?? '',
				'from_name'  => '',
				'from_email' => '',
				'ip'         => $entry['ip'] ?? '',
				'fields'     => $fields,
			);
		}

		return $rows;
	}

	/* ---------------- Elementor Pro ---------------- */

	private static function read_elementor_leads( $offset, $limit ) {
		global $wpdb;

		$submissions = $wpdb->prefix . 'e_submissions';
		$values      = $wpdb->prefix . 'e_submissions_values';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
		$entries = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM `{$submissions}` ORDER BY id ASC LIMIT %d OFFSET %d", $limit, $offset )
		);

		if ( ! $entries ) {
			return array();
		}

		$ids = wp_list_pluck( $entries, 'id' );

		$fields_by_entry = array();

		if ( self::table_exists( 'e_submissions_values' ) && $ids ) {
			$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
			$all = $wpdb->get_results(
				$wpdb->prepare( "SELECT submission_id, `key`, value FROM `{$values}` WHERE submission_id IN ({$placeholders})", $ids )
			);

			foreach ( (array) $all as $value ) {
				$fields_by_entry[ (int) $value->submission_id ][ $value->key ] = $value->value;
			}
		}

		$rows = array();

		foreach ( $entries as $entry ) {
			$rows[] = array(
				'id'         => (int) $entry->id,
				'form_id'    => $entry->element_id ?? '',
				'form_title' => $entry->form_name ?? '',
				'submitted'  => $entry->created_at ?? '',
				'status'     => $entry->status ?? '',
				'from_name'  => '',
				'from_email' => '',
				'ip'         => $entry->user_ip ?? '',
				'fields'     => $fields_by_entry[ (int) $entry->id ] ?? array(),
			);
		}

		return $rows;
	}

	/* ---------------- helpers ---------------- */

	/**
	 * @param string $type   Post type.
	 * @param int    $offset Offset.
	 * @param int    $limit  Limit.
	 * @return WP_Post[]
	 */
	private static function posts( $type, $offset, $limit ) {
		return (array) get_posts(
			array(
				'post_type'        => $type,
				'post_status'      => 'any',
				'numberposts'      => $limit,
				'offset'           => $offset,
				'orderby'          => 'ID',
				'order'            => 'ASC',
				'suppress_filters' => false,
			)
		);
	}

	/**
	 * @param array  $meta All meta.
	 * @param string $key  Key.
	 * @return string
	 */
	private static function first_meta( array $meta, $key ) {
		if ( empty( $meta[ $key ] ) ) {
			return '';
		}

		$value = reset( $meta[ $key ] );

		return is_scalar( $value ) ? (string) $value : '';
	}
}

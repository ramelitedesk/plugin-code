=== Site Security ===
Contributors: newyorkmechanics
Tags: security, hardening
Requires at least: 4.0
Tested up to: 6.8
Requires PHP: 5.6
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Advanced hardening for this site. No scanner and no logging - it only removes
the ways code gets injected in the first place.

== Description ==

Everything is managed at **Tools -> Security**: tick the protections you want,
press Save, and only those are applied. The screen also reports which server
rules are actually in place and any wp-config.php problem the plugin cannot fix
from inside PHP (placeholder salts, debug output, missing FORCE_SSL_ADMIN).

A protection defined as a constant in wp-config.php always wins and is shown as
locked, with its input disabled and its value refused on save. That is worth
using for the settings you never want touched from a browser: wp-config.php is
a file the web server never serves, so a stolen admin session cannot reach it.

== Naming ==

The name in the plugin list, the Tools menu and the settings heading is built
from the site title at runtime, so the plugin reads as "<Site Name> Security"
wherever it is installed - change the site title and the plugin name follows.

The file header says "Site Security" because WordPress parses that header
statically out of the file; it is only visible while the plugin is inactive.

The folder name is fixed at install time. A plugin cannot rename its own
directory: WordPress identifies an active plugin by its path, so renaming it
mid-request would deactivate the plugin and drop every protection with it. The
settings screen shows the folder name that would match the site title, and
renaming it over SFTP then reactivating is a safe manual step.

What it does, layer by layer.

**Core**
* Disables the plugin and theme file editors and blocks deep links to them.
* Removes `unfiltered_html` from every role, so no account - not even an
  administrator - can store raw `<script>` in post content.
* Hides the WordPress version from the head, feeds, the admin footer and the
  outbound user agent.
* Keeps minor (security) core updates flowing automatically.
* Refuses WordPress-initiated HTTP requests aimed at private IP ranges (SSRF).

**Files and server rules**
* Writes an `Options -Indexes` rule and denies web access to `wp-config.php`,
  `.env`, `.htaccess`, log files, database dumps, archives and editor backups.
* Refuses to execute PHP, CGI, Perl, Python or `.htaccess` from
  `wp-content/uploads`, at both the RedirectMatch and the per-directory level,
  with `php_flag engine off` and `RemoveHandler` as belt and braces.
* Blocks direct requests into `wp-includes/*.php` apart from the two real
  entry points (`ms-files.php`, `wp-tinymce.php`).
* Blocks every hidden file and folder - `.git`, `.svn`, `.env`, editor state -
  while leaving `.well-known` reachable so certificate renewal keeps working.
* Its rules are written into a marked block placed *above* the WordPress block
  in `.htaccess`, because the rule WordPress writes is terminal. Deactivating
  the plugin removes the block and leaves the WordPress one untouched.
* Re-checks its own protective files once an hour and restores them if
  something deletes them.

**Uploads**
* Rejects executable extensions in *any* position of the file name, so both
  `shell.php.jpg` and `shell.jpg.php` are refused.
* Removes executable types from the allowed mime list and turns SVG off.
* Reads the uploaded bytes and rejects anything containing a PHP open tag,
  a PHP shebang, or an eval-style call wired to `base64_decode`, `gzinflate`
  or a superglobal.
* Verifies that files declared as images actually decode as images.
* Strips null bytes and unusual characters from file names.

**Requests**
* A conservative filter over the URL, query string and a few headers: PHP tags,
  stream wrappers (`php://`, `data://`, `phar://`), traversal, superglobal
  tampering, reflected script injection, SQL injection probes and PHP object
  injection. Post bodies are never inspected and logged-in editors are exempt,
  so normal content work cannot trip it.

**Headers**
* `X-Frame-Options`, `X-Content-Type-Options: nosniff`, `Referrer-Policy`,
  `Permissions-Policy`, `Cross-Origin-Resource-Policy`, HSTS on HTTPS, and
  `noindex` on the login and admin screens. `X-Powered-By` is removed.

**Login**
* Locks a client out after repeated failures (5 attempts / 15 minutes).
* Collapses "unknown user" and "wrong password" into a single message, and
  gives the same answer on the lost-password form, so account names cannot be
  confirmed.
* Requires 14 character mixed passwords for administrators, editors and
  authors, 10 for everyone else.

**Machine interfaces**
* XML-RPC is disabled and direct hits on `xmlrpc.php` are refused; pingbacks
  are closed.
* Application passwords are turned off.
* The REST user routes, the user sitemap, oEmbed author fields and the
  `?author=N` probe are all closed to anonymous visitors.

== Configuration ==

Define any of these in `wp-config.php` *above* the "That's all, stop editing"
line to override the default:

    define( 'NYMS_DISALLOW_FILE_EDIT', true );    // Editors off.
    define( 'NYMS_DISALLOW_FILE_MODS', false );   // true = no installs/updates from wp-admin.
    define( 'NYMS_FORCE_KSES', true );            // Remove unfiltered_html everywhere.
    define( 'NYMS_MINOR_AUTO_UPDATES', true );
    define( 'NYMS_MANAGE_HTACCESS', true );
    define( 'NYMS_BLOCK_PHP_IN_UPLOADS', true );
    define( 'NYMS_UPLOAD_GUARD', true );
    define( 'NYMS_REQUEST_GUARD', true );
    define( 'NYMS_TRUST_PROXY', false );          // true only behind Cloudflare or a known proxy.
    define( 'NYMS_SECURITY_HEADERS', true );
    define( 'NYMS_FRAME_POLICY', 'SAMEORIGIN' );  // Or 'DENY'.
    define( 'NYMS_LOGIN_GUARD', true );
    define( 'NYMS_LOGIN_MAX_ATTEMPTS', 5 );
    define( 'NYMS_LOGIN_LOCKOUT', 900 );
    define( 'NYMS_STRONG_PASSWORDS', true );
    define( 'NYMS_DISABLE_XMLRPC', true );
    define( 'NYMS_BLOCK_ENUMERATION', true );
    define( 'NYMS_DISABLE_APP_PASSWORDS', true );
    define( 'NYMS_ALLOW_SVG_UPLOADS', false );

A constant set here is locked on the settings screen: its input is disabled and
the value is refused on save.

Filters, for the rare exception:

    add_filter( 'nyms_allow_svg_uploads', '__return_true' );
    add_filter( 'nyms_security_headers', 'my_headers' );          // e.g. add a CSP.
    add_filter( 'nyms_minimum_password_length', 'my_length', 10, 2 );
    add_filter( 'nyms_skip_request_guard', 'my_condition' );

== nginx ==

`.htaccess` is ignored by nginx. Add the equivalent to the server block:

    location ~* /wp-content/uploads/.*\.(php|phtml|phar|pht|shtml|cgi|pl|py|asp|aspx|jsp)$ { deny all; }
    location ~* /wp-content/(uploads|upgrade)/.*\.(htaccess|htm|html)$ { deny all; }
    location ~* ^/wp-includes/(?!ms-files\.php|js/tinymce/wp-tinymce\.php).*\.php$ { deny all; }
    location ~* /\.(env|git|htaccess|htpasswd) { deny all; }
    location ~* \.(bak|old|orig|save|swp|sql|log|ini|sh|inc)$ { deny all; }
    location = /wp-config.php { deny all; }
    location = /xmlrpc.php { deny all; }
    autoindex off;

== Recommended wp-config.php companions ==

These cannot be set from a plugin because they are read before plugins load:

    define( 'WP_DEBUG', false );
    define( 'WP_DEBUG_DISPLAY', false );
    define( 'WP_DEBUG_LOG', false );        // A readable debug.log is a disclosure risk.
    define( 'FORCE_SSL_ADMIN', true );
    define( 'DISALLOW_UNFILTERED_UPLOADS', true );

Rotating the salts in wp-config.php after a cleanup logs every session out,
including the attacker's.

== Changelog ==

= 1.1.0 =
* Added the Tools -> Security screen: each protection can be switched on or
  off and saved. Constants in wp-config.php still win and render as locked.
* SVG uploads are now a setting rather than a filter-only option.

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.1.0 =
Adds a settings screen. Existing behaviour is unchanged until you change it.

=== Site Security ===
Contributors: newyorkmechanics
Tags: security, hardening, firewall, uploads, two-factor
Requires at least: 4.0
Tested up to: 6.8
Requires PHP: 5.6
Stable tag: 2.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Hardening only: server rules, upload and package controls, a request firewall,
two-factor authentication and self-protection. It does not scan for malware.

== Description ==

Everything is managed at **Tools -> Security**. The screen has nine tabs:
Overview, Settings, Event log, Self-protection, Plugins, Accounts, Firewall,
Network and Server rules. Tick the protections you want, press Save, and only
those are applied.

This plugin closes the ways code gets onto a site and records what it refused.
It deliberately does not look for malicious code in files that are already
there: no signature engine, no file baseline, no quarantine, no database scan.
That is a malware scanner's job, it is a job worth doing properly, and running
two of them side by side means two sets of false positives fighting over the
same files. Pair this with a scanner rather than replacing one.

A protection defined as a constant in `wp-config.php` always wins and is shown
as locked, with its input disabled and its value refused on save. That is worth
using for the settings you never want touched from a browser: `wp-config.php` is
a file the web server never serves, so a stolen admin session cannot reach it.

== Naming ==

The name in the plugin list, the Tools menu and the settings heading is built
from the site title at runtime, so the plugin reads as "<Site Name> Security"
wherever it is installed - change the site title and the plugin name follows.

The file header says "Site Security" because WordPress parses that header
statically out of the file; it is only visible while the plugin is inactive.

The folder name is fixed at install time. A plugin cannot rename its own
directory: WordPress identifies an active plugin by its path, so renaming it
mid-request would deactivate the plugin and drop every protection with it.

== What it does, layer by layer ==

**Core**

* Disables the plugin and theme file editors and blocks deep links to them.
* Removes `unfiltered_html` from every role, so no account - not even an
  administrator - can store raw `<script>` in post content.
* Hides the WordPress version from the head, feeds, the admin footer, the
  `X-Redirect-By` header and the outbound user agent.
* Keeps minor (security) core updates flowing automatically.
* Refuses WordPress-initiated HTTP requests aimed at private IP ranges (SSRF).
* Optionally disables RSS and Atom feeds, which otherwise list every post,
  author and comment in one request.

**Plugins and themes**

* Every package is checked for shape before anything is written: the uploaded
  ZIP entry by entry, then the unpacked folder file by file. Path traversal,
  absolute paths, executables, server configuration files, hidden scripts,
  double extensions, decompression bombs, oversized entries and archives nested
  inside archives are all refused, and nothing is extracted to disk to check it.
* Downloads are only accepted from hosts on the approved source list.
* Installed plugins are checked against the checksums their author published.
  A file that differs, or a file the author never shipped, is reported as
  modified - which is exactly what a nulled copy with a backdoor looks like.
* Plugins withdrawn from the WordPress directory (which usually means an
  unfixed security problem) are always refused. Plugins that are not published
  there at all, or that have not been updated for years, can be refused too.
* An approval workflow: in enforce mode a plugin has to be approved by name
  before it can be installed or activated, and a blocklisted plugin is not
  loaded even if the active-plugins option still names it.

**Uploads**

* Rejects executable extensions in *any* position of the file name, so both
  `shell.php.jpg` and `shell.jpg.php` are refused.
* Three passes: the name, the declared type, and the first bytes. The extension must
  match the file's magic bytes, the declared MIME type must agree with what the
  server reads from the contents, and an image extension must actually decode
  as an image.
* Null bytes, Unicode direction overrides and zero-width characters are removed
  from names before any decision is made about them, and names are normalised
  so `photo<RLO>gnp.php` cannot pose as `photo.png`.
* SVG is off by default. When it is switched on, every file is parsed and
  rewritten against an element and attribute allow list: scripts, event
  handlers, external references, `foreignObject` and entity declarations are
  all stripped and only the drawing is kept.
* HTML, JavaScript and archive uploads are separate switches.
* Archives are inspected entry by entry, including archives inside archives.
* A size limit of your own, applied on top of the server's.
* Anything that reaches the media library by another route - an importer, a
  REST call, a plugin sideloading its own file - is removed if its extension is
  executable.

**Server rules**

* `Options -Indexes` plus deny rules for `wp-config.php`, `.env`, `.user.ini`,
  `php.ini`, `web.config`, lock files, log files, database dumps, archives and
  editor backups.
* PHP, CGI, Perl, Python and `.htaccess` execution refused in the uploads
  folder *and* in every cache, temporary and upgrade folder found on the site,
  at both the RedirectMatch and the per-directory level, with
  `php_flag engine off` and `RemoveHandler` as belt and braces.
* Direct requests into `wp-includes/*.php` blocked apart from the two real
  entry points (`ms-files.php`, `wp-tinymce.php`).
* Every hidden file and folder blocked - `.git`, `.svn`, `.env`, editor state -
  while `.well-known` stays reachable so certificate renewal keeps working.
* The rules go into a marked block placed *above* the WordPress block, because
  the rule WordPress writes is terminal. Deactivating the plugin removes the
  block and leaves the WordPress one untouched.
* The equivalent nginx configuration is generated for you on the Server rules
  tab, ready to paste into the server block.

**Requests and the firewall**

* A conservative filter over the URL, query string and a few headers: PHP tags,
  stream wrappers, traversal, superglobal tampering, reflected script
  injection, SQL injection probes and PHP object injection. Post bodies are
  never inspected and logged-in editors are exempt, so normal content work
  cannot trip it.
* Per-address rate limits for the site as a whole, the sign-in page, XML-RPC
  and the REST API.
* Address allowlist and blocklist, both accepting single addresses, CIDR
  ranges and trailing wildcards.
* User-agent filtering, with the common vulnerability scanners built in.
* Country blocking, when a proxy in front of the site reports the country
  (Cloudflare, CloudFront, an nginx GeoIP module). Without one the check stands
  down rather than guessing.
* Automatic blocking after repeated refusals, including missing-page storms,
  with each repeat lasting twice as long as the last.

**Accounts and sessions**

* New administrators, promoted accounts, added roles, changed addresses and
  passwords, deleted accounts and new application passwords are all recorded,
  and the serious ones e-mailed.
* Sign-ins are recorded with the address they came from; an administrator
  signing in from an address never seen before is reported.
* Two-factor authentication per person on their own profile: an authenticator
  app (TOTP, RFC 6238) or a code by e-mail, with eight single-use recovery
  codes. The app method has to be confirmed with a working code before it is
  switched on, so nobody can lock themselves out.
* Session listing, forced sign-out, an optional session limit, and a report
  when an administrator has an unusual number of sessions open.
* Obvious user names are refused; existing ones are reported.
* Privileged accounts that have not signed in for months are reported and can
  be disabled automatically. Disabling is reversible and deletes nothing.
* Brute-force lockout, identical answers for "unknown user" and "wrong
  password", and a password policy of 14 mixed characters for administrators,
  editors and authors, 10 for everyone else.

**Outbound network**

* Every host WordPress contacts is recorded with a first-seen and last-seen
  time, and the first contact with an unexpected host is reported. A host you
  do not recognise, contacted regularly, is what a backdoor phoning home looks
  like.
* Domain blocklist, always enforced, seeded with hosts known to be used by
  WordPress malware and by browser miners.
* Optional allowlist mode: nothing outside the list goes anywhere. This is the
  strongest anti-backdoor setting in the plugin - a shell that cannot phone
  home is nearly useless - so watch the recorded host list for a week first.
* Optional reputation checks against the Spamhaus DBL and ZEN lists over DNS,
  cached for a day.

**Self-protection**

A security plugin is the first thing an intruder switches off, so it:

* hashes its own files and reports any change, deletion or addition;
* recreates its log table if it is dropped;
* denies direct web access to its own `includes` folder;
* refuses to be removed from the active plugin list, and refuses the
  capability that would delete it, until an administrator unlocks it
  deliberately on the Self-protection tab - the lock closes again after fifteen
  minutes;
* refuses any write to its settings that does not come from an administrator
  inside wp-admin;
* puts back any of its scheduled jobs that go missing.

**Event log and alerts**

Every block, rejected upload, refused package, role change and refusal is
written to
its own table with a severity, the client address and the acting user.
Identical events inside five minutes are collapsed so a flood cannot fill the
table. Critical events are e-mailed, at most one message an hour per kind, and
shown as a notice on every admin screen until they are looked at. Old entries
are deleted on a schedule you choose.

== Scheduled work ==

    nyms_plugin_audit     daily    check installed plugins against their author
    nyms_user_audit       daily    administrators, inactivity, suspicious names
    nyms_self_check       hourly   the plugin's own files and table
    nyms_prune_blocks     hourly   expire finished address blocks
    nyms_maintenance      daily    trim the log to the retention window

== Configuration ==

Define any of these in `wp-config.php` *above* the "That's all, stop editing"
line to override the setting and lock it out of the browser:

    // Core
    define( 'NYMS_DISALLOW_FILE_EDIT', true );
    define( 'NYMS_DISALLOW_FILE_MODS', false );
    define( 'NYMS_FORCE_KSES', true );
    define( 'NYMS_MINOR_AUTO_UPDATES', true );

    // Server rules and files
    define( 'NYMS_MANAGE_HTACCESS', true );
    define( 'NYMS_BLOCK_PHP_IN_UPLOADS', true );

    // Logging and self-protection
    define( 'NYMS_LOGGING', true );
    define( 'NYMS_LOG_RETENTION_DAYS', 60 );
    define( 'NYMS_ALERT_EMAIL', true );
    define( 'NYMS_SELF_PROTECT', true );

    // Plugins and themes
    define( 'NYMS_PLUGIN_GUARD', true );
    define( 'NYMS_PLUGIN_POLICY', 'monitor' );      // off | monitor | enforce
    define( 'NYMS_BLOCK_UNKNOWN_PLUGINS', false );
    define( 'NYMS_BLOCK_ABANDONED_PLUGINS', false );
    define( 'NYMS_ABANDONED_MONTHS', 24 );
    define( 'NYMS_VERIFY_PLUGIN_FILES', true );

    // Uploads
    define( 'NYMS_UPLOAD_GUARD', true );
    define( 'NYMS_ALLOW_SVG_UPLOADS', false );
    define( 'NYMS_SANITIZE_SVG', true );
    define( 'NYMS_ALLOW_HTML_UPLOADS', false );
    define( 'NYMS_ALLOW_JS_UPLOADS', false );
    define( 'NYMS_ALLOW_ARCHIVE_UPLOADS', true );
    define( 'NYMS_SCAN_ARCHIVES', true );
    define( 'NYMS_MAX_UPLOAD_MB', 64 );
    define( 'NYMS_ARCHIVE_MAX_ENTRIES', 20000 );
    define( 'NYMS_ARCHIVE_MAX_FILE_MB', 50 );
    define( 'NYMS_ARCHIVE_MAX_TOTAL_MB', 500 );
    define( 'NYMS_ARCHIVE_MAX_RATIO', 120 );

    // Requests and firewall
    define( 'NYMS_REQUEST_GUARD', true );
    define( 'NYMS_TRUST_PROXY', false );            // true only behind a known proxy
    define( 'NYMS_FIREWALL', true );
    define( 'NYMS_RATE_GENERAL', 240 );
    define( 'NYMS_RATE_LOGIN', 12 );
    define( 'NYMS_RATE_REST', 120 );
    define( 'NYMS_AUTO_BLOCK', true );
    define( 'NYMS_BLOCK_THRESHOLD', 10 );
    define( 'NYMS_BLOCK_MINUTES', 30 );
    define( 'NYMS_MAX_NOT_FOUND', 30 );
    define( 'NYMS_BLOCK_EMPTY_AGENT', false );

    // Headers
    define( 'NYMS_SECURITY_HEADERS', true );
    define( 'NYMS_FRAME_POLICY', 'SAMEORIGIN' );    // Or 'DENY'

    // Login and accounts
    define( 'NYMS_LOGIN_GUARD', true );
    define( 'NYMS_LOGIN_MAX_ATTEMPTS', 5 );
    define( 'NYMS_LOGIN_LOCKOUT', 900 );
    define( 'NYMS_STRONG_PASSWORDS', true );
    define( 'NYMS_USER_GUARD', true );
    define( 'NYMS_TWO_FACTOR', true );
    define( 'NYMS_REQUIRE_2FA_ADMINS', true );
    define( 'NYMS_BLOCK_WEAK_USERNAMES', true );
    define( 'NYMS_LIMIT_SESSIONS', false );
    define( 'NYMS_MAX_SESSIONS', 5 );
    define( 'NYMS_INACTIVE_DAYS', 180 );
    define( 'NYMS_DISABLE_INACTIVE', false );

    // Outbound network
    define( 'NYMS_NETWORK_GUARD', true );
    define( 'NYMS_DOMAIN_ALLOWLIST_MODE', false );
    define( 'NYMS_DNS_REPUTATION', false );

    // Machine interfaces
    define( 'NYMS_DISABLE_XMLRPC', true );
    define( 'NYMS_DISABLE_APP_PASSWORDS', true );
    define( 'NYMS_BLOCK_ENUMERATION', true );
    define( 'NYMS_RESTRICT_REST', false );
    define( 'NYMS_DISABLE_FEEDS', false );

Filters, for the rare exception:

    add_filter( 'nyms_allow_svg_uploads', '__return_true' );
    add_filter( 'nyms_security_headers', 'my_headers' );        // e.g. add a CSP
    add_filter( 'nyms_minimum_password_length', 'my_length', 10, 2 );
    add_filter( 'nyms_skip_request_guard', 'my_condition' );
    add_filter( 'nyms_no_execute_dirs', 'my_dirs' );            // more no-PHP folders
    add_filter( 'nyms_public_rest_routes', 'my_routes' );       // keep a route open
    add_filter( 'nyms_privileged_roles', 'my_roles' );

== Turning the strict settings on safely ==

Three settings can lock you out of your own workflow if they are switched on
without preparation. In each case the plugin runs in a reporting mode first so
you can see what would happen.

1. **Plugin policy: enforce.** Open the Plugins tab, press "Check every
   installed plugin now", approve everything you actually use, then switch the
   policy. Add the update host of any paid plugin to the approved sources at
   the same time.
2. **Outbound allowlist mode.** Leave the network guard on in its default mode
   for a week, then open the Network tab and add every host in the list that
   belongs there before switching the mode on.
3. **Require a sign-in for the REST API.** Switch it on, then load the front
   end signed out and click through the site. Anything that breaks needs its
   route adding through the `nyms_public_rest_routes` filter.

Put your own address on the firewall allowlist before tightening anything.

== Recommended wp-config.php companions ==

These cannot be set from a plugin because they are read before plugins load:

    define( 'WP_DEBUG', false );
    define( 'WP_DEBUG_DISPLAY', false );
    define( 'WP_DEBUG_LOG', false );        // A readable debug.log is a disclosure risk.
    define( 'FORCE_SSL_ADMIN', true );
    define( 'DISALLOW_UNFILTERED_UPLOADS', true );

Rotating the salts in `wp-config.php` after a cleanup logs every session out,
including the intruder's.

== What this plugin does not do ==

Said plainly, because a security plugin that overstates itself is worse than
none:

* **It does not find malware that is already on the site.** There is no
  signature engine, no file baseline and no database scan here by design. This
  plugin stops code getting in; finding what got in before it was installed, or
  through a hole it does not cover, needs a dedicated scanner alongside it.
* **It cannot stop a write it does not perform.** PHP can refuse an upload and
  refuse an installer, and the server rules stop uploaded code from running -
  but a process already executing on the server can write a file straight to
  disk, and nothing in PHP sees that happen.
* **Country blocking needs a proxy** that reports the country. There is no
  bundled GeoIP database.
* **Vulnerability data is limited to what wordpress.org publishes** - whether a
  plugin has been withdrawn, and when it was last updated. There is no
  commercial vulnerability feed behind it, so "no known vulnerability" here
  means "nothing that wordpress.org has flagged", not a clean bill of health.
* **Passkeys and WebAuthn are not implemented.** Two-factor is TOTP or e-mail.
  A half-finished WebAuthn implementation is worse than none, so if you need
  passkeys, add a dedicated plugin for that one job.
* **Archive inspection needs the PHP zip extension.** Without it the plugin
  says so on the Overview tab rather than quietly passing archives through.
* **It is not a substitute for backups**, for keeping WordPress and its plugins
  updated, or for not reusing passwords.

== Changelog ==

= 2.1.0 =
* Removed the malware-scanning half of the plugin so it does not duplicate a
  dedicated scanner: the signature engine, the file-hash baseline and integrity
  comparison, core checksum verification and rollback, the quarantine store and
  the database content scan are all gone, with their settings, tables, cron
  jobs and screens.
* Uploads and packages are still checked, on structure alone: names, extensions,
  magic bytes, MIME consistency, archive shape and PHP tags in files that are
  not scripts. Nothing is judged on what its code appears to do.
* The Files and Database tabs are replaced by a Self-protection tab.
* Executable files that reach the media library by another route are removed
  rather than quarantined.

= 2.0.0 =
* File integrity baseline, official core checksum verification and rollback.
* Quarantine with review and one-click restore.
* Shared signature engine for PHP, JavaScript, HTML and SVG.
* Plugin and theme package inspection, allowlist, blocklist and approval
  workflow, with author checksum verification for installed plugins.
* Upload guard extended: magic bytes, MIME consistency, Unicode name folding,
  SVG sanitisation, archive and nested-archive inspection, decompression bomb
  and oversize detection.
* Request firewall: rate limits, address lists, user-agent and country
  filtering, automatic escalating blocks.
* Account monitoring, session management, two-factor authentication with
  recovery codes, inactive account handling.
* Database and outbound-network inspection.
* Self-protection for the plugin's own files, tables, options and quarantine.
* Event log with severity, e-mail alerts and admin notices.
* No-execution rules extended to cache, temporary and upgrade folders, and an
  nginx configuration generated on screen.

= 1.1.0 =
* Added the Tools -> Security screen: each protection can be switched on or
  off and saved. Constants in wp-config.php still win and render as locked.
* SVG uploads are now a setting rather than a filter-only option.

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 2.1.0 =
The malware-scanning side is removed; this is now a hardening plugin only. Its
hash table, quarantine folder and scanner settings go with it, so run a
dedicated scanner alongside. Nothing that blocks a request, an upload or an
install has changed.

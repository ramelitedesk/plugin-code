<?php
/**
 * Plugin loader.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Boots every hardening module.
 */
final class NYMS_Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var NYMS_Plugin|null
	 */
	private static $instance = null;

	/**
	 * Loaded modules.
	 *
	 * @var array
	 */
	private $modules = array();

	/**
	 * Modules shipped with the plugin, in load order.
	 *
	 * @var array
	 */
	private $registry = array(
		'core'    => 'NYMS_Core_Hardening',
		'files'   => 'NYMS_File_Guard',
		'uploads' => 'NYMS_Upload_Guard',
		'request' => 'NYMS_Request_Guard',
		'headers' => 'NYMS_Headers',
		'login'   => 'NYMS_Login_Guard',
		'api'     => 'NYMS_Api_Guard',
		'admin'   => 'NYMS_Admin',
	);

	/**
	 * Retrieve the singleton.
	 *
	 * @return NYMS_Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Private constructor.
	 */
	private function __construct() {}

	/**
	 * Load dependencies and register every module.
	 *
	 * @return void
	 */
	public function run() {
		require_once NYMS_PATH . 'includes/class-nyms-helpers.php';
		require_once NYMS_PATH . 'includes/class-nyms-htaccess.php';

		foreach ( $this->registry as $slug => $class ) {
			$file = NYMS_PATH . 'includes/class-' . str_replace( '_', '-', strtolower( $class ) ) . '.php';

			if ( ! file_exists( $file ) ) {
				continue;
			}

			require_once $file;

			if ( ! class_exists( $class ) ) {
				continue;
			}

			$module = new $class();

			if ( method_exists( $module, 'register' ) ) {
				$module->register();
			}

			$this->modules[ $slug ] = $module;
		}
	}

	/**
	 * Fetch a loaded module.
	 *
	 * @param string $slug Module slug.
	 * @return object|null
	 */
	public function module( $slug ) {
		return isset( $this->modules[ $slug ] ) ? $this->modules[ $slug ] : null;
	}

	/**
	 * Activation routine.
	 *
	 * @return void
	 */
	public static function on_activate() {
		require_once NYMS_PATH . 'includes/class-nyms-helpers.php';
		require_once NYMS_PATH . 'includes/class-nyms-htaccess.php';

		NYMS_Htaccess::install();

		update_option( 'nyms_version', NYMS_VERSION, false );
	}

	/**
	 * Deactivation routine. Removes only what this plugin wrote.
	 *
	 * @return void
	 */
	public static function on_deactivate() {
		require_once NYMS_PATH . 'includes/class-nyms-helpers.php';
		require_once NYMS_PATH . 'includes/class-nyms-htaccess.php';

		NYMS_Htaccess::uninstall();
	}
}

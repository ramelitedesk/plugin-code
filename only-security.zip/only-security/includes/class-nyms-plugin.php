<?php
/**
 * Plugin loader.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Boots every hardening module.
 */
final class NYMS_Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var NYMS_Plugin|null
	 */
	private static $instance = null;

	/**
	 * Loaded modules.
	 *
	 * @var array
	 */
	private $modules = array();

	/**
	 * Classes with no hooks of their own, loaded before the modules.
	 *
	 * @var array
	 */
	private $libraries = array(
		'NYMS_Helpers',
		'NYMS_Log',
		'NYMS_Archive',
		'NYMS_Svg',
		'NYMS_Htaccess',
	);

	/**
	 * Modules shipped with the plugin, in load order.
	 *
	 * The firewall runs first: there is no point inspecting a request from an
	 * address that is not allowed to make one.
	 *
	 * @var array
	 */
	private $registry = array(
		'firewall'  => 'NYMS_Firewall',
		'request'   => 'NYMS_Request_Guard',
		'core'      => 'NYMS_Core_Hardening',
		'files'     => 'NYMS_File_Guard',
		'uploads'   => 'NYMS_Upload_Guard',
		'packages'  => 'NYMS_Plugin_Guard',
		'headers'   => 'NYMS_Headers',
		'login'     => 'NYMS_Login_Guard',
		'users'     => 'NYMS_User_Guard',
		'twofactor' => 'NYMS_Two_Factor',
		'api'       => 'NYMS_Api_Guard',
		'network'   => 'NYMS_Network_Guard',
		'self'      => 'NYMS_Self_Protect',
		'admin'     => 'NYMS_Admin',
	);

	/**
	 * The scheduled jobs the plugin owns: hook => recurrence.
	 *
	 * @var array
	 */
	private static $schedule = array(
		'nyms_plugin_audit'   => 'daily',
		'nyms_user_audit'     => 'daily',
		'nyms_self_check'     => 'hourly',
		'nyms_prune_blocks'   => 'hourly',
		'nyms_maintenance'    => 'daily',
	);

	/**
	 * Retrieve the singleton.
	 *
	 * @return NYMS_Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Private constructor.
	 */
	private function __construct() {}

	/**
	 * Load dependencies and register every module.
	 *
	 * @return void
	 */
	public function run() {
		foreach ( $this->libraries as $class ) {
			$this->load( $class );
		}

		foreach ( $this->registry as $slug => $class ) {
			if ( ! $this->load( $class ) ) {
				continue;
			}

			$module = new $class();

			if ( method_exists( $module, 'register' ) ) {
				$module->register();
			}

			$this->modules[ $slug ] = $module;
		}

		add_action( 'nyms_maintenance', array( $this, 'maintenance' ) );
		add_action( 'init', array( $this, 'verify_schedule' ) );
		add_action( 'admin_init', array( $this, 'maybe_upgrade' ), 1 );
	}

	/**
	 * Bring an older installation up to date.
	 *
	 * Updating the plugin changes its own files, which self-protection would
	 * otherwise report as tampering, and may add a table. Both are handled
	 * here rather than asking the site owner to deactivate and reactivate.
	 *
	 * @return void
	 */
	public function maybe_upgrade() {
		$installed = (string) get_option( 'nyms_version', '' );

		if ( NYMS_VERSION === $installed ) {
			return;
		}

		NYMS_Log::install();

		$self = $this->module( 'self' );

		if ( $self instanceof NYMS_Self_Protect ) {
			$self->record();
			$self->protect_own_directory();
		}

		if ( NYMS_MANAGE_HTACCESS ) {
			NYMS_Htaccess::install();
		}

		$this->verify_schedule();

		update_option( 'nyms_version', NYMS_VERSION, false );

		NYMS_Log::record(
			'plugin_upgraded',
			NYMS_Log::NOTICE,
			sprintf(
				/* translators: 1: previous version, 2: new version. */
				__( 'Security plugin updated from %1$s to %2$s.', 'newyorkmechanics-security' ),
				'' === $installed ? __( 'an unknown version', 'newyorkmechanics-security' ) : $installed,
				NYMS_VERSION
			)
		);
	}

	/**
	 * Require the file that holds a class.
	 *
	 * @param string $class Class name.
	 * @return bool
	 */
	private function load( $class ) {
		if ( class_exists( $class ) ) {
			return true;
		}

		$file = NYMS_PATH . 'includes/class-' . str_replace( '_', '-', strtolower( $class ) ) . '.php';

		if ( ! file_exists( $file ) ) {
			return false;
		}

		require_once $file;

		return class_exists( $class );
	}

	/**
	 * Fetch a loaded module.
	 *
	 * @param string $slug Module slug.
	 * @return object|null
	 */
	public function module( $slug ) {
		return isset( $this->modules[ $slug ] ) ? $this->modules[ $slug ] : null;
	}

	/**
	 * The scheduled jobs and when each next runs.
	 *
	 * @return array
	 */
	public static function schedule() {
		$out = array();

		foreach ( self::$schedule as $hook => $recurrence ) {
			$out[ $hook ] = array(
				'recurrence' => $recurrence,
				'next'       => (int) wp_next_scheduled( $hook ),
			);
		}

		return $out;
	}

	/**
	 * Put back any job that has gone missing.
	 *
	 * A compromise usually starts by clearing the schedule so nothing notices.
	 *
	 * @return void
	 */
	public function verify_schedule() {
		foreach ( self::$schedule as $hook => $recurrence ) {
			if ( ! wp_next_scheduled( $hook ) ) {
				wp_schedule_event( time() + wp_rand( 60, 900 ), $recurrence, $hook );
			}
		}
	}

	/**
	 * Daily housekeeping.
	 *
	 * @return void
	 */
	public function maintenance() {
		NYMS_Log::prune();

		$firewall = $this->module( 'firewall' );

		if ( $firewall instanceof NYMS_Firewall ) {
			$firewall->prune();
		}
	}

	/**
	 * Activation routine.
	 *
	 * @return void
	 */
	public static function on_activate() {
		require_once NYMS_PATH . 'includes/class-nyms-helpers.php';
		require_once NYMS_PATH . 'includes/class-nyms-log.php';
		require_once NYMS_PATH . 'includes/class-nyms-htaccess.php';
		require_once NYMS_PATH . 'includes/class-nyms-self-protect.php';

		NYMS_Log::install();
		NYMS_Htaccess::install();

		$self = new NYMS_Self_Protect();

		$self->record();
		$self->protect_own_directory();

		foreach ( self::$schedule as $hook => $recurrence ) {
			if ( ! wp_next_scheduled( $hook ) ) {
				wp_schedule_event( time() + wp_rand( 60, 900 ), $recurrence, $hook );
			}
		}

		update_option( 'nyms_version', NYMS_VERSION, false );

		NYMS_Log::record( 'plugin_activated', NYMS_Log::NOTICE, __( 'Security plugin activated.', 'newyorkmechanics-security' ) );
	}

	/**
	 * Deactivation routine. Removes only what this plugin wrote.
	 *
	 * @return void
	 */
	public static function on_deactivate() {
		require_once NYMS_PATH . 'includes/class-nyms-helpers.php';
		require_once NYMS_PATH . 'includes/class-nyms-htaccess.php';

		NYMS_Htaccess::uninstall();

		foreach ( array_keys( self::$schedule ) as $hook ) {
			wp_clear_scheduled_hook( $hook );
		}

		delete_option( 'nyms_allow_deactivation' );
	}
}

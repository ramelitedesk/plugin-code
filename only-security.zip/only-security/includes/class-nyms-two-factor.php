<?php
/**
 * Two-factor authentication.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A second factor for the accounts that matter.
 *
 * Two methods are offered. An authenticator app (TOTP, RFC 6238) is the
 * strong one and works offline. A code sent by e-mail is the fallback for
 * people who will not install an app; it is only as strong as the mailbox,
 * which is said plainly on the screen.
 *
 * The password is verified first, exactly as before. Only then is the second
 * factor asked for, on a separate screen, with the session not yet issued.
 */
class NYMS_Two_Factor {

	/**
	 * User meta keys.
	 */
	const SECRET    = 'nyms_2fa_secret';
	const METHOD    = 'nyms_2fa_method';
	const RECOVERY  = 'nyms_2fa_recovery';
	const EMAIL_OTP = 'nyms_2fa_email_code';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! NYMS_TWO_FACTOR ) {
			return;
		}

		add_action( 'wp_login', array( $this, 'intercept_login' ), 5, 2 );
		add_action( 'login_form_nyms_2fa', array( $this, 'handle_challenge' ) );

		add_action( 'show_user_profile', array( $this, 'profile_fields' ) );
		add_action( 'edit_user_profile', array( $this, 'profile_fields' ) );
		add_action( 'personal_options_update', array( $this, 'save_profile' ) );
		add_action( 'edit_user_profile_update', array( $this, 'save_profile' ) );

		if ( NYMS_REQUIRE_2FA_ADMINS ) {
			add_action( 'admin_notices', array( $this, 'nag' ) );
		}
	}

	/**
	 * Whether an account has a working second factor.
	 *
	 * @param int $user_id User ID.
	 * @return bool
	 */
	public static function is_enabled( $user_id ) {
		$method = get_user_meta( $user_id, self::METHOD, true );

		if ( 'email' === $method ) {
			return true;
		}

		return 'totp' === $method && (bool) get_user_meta( $user_id, self::SECRET, true );
	}

	/**
	 * Whether this account must pass a second factor.
	 *
	 * @param WP_User $user User.
	 * @return bool
	 */
	public function required_for( $user ) {
		if ( ! $user instanceof WP_User ) {
			return false;
		}

		if ( self::is_enabled( $user->ID ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Take over the login the moment the password check passes.
	 *
	 * @param string  $login User name.
	 * @param WP_User $user  User object.
	 * @return void
	 */
	public function intercept_login( $login, $user = null ) {
		unset( $login );

		if ( ! $user instanceof WP_User || ! $this->required_for( $user ) ) {
			return;
		}

		// The challenge screen is drawn with the login-page helpers. When the
		// sign-in came from somewhere else - WP-CLI, a REST call - the safe
		// answer is to leave the session unissued and say so.
		if ( ! function_exists( 'login_header' ) ) {
			wp_clear_auth_cookie();

			wp_die(
				esc_html__( 'This account requires a second factor, which can only be entered on the sign-in screen.', 'newyorkmechanics-security' ),
				esc_html__( 'Two-factor authentication', 'newyorkmechanics-security' ),
				array( 'response' => 403 )
			);
		}

		// The cookie WordPress just set is withdrawn until the code is right.
		wp_clear_auth_cookie();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$remember = ! empty( $_POST['rememberme'] );
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$redirect = isset( $_POST['redirect_to'] ) ? (string) wp_unslash( $_POST['redirect_to'] ) : admin_url();

		$token = $this->issue_token( $user->ID, $remember, $redirect );

		if ( 'email' === get_user_meta( $user->ID, self::METHOD, true ) ) {
			$this->send_email_code( $user );
		}

		$this->render_form( $user, $token, '' );

		exit;
	}

	/**
	 * Create the short-lived token that stands in for the half-finished login.
	 *
	 * @param int    $user_id  User ID.
	 * @param bool   $remember Whether to remember the session.
	 * @param string $redirect Where to go afterwards.
	 * @return string
	 */
	private function issue_token( $user_id, $remember, $redirect ) {
		$token = wp_generate_password( 40, false );

		set_transient(
			'nyms_2fa_' . $token,
			array(
				'user'     => (int) $user_id,
				'remember' => (bool) $remember,
				'redirect' => $redirect,
				'ip'       => NYMS_Helpers::client_ip(),
			),
			10 * MINUTE_IN_SECONDS
		);

		return $token;
	}

	/**
	 * Validate the submitted code and finish the login.
	 *
	 * @return void
	 */
	public function handle_challenge() {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$token = isset( $_POST['nyms_2fa_token'] ) ? sanitize_text_field( wp_unslash( $_POST['nyms_2fa_token'] ) ) : '';
		$data  = $token ? get_transient( 'nyms_2fa_' . $token ) : false;

		if ( ! is_array( $data ) ) {
			wp_safe_redirect( wp_login_url() );
			exit;
		}

		$user = get_userdata( $data['user'] );

		if ( ! $user ) {
			delete_transient( 'nyms_2fa_' . $token );

			wp_safe_redirect( wp_login_url() );
			exit;
		}

		// The second factor must come from the same place as the first.
		if ( $data['ip'] !== NYMS_Helpers::client_ip() ) {
			delete_transient( 'nyms_2fa_' . $token );

			NYMS_Log::record(
				'2fa_ip_mismatch',
				NYMS_Log::WARNING,
				sprintf( /* translators: %s: user login. */ __( 'A second-factor code for %s was submitted from a different address.', 'newyorkmechanics-security' ), $user->user_login ),
				array( 'user_id' => $user->ID )
			);

			wp_safe_redirect( wp_login_url() );
			exit;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$code = isset( $_POST['nyms_2fa_code'] ) ? preg_replace( '/[^a-zA-Z0-9]/', '', (string) wp_unslash( $_POST['nyms_2fa_code'] ) ) : '';

		$attempts_key = 'nyms_2fa_try_' . NYMS_Helpers::ip_key( NYMS_Helpers::client_ip() );
		$attempts     = (int) get_transient( $attempts_key );

		if ( $attempts > 10 ) {
			delete_transient( 'nyms_2fa_' . $token );

			NYMS_Helpers::forbid();
		}

		if ( ! $this->verify( $user, $code ) ) {
			set_transient( $attempts_key, $attempts + 1, 15 * MINUTE_IN_SECONDS );

			NYMS_Log::record(
				'2fa_failed',
				NYMS_Log::WARNING,
				sprintf( /* translators: %s: user login. */ __( 'A wrong second-factor code was entered for %s.', 'newyorkmechanics-security' ), $user->user_login ),
				array( 'user_id' => $user->ID )
			);

			$this->render_form( $user, $token, __( 'That code was not right. Try the next one.', 'newyorkmechanics-security' ) );

			exit;
		}

		delete_transient( 'nyms_2fa_' . $token );
		delete_transient( $attempts_key );

		wp_set_auth_cookie( $user->ID, $data['remember'] );
		wp_set_current_user( $user->ID );

		NYMS_Log::record(
			'2fa_passed',
			NYMS_Log::INFO,
			sprintf( /* translators: %s: user login. */ __( 'Second factor accepted for %s.', 'newyorkmechanics-security' ), $user->user_login ),
			array( 'user_id' => $user->ID )
		);

		$redirect = ! empty( $data['redirect'] ) ? $data['redirect'] : admin_url();

		wp_safe_redirect( wp_validate_redirect( $redirect, admin_url() ) );

		exit;
	}

	/**
	 * Check a submitted code against every accepted form.
	 *
	 * @param WP_User $user User.
	 * @param string  $code Submitted code.
	 * @return bool
	 */
	public function verify( $user, $code ) {
		if ( '' === $code ) {
			return false;
		}

		$method = get_user_meta( $user->ID, self::METHOD, true );

		if ( 'totp' === $method ) {
			$secret = (string) get_user_meta( $user->ID, self::SECRET, true );

			if ( self::verify_totp( $secret, $code ) ) {
				return true;
			}
		}

		if ( 'email' === $method ) {
			$stored = get_user_meta( $user->ID, self::EMAIL_OTP, true );

			if ( is_array( $stored ) && ! empty( $stored['hash'] ) && $stored['expires'] > time() ) {
				if ( wp_check_password( $code, $stored['hash'] ) ) {
					delete_user_meta( $user->ID, self::EMAIL_OTP );

					return true;
				}
			}
		}

		return $this->consume_recovery_code( $user->ID, $code );
	}

	/**
	 * Spend a recovery code.
	 *
	 * @param int    $user_id User ID.
	 * @param string $code    Submitted code.
	 * @return bool
	 */
	private function consume_recovery_code( $user_id, $code ) {
		$codes = get_user_meta( $user_id, self::RECOVERY, true );

		if ( ! is_array( $codes ) || ! $codes ) {
			return false;
		}

		$needle = strtolower( preg_replace( '/[^a-z0-9]/i', '', $code ) );

		foreach ( $codes as $index => $hash ) {
			if ( wp_check_password( $needle, $hash ) ) {
				unset( $codes[ $index ] );

				update_user_meta( $user_id, self::RECOVERY, array_values( $codes ) );

				NYMS_Log::record(
					'2fa_recovery_used',
					NYMS_Log::WARNING,
					sprintf(
						/* translators: 1: user ID, 2: codes remaining. */
						__( 'A recovery code was used for user %1$d. %2$d codes remain.', 'newyorkmechanics-security' ),
						$user_id,
						count( $codes )
					),
					array( 'user_id' => $user_id )
				);

				return true;
			}
		}

		return false;
	}

	/**
	 * Mail a one-time code.
	 *
	 * @param WP_User $user User.
	 * @return void
	 */
	private function send_email_code( $user ) {
		$code = str_pad( (string) wp_rand( 0, 999999 ), 6, '0', STR_PAD_LEFT );

		update_user_meta(
			$user->ID,
			self::EMAIL_OTP,
			array(
				'hash'    => wp_hash_password( $code ),
				'expires' => time() + ( 10 * MINUTE_IN_SECONDS ),
			)
		);

		wp_mail(
			$user->user_email,
			sprintf(
				/* translators: %s: site name. */
				__( '[%s] Your sign-in code', 'newyorkmechanics-security' ),
				get_bloginfo( 'name' )
			),
			sprintf(
				/* translators: 1: code, 2: client IP address. */
				__( "Your sign-in code is %1\$s. It expires in ten minutes.\n\nIt was requested from %2\$s. If that was not you, change your password now.", 'newyorkmechanics-security' ),
				$code,
				NYMS_Helpers::client_ip()
			)
		);
	}

	/**
	 * Draw the challenge screen.
	 *
	 * @param WP_User $user  User.
	 * @param string  $token Login token.
	 * @param string  $error Error message, if any.
	 * @return void
	 */
	private function render_form( $user, $token, $error ) {
		$method = get_user_meta( $user->ID, self::METHOD, true );

		login_header(
			__( 'Two-factor authentication', 'newyorkmechanics-security' ),
			'',
			$error ? new WP_Error( 'nyms_2fa', $error ) : null
		);
		?>
		<form name="nyms_2fa_form" id="loginform" method="post"
			action="<?php echo esc_url( site_url( 'wp-login.php?action=nyms_2fa', 'login_post' ) ); ?>">
			<input type="hidden" name="nyms_2fa_token" value="<?php echo esc_attr( $token ); ?>" />

			<p>
				<?php
				if ( 'email' === $method ) {
					printf(
						/* translators: %s: partly hidden e-mail address. */
						esc_html__( 'A six-digit code has been sent to %s.', 'newyorkmechanics-security' ),
						esc_html( $this->mask_email( $user->user_email ) )
					);
				} else {
					esc_html_e( 'Enter the six-digit code from your authenticator app.', 'newyorkmechanics-security' );
				}
				?>
			</p>

			<p>
				<label for="nyms_2fa_code"><?php esc_html_e( 'Code', 'newyorkmechanics-security' ); ?></label>
				<input type="text" name="nyms_2fa_code" id="nyms_2fa_code" class="input"
					value="" size="20" autocomplete="one-time-code" inputmode="numeric"
					autofocus="autofocus" />
			</p>

			<p class="description" style="font-size:12px;">
				<?php esc_html_e( 'A recovery code works here too, and can only be used once.', 'newyorkmechanics-security' ); ?>
			</p>

			<p class="submit">
				<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large"
					value="<?php esc_attr_e( 'Continue', 'newyorkmechanics-security' ); ?>" />
			</p>
		</form>
		<?php
		login_footer( 'nyms_2fa_code' );
	}

	/**
	 * Hide most of an address.
	 *
	 * @param string $email Address.
	 * @return string
	 */
	private function mask_email( $email ) {
		$parts = explode( '@', (string) $email );

		if ( count( $parts ) !== 2 ) {
			return '***';
		}

		$name = $parts[0];
		$kept = substr( $name, 0, 1 );

		return $kept . str_repeat( '*', max( 1, strlen( $name ) - 1 ) ) . '@' . $parts[1];
	}

	/**
	 * The profile section.
	 *
	 * @param WP_User $user User being edited.
	 * @return void
	 */
	public function profile_fields( $user ) {
		if ( get_current_user_id() !== $user->ID && ! current_user_can( 'edit_users' ) ) {
			return;
		}

		$method = get_user_meta( $user->ID, self::METHOD, true );
		$secret = (string) get_user_meta( $user->ID, self::SECRET, true );
		$codes  = get_user_meta( $user->ID, self::RECOVERY, true );

		if ( '' === $secret ) {
			$secret = self::generate_secret();

			update_user_meta( $user->ID, self::SECRET, $secret );
		}

		$issuer = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$uri    = 'otpauth://totp/' . rawurlencode( $issuer . ':' . $user->user_login )
			. '?secret=' . $secret
			. '&issuer=' . rawurlencode( $issuer )
			. '&algorithm=SHA1&digits=6&period=30';
		?>
		<h2 id="nyms-2fa"><?php esc_html_e( 'Two-factor authentication', 'newyorkmechanics-security' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><?php esc_html_e( 'Second factor', 'newyorkmechanics-security' ); ?></th>
				<td>
					<?php wp_nonce_field( 'nyms_2fa_profile', 'nyms_2fa_nonce' ); ?>
					<label>
						<input type="radio" name="nyms_2fa_method" value=""<?php checked( '', $method ); ?> />
						<?php esc_html_e( 'Off', 'newyorkmechanics-security' ); ?>
					</label><br />
					<label>
						<input type="radio" name="nyms_2fa_method" value="totp"<?php checked( 'totp', $method ); ?> />
						<?php esc_html_e( 'Authenticator app (recommended)', 'newyorkmechanics-security' ); ?>
					</label><br />
					<label>
						<input type="radio" name="nyms_2fa_method" value="email"<?php checked( 'email', $method ); ?> />
						<?php esc_html_e( 'Code sent by e-mail', 'newyorkmechanics-security' ); ?>
					</label>
					<p class="description">
						<?php esc_html_e( 'An e-mailed code is only as strong as the mailbox it arrives in. Use the app if you can.', 'newyorkmechanics-security' ); ?>
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Setup key', 'newyorkmechanics-security' ); ?></th>
				<td>
					<code style="font-size:15px;letter-spacing:2px;"><?php echo esc_html( trim( chunk_split( $secret, 4, ' ' ) ) ); ?></code>
					<p class="description">
						<?php esc_html_e( 'Add this key to Google Authenticator, 1Password, Aegis or any other TOTP app, then tick "Authenticator app" above, enter a code to confirm, and save.', 'newyorkmechanics-security' ); ?>
					</p>
					<p class="description" style="word-break:break-all;">
						<code><?php echo esc_html( $uri ); ?></code>
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Confirm a code', 'newyorkmechanics-security' ); ?></th>
				<td>
					<input type="text" name="nyms_2fa_confirm" value="" class="regular-text" inputmode="numeric"
						autocomplete="off" />
					<p class="description">
						<?php esc_html_e( 'Required the first time you turn the authenticator app on, so you cannot lock yourself out.', 'newyorkmechanics-security' ); ?>
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Recovery codes', 'newyorkmechanics-security' ); ?></th>
				<td>
					<?php if ( is_array( $codes ) && $codes ) : ?>
						<p>
							<?php
							printf(
								/* translators: %d: number of codes. */
								esc_html__( '%d unused recovery codes remain.', 'newyorkmechanics-security' ),
								count( $codes )
							);
							?>
						</p>
					<?php endif; ?>
					<label>
						<input type="checkbox" name="nyms_2fa_new_codes" value="1" />
						<?php esc_html_e( 'Generate a fresh set of recovery codes and show them once', 'newyorkmechanics-security' ); ?>
					</label>
					<?php
					$fresh = get_user_meta( $user->ID, 'nyms_2fa_show_codes', true );

					if ( is_array( $fresh ) && $fresh ) {
						delete_user_meta( $user->ID, 'nyms_2fa_show_codes' );
						?>
						<div class="notice notice-warning inline" style="margin-top:10px;padding:10px;">
							<p><strong><?php esc_html_e( 'Write these down now. They are not shown again.', 'newyorkmechanics-security' ); ?></strong></p>
							<p><code style="line-height:2;"><?php echo esc_html( implode( '   ', $fresh ) ); ?></code></p>
						</div>
						<?php
					}
					?>
				</td>
			</tr>
		</table>
		<?php
	}

	/**
	 * Save the profile section.
	 *
	 * @param int $user_id User ID.
	 * @return void
	 */
	public function save_profile( $user_id ) {
		if ( get_current_user_id() !== (int) $user_id && ! current_user_can( 'edit_users' ) ) {
			return;
		}

		if ( ! isset( $_POST['nyms_2fa_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nyms_2fa_nonce'] ) ), 'nyms_2fa_profile' ) ) {
			return;
		}

		$method  = isset( $_POST['nyms_2fa_method'] ) ? sanitize_key( wp_unslash( $_POST['nyms_2fa_method'] ) ) : '';
		$confirm = isset( $_POST['nyms_2fa_confirm'] ) ? preg_replace( '/\D/', '', (string) wp_unslash( $_POST['nyms_2fa_confirm'] ) ) : '';
		$current = get_user_meta( $user_id, self::METHOD, true );

		if ( ! in_array( $method, array( '', 'totp', 'email' ), true ) ) {
			$method = '';
		}

		if ( 'totp' === $method && 'totp' !== $current ) {
			$secret = (string) get_user_meta( $user_id, self::SECRET, true );

			if ( ! self::verify_totp( $secret, $confirm ) ) {
				// Without a confirmed code the switch is refused, silently
				// leaving the account exactly as it was.
				$method = $current;

				add_action(
					'user_profile_update_errors',
					function ( $errors ) {
						$errors->add( 'nyms_2fa', __( 'The authenticator code did not match, so two-factor authentication was left switched off.', 'newyorkmechanics-security' ) );
					}
				);
			}
		}

		if ( $method !== $current ) {
			update_user_meta( $user_id, self::METHOD, $method );

			NYMS_Log::record(
				'2fa_changed',
				'' === $method ? NYMS_Log::WARNING : NYMS_Log::NOTICE,
				sprintf(
					/* translators: 1: user ID, 2: method. */
					__( 'Two-factor authentication for user %1$d was set to: %2$s', 'newyorkmechanics-security' ),
					$user_id,
					'' === $method ? __( 'off', 'newyorkmechanics-security' ) : $method
				),
				array( 'user_id' => $user_id, 'by' => get_current_user_id() )
			);
		}

		if ( ! empty( $_POST['nyms_2fa_new_codes'] ) ) {
			$this->issue_recovery_codes( $user_id );
		}
	}

	/**
	 * Make and store a fresh set of recovery codes.
	 *
	 * @param int $user_id User ID.
	 * @return array The plain codes, shown once.
	 */
	public function issue_recovery_codes( $user_id ) {
		$plain  = array();
		$hashed = array();

		for ( $i = 0; $i < 8; $i++ ) {
			$code     = strtolower( wp_generate_password( 10, false, false ) );
			$plain[]  = $code;
			$hashed[] = wp_hash_password( $code );
		}

		update_user_meta( $user_id, self::RECOVERY, $hashed );
		update_user_meta( $user_id, 'nyms_2fa_show_codes', $plain );

		return $plain;
	}

	/**
	 * Remind administrators who have not turned it on.
	 *
	 * @return void
	 */
	public function nag() {
		if ( ! current_user_can( 'manage_options' ) || self::is_enabled( get_current_user_id() ) ) {
			return;
		}

		printf(
			'<div class="notice notice-warning"><p>%s <a href="%s">%s</a></p></div>',
			esc_html__( 'Your administrator account has no second factor. A stolen password is enough to take over this site.', 'newyorkmechanics-security' ),
			esc_url( admin_url( 'profile.php#nyms-2fa' ) ),
			esc_html__( 'Set it up now', 'newyorkmechanics-security' )
		);
	}

	/**
	 * A new base32 secret.
	 *
	 * @return string
	 */
	public static function generate_secret() {
		$alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
		$secret   = '';

		for ( $i = 0; $i < 32; $i++ ) {
			$secret .= $alphabet[ wp_rand( 0, 31 ) ];
		}

		return $secret;
	}

	/**
	 * Verify a TOTP code against a secret.
	 *
	 * @param string $secret Base32 secret.
	 * @param string $code   Six-digit code.
	 * @param int    $window How many 30-second steps of drift to accept.
	 * @return bool
	 */
	public static function verify_totp( $secret, $code, $window = 1 ) {
		$code = preg_replace( '/\D/', '', (string) $code );

		if ( strlen( $code ) !== 6 || '' === $secret ) {
			return false;
		}

		$key = self::base32_decode( $secret );

		if ( '' === $key ) {
			return false;
		}

		$step = (int) floor( time() / 30 );

		for ( $offset = -$window; $offset <= $window; $offset++ ) {
			if ( hash_equals( self::totp_at( $key, $step + $offset ), $code ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * The six-digit code for one time step.
	 *
	 * @param string $key  Raw secret.
	 * @param int    $step Time step.
	 * @return string
	 */
	private static function totp_at( $key, $step ) {
		// An eight-byte big-endian counter, built without 64-bit pack codes so
		// this still works on a 32-bit build.
		$counter = str_repeat( "\0", 4 ) . pack( 'N*', $step );

		$hash   = hash_hmac( 'sha1', $counter, $key, true );
		$offset = ord( substr( $hash, -1 ) ) & 0x0f;

		$value = ( ( ord( $hash[ $offset ] ) & 0x7f ) << 24 )
			| ( ( ord( $hash[ $offset + 1 ] ) & 0xff ) << 16 )
			| ( ( ord( $hash[ $offset + 2 ] ) & 0xff ) << 8 )
			| ( ord( $hash[ $offset + 3 ] ) & 0xff );

		return str_pad( (string) ( $value % 1000000 ), 6, '0', STR_PAD_LEFT );
	}

	/**
	 * Decode a base32 string.
	 *
	 * @param string $input Base32 text.
	 * @return string Raw bytes, empty on error.
	 */
	public static function base32_decode( $input ) {
		$alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
		$input    = strtoupper( str_replace( array( '=', ' ', '-' ), '', (string) $input ) );

		if ( '' === $input ) {
			return '';
		}

		$bits = '';

		for ( $i = 0, $length = strlen( $input ); $i < $length; $i++ ) {
			$position = strpos( $alphabet, $input[ $i ] );

			if ( false === $position ) {
				return '';
			}

			$bits .= str_pad( decbin( $position ), 5, '0', STR_PAD_LEFT );
		}

		$output = '';

		foreach ( str_split( $bits, 8 ) as $byte ) {
			if ( strlen( $byte ) === 8 ) {
				$output .= chr( bindec( $byte ) );
			}
		}

		return $output;
	}
}

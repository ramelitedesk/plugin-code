<?php
/**
 * Login hardening.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Slows down credential stuffing, removes the hints WordPress gives about
 * which half of a login was wrong, and refuses weak passwords on accounts
 * that can publish or install anything.
 */
class NYMS_Login_Guard {

	/**
	 * Transient prefix for failure counters.
	 */
	const PREFIX = 'nyms_la_';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register() {
		if ( NYMS_LOGIN_GUARD ) {
			add_filter( 'authenticate', array( $this, 'check_lockout' ), 30, 3 );
			add_action( 'wp_login_failed', array( $this, 'record_failure' ) );
			add_action( 'wp_login', array( $this, 'clear_failures' ), 10, 2 );

			// Never confirm that a user name exists.
			add_filter( 'authenticate', array( $this, 'generic_error' ), 999, 3 );
			add_filter( 'wp_login_errors', array( $this, 'generic_notice' ), 99, 2 );
			add_filter( 'shake_error_codes', array( $this, 'shake_codes' ) );

			// Do not let a login form remember which user failed.
			add_filter( 'login_form_defaults', array( $this, 'clear_remembered_user' ) );
		}

		if ( NYMS_STRONG_PASSWORDS ) {
			add_action( 'user_profile_update_errors', array( $this, 'validate_profile_password' ), 10, 3 );
			add_filter( 'registration_errors', array( $this, 'validate_registration_password' ), 10, 3 );
			add_action( 'validate_password_reset', array( $this, 'validate_reset_password' ), 10, 2 );
		}
	}

	/**
	 * Transient key for the current client.
	 *
	 * @return string
	 */
	private function key() {
		return self::PREFIX . NYMS_Helpers::ip_key( NYMS_Helpers::client_ip() );
	}

	/**
	 * Refuse authentication while the client is locked out.
	 *
	 * @param null|WP_User|WP_Error $user     Current result.
	 * @param string                $username Submitted user name.
	 * @param string                $password Submitted password.
	 * @return null|WP_User|WP_Error
	 */
	public function check_lockout( $user, $username, $password ) {
		if ( empty( $username ) && empty( $password ) ) {
			return $user;
		}

		$attempts = (int) get_transient( $this->key() );

		if ( $attempts < (int) NYMS_LOGIN_MAX_ATTEMPTS ) {
			return $user;
		}

		return new WP_Error(
			'nyms_locked_out',
			sprintf(
				/* translators: %d: number of minutes. */
				__( 'Too many failed sign-in attempts. Please try again in %d minutes.', 'newyorkmechanics-security' ),
				max( 1, (int) round( NYMS_LOGIN_LOCKOUT / 60 ) )
			)
		);
	}

	/**
	 * Count a failed attempt.
	 *
	 * @param string $username Attempted user name.
	 * @return void
	 */
	public function record_failure( $username ) {
		unset( $username );

		$key      = $this->key();
		$attempts = (int) get_transient( $key ) + 1;

		set_transient( $key, $attempts, (int) NYMS_LOGIN_LOCKOUT );
	}

	/**
	 * Reset the counter after a successful sign-in.
	 *
	 * @param string       $user_login User name.
	 * @param WP_User|null $user       User object.
	 * @return void
	 */
	public function clear_failures( $user_login, $user = null ) {
		unset( $user_login, $user );

		delete_transient( $this->key() );
	}

	/**
	 * Collapse "unknown user" and "wrong password" into one answer.
	 *
	 * Distinct messages let an attacker confirm which accounts exist before
	 * spending any attempts on passwords.
	 *
	 * @param null|WP_User|WP_Error $user     Authentication result.
	 * @param string                $username Submitted user name.
	 * @param string                $password Submitted password.
	 * @return null|WP_User|WP_Error
	 */
	public function generic_error( $user, $username, $password ) {
		unset( $username, $password );

		if ( ! is_wp_error( $user ) ) {
			return $user;
		}

		$leaky = array(
			'invalid_username',
			'invalid_email',
			'incorrect_password',
			'invalidcombo',
			'invalid_user_password',
		);

		if ( ! array_intersect( $leaky, $user->get_error_codes() ) ) {
			return $user;
		}

		return new WP_Error(
			'nyms_invalid_credentials',
			__( '<strong>Error</strong>: The user name or password you entered is incorrect.', 'newyorkmechanics-security' )
		);
	}

	/**
	 * Do not confirm whether an address is registered on the lost password form.
	 *
	 * @param WP_Error $errors   Error object.
	 * @param string   $redirect Redirect target.
	 * @return WP_Error
	 */
	public function generic_notice( $errors, $redirect ) {
		unset( $redirect );

		if ( ! is_wp_error( $errors ) ) {
			return $errors;
		}

		foreach ( array( 'invalidcombo', 'invalid_email', 'invalid_username' ) as $code ) {
			if ( in_array( $code, $errors->get_error_codes(), true ) ) {
				return new WP_Error(
					'nyms_generic',
					__( 'If that account exists, a reset link has been sent.', 'newyorkmechanics-security' )
				);
			}
		}

		return $errors;
	}

	/**
	 * Keep the form shaking on our own error code too.
	 *
	 * @param array $codes Error codes.
	 * @return array
	 */
	public function shake_codes( $codes ) {
		$codes[] = 'nyms_locked_out';
		$codes[] = 'nyms_generic';
		$codes[] = 'nyms_invalid_credentials';
		$codes[] = 'nyms_weak_password';

		return $codes;
	}

	/**
	 * Never pre-fill the user name field from a failed attempt.
	 *
	 * @param array $defaults Login form defaults.
	 * @return array
	 */
	public function clear_remembered_user( $defaults ) {
		$defaults['value_username'] = '';

		return $defaults;
	}

	/**
	 * Enforce the password policy when a profile is saved.
	 *
	 * @param WP_Error $errors Error object.
	 * @param bool     $update Whether this is an existing user.
	 * @param stdClass $user   User data being saved.
	 * @return void
	 */
	public function validate_profile_password( $errors, $update, $user ) {
		unset( $update );

		if ( empty( $user->user_pass ) ) {
			return;
		}

		$role = isset( $user->role ) ? $user->role : '';

		$this->add_password_error( $errors, $user->user_pass, $role );
	}

	/**
	 * Enforce the password policy on self-registration.
	 *
	 * @param WP_Error $errors Error object.
	 * @param string   $login  Sanitised user name.
	 * @param string   $email  Submitted address.
	 * @return WP_Error
	 */
	public function validate_registration_password( $errors, $login, $email ) {
		unset( $login, $email );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( ! empty( $_POST['pass1'] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$this->add_password_error( $errors, (string) wp_unslash( $_POST['pass1'] ), '' );
		}

		return $errors;
	}

	/**
	 * Enforce the password policy on reset.
	 *
	 * @param WP_Error         $errors Error object.
	 * @param WP_User|WP_Error $user   User being reset.
	 * @return void
	 */
	public function validate_reset_password( $errors, $user ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( empty( $_POST['pass1'] ) ) {
			return;
		}

		$role = ( $user instanceof WP_User && ! empty( $user->roles ) ) ? (string) reset( $user->roles ) : '';

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$this->add_password_error( $errors, (string) wp_unslash( $_POST['pass1'] ), $role );
	}

	/**
	 * Apply the policy and register an error when the password is too weak.
	 *
	 * @param WP_Error $errors   Error object.
	 * @param string   $password Proposed password.
	 * @param string   $role     Role slug, when known.
	 * @return void
	 */
	private function add_password_error( $errors, $password, $role ) {
		if ( ! is_wp_error( $errors ) ) {
			return;
		}

		$minimum = $this->minimum_length( $role );

		/**
		 * Filter the password policy.
		 *
		 * @param int    $minimum  Minimum length.
		 * @param string $role     Role slug.
		 */
		$minimum = (int) apply_filters( 'nyms_minimum_password_length', $minimum, $role );

		$classes = 0;
		$classes += preg_match( '/[a-z]/', $password );
		$classes += preg_match( '/[A-Z]/', $password );
		$classes += preg_match( '/[0-9]/', $password );
		$classes += preg_match( '/[^a-zA-Z0-9]/', $password );

		if ( strlen( $password ) < $minimum || $classes < 3 ) {
			$errors->add(
				'nyms_weak_password',
				sprintf(
					/* translators: %d: minimum password length. */
					__( '<strong>Error</strong>: The password must be at least %d characters long and mix upper case, lower case, numbers and symbols.', 'newyorkmechanics-security' ),
					$minimum
				)
			);
		}
	}

	/**
	 * Longer passwords for accounts that can change the site.
	 *
	 * @param string $role Role slug.
	 * @return int
	 */
	private function minimum_length( $role ) {
		$privileged = array( 'administrator', 'editor', 'author', 'shop_manager' );

		return in_array( (string) $role, $privileged, true ) ? 14 : 10;
	}
}

<?php
/**
 * Self-protection.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A security plugin is the first thing an intruder switches off.
 *
 * This module watches the plugin's own files, tables, options, log and
 * quarantine, refuses to be deactivated or deleted by anything that is not a
 * deliberate administrator action, and shouts when any of that is attempted.
 */
class NYMS_Self_Protect {

	/**
	 * Option holding the hashes of the plugin's own files.
	 */
	const HASHES = 'nyms_self_hashes';

	/**
	 * Option that has to be set before the plugin can be switched off.
	 */
	const UNLOCK = 'nyms_allow_deactivation';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! NYMS_SELF_PROTECT ) {
			return;
		}

		add_action( 'admin_init', array( $this, 'verify' ) );
		add_action( 'nyms_self_check', array( $this, 'verify' ) );

		add_filter( 'plugin_action_links_' . NYMS_BASENAME, array( $this, 'guard_links' ), 100 );
		add_filter( 'pre_update_option_active_plugins', array( $this, 'refuse_deactivation' ), 20, 2 );
		add_filter( 'user_has_cap', array( $this, 'refuse_deletion' ), 10, 4 );

		// Nothing may edit our options from the front of the site.
		add_filter( 'pre_update_option_' . NYMS_Settings::OPTION, array( $this, 'guard_settings_write' ), 10, 2 );
	}

	/**
	 * Files that make up the plugin, hashed.
	 *
	 * @return array relative path => sha256.
	 */
	public function fingerprint() {
		$hashes = array();
		$root   = wp_normalize_path( trailingslashit( NYMS_PATH ) );

		try {
			$iterator = new RecursiveIteratorIterator(
				new RecursiveDirectoryIterator( NYMS_PATH, FilesystemIterator::SKIP_DOTS | FilesystemIterator::UNIX_PATHS ),
				RecursiveIteratorIterator::LEAVES_ONLY,
				RecursiveIteratorIterator::CATCH_GET_CHILD
			);
		} catch ( Exception $e ) {
			return $hashes;
		}

		foreach ( $iterator as $file ) {
			if ( ! $file->isFile() ) {
				continue;
			}

			$path = wp_normalize_path( $file->getPathname() );

			$hashes[ str_replace( $root, '', $path ) ] = (string) @hash_file( 'sha256', $path );
		}

		ksort( $hashes );

		return $hashes;
	}

	/**
	 * Store the current state as the trusted one.
	 *
	 * @return void
	 */
	public function record() {
		update_option( self::HASHES, $this->fingerprint(), false );
	}

	/**
	 * Check everything the plugin owns.
	 *
	 * @return array Problems found.
	 */
	public function verify() {
		if ( get_transient( 'nyms_self_checked' ) ) {
			return array();
		}

		set_transient( 'nyms_self_checked', 1, HOUR_IN_SECONDS );

		$problems = array();

		$problems = array_merge( $problems, $this->verify_files() );
		$problems = array_merge( $problems, $this->verify_storage() );

		foreach ( $problems as $problem ) {
			NYMS_Log::record( 'self_protect', NYMS_Log::CRITICAL, $problem );
		}

		update_option( 'nyms_self_status', array( 'at' => time(), 'problems' => $problems ), false );

		return $problems;
	}

	/**
	 * Compare the plugin's files against the recorded hashes.
	 *
	 * @return array
	 */
	public function verify_files() {
		$known = get_option( self::HASHES, array() );

		if ( ! is_array( $known ) || ! $known ) {
			$this->record();

			return array();
		}

		$now      = $this->fingerprint();
		$problems = array();

		foreach ( $known as $relative => $hash ) {
			if ( ! isset( $now[ $relative ] ) ) {
				$problems[] = sprintf(
					/* translators: %s: file name. */
					__( 'A file belonging to the security plugin has been deleted: %s', 'newyorkmechanics-security' ),
					$relative
				);

				continue;
			}

			if ( $now[ $relative ] !== $hash ) {
				$problems[] = sprintf(
					/* translators: %s: file name. */
					__( 'A file belonging to the security plugin has been modified: %s', 'newyorkmechanics-security' ),
					$relative
				);
			}
		}

		foreach ( $now as $relative => $hash ) {
			unset( $hash );

			if ( ! isset( $known[ $relative ] ) ) {
				$problems[] = sprintf(
					/* translators: %s: file name. */
					__( 'A file that is not part of the security plugin appeared in its folder: %s', 'newyorkmechanics-security' ),
					$relative
				);
			}
		}

		return $problems;
	}

	/**
	 * Check that the tables, the log and the quarantine are still there.
	 *
	 * @return array
	 */
	public function verify_storage() {
		global $wpdb;

		$problems = array();

		$table = NYMS_Log::table();
		$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ); // phpcs:ignore WordPress.DB

		if ( $found !== $table ) {
			$problems[] = sprintf(
				/* translators: %s: table name. */
				__( 'The security plugin table %s is missing and has been recreated.', 'newyorkmechanics-security' ),
				$table
			);

			NYMS_Log::install();
		}

		// The plugin's own folder must not be browsable or directly runnable.
		$this->protect_own_directory();

		return $problems;
	}

	/**
	 * Drop a deny rule into the plugin's include folder.
	 *
	 * The files there are only ever loaded by PHP from the main plugin file;
	 * nothing should be able to request them over the web.
	 *
	 * @return void
	 */
	public function protect_own_directory() {
		$targets = array( trailingslashit( NYMS_PATH ) . 'includes/.htaccess' );

		$rules = "# These files are loaded by PHP, never requested directly.\n"
			. "<FilesMatch \"\\.(php|inc)$\">\n"
			. "<IfModule mod_authz_core.c>\n\tRequire all denied\n</IfModule>\n"
			. "<IfModule !mod_authz_core.c>\n\tOrder allow,deny\n\tDeny from all\n</IfModule>\n"
			. "</FilesMatch>\n"
			. "Options -Indexes\n";

		foreach ( $targets as $file ) {
			if ( file_exists( $file ) || ! is_dir( dirname( $file ) ) || ! is_writable( dirname( $file ) ) ) {
				continue;
			}

			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			@file_put_contents( $file, $rules );
		}
	}

	/**
	 * Replace the deactivate link with a warning until the lock is lifted.
	 *
	 * @param array $links Action links.
	 * @return array
	 */
	public function guard_links( $links ) {
		if ( $this->deactivation_allowed() ) {
			return $links;
		}

		unset( $links['deactivate'] );

		$links['nyms_locked'] = '<span title="' . esc_attr__( 'Tick "allow this plugin to be switched off" on the Security screen first.', 'newyorkmechanics-security' ) . '" style="color:#996800;">'
			. esc_html__( 'Protected', 'newyorkmechanics-security' )
			. '</span>';

		return $links;
	}

	/**
	 * Whether the administrator has unlocked deactivation.
	 *
	 * @return bool
	 */
	public function deactivation_allowed() {
		$until = (int) get_option( self::UNLOCK, 0 );

		return $until > time();
	}

	/**
	 * Open the lock for fifteen minutes.
	 *
	 * @return void
	 */
	public static function unlock() {
		update_option( self::UNLOCK, time() + ( 15 * MINUTE_IN_SECONDS ), false );

		NYMS_Log::record(
			'self_unlocked',
			NYMS_Log::CRITICAL,
			__( 'The security plugin was unlocked so it can be deactivated or deleted. The lock closes again in fifteen minutes.', 'newyorkmechanics-security' ),
			array( 'by' => get_current_user_id() )
		);
	}

	/**
	 * Refuse to be removed from the active plugin list.
	 *
	 * @param array $value New value.
	 * @param array $old   Old value.
	 * @return array
	 */
	public function refuse_deactivation( $value, $old ) {
		if ( ! is_array( $value ) || ! is_array( $old ) ) {
			return $value;
		}

		if ( ! in_array( NYMS_BASENAME, $old, true ) || in_array( NYMS_BASENAME, $value, true ) ) {
			return $value;
		}

		if ( $this->deactivation_allowed() ) {
			return $value;
		}

		NYMS_Log::record(
			'self_deactivation_blocked',
			NYMS_Log::CRITICAL,
			__( 'Something tried to deactivate the security plugin. The attempt was refused.', 'newyorkmechanics-security' ),
			array( 'by' => get_current_user_id(), 'ip' => NYMS_Helpers::client_ip() )
		);

		$value[] = NYMS_BASENAME;

		return $value;
	}

	/**
	 * Refuse the capability that would delete this plugin's files.
	 *
	 * @param array   $allcaps All capabilities of the user.
	 * @param array   $caps    Required primitive capabilities.
	 * @param array   $args    Arguments: capability, user ID, object ID.
	 * @param WP_User $user    The user.
	 * @return array
	 */
	public function refuse_deletion( $allcaps, $caps, $args, $user ) {
		unset( $caps, $user );

		if ( empty( $args[0] ) || 'delete_plugins' !== $args[0] ) {
			return $allcaps;
		}

		if ( $this->deactivation_allowed() ) {
			return $allcaps;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$request = isset( $_REQUEST['checked'] ) ? (array) wp_unslash( $_REQUEST['checked'] ) : array();

		foreach ( $request as $plugin ) {
			if ( NYMS_BASENAME === $plugin ) {
				NYMS_Log::record(
					'self_deletion_blocked',
					NYMS_Log::CRITICAL,
					__( 'Something tried to delete the security plugin. The attempt was refused.', 'newyorkmechanics-security' ),
					array( 'by' => get_current_user_id() )
				);

				$allcaps['delete_plugins'] = false;
			}
		}

		return $allcaps;
	}

	/**
	 * Only an administrator inside wp-admin may rewrite the settings.
	 *
	 * @param mixed $value New value.
	 * @param mixed $old   Old value.
	 * @return mixed
	 */
	public function guard_settings_write( $value, $old ) {
		if ( is_admin() && current_user_can( 'manage_options' ) ) {
			return $value;
		}

		if ( ( defined( 'WP_CLI' ) && WP_CLI ) || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) {
			return $value;
		}

		NYMS_Log::record(
			'self_settings_write_blocked',
			NYMS_Log::CRITICAL,
			__( 'Something outside the settings screen tried to rewrite the security settings. The write was refused.', 'newyorkmechanics-security' ),
			array( 'ip' => NYMS_Helpers::client_ip(), 'path' => NYMS_Helpers::request_path() )
		);

		return $old;
	}

	/**
	 * The stored result of the last self check.
	 *
	 * @return array
	 */
	public static function status() {
		$status = get_option( 'nyms_self_status', array() );

		return is_array( $status ) ? $status : array();
	}
}

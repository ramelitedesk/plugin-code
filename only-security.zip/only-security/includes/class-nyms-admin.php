<?php
/**
 * Admin screen: settings, status and the tools that act on what was found.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the plugin's screen.
 *
 * Saving and every action are guarded by a capability check and a nonce, and
 * any switch defined in wp-config.php is refused here - the file the web
 * server never serves always wins over the browser.
 */
class NYMS_Admin {

	/**
	 * Menu slug.
	 */
	const SLUG = 'nyms-security';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_menu', array( $this, 'add_page' ) );
		add_action( 'admin_post_nyms_save', array( $this, 'handle_save' ) );
		add_action( 'admin_post_nyms_action', array( $this, 'handle_action' ) );
		add_action( 'admin_init', array( $this, 'maybe_sync_rules' ) );
		add_action( 'admin_notices', array( $this, 'critical_notice' ) );
		add_filter( 'plugin_action_links_' . NYMS_BASENAME, array( $this, 'action_link' ) );
		add_filter( 'all_plugins', array( $this, 'filter_plugin_name' ) );
	}

	/**
	 * Show the plugin under the site's own name in the plugin list.
	 *
	 * @param array $plugins Plugin data keyed by basename.
	 * @return array
	 */
	public function filter_plugin_name( $plugins ) {
		if ( ! is_array( $plugins ) || ! isset( $plugins[ NYMS_BASENAME ] ) ) {
			return $plugins;
		}

		$name = NYMS_Helpers::plugin_name();

		$plugins[ NYMS_BASENAME ]['Name']  = $name;
		$plugins[ NYMS_BASENAME ]['Title'] = $name;

		return $plugins;
	}

	/**
	 * Add the screen under Tools.
	 *
	 * @return void
	 */
	public function add_page() {
		$counts = NYMS_Log::counts( 1 );
		$bubble = isset( $counts[ NYMS_Log::CRITICAL ] ) ? (int) $counts[ NYMS_Log::CRITICAL ] : 0;

		$title = __( 'Security', 'newyorkmechanics-security' );

		if ( $bubble ) {
			$title .= ' <span class="update-plugins count-' . $bubble . '"><span class="update-count">' . number_format_i18n( $bubble ) . '</span></span>';
		}

		add_management_page(
			NYMS_Helpers::plugin_name(),
			$title,
			'manage_options',
			self::SLUG,
			array( $this, 'render' )
		);
	}

	/**
	 * Add a shortcut from the plugin list.
	 *
	 * @param array $links Existing links.
	 * @return array
	 */
	public function action_link( $links ) {
		if ( ! is_array( $links ) ) {
			$links = array();
		}

		array_unshift(
			$links,
			'<a href="' . esc_url( $this->url() ) . '">' . esc_html__( 'Settings', 'newyorkmechanics-security' ) . '</a>'
		);

		return $links;
	}

	/**
	 * URL of the screen.
	 *
	 * @param string $tab   Tab to open.
	 * @param array  $extra Extra query arguments.
	 * @return string
	 */
	private function url( $tab = '', $extra = array() ) {
		$args = array( 'page' => self::SLUG );

		if ( '' !== $tab ) {
			$args['tab'] = $tab;
		}

		return add_query_arg( array_merge( $args, $extra ), admin_url( 'tools.php' ) );
	}

	/**
	 * The tabs, in order.
	 *
	 * @return array
	 */
	private function tabs() {
		return array(
			'overview' => __( 'Overview', 'newyorkmechanics-security' ),
			'settings' => __( 'Settings', 'newyorkmechanics-security' ),
			'events'   => __( 'Event log', 'newyorkmechanics-security' ),
			'self'     => __( 'Self-protection', 'newyorkmechanics-security' ),
			'plugins'  => __( 'Plugins', 'newyorkmechanics-security' ),
			'accounts' => __( 'Accounts', 'newyorkmechanics-security' ),
			'firewall' => __( 'Firewall', 'newyorkmechanics-security' ),
			'network'  => __( 'Network', 'newyorkmechanics-security' ),
			'server'   => __( 'Server rules', 'newyorkmechanics-security' ),
		);
	}

	/**
	 * The tab currently being shown.
	 *
	 * @return string
	 */
	private function current_tab() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only navigation.
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'overview';
		$tabs = $this->tabs();

		return isset( $tabs[ $tab ] ) ? $tab : 'overview';
	}

	/**
	 * Save the submitted settings.
	 *
	 * @return void
	 */
	public function handle_save() {
		$this->authorise( 'nyms_save' );

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each value is validated against its own definition in NYMS_Settings::save().
		$input = isset( $_POST['nyms'] ) && is_array( $_POST['nyms'] ) ? wp_unslash( $_POST['nyms'] ) : array();

		NYMS_Settings::save( $input );

		if ( isset( $_POST['nyms_alert_address'] ) ) {
			$address = sanitize_email( wp_unslash( $_POST['nyms_alert_address'] ) );

			update_option( 'nyms_alert_address', is_email( $address ) ? $address : '', false );
		}

		$lists = array(
			'nyms_ip_allowlist'      => NYMS_Firewall::ALLOWED,
			'nyms_ip_blocklist'      => NYMS_Firewall::DENIED,
			'nyms_blocked_countries' => NYMS_Firewall::COUNTRIES,
			'nyms_blocked_agents'    => NYMS_Firewall::AGENTS,
			'nyms_domain_allowlist'  => NYMS_Network_Guard::ALLOWED,
			'nyms_domain_blocklist'  => NYMS_Network_Guard::DENIED,
			'nyms_plugin_sources'    => NYMS_Plugin_Guard::SOURCES,
		);

		foreach ( $lists as $field => $option ) {
			if ( isset( $_POST[ $field ] ) ) {
				// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitised per line in save_list().
				NYMS_Firewall::save_list( $option, wp_unslash( $_POST[ $field ] ) );
			}
		}

		// The constants for this request already hold the old values, so the
		// server rules are rewritten on the next load instead.
		set_transient( 'nyms_sync_rules', 1, 5 * MINUTE_IN_SECONDS );
		delete_transient( 'nyms_protection_checked' );

		$this->done( 'settings', __( 'Settings saved.', 'newyorkmechanics-security' ) );
	}

	/**
	 * Run one of the actions offered on the screen.
	 *
	 * @return void
	 */
	public function handle_action() {
		$this->authorise( 'nyms_action' );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked in authorise().
		$do = isset( $_REQUEST['do'] ) ? sanitize_key( wp_unslash( $_REQUEST['do'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$target = isset( $_REQUEST['target'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['target'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$tab = isset( $_REQUEST['tab'] ) ? sanitize_key( wp_unslash( $_REQUEST['tab'] ) ) : 'overview';

		$plugin  = NYMS_Plugin::instance();
		$message = __( 'Done.', 'newyorkmechanics-security' );

		switch ( $do ) {
			case 'plugin_audit':
				$packages = $plugin->module( 'packages' );

				if ( $packages instanceof NYMS_Plugin_Guard ) {
					$report = $packages->audit();

					$message = sprintf(
						/* translators: %d: number of plugins. */
						__( '%d plugins checked.', 'newyorkmechanics-security' ),
						count( $report )
					);
				}
				break;

			case 'approve':
				NYMS_Plugin_Guard::approve( $target );

				$message = __( 'Plugin approved.', 'newyorkmechanics-security' );
				break;

			case 'revoke':
				NYMS_Plugin_Guard::revoke( $target );

				$message = __( 'Approval withdrawn.', 'newyorkmechanics-security' );
				break;

			case 'blocklist':
				NYMS_Plugin_Guard::block( $target, __( 'blocked by an administrator', 'newyorkmechanics-security' ) );

				$message = __( 'Plugin added to the blocklist.', 'newyorkmechanics-security' );
				break;

			case 'unblocklist':
				NYMS_Plugin_Guard::block( $target, '' );

				$message = __( 'Plugin removed from the blocklist.', 'newyorkmechanics-security' );
				break;

			case 'user_audit':
				$users = $plugin->module( 'users' );

				if ( $users instanceof NYMS_User_Guard ) {
					$users->audit();

					$message = __( 'Accounts checked.', 'newyorkmechanics-security' );
				}
				break;

			case 'disable_user':
				NYMS_User_Guard::set_disabled( (int) $target, true );

				$message = __( 'Account disabled and its sessions ended.', 'newyorkmechanics-security' );
				break;

			case 'enable_user':
				NYMS_User_Guard::set_disabled( (int) $target, false );

				$message = __( 'Account re-enabled.', 'newyorkmechanics-security' );
				break;

			case 'logout_user':
				NYMS_User_Guard::force_logout( (int) $target );

				$message = __( 'Every session for that account was ended.', 'newyorkmechanics-security' );
				break;

			case 'unblock_ip':
				NYMS_Firewall::unblock( $target );

				$message = __( 'The block was lifted.', 'newyorkmechanics-security' );
				break;

			case 'block_ip':
				$firewall = $plugin->module( 'firewall' );

				if ( $firewall instanceof NYMS_Firewall && filter_var( $target, FILTER_VALIDATE_IP ) ) {
					$firewall->block_ip( $target, __( 'blocked by an administrator', 'newyorkmechanics-security' ), WEEK_IN_SECONDS, 3 );

					$message = __( 'Address blocked for a week.', 'newyorkmechanics-security' );
				}
				break;

			case 'clear_log':
				NYMS_Log::clear();

				$message = __( 'The event log was emptied.', 'newyorkmechanics-security' );
				break;

			case 'self_check':
				$self = $plugin->module( 'self' );

				if ( $self instanceof NYMS_Self_Protect ) {
					delete_transient( 'nyms_self_checked' );

					$problems = $self->verify();

					$message = $problems
						? sprintf(
							/* translators: %d: number of problems. */
							__( 'The plugin found %d problems with its own files or storage.', 'newyorkmechanics-security' ),
							count( $problems )
						)
						: __( 'The plugin verified its own files, tables and quarantine. Everything is as it should be.', 'newyorkmechanics-security' );
				}
				break;

			case 'self_record':
				$self = $plugin->module( 'self' );

				if ( $self instanceof NYMS_Self_Protect ) {
					$self->record();

					$message = __( 'The plugin recorded its current files as trusted.', 'newyorkmechanics-security' );
				}
				break;

			case 'unlock':
				NYMS_Self_Protect::unlock();

				$message = __( 'The plugin is unlocked for fifteen minutes and can now be deactivated or deleted.', 'newyorkmechanics-security' );
				break;

			default:
				$message = __( 'Nothing to do.', 'newyorkmechanics-security' );
		}

		$this->done( $tab, $message );
	}

	/**
	 * Check the capability and the nonce, or stop.
	 *
	 * @param string $action Nonce action.
	 * @return void
	 */
	private function authorise( $action ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to change these settings.', 'newyorkmechanics-security' ) );
		}

		check_admin_referer( $action );
	}

	/**
	 * Store a message and go back to the screen.
	 *
	 * @param string $tab     Tab to return to.
	 * @param string $message Message to show.
	 * @return void
	 */
	private function done( $tab, $message ) {
		set_transient( 'nyms_notice_' . get_current_user_id(), $message, 60 );

		wp_safe_redirect( $this->url( $tab ) );

		exit;
	}

	/**
	 * A link that performs an action.
	 *
	 * @param string $do     Action name.
	 * @param string $target Target value.
	 * @param string $tab    Tab to return to.
	 * @return string
	 */
	private function action_url( $do, $target = '', $tab = '' ) {
		$args = array(
			'action' => 'nyms_action',
			'do'     => $do,
			'target' => $target,
			'tab'    => '' === $tab ? $this->current_tab() : $tab,
		);

		return wp_nonce_url( add_query_arg( $args, admin_url( 'admin-post.php' ) ), 'nyms_action' );
	}

	/**
	 * A button that performs an action.
	 *
	 * @param string $do      Action name.
	 * @param string $label   Button label.
	 * @param string $target  Target value.
	 * @param string $classes Extra CSS classes.
	 * @return void
	 */
	private function button( $do, $label, $target = '', $classes = 'button' ) {
		printf(
			'<a class="%1$s" href="%2$s">%3$s</a> ',
			esc_attr( $classes ),
			esc_url( $this->action_url( $do, $target ) ),
			esc_html( $label )
		);
	}

	/**
	 * Bring the .htaccess rules in line after a save.
	 *
	 * @return void
	 */
	public function maybe_sync_rules() {
		if ( ! get_transient( 'nyms_sync_rules' ) ) {
			return;
		}

		delete_transient( 'nyms_sync_rules' );

		if ( NYMS_MANAGE_HTACCESS ) {
			NYMS_Htaccess::install();
		} else {
			NYMS_Htaccess::uninstall();
		}
	}

	/**
	 * Put a critical event in front of an administrator wherever they are.
	 *
	 * @return void
	 */
	public function critical_notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		if ( $screen && 'tools_page_' . self::SLUG === $screen->id ) {
			return;
		}

		$events = NYMS_Log::query(
			array(
				'severity' => NYMS_Log::CRITICAL,
				'limit'    => 3,
				'since'    => gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS ),
			)
		);

		if ( ! $events ) {
			return;
		}

		echo '<div class="notice notice-error"><p><strong>'
			. esc_html__( 'Security: something happened in the last day that needs looking at.', 'newyorkmechanics-security' )
			. '</strong></p><ul style="margin-left:20px;list-style:disc;">';

		foreach ( $events as $event ) {
			echo '<li>' . esc_html( $event->message ) . '</li>';
		}

		echo '</ul><p><a class="button button-primary" href="' . esc_url( $this->url( 'events' ) ) . '">'
			. esc_html__( 'Open the event log', 'newyorkmechanics-security' )
			. '</a></p></div>';
	}

	/**
	 * Render the screen.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'newyorkmechanics-security' ) );
		}

		$tab    = $this->current_tab();
		$notice = get_transient( 'nyms_notice_' . get_current_user_id() );

		if ( $notice ) {
			delete_transient( 'nyms_notice_' . get_current_user_id() );
		}
		?>
		<div class="wrap">
			<h1><?php echo esc_html( NYMS_Helpers::plugin_name() ); ?></h1>

			<?php if ( $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $notice ); ?></p></div>
			<?php endif; ?>

			<h2 class="nav-tab-wrapper">
				<?php foreach ( $this->tabs() as $key => $label ) : ?>
					<a class="nav-tab<?php echo $key === $tab ? ' nav-tab-active' : ''; ?>"
						href="<?php echo esc_url( $this->url( $key ) ); ?>"><?php echo esc_html( $label ); ?></a>
				<?php endforeach; ?>
			</h2>

			<div style="margin-top:16px;">
				<?php
				switch ( $tab ) {
					case 'settings':
						$this->tab_settings();
						break;

					case 'events':
						$this->tab_events();
						break;

					case 'self':
						$this->tab_self();
						break;

					case 'plugins':
						$this->tab_plugins();
						break;

					case 'accounts':
						$this->tab_accounts();
						break;

					case 'firewall':
						$this->tab_firewall();
						break;

					case 'network':
						$this->tab_network();
						break;

					case 'server':
						$this->tab_server();
						break;

					default:
						$this->tab_overview();
				}
				?>
			</div>
		</div>
		<?php
	}

	/**
	 * Overview tab.
	 *
	 * @return void
	 */
	private function tab_overview() {
		$counts   = NYMS_Log::counts( 7 );
		$self     = NYMS_Self_Protect::status();
		$audit    = NYMS_Plugin_Guard::last_audit();
		$warnings = $this->warnings();
		$blocked  = 0;

		foreach ( NYMS_Firewall::blocks() as $block ) {
			if ( $block['until'] > time() ) {
				$blocked++;
			}
		}
		?>
		<div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:20px;">
			<?php
			$this->tile( __( 'Critical, last 7 days', 'newyorkmechanics-security' ), (int) $counts[ NYMS_Log::CRITICAL ], NYMS_Log::severity_colour( NYMS_Log::CRITICAL ) );
			$this->tile( __( 'Warnings, last 7 days', 'newyorkmechanics-security' ), (int) $counts[ NYMS_Log::WARNING ], NYMS_Log::severity_colour( NYMS_Log::WARNING ) );
			$this->tile( __( 'Refusals, last 7 days', 'newyorkmechanics-security' ), (int) $counts[ NYMS_Log::NOTICE ], '#2271b1' );
			$this->tile( __( 'Addresses blocked now', 'newyorkmechanics-security' ), $blocked, $blocked ? '#996800' : '#007017' );
			?>
		</div>

		<p class="description" style="max-width:820px;">
			<?php esc_html_e( 'This plugin hardens the site: it closes the ways code gets in and records what it refused. It does not scan for malware already on the site - run a dedicated scanner for that.', 'newyorkmechanics-security' ); ?>
		</p>

		<?php if ( $warnings ) : ?>
			<div class="notice notice-warning">
				<p><strong><?php esc_html_e( 'Needs your attention in wp-config.php or on the server:', 'newyorkmechanics-security' ); ?></strong></p>
				<ul style="list-style:disc;margin-left:20px;">
					<?php foreach ( $warnings as $warning ) : ?>
						<li><?php echo esc_html( $warning ); ?></li>
					<?php endforeach; ?>
				</ul>
			</div>
		<?php endif; ?>

		<h2><?php esc_html_e( 'Last checks', 'newyorkmechanics-security' ); ?></h2>
		<table class="widefat striped" style="max-width:900px;">
			<tbody>
				<tr>
					<td style="width:34%;"><?php esc_html_e( 'Plugin audit', 'newyorkmechanics-security' ); ?></td>
					<td><?php echo esc_html( $this->when( isset( $audit['at'] ) ? $audit['at'] : 0 ) ); ?></td>
					<td>
						<?php
						printf(
							/* translators: %d: number of plugins. */
							esc_html__( '%d plugins', 'newyorkmechanics-security' ),
							isset( $audit['report'] ) ? count( $audit['report'] ) : 0
						);
						?>
					</td>
					<td><?php $this->button( 'plugin_audit', __( 'Run now', 'newyorkmechanics-security' ) ); ?></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Self check', 'newyorkmechanics-security' ); ?></td>
					<td><?php echo esc_html( $this->when( isset( $self['at'] ) ? $self['at'] : 0 ) ); ?></td>
					<td>
						<?php
						if ( empty( $self['problems'] ) ) {
							echo '<span style="color:#007017;font-weight:600;">' . esc_html__( 'Intact', 'newyorkmechanics-security' ) . '</span>';
						} else {
							echo '<span style="color:#8a2424;font-weight:600;">' . esc_html( implode( ' / ', array_slice( $self['problems'], 0, 2 ) ) ) . '</span>';
						}
						?>
					</td>
					<td><?php $this->button( 'self_check', __( 'Check now', 'newyorkmechanics-security' ) ); ?></td>
				</tr>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'Scheduled jobs', 'newyorkmechanics-security' ); ?></h2>
		<table class="widefat striped" style="max-width:900px;">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Job', 'newyorkmechanics-security' ); ?></th>
					<th><?php esc_html_e( 'How often', 'newyorkmechanics-security' ); ?></th>
					<th><?php esc_html_e( 'Next run', 'newyorkmechanics-security' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( NYMS_Plugin::schedule() as $hook => $job ) : ?>
					<tr>
						<td><code><?php echo esc_html( $hook ); ?></code></td>
						<td><?php echo esc_html( $job['recurrence'] ); ?></td>
						<td>
							<?php
							echo $job['next']
								? esc_html( $this->when( $job['next'] ) )
								: '<span style="color:#8a2424;">' . esc_html__( 'not scheduled', 'newyorkmechanics-security' ) . '</span>';
							?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'Most recent events', 'newyorkmechanics-security' ); ?></h2>
		<?php $this->events_table( NYMS_Log::query( array( 'limit' => 15 ) ) ); ?>
		<?php
	}

	/**
	 * One number in a box.
	 *
	 * @param string $label  Label.
	 * @param int    $value  Number.
	 * @param string $colour Accent colour.
	 * @return void
	 */
	private function tile( $label, $value, $colour ) {
		printf(
			'<div style="flex:1;min-width:180px;background:#fff;border:1px solid #c3c4c7;border-left:4px solid %1$s;padding:12px 16px;">
				<div style="font-size:26px;font-weight:600;color:%1$s;">%2$s</div>
				<div style="color:#50575e;">%3$s</div>
			</div>',
			esc_attr( $colour ),
			esc_html( number_format_i18n( $value ) ),
			esc_html( $label )
		);
	}

	/**
	 * Settings tab.
	 *
	 * @return void
	 */
	private function tab_settings() {
		$definitions = NYMS_Settings::definitions();
		$groups      = NYMS_Settings::groups();
		?>
		<p class="description" style="max-width:820px;">
			<?php esc_html_e( 'Tick a protection to apply it. Anything defined in wp-config.php is shown as locked and cannot be changed here - that is the safest place for the settings you never want touched from a browser.', 'newyorkmechanics-security' ); ?>
		</p>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="nyms_save" />
			<?php wp_nonce_field( 'nyms_save' ); ?>

			<?php foreach ( $groups as $group_key => $group_title ) : ?>
				<h2><?php echo esc_html( $group_title ); ?></h2>
				<table class="widefat striped" style="max-width:900px;">
					<tbody>
						<?php foreach ( $definitions as $key => $definition ) : ?>
							<?php
							if ( $definition['group'] !== $group_key ) {
								continue;
							}

							$locked = NYMS_Settings::is_locked( $key );
							$value  = NYMS_Settings::value( $key );
							?>
							<tr>
								<td style="width:70%;">
									<label for="<?php echo esc_attr( $key ); ?>">
										<strong><?php echo esc_html( $definition['label'] ); ?></strong>
									</label>
									<p class="description" style="margin:4px 0 0;">
										<?php echo wp_kses( $definition['help'], array( 'code' => array() ) ); ?>
									</p>
									<code style="font-size:11px;opacity:.6;"><?php echo esc_html( $key ); ?></code>
									<?php if ( $locked ) : ?>
										<span style="font-size:11px;color:#996800;">
											&#128274; <?php esc_html_e( 'locked in wp-config.php', 'newyorkmechanics-security' ); ?>
										</span>
									<?php endif; ?>
								</td>
								<td style="vertical-align:middle;">
									<?php $this->field( $key, $definition, $value, $locked ); ?>
								</td>
							</tr>
						<?php endforeach; ?>

						<?php if ( 'monitoring' === $group_key ) : ?>
							<tr>
								<td>
									<strong><?php esc_html_e( 'Where alerts are sent', 'newyorkmechanics-security' ); ?></strong>
									<p class="description" style="margin:4px 0 0;">
										<?php esc_html_e( 'Leave empty to use the site administration address.', 'newyorkmechanics-security' ); ?>
									</p>
								</td>
								<td>
									<input type="email" name="nyms_alert_address" class="regular-text"
										value="<?php echo esc_attr( (string) get_option( 'nyms_alert_address', '' ) ); ?>" />
								</td>
							</tr>
						<?php endif; ?>
					</tbody>
				</table>
			<?php endforeach; ?>

			<h2><?php esc_html_e( 'Lists', 'newyorkmechanics-security' ); ?></h2>
			<table class="widefat striped" style="max-width:900px;">
				<tbody>
					<?php
					$this->list_field(
						'nyms_ip_allowlist',
						NYMS_Firewall::ALLOWED,
						__( 'Addresses that bypass every rule', 'newyorkmechanics-security' ),
						__( 'One per line. Single addresses, CIDR ranges (203.0.113.0/24) and trailing wildcards all work. Put your own address here before tightening anything.', 'newyorkmechanics-security' )
					);

					$this->list_field(
						'nyms_ip_blocklist',
						NYMS_Firewall::DENIED,
						__( 'Addresses that are always refused', 'newyorkmechanics-security' ),
						__( 'One per line, same formats.', 'newyorkmechanics-security' )
					);

					$this->list_field(
						'nyms_blocked_countries',
						NYMS_Firewall::COUNTRIES,
						__( 'Country codes to refuse', 'newyorkmechanics-security' ),
						__( 'Two-letter codes, one per line. This only works when a proxy in front of the site reports the country - Cloudflare, CloudFront or an nginx GeoIP module. Without one the check stands down rather than guessing.', 'newyorkmechanics-security' )
					);

					$this->list_field(
						'nyms_blocked_agents',
						NYMS_Firewall::AGENTS,
						__( 'Extra user-agent fragments to refuse', 'newyorkmechanics-security' ),
						__( 'One per line, matched anywhere in the string. The common scanners are already built in.', 'newyorkmechanics-security' )
					);

					$this->list_field(
						'nyms_domain_allowlist',
						NYMS_Network_Guard::ALLOWED,
						__( 'Hosts this site may contact', 'newyorkmechanics-security' ),
						__( 'One per line. Subdomains of an entry are included. Used when outbound allowlist mode is on; wordpress.org and Gravatar are always allowed.', 'newyorkmechanics-security' )
					);

					$this->list_field(
						'nyms_domain_blocklist',
						NYMS_Network_Guard::DENIED,
						__( 'Hosts this site may never contact', 'newyorkmechanics-security' ),
						__( 'Always enforced, whatever the mode.', 'newyorkmechanics-security' )
					);

					$this->list_field(
						'nyms_plugin_sources',
						NYMS_Plugin_Guard::SOURCES,
						__( 'Hosts a plugin or theme may be downloaded from', 'newyorkmechanics-security' ),
						__( 'One per line. Add the update server of any paid plugin you use, or its updates will be refused in enforce mode.', 'newyorkmechanics-security' )
					);
					?>
				</tbody>
			</table>

			<p class="submit">
				<input type="submit" class="button button-primary"
					value="<?php esc_attr_e( 'Save settings', 'newyorkmechanics-security' ); ?>" />
			</p>
		</form>
		<?php
	}

	/**
	 * One textarea backed by a list option.
	 *
	 * @param string $field  Form field name.
	 * @param string $option Option name.
	 * @param string $label  Label.
	 * @param string $help   Description.
	 * @return void
	 */
	private function list_field( $field, $option, $label, $help ) {
		$values = NYMS_Firewall::list_option( $option );
		?>
		<tr>
			<td style="width:45%;">
				<strong><?php echo esc_html( $label ); ?></strong>
				<p class="description" style="margin:4px 0 0;"><?php echo esc_html( $help ); ?></p>
				<code style="font-size:11px;opacity:.6;"><?php echo esc_html( $option ); ?></code>
			</td>
			<td>
				<textarea name="<?php echo esc_attr( $field ); ?>" rows="4" class="large-text code"><?php echo esc_textarea( implode( "\n", $values ) ); ?></textarea>
			</td>
		</tr>
		<?php
	}

	/**
	 * Event log tab.
	 *
	 * @return void
	 */
	private function tab_events() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$severity = isset( $_GET['severity'] ) ? (int) $_GET['severity'] : -1;
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$paged = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1;

		$per_page = 50;

		$events = NYMS_Log::query(
			array(
				'severity' => $severity,
				'limit'    => $per_page,
				'offset'   => ( $paged - 1 ) * $per_page,
			)
		);
		?>
		<p>
			<?php
			$levels = array(
				-1                 => __( 'Everything', 'newyorkmechanics-security' ),
				NYMS_Log::NOTICE   => __( 'Notices and above', 'newyorkmechanics-security' ),
				NYMS_Log::WARNING  => __( 'Warnings and above', 'newyorkmechanics-security' ),
				NYMS_Log::CRITICAL => __( 'Critical only', 'newyorkmechanics-security' ),
			);

			foreach ( $levels as $level => $label ) {
				printf(
					'<a class="button%1$s" href="%2$s">%3$s</a> ',
					$severity === $level ? ' button-primary' : '',
					esc_url( $this->url( 'events', array( 'severity' => $level ) ) ),
					esc_html( $label )
				);
			}
			?>
			<span style="float:right;"><?php $this->button( 'clear_log', __( 'Empty the log', 'newyorkmechanics-security' ) ); ?></span>
		</p>

		<?php $this->events_table( $events ); ?>

		<p>
			<?php if ( $paged > 1 ) : ?>
				<a class="button" href="<?php echo esc_url( $this->url( 'events', array( 'severity' => $severity, 'paged' => $paged - 1 ) ) ); ?>">
					<?php esc_html_e( 'Newer', 'newyorkmechanics-security' ); ?>
				</a>
			<?php endif; ?>

			<?php if ( count( $events ) === $per_page ) : ?>
				<a class="button" href="<?php echo esc_url( $this->url( 'events', array( 'severity' => $severity, 'paged' => $paged + 1 ) ) ); ?>">
					<?php esc_html_e( 'Older', 'newyorkmechanics-security' ); ?>
				</a>
			<?php endif; ?>
		</p>
		<?php
	}

	/**
	 * Render a list of events.
	 *
	 * @param array $events Event rows.
	 * @return void
	 */
	private function events_table( $events ) {
		if ( ! NYMS_Log::ready() ) {
			echo '<div class="notice notice-warning inline"><p>'
				. esc_html__( 'The log table does not exist yet. Deactivate and reactivate the plugin to create it.', 'newyorkmechanics-security' )
				. '</p></div>';

			return;
		}

		if ( ! $events ) {
			echo '<p>' . esc_html__( 'Nothing recorded.', 'newyorkmechanics-security' ) . '</p>';

			return;
		}
		?>
		<table class="widefat striped">
			<thead>
				<tr>
					<th style="width:150px;"><?php esc_html_e( 'When', 'newyorkmechanics-security' ); ?></th>
					<th style="width:90px;"><?php esc_html_e( 'Level', 'newyorkmechanics-security' ); ?></th>
					<th style="width:170px;"><?php esc_html_e( 'Event', 'newyorkmechanics-security' ); ?></th>
					<th><?php esc_html_e( 'Detail', 'newyorkmechanics-security' ); ?></th>
					<th style="width:130px;"><?php esc_html_e( 'Address', 'newyorkmechanics-security' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $events as $event ) : ?>
					<tr>
						<td><?php echo esc_html( $this->when( strtotime( $event->logged_at . ' UTC' ) ) ); ?></td>
						<td>
							<span style="color:<?php echo esc_attr( NYMS_Log::severity_colour( $event->severity ) ); ?>;font-weight:600;">
								<?php echo esc_html( NYMS_Log::severity_label( $event->severity ) ); ?>
							</span>
						</td>
						<td><code><?php echo esc_html( $event->event_type ); ?></code></td>
						<td>
							<?php echo esc_html( $event->message ); ?>
							<?php
							$context = json_decode( (string) $event->context, true );

							if ( is_array( $context ) && $context ) :
								?>
								<details style="margin-top:4px;">
									<summary style="cursor:pointer;color:#2271b1;"><?php esc_html_e( 'detail', 'newyorkmechanics-security' ); ?></summary>
									<pre style="white-space:pre-wrap;word-break:break-all;font-size:11px;background:#f6f7f7;padding:8px;margin:4px 0 0;"><?php echo esc_html( wp_json_encode( $context, 128 ) ); ?></pre>
								</details>
							<?php endif; ?>
						</td>
						<td><code><?php echo esc_html( $event->ip ); ?></code></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Self-protection tab.
	 *
	 * @return void
	 */
	private function tab_self() {
		$status = NYMS_Self_Protect::status();
		$lock   = NYMS_Plugin::instance()->module( 'self' );
		?>
		<p class="description" style="max-width:820px;">
			<?php esc_html_e( 'A security plugin is the first thing an intruder switches off, so this one watches itself: its own files, its log table, its settings and the deny rule over its code folder. It looks for malicious code nowhere else - that is a malware scanner\'s job and this plugin leaves it to one.', 'newyorkmechanics-security' ); ?>
		</p>

		<table class="widefat striped" style="max-width:900px;">
			<tbody>
				<tr>
					<td style="width:70%;">
						<?php esc_html_e( 'Own files, table and settings', 'newyorkmechanics-security' ); ?>
						<p class="description" style="margin:4px 0 0;">
							<?php
							printf(
								/* translators: %s: date and time. */
								esc_html__( 'Last checked %s.', 'newyorkmechanics-security' ),
								esc_html( $this->when( isset( $status['at'] ) ? $status['at'] : 0 ) )
							);
							?>
						</p>
					</td>
					<td>
						<?php
						if ( empty( $status['problems'] ) ) {
							echo '<span style="color:#007017;font-weight:600;">' . esc_html__( 'Intact', 'newyorkmechanics-security' ) . '</span>';
						} else {
							echo '<ul style="list-style:disc;margin-left:18px;">';

							foreach ( $status['problems'] as $problem ) {
								echo '<li style="color:#8a2424;">' . esc_html( $problem ) . '</li>';
							}

							echo '</ul>';
						}
						?>
						<p><?php $this->button( 'self_check', __( 'Check now', 'newyorkmechanics-security' ) ); ?></p>
					</td>
				</tr>
				<tr>
					<td>
						<?php esc_html_e( 'Deactivation lock', 'newyorkmechanics-security' ); ?>
						<p class="description" style="margin:4px 0 0;">
							<?php esc_html_e( 'While this is locked, nothing can remove the plugin from the active list or delete its files - including code running as an administrator.', 'newyorkmechanics-security' ); ?>
						</p>
					</td>
					<td>
						<?php
						if ( $lock instanceof NYMS_Self_Protect && $lock->deactivation_allowed() ) {
							echo '<span style="color:#996800;font-weight:600;">' . esc_html__( 'Unlocked for the next few minutes.', 'newyorkmechanics-security' ) . '</span>';
						} else {
							echo '<span style="color:#007017;font-weight:600;">' . esc_html__( 'Locked', 'newyorkmechanics-security' ) . '</span><br /><br />';

							$this->button( 'unlock', __( 'Unlock for 15 minutes', 'newyorkmechanics-security' ) );
						}
						?>
					</td>
				</tr>
				<tr>
					<td>
						<?php esc_html_e( 'Trusted copy of the plugin files', 'newyorkmechanics-security' ); ?>
						<p class="description" style="margin:4px 0 0;">
							<?php esc_html_e( 'Re-recorded automatically when the plugin is updated. Use this only if you have edited the plugin yourself.', 'newyorkmechanics-security' ); ?>
						</p>
					</td>
					<td><?php $this->button( 'self_record', __( 'Re-record now', 'newyorkmechanics-security' ) ); ?></td>
				</tr>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'Recent events about this plugin', 'newyorkmechanics-security' ); ?></h2>
		<?php
		$events = array();

		foreach ( array( 'self_protect', 'self_deactivation_blocked', 'self_deletion_blocked', 'self_settings_write_blocked', 'self_unlocked', 'plugin_upgraded' ) as $type ) {
			$events = array_merge( $events, NYMS_Log::query( array( 'type' => $type, 'limit' => 5 ) ) );
		}

		usort(
			$events,
			function ( $a, $b ) {
				return (int) $b->id - (int) $a->id;
			}
		);

		$this->events_table( array_slice( $events, 0, 20 ) );
	}

	/**
	 * Plugins tab.
	 *
	 * @return void
	 */
	private function tab_plugins() {
		$guard   = NYMS_Plugin::instance()->module( 'packages' );
		$audit   = NYMS_Plugin_Guard::last_audit();
		$report  = isset( $audit['report'] ) ? $audit['report'] : array();
		$allowed = NYMS_Plugin_Guard::allowlist();
		$blocked = NYMS_Plugin_Guard::blocklist();
		?>
		<p>
			<?php $this->button( 'plugin_audit', __( 'Check every installed plugin now', 'newyorkmechanics-security' ), '', 'button button-primary' ); ?>
			<span class="description" style="margin-left:8px;">
				<?php
				printf(
					/* translators: %s: policy name. */
					esc_html__( 'Current policy: %s', 'newyorkmechanics-security' ),
					esc_html( $guard instanceof NYMS_Plugin_Guard ? $guard->policy() : 'off' )
				);
				?>
			</span>
		</p>

		<?php if ( ! $report ) : ?>
			<p><?php esc_html_e( 'No audit has been run yet.', 'newyorkmechanics-security' ); ?></p>
		<?php else : ?>
			<table class="widefat striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Plugin', 'newyorkmechanics-security' ); ?></th>
						<th style="width:90px;"><?php esc_html_e( 'Version', 'newyorkmechanics-security' ); ?></th>
						<th style="width:110px;"><?php esc_html_e( 'Directory', 'newyorkmechanics-security' ); ?></th>
						<th style="width:110px;"><?php esc_html_e( 'Files', 'newyorkmechanics-security' ); ?></th>
						<th style="width:100px;"><?php esc_html_e( 'Approval', 'newyorkmechanics-security' ); ?></th>
						<th style="width:230px;"><?php esc_html_e( 'Actions', 'newyorkmechanics-security' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $report as $slug => $row ) : ?>
						<tr>
							<td>
								<strong><?php echo esc_html( $row['name'] ); ?></strong>
								<div><code style="font-size:11px;"><?php echo esc_html( $slug ); ?></code></div>
								<?php if ( ! empty( $row['changed'] ) ) : ?>
									<details style="margin-top:4px;">
										<summary style="cursor:pointer;color:#8a2424;"><?php esc_html_e( 'files that differ', 'newyorkmechanics-security' ); ?></summary>
										<pre style="white-space:pre-wrap;font-size:11px;background:#f6f7f7;padding:8px;"><?php echo esc_html( implode( "\n", $row['changed'] ) ); ?></pre>
									</details>
								<?php endif; ?>
							</td>
							<td><?php echo esc_html( $row['version'] ); ?></td>
							<td>
								<?php
								$states = array(
									'known'     => array( __( 'Published', 'newyorkmechanics-security' ), '#007017' ),
									'unknown'   => array( __( 'Not listed', 'newyorkmechanics-security' ), '#996800' ),
									'abandoned' => array( __( 'Abandoned', 'newyorkmechanics-security' ), '#996800' ),
									'closed'    => array( __( 'Withdrawn', 'newyorkmechanics-security' ), '#8a2424' ),
								);

								$state = isset( $states[ $row['state'] ] ) ? $states[ $row['state'] ] : array( $row['state'], '#50575e' );

								printf( '<span style="color:%s;font-weight:600;">%s</span>', esc_attr( $state[1] ), esc_html( $state[0] ) );

								if ( ! empty( $row['last_updated'] ) ) {
									echo '<div style="font-size:11px;color:#50575e;">' . esc_html( $row['last_updated'] ) . '</div>';
								}
								?>
							</td>
							<td>
								<?php
								$files = array(
									'verified'    => array( __( 'Verified', 'newyorkmechanics-security' ), '#007017' ),
									'modified'    => array( __( 'Modified', 'newyorkmechanics-security' ), '#8a2424' ),
									'unavailable' => array( __( 'No checksums', 'newyorkmechanics-security' ), '#50575e' ),
								);

								$file_state = isset( $files[ $row['files'] ] ) ? $files[ $row['files'] ] : array( $row['files'], '#50575e' );

								printf( '<span style="color:%s;font-weight:600;">%s</span>', esc_attr( $file_state[1] ), esc_html( $file_state[0] ) );
								?>
							</td>
							<td>
								<?php
								if ( isset( $blocked[ $slug ] ) ) {
									echo '<span style="color:#8a2424;font-weight:600;">' . esc_html__( 'Blocked', 'newyorkmechanics-security' ) . '</span>';
								} elseif ( isset( $allowed[ $slug ] ) ) {
									echo '<span style="color:#007017;font-weight:600;">' . esc_html__( 'Approved', 'newyorkmechanics-security' ) . '</span>';
								} else {
									echo '<span style="color:#996800;font-weight:600;">' . esc_html__( 'Not approved', 'newyorkmechanics-security' ) . '</span>';
								}
								?>
							</td>
							<td>
								<?php
								if ( isset( $allowed[ $slug ] ) ) {
									$this->button( 'revoke', __( 'Withdraw', 'newyorkmechanics-security' ), $slug );
								} else {
									$this->button( 'approve', __( 'Approve', 'newyorkmechanics-security' ), $slug );
								}

								if ( isset( $blocked[ $slug ] ) ) {
									$this->button( 'unblocklist', __( 'Unblock', 'newyorkmechanics-security' ), $slug );
								} else {
									$this->button( 'blocklist', __( 'Block', 'newyorkmechanics-security' ), $slug, 'button button-link-delete' );
								}
								?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
		<?php
	}

	/**
	 * Accounts tab.
	 *
	 * @return void
	 */
	private function tab_accounts() {
		$users = NYMS_Plugin::instance()->module( 'users' );

		if ( ! $users instanceof NYMS_User_Guard ) {
			echo '<p>' . esc_html__( 'Account monitoring is switched off.', 'newyorkmechanics-security' ) . '</p>';

			return;
		}

		$admins = $users->administrators();
		?>
		<p><?php $this->button( 'user_audit', __( 'Check accounts now', 'newyorkmechanics-security' ), '', 'button button-primary' ); ?></p>

		<table class="widefat striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Account', 'newyorkmechanics-security' ); ?></th>
					<th style="width:130px;"><?php esc_html_e( 'Roles', 'newyorkmechanics-security' ); ?></th>
					<th style="width:150px;"><?php esc_html_e( 'Last sign-in', 'newyorkmechanics-security' ); ?></th>
					<th style="width:120px;"><?php esc_html_e( 'From', 'newyorkmechanics-security' ); ?></th>
					<th style="width:80px;"><?php esc_html_e( 'Sessions', 'newyorkmechanics-security' ); ?></th>
					<th style="width:80px;"><?php esc_html_e( '2FA', 'newyorkmechanics-security' ); ?></th>
					<th style="width:230px;"><?php esc_html_e( 'Actions', 'newyorkmechanics-security' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $admins as $admin ) : ?>
					<tr>
						<td>
							<strong><?php echo esc_html( $admin['login'] ); ?></strong>
							<div style="font-size:11px;color:#50575e;"><?php echo esc_html( $admin['email'] ); ?></div>
							<?php if ( $admin['suspicious'] ) : ?>
								<div style="color:#8a2424;font-size:11px;">
									<?php
									printf(
										/* translators: %s: reason. */
										esc_html__( 'Suspicious name: %s', 'newyorkmechanics-security' ),
										esc_html( $admin['suspicious'] )
									);
									?>
								</div>
							<?php endif; ?>
							<?php if ( $admin['disabled'] ) : ?>
								<div style="color:#8a2424;font-size:11px;font-weight:600;"><?php esc_html_e( 'Disabled', 'newyorkmechanics-security' ); ?></div>
							<?php endif; ?>
						</td>
						<td><?php echo esc_html( implode( ', ', $admin['roles'] ) ); ?></td>
						<td><?php echo esc_html( $admin['last_login'] ? $this->when( $admin['last_login'] ) : __( 'never recorded', 'newyorkmechanics-security' ) ); ?></td>
						<td><code style="font-size:11px;"><?php echo esc_html( $admin['last_ip'] ); ?></code></td>
						<td><?php echo esc_html( number_format_i18n( $admin['sessions'] ) ); ?></td>
						<td>
							<?php
							echo $admin['2fa']
								? '<span style="color:#007017;font-weight:600;">' . esc_html__( 'On', 'newyorkmechanics-security' ) . '</span>'
								: '<span style="color:#8a2424;font-weight:600;">' . esc_html__( 'Off', 'newyorkmechanics-security' ) . '</span>';
							?>
						</td>
						<td>
							<?php
							$this->button( 'logout_user', __( 'End sessions', 'newyorkmechanics-security' ), (string) $admin['id'] );

							if ( get_current_user_id() !== $admin['id'] ) {
								if ( $admin['disabled'] ) {
									$this->button( 'enable_user', __( 'Enable', 'newyorkmechanics-security' ), (string) $admin['id'] );
								} else {
									$this->button( 'disable_user', __( 'Disable', 'newyorkmechanics-security' ), (string) $admin['id'], 'button button-link-delete' );
								}
							}
							?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'Recent account events', 'newyorkmechanics-security' ); ?></h2>
		<?php
		$events = array();

		foreach ( array( 'admin_created', 'privilege_escalation', 'role_changed', 'login_new_location', 'app_password_created', 'login_failed', '2fa_failed' ) as $type ) {
			$events = array_merge( $events, NYMS_Log::query( array( 'type' => $type, 'limit' => 5 ) ) );
		}

		usort(
			$events,
			function ( $a, $b ) {
				return (int) $b->id - (int) $a->id;
			}
		);

		$this->events_table( array_slice( $events, 0, 20 ) );
	}

	/**
	 * Firewall tab.
	 *
	 * @return void
	 */
	private function tab_firewall() {
		$blocks = NYMS_Firewall::blocks();

		arsort( $blocks );
		?>
		<h2><?php esc_html_e( 'Blocked addresses', 'newyorkmechanics-security' ); ?></h2>

		<?php if ( ! $blocks ) : ?>
			<p><?php esc_html_e( 'Nothing is blocked right now.', 'newyorkmechanics-security' ); ?></p>
		<?php else : ?>
			<table class="widefat striped">
				<thead>
					<tr>
						<th style="width:150px;"><?php esc_html_e( 'Address', 'newyorkmechanics-security' ); ?></th>
						<th><?php esc_html_e( 'Why', 'newyorkmechanics-security' ); ?></th>
						<th style="width:80px;"><?php esc_html_e( 'Strikes', 'newyorkmechanics-security' ); ?></th>
						<th style="width:170px;"><?php esc_html_e( 'Until', 'newyorkmechanics-security' ); ?></th>
						<th style="width:120px;"><?php esc_html_e( 'Actions', 'newyorkmechanics-security' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $blocks as $ip => $block ) : ?>
						<tr>
							<td><code><?php echo esc_html( $ip ); ?></code></td>
							<td><?php echo esc_html( $block['reason'] ); ?></td>
							<td><?php echo esc_html( number_format_i18n( $block['strikes'] ) ); ?></td>
							<td>
								<?php
								echo $block['until'] > time()
									? esc_html( $this->when( (int) $block['until'] ) )
									: '<span style="color:#50575e;">' . esc_html__( 'expired', 'newyorkmechanics-security' ) . '</span>';
								?>
							</td>
							<td><?php $this->button( 'unblock_ip', __( 'Lift', 'newyorkmechanics-security' ), $ip ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>

		<h2><?php esc_html_e( 'Recent refusals', 'newyorkmechanics-security' ); ?></h2>
		<?php
		$events = array();

		foreach ( array( 'ip_blocked', 'rate_limited', 'agent_blocked', 'country_blocked', 'ip_blocklist', 'ip_autoblock' ) as $type ) {
			$events = array_merge( $events, NYMS_Log::query( array( 'type' => $type, 'limit' => 8 ) ) );
		}

		usort(
			$events,
			function ( $a, $b ) {
				return (int) $b->id - (int) $a->id;
			}
		);

		$this->events_table( array_slice( $events, 0, 25 ) );
		?>

		<p class="description" style="max-width:820px;margin-top:12px;">
			<?php
			printf(
				/* translators: %s: the client address as the plugin sees it. */
				esc_html__( 'Your address, as this plugin sees it, is %s. If that is a private address and the site sits behind Cloudflare or another proxy, switch on "Trust proxy headers" or every visitor will look like one client.', 'newyorkmechanics-security' ),
				esc_html( NYMS_Helpers::client_ip() )
			);
			?>
		</p>
		<?php
	}

	/**
	 * Network tab.
	 *
	 * @return void
	 */
	private function tab_network() {
		$seen = NYMS_Network_Guard::seen();

		uasort(
			$seen,
			function ( $a, $b ) {
				return $b['last'] - $a['last'];
			}
		);

		$expected = array_merge( NYMS_Network_Guard::core_hosts(), NYMS_Firewall::list_option( NYMS_Network_Guard::ALLOWED ) );
		$guard    = NYMS_Plugin::instance()->module( 'network' );
		?>
		<h2><?php esc_html_e( 'Everything this site has connected to', 'newyorkmechanics-security' ); ?></h2>
		<p class="description" style="max-width:820px;">
			<?php esc_html_e( 'A host you do not recognise, contacted regularly, is what a backdoor phoning home looks like. Watch this list for a week before turning allowlist mode on.', 'newyorkmechanics-security' ); ?>
		</p>

		<?php if ( ! $seen ) : ?>
			<p><?php esc_html_e( 'Nothing recorded yet.', 'newyorkmechanics-security' ); ?></p>
		<?php else : ?>
			<table class="widefat striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Host', 'newyorkmechanics-security' ); ?></th>
						<th style="width:90px;"><?php esc_html_e( 'Requests', 'newyorkmechanics-security' ); ?></th>
						<th style="width:150px;"><?php esc_html_e( 'First seen', 'newyorkmechanics-security' ); ?></th>
						<th style="width:150px;"><?php esc_html_e( 'Last seen', 'newyorkmechanics-security' ); ?></th>
						<th style="width:120px;"><?php esc_html_e( 'Expected', 'newyorkmechanics-security' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( array_slice( $seen, 0, 200, true ) as $host => $record ) : ?>
						<tr>
							<td><code><?php echo esc_html( $host ); ?></code></td>
							<td><?php echo esc_html( number_format_i18n( $record['count'] ) ); ?></td>
							<td><?php echo esc_html( $this->when( (int) $record['first'] ) ); ?></td>
							<td><?php echo esc_html( $this->when( (int) $record['last'] ) ); ?></td>
							<td>
								<?php
								$known = $guard instanceof NYMS_Network_Guard && $guard->host_in( $host, $expected );

								echo $known
									? '<span style="color:#007017;font-weight:600;">' . esc_html__( 'Yes', 'newyorkmechanics-security' ) . '</span>'
									: '<span style="color:#996800;font-weight:600;">' . esc_html__( 'Unlisted', 'newyorkmechanics-security' ) . '</span>';
								?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
		<?php
	}

	/**
	 * Server rules tab.
	 *
	 * @return void
	 */
	private function tab_server() {
		$server = NYMS_Htaccess::status();
		?>
		<h2><?php esc_html_e( 'Server rules in place right now', 'newyorkmechanics-security' ); ?></h2>
		<table class="widefat striped" style="max-width:900px;">
			<tbody>
				<tr>
					<td style="width:70%;"><?php esc_html_e( 'Server honours .htaccess (Apache or LiteSpeed)', 'newyorkmechanics-security' ); ?></td>
					<td><?php echo wp_kses_post( $this->badge( $server['apache'] ) ); ?></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Site root: hidden files, backups, wp-config.php, wp-includes, directory listings', 'newyorkmechanics-security' ); ?></td>
					<td><?php echo wp_kses_post( $this->badge( $server['root'] ) ); ?></td>
				</tr>
				<?php foreach ( $server['writable'] as $dir => $state ) : ?>
					<tr>
						<td>
							<?php esc_html_e( 'No execution in', 'newyorkmechanics-security' ); ?>
							<code><?php echo esc_html( str_replace( wp_normalize_path( ABSPATH ), '', wp_normalize_path( $dir ) ) ); ?></code>
						</td>
						<td><?php echo wp_kses_post( $this->badge( $state ) ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'nginx', 'newyorkmechanics-security' ); ?></h2>
		<p class="description" style="max-width:820px;">
			<?php esc_html_e( 'nginx never reads .htaccess. On that server the rules below have to go into the server block by hand; every protection written in PHP works either way.', 'newyorkmechanics-security' ); ?>
		</p>
		<textarea readonly="readonly" rows="26" class="large-text code" style="font-family:monospace;"><?php echo esc_textarea( NYMS_Htaccess::nginx_rules() ); ?></textarea>

		<h2><?php esc_html_e( 'Environment', 'newyorkmechanics-security' ); ?></h2>
		<?php
		$folder    = basename( dirname( NYMS_FILE ) );
		$suggested = NYMS_Helpers::plugin_slug();
		?>
		<table class="widefat striped" style="max-width:900px;">
			<tbody>
				<tr>
					<td style="width:70%;"><?php esc_html_e( 'Plugin version', 'newyorkmechanics-security' ); ?></td>
					<td><code><?php echo esc_html( NYMS_VERSION ); ?></code></td>
				</tr>
				<tr>
					<td>
						<?php esc_html_e( 'Plugin folder', 'newyorkmechanics-security' ); ?>
						<?php if ( $folder !== $suggested ) : ?>
							<p class="description" style="margin:4px 0 0;">
								<?php
								printf(
									/* translators: %s: suggested folder name. */
									esc_html__( 'To match the site name it would be %s. Renaming the folder is a manual step - a plugin that renamed its own directory would deactivate itself mid-request.', 'newyorkmechanics-security' ),
									'<code>' . esc_html( $suggested ) . '</code>'
								);
								?>
							</p>
						<?php endif; ?>
					</td>
					<td><code><?php echo esc_html( $folder ); ?></code></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'WordPress', 'newyorkmechanics-security' ); ?></td>
					<td><code><?php echo esc_html( get_bloginfo( 'version' ) ); ?></code></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'PHP', 'newyorkmechanics-security' ); ?></td>
					<td><code><?php echo esc_html( PHP_VERSION ); ?></code></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'ZIP inspection available', 'newyorkmechanics-security' ); ?></td>
					<td><?php echo wp_kses_post( $this->badge( class_exists( 'ZipArchive' ) ) ); ?></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Your IP as this plugin sees it', 'newyorkmechanics-security' ); ?></td>
					<td><code><?php echo esc_html( NYMS_Helpers::client_ip() ); ?></code></td>
				</tr>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Environment problems the plugin cannot fix from inside PHP.
	 *
	 * @return array
	 */
	private function warnings() {
		$warnings = array();

		if ( $this->has_default_salts() ) {
			$warnings[] = __( 'The security keys and salts in wp-config.php are still the placeholder values. Anyone who knows them can forge login cookies. Replace them from the WordPress secret-key service; it signs everyone out, including an intruder.', 'newyorkmechanics-security' );
		}

		if ( defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_DISPLAY' ) && WP_DEBUG_DISPLAY ) {
			$warnings[] = __( 'WP_DEBUG_DISPLAY is on. PHP errors printed to the page reveal file paths and database details.', 'newyorkmechanics-security' );
		}

		if ( defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
			$warnings[] = __( 'WP_DEBUG_LOG is on. The log file is blocked from the web while the server rules are active, but turning it off on a live site is better.', 'newyorkmechanics-security' );
		}

		if ( is_ssl() && ( ! defined( 'FORCE_SSL_ADMIN' ) || ! FORCE_SSL_ADMIN ) ) {
			$warnings[] = __( 'FORCE_SSL_ADMIN is not set in wp-config.php, so the admin area can be reached over plain HTTP.', 'newyorkmechanics-security' );
		}

		if ( ! defined( 'DISALLOW_UNFILTERED_UPLOADS' ) || ! DISALLOW_UNFILTERED_UPLOADS ) {
			$warnings[] = __( 'DISALLOW_UNFILTERED_UPLOADS is not set in wp-config.php. Adding it stops any code path from bypassing the upload type checks.', 'newyorkmechanics-security' );
		}

		if ( file_exists( ABSPATH . 'readme.html' ) ) {
			$warnings[] = __( 'readme.html still exists in the site root. It is blocked from the web while the server rules are active, but deleting it is cleaner - WordPress recreates it on every update.', 'newyorkmechanics-security' );
		}

		if ( ! class_exists( 'ZipArchive' ) ) {
			$warnings[] = __( 'The PHP zip extension is not installed, so uploaded archives and plugin packages cannot be inspected before they are unpacked.', 'newyorkmechanics-security' );
		}

		return $warnings;
	}

	/**
	 * Detect untouched wp-config.php placeholders.
	 *
	 * @return bool
	 */
	private function has_default_salts() {
		$keys = array( 'AUTH_KEY', 'SECURE_AUTH_KEY', 'LOGGED_IN_KEY', 'NONCE_KEY', 'AUTH_SALT', 'SECURE_AUTH_SALT', 'LOGGED_IN_SALT', 'NONCE_SALT' );
		$seen = array();

		foreach ( $keys as $key ) {
			if ( ! defined( $key ) ) {
				continue;
			}

			$value = (string) constant( $key );

			if ( '' === $value || NYMS_Helpers::has( str_replace( '-', ' ', $value ), 'put your unique phrase' ) ) {
				return true;
			}

			$seen[] = $value;
		}

		return count( $seen ) > 1 && count( array_unique( $seen ) ) < count( $seen );
	}

	/**
	 * A timestamp in the site's own timezone.
	 *
	 * @param int $timestamp Unix time.
	 * @return string
	 */
	private function when( $timestamp ) {
		$timestamp = (int) $timestamp;

		if ( $timestamp < 1 ) {
			return __( 'never', 'newyorkmechanics-security' );
		}

		return wp_date( 'Y-m-d H:i', $timestamp );
	}

	/**
	 * Render one input.
	 *
	 * @param string $key        Constant name.
	 * @param array  $definition Field definition.
	 * @param mixed  $value      Current value.
	 * @param bool   $locked     Whether wp-config.php owns this switch.
	 * @return void
	 */
	private function field( $key, $definition, $value, $locked ) {
		$name = 'nyms[' . $key . ']';

		if ( 'bool' === $definition['type'] ) {
			printf(
				'<label><input type="checkbox" id="%1$s" name="%2$s" value="1"%3$s%4$s /> %5$s</label>',
				esc_attr( $key ),
				esc_attr( $name ),
				checked( (bool) $value, true, false ),
				$locked ? ' disabled="disabled"' : '', // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed literal.
				esc_html__( 'Enabled', 'newyorkmechanics-security' )
			);

			return;
		}

		if ( 'choice' === $definition['type'] ) {
			echo '<select id="' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '"' . ( $locked ? ' disabled="disabled"' : '' ) . '>';

			foreach ( $definition['choices'] as $choice => $label ) {
				printf(
					'<option value="%1$s"%2$s>%3$s</option>',
					esc_attr( $choice ),
					selected( (string) $value, (string) $choice, false ),
					esc_html( $label )
				);
			}

			echo '</select>';

			return;
		}

		printf(
			'<input type="number" id="%1$s" name="%2$s" value="%3$s" min="%4$d" max="%5$d" class="small-text"%6$s />',
			esc_attr( $key ),
			esc_attr( $name ),
			esc_attr( $value ),
			(int) $definition['min'],
			(int) $definition['max'],
			$locked ? ' disabled="disabled"' : '' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed literal.
		);
	}

	/**
	 * A coloured yes/no badge.
	 *
	 * @param bool|null $state True, false, or null when it cannot be read.
	 * @return string
	 */
	private function badge( $state ) {
		if ( null === $state ) {
			return '<span style="color:#996800;font-weight:600;">' . esc_html__( 'Cannot read', 'newyorkmechanics-security' ) . '</span>';
		}

		if ( $state ) {
			return '<span style="color:#007017;font-weight:600;">&#10003; ' . esc_html__( 'Active', 'newyorkmechanics-security' ) . '</span>';
		}

		return '<span style="color:#8a2424;font-weight:600;">&#10007; ' . esc_html__( 'Off', 'newyorkmechanics-security' ) . '</span>';
	}
}

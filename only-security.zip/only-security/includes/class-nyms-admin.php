<?php
/**
 * Admin screen: settings plus live status.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the one screen this plugin has.
 *
 * Saving is guarded by a capability check and a nonce, and any switch that is
 * defined in wp-config.php is refused here - the file the web server never
 * serves always wins over the browser.
 */
class NYMS_Admin {

	/**
	 * Menu slug.
	 */
	const SLUG = 'nyms-security';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_menu', array( $this, 'add_page' ) );
		add_action( 'admin_post_nyms_save', array( $this, 'handle_save' ) );
		add_action( 'admin_init', array( $this, 'maybe_sync_rules' ) );
		add_filter( 'plugin_action_links_' . NYMS_BASENAME, array( $this, 'action_link' ) );
		add_filter( 'all_plugins', array( $this, 'filter_plugin_name' ) );
	}

	/**
	 * Show the plugin under the site's own name in the plugin list.
	 *
	 * @param array $plugins Plugin data keyed by basename.
	 * @return array
	 */
	public function filter_plugin_name( $plugins ) {
		if ( ! is_array( $plugins ) || ! isset( $plugins[ NYMS_BASENAME ] ) ) {
			return $plugins;
		}

		$name = NYMS_Helpers::plugin_name();

		$plugins[ NYMS_BASENAME ]['Name']  = $name;
		$plugins[ NYMS_BASENAME ]['Title'] = $name;

		return $plugins;
	}

	/**
	 * Add the screen under Tools.
	 *
	 * @return void
	 */
	public function add_page() {
		add_management_page(
			NYMS_Helpers::plugin_name(),
			__( 'Security', 'newyorkmechanics-security' ),
			'manage_options',
			self::SLUG,
			array( $this, 'render' )
		);
	}

	/**
	 * Add a shortcut from the plugin list.
	 *
	 * @param array $links Existing links.
	 * @return array
	 */
	public function action_link( $links ) {
		if ( ! is_array( $links ) ) {
			$links = array();
		}

		array_unshift(
			$links,
			'<a href="' . esc_url( $this->url() ) . '">' . esc_html__( 'Settings', 'newyorkmechanics-security' ) . '</a>'
		);

		return $links;
	}

	/**
	 * URL of the screen.
	 *
	 * @return string
	 */
	private function url() {
		return admin_url( 'tools.php?page=' . self::SLUG );
	}

	/**
	 * Save the submitted settings.
	 *
	 * @return void
	 */
	public function handle_save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to change these settings.', 'newyorkmechanics-security' ) );
		}

		check_admin_referer( 'nyms_save' );

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each value is validated against its own definition in NYMS_Settings::save().
		$input = isset( $_POST['nyms'] ) && is_array( $_POST['nyms'] ) ? wp_unslash( $_POST['nyms'] ) : array();

		NYMS_Settings::save( $input );

		// The constants for this request already hold the old values, so the
		// server rules are rewritten on the next load instead.
		set_transient( 'nyms_sync_rules', 1, 5 * MINUTE_IN_SECONDS );
		delete_transient( 'nyms_protection_checked' );

		wp_safe_redirect( add_query_arg( 'nyms-saved', '1', $this->url() ) );
		exit;
	}

	/**
	 * Bring the .htaccess rules in line after a save.
	 *
	 * @return void
	 */
	public function maybe_sync_rules() {
		if ( ! get_transient( 'nyms_sync_rules' ) ) {
			return;
		}

		delete_transient( 'nyms_sync_rules' );

		if ( NYMS_MANAGE_HTACCESS ) {
			NYMS_Htaccess::install();
		} else {
			NYMS_Htaccess::uninstall();
		}
	}

	/**
	 * Environment problems the plugin cannot fix from inside PHP.
	 *
	 * @return array
	 */
	private function warnings() {
		$warnings = array();

		if ( $this->has_default_salts() ) {
			$warnings[] = __( 'The security keys and salts in wp-config.php are still the placeholder values. Anyone who knows them can forge login cookies. Replace them from the WordPress secret-key service; it signs everyone out, including an intruder.', 'newyorkmechanics-security' );
		}

		if ( defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_DISPLAY' ) && WP_DEBUG_DISPLAY ) {
			$warnings[] = __( 'WP_DEBUG_DISPLAY is on. PHP errors printed to the page reveal file paths and database details.', 'newyorkmechanics-security' );
		}

		if ( defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
			$warnings[] = __( 'WP_DEBUG_LOG is on. The log file is blocked from the web while the server rules are active, but turning it off on a live site is better.', 'newyorkmechanics-security' );
		}

		if ( is_ssl() && ( ! defined( 'FORCE_SSL_ADMIN' ) || ! FORCE_SSL_ADMIN ) ) {
			$warnings[] = __( 'FORCE_SSL_ADMIN is not set in wp-config.php, so the admin area can be reached over plain HTTP.', 'newyorkmechanics-security' );
		}

		if ( ! defined( 'DISALLOW_UNFILTERED_UPLOADS' ) || ! DISALLOW_UNFILTERED_UPLOADS ) {
			$warnings[] = __( 'DISALLOW_UNFILTERED_UPLOADS is not set in wp-config.php. Adding it stops any code path from bypassing the upload type checks.', 'newyorkmechanics-security' );
		}

		if ( file_exists( ABSPATH . 'readme.html' ) ) {
			$warnings[] = __( 'readme.html still exists in the site root. It is blocked from the web while the server rules are active, but deleting it is cleaner - WordPress recreates it on every update.', 'newyorkmechanics-security' );
		}

		return $warnings;
	}

	/**
	 * Detect untouched wp-config.php placeholders.
	 *
	 * @return bool
	 */
	private function has_default_salts() {
		$keys = array( 'AUTH_KEY', 'SECURE_AUTH_KEY', 'LOGGED_IN_KEY', 'NONCE_KEY', 'AUTH_SALT', 'SECURE_AUTH_SALT', 'LOGGED_IN_SALT', 'NONCE_SALT' );
		$seen = array();

		foreach ( $keys as $key ) {
			if ( ! defined( $key ) ) {
				continue;
			}

			$value = (string) constant( $key );

			if ( '' === $value || NYMS_Helpers::has( str_replace( '-', ' ', $value ), 'put your unique phrase' ) ) {
				return true;
			}

			$seen[] = $value;
		}

		return count( $seen ) > 1 && count( array_unique( $seen ) ) < count( $seen );
	}

	/**
	 * Render the screen.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'newyorkmechanics-security' ) );
		}

		$definitions = NYMS_Settings::definitions();
		$groups      = NYMS_Settings::groups();
		$server      = NYMS_Htaccess::status();
		$warnings    = $this->warnings();
		$folder      = basename( dirname( NYMS_FILE ) );
		$suggested   = NYMS_Helpers::plugin_slug();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only notice flag.
		$saved = isset( $_GET['nyms-saved'] );
		?>
		<div class="wrap">
			<h1><?php echo esc_html( NYMS_Helpers::plugin_name() ); ?></h1>

			<?php if ( $saved ) : ?>
				<div class="notice notice-success is-dismissible">
					<p><?php esc_html_e( 'Settings saved. Only the protections ticked below are applied.', 'newyorkmechanics-security' ); ?></p>
				</div>
			<?php endif; ?>

			<p class="description" style="max-width:820px;">
				<?php esc_html_e( 'Tick a protection to apply it. Anything defined in wp-config.php is shown as locked and cannot be changed here - that is the safest place for the settings you never want touched from a browser.', 'newyorkmechanics-security' ); ?>
			</p>

			<?php if ( $warnings ) : ?>
				<div class="notice notice-warning">
					<p><strong><?php esc_html_e( 'Needs your attention in wp-config.php or on the server:', 'newyorkmechanics-security' ); ?></strong></p>
					<ul style="list-style:disc;margin-left:20px;">
						<?php foreach ( $warnings as $warning ) : ?>
							<li><?php echo esc_html( $warning ); ?></li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>

			<h2><?php esc_html_e( 'Server rules in place right now', 'newyorkmechanics-security' ); ?></h2>
			<table class="widefat striped" style="max-width:820px;">
				<tbody>
					<tr>
						<td style="width:70%;"><?php esc_html_e( 'Server honours .htaccess (Apache or LiteSpeed)', 'newyorkmechanics-security' ); ?></td>
						<td><?php echo wp_kses_post( $this->badge( $server['apache'] ) ); ?></td>
					</tr>
					<tr>
						<td><?php esc_html_e( 'Site root: hidden files, backups, wp-config.php, wp-includes, directory listings', 'newyorkmechanics-security' ); ?></td>
						<td><?php echo wp_kses_post( $this->badge( $server['root'] ) ); ?></td>
					</tr>
					<tr>
						<td><?php esc_html_e( 'Uploads folder: PHP, CGI and script execution refused', 'newyorkmechanics-security' ); ?></td>
						<td><?php echo wp_kses_post( $this->badge( $server['uploads'] ) ); ?></td>
					</tr>
				</tbody>
			</table>

			<?php if ( ! $server['apache'] ) : ?>
				<p class="description">
					<?php esc_html_e( 'This server does not read .htaccess. Copy the nginx rules from the plugin readme.txt into the server block; the PHP-level protections work either way.', 'newyorkmechanics-security' ); ?>
				</p>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="nyms_save" />
				<?php wp_nonce_field( 'nyms_save' ); ?>

				<?php foreach ( $groups as $group_key => $group_title ) : ?>
					<h2><?php echo esc_html( $group_title ); ?></h2>
					<table class="widefat striped" style="max-width:820px;">
						<tbody>
							<?php foreach ( $definitions as $key => $definition ) : ?>
								<?php
								if ( $definition['group'] !== $group_key ) {
									continue;
								}

								$locked = NYMS_Settings::is_locked( $key );
								$value  = NYMS_Settings::value( $key );
								?>
								<tr>
									<td style="width:70%;">
										<label for="<?php echo esc_attr( $key ); ?>">
											<strong><?php echo esc_html( $definition['label'] ); ?></strong>
										</label>
										<p class="description" style="margin:4px 0 0;">
											<?php echo wp_kses( $definition['help'], array( 'code' => array() ) ); ?>
										</p>
										<code style="font-size:11px;opacity:.6;"><?php echo esc_html( $key ); ?></code>
										<?php if ( $locked ) : ?>
											<span style="font-size:11px;color:#996800;">
												&#128274; <?php esc_html_e( 'locked in wp-config.php', 'newyorkmechanics-security' ); ?>
											</span>
										<?php endif; ?>
									</td>
									<td style="vertical-align:middle;">
										<?php $this->field( $key, $definition, $value, $locked ); ?>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				<?php endforeach; ?>

				<p class="submit">
					<input type="submit" class="button button-primary"
						value="<?php esc_attr_e( 'Save settings', 'newyorkmechanics-security' ); ?>" />
				</p>
			</form>

			<h2><?php esc_html_e( 'Environment', 'newyorkmechanics-security' ); ?></h2>
			<table class="widefat striped" style="max-width:820px;">
				<tbody>
					<tr>
						<td style="width:70%;"><?php esc_html_e( 'Plugin version', 'newyorkmechanics-security' ); ?></td>
						<td><code><?php echo esc_html( NYMS_VERSION ); ?></code></td>
					</tr>
					<tr>
						<td>
							<?php esc_html_e( 'Plugin folder', 'newyorkmechanics-security' ); ?>
							<?php if ( $folder !== $suggested ) : ?>
								<p class="description" style="margin:4px 0 0;">
									<?php
									printf(
										/* translators: %s: suggested folder name. */
										esc_html__( 'To match the site name it would be %s. Renaming the folder is a manual step - a plugin that renamed its own directory would deactivate itself mid-request - so rename it over SFTP and reactivate if you want them to match.', 'newyorkmechanics-security' ),
										'<code>' . esc_html( $suggested ) . '</code>'
									);
									?>
								</p>
							<?php endif; ?>
						</td>
						<td><code><?php echo esc_html( $folder ); ?></code></td>
					</tr>
					<tr>
						<td><?php esc_html_e( 'WordPress', 'newyorkmechanics-security' ); ?></td>
						<td><code><?php echo esc_html( get_bloginfo( 'version' ) ); ?></code></td>
					</tr>
					<tr>
						<td><?php esc_html_e( 'PHP', 'newyorkmechanics-security' ); ?></td>
						<td><code><?php echo esc_html( PHP_VERSION ); ?></code></td>
					</tr>
					<tr>
						<td><?php esc_html_e( 'Your IP as this plugin sees it', 'newyorkmechanics-security' ); ?></td>
						<td><code><?php echo esc_html( NYMS_Helpers::client_ip() ); ?></code></td>
					</tr>
				</tbody>
			</table>
		</div>
		<?php
	}

	/**
	 * Render one input.
	 *
	 * @param string $key        Constant name.
	 * @param array  $definition Field definition.
	 * @param mixed  $value      Current value.
	 * @param bool   $locked     Whether wp-config.php owns this switch.
	 * @return void
	 */
	private function field( $key, $definition, $value, $locked ) {
		$name = 'nyms[' . $key . ']';

		if ( 'bool' === $definition['type'] ) {
			printf(
				'<label><input type="checkbox" id="%1$s" name="%2$s" value="1"%3$s%4$s /> %5$s</label>',
				esc_attr( $key ),
				esc_attr( $name ),
				checked( (bool) $value, true, false ),
				$locked ? ' disabled="disabled"' : '', // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed literal.
				esc_html__( 'Enabled', 'newyorkmechanics-security' )
			);

			return;
		}

		if ( 'choice' === $definition['type'] ) {
			echo '<select id="' . esc_attr( $key ) . '" name="' . esc_attr( $name ) . '"' . ( $locked ? ' disabled="disabled"' : '' ) . '>';

			foreach ( $definition['choices'] as $choice => $label ) {
				printf(
					'<option value="%1$s"%2$s>%3$s</option>',
					esc_attr( $choice ),
					selected( (string) $value, (string) $choice, false ),
					esc_html( $label )
				);
			}

			echo '</select>';

			return;
		}

		printf(
			'<input type="number" id="%1$s" name="%2$s" value="%3$s" min="%4$d" max="%5$d" class="small-text"%6$s />',
			esc_attr( $key ),
			esc_attr( $name ),
			esc_attr( $value ),
			(int) $definition['min'],
			(int) $definition['max'],
			$locked ? ' disabled="disabled"' : '' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed literal.
		);
	}

	/**
	 * A coloured yes/no badge.
	 *
	 * @param bool|null $state True, false, or null when it cannot be read.
	 * @return string
	 */
	private function badge( $state ) {
		if ( null === $state ) {
			return '<span style="color:#996800;font-weight:600;">' . esc_html__( 'Cannot read', 'newyorkmechanics-security' ) . '</span>';
		}

		if ( $state ) {
			return '<span style="color:#007017;font-weight:600;">&#10003; ' . esc_html__( 'Active', 'newyorkmechanics-security' ) . '</span>';
		}

		return '<span style="color:#8a2424;font-weight:600;">&#10007; ' . esc_html__( 'Off', 'newyorkmechanics-security' ) . '</span>';
	}
}

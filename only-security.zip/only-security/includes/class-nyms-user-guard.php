<?php
/**
 * Account, session and privilege monitoring.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Watches the accounts that can change the site.
 *
 * The first thing an intruder does after getting in is make a second way in:
 * a new administrator, a quietly promoted subscriber, an application password.
 * Every one of those leaves a trace here.
 */
class NYMS_User_Guard {

	/**
	 * Meta keys.
	 */
	const LAST_LOGIN = 'nyms_last_login';
	const DISABLED   = 'nyms_disabled';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! NYMS_USER_GUARD ) {
			return;
		}

		add_action( 'user_register', array( $this, 'on_register' ), 10, 1 );
		add_action( 'set_user_role', array( $this, 'on_role_change' ), 10, 3 );
		add_action( 'add_user_role', array( $this, 'on_role_added' ), 10, 2 );
		add_action( 'profile_update', array( $this, 'on_profile_update' ), 10, 2 );
		add_action( 'delete_user', array( $this, 'on_delete_user' ), 10, 1 );

		add_action( 'wp_login', array( $this, 'on_login' ), 10, 2 );
		add_action( 'wp_login_failed', array( $this, 'on_login_failed' ), 10, 1 );
		add_action( 'wp_logout', array( $this, 'on_logout' ), 10, 1 );

		add_filter( 'authenticate', array( $this, 'block_disabled_accounts' ), 40, 3 );

		add_action( 'nyms_user_audit', array( $this, 'audit' ) );

		// Administrator activity worth keeping.
		add_action( 'switch_theme', array( $this, 'on_theme_switch' ), 10, 1 );
		add_action( 'updated_option', array( $this, 'on_option_change' ), 10, 3 );
		add_action( 'added_option', array( $this, 'on_option_added' ), 10, 2 );
		add_action( 'wp_create_application_password', array( $this, 'on_app_password' ), 10, 4 );

		if ( NYMS_LIMIT_SESSIONS ) {
			add_action( 'wp_login', array( $this, 'enforce_session_limit' ), 20, 2 );
		}

		if ( NYMS_BLOCK_WEAK_USERNAMES ) {
			add_filter( 'validate_username', array( $this, 'validate_username' ), 10, 2 );
		}
	}

	/**
	 * User names that should never exist on a live site.
	 *
	 * @return array
	 */
	public static function reserved_names() {
		return array(
			'admin', 'administrator', 'root', 'test', 'demo', 'user', 'guest',
			'wordpress', 'wpadmin', 'webmaster', 'support', 'sysadmin', 'operator',
			'manager', 'backup', 'temp', 'sql', 'mysql', 'www', 'ftp',
		);
	}

	/**
	 * Whether a login name looks like one an attacker created.
	 *
	 * @param string $login User name.
	 * @return string|false Reason, or false.
	 */
	public static function suspicious_username( $login ) {
		$login = (string) $login;
		$lower = strtolower( $login );

		if ( in_array( $lower, self::reserved_names(), true ) ) {
			return __( 'it is one of the names every password-guessing script tries first', 'newyorkmechanics-security' );
		}

		// Random hex or base-36 blobs: wp8f3a91, a1b2c3d4e5.
		if ( preg_match( '/^[a-f0-9]{8,}$/i', $lower ) || preg_match( '/^[a-z]{1,3}[0-9]{6,}$/', $lower ) ) {
			return __( 'the name looks machine generated', 'newyorkmechanics-security' );
		}

		// Names built to sit next to a real one in a list.
		if ( preg_match( '/^(wp|wordpress|site|admin|adm|sys)[\-_.]?(support|admin|user|backup|service|update|helper|content)/i', $lower ) ) {
			return __( 'the name imitates a WordPress or hosting service account', 'newyorkmechanics-security' );
		}

		if ( preg_match( '/[^\x20-\x7e]/', $login ) ) {
			return __( 'the name contains characters outside the printable ASCII range', 'newyorkmechanics-security' );
		}

		return false;
	}

	/**
	 * Refuse to register an obviously bad user name.
	 *
	 * @param bool   $valid Whether the name is acceptable.
	 * @param string $login Proposed name.
	 * @return bool
	 */
	public function validate_username( $valid, $login ) {
		if ( ! $valid ) {
			return $valid;
		}

		return self::suspicious_username( $login ) ? false : $valid;
	}

	/**
	 * Note a new account, loudly when it can administer the site.
	 *
	 * @param int $user_id New user ID.
	 * @return void
	 */
	public function on_register( $user_id ) {
		$user = get_userdata( $user_id );

		if ( ! $user ) {
			return;
		}

		$privileged = $this->is_privileged( $user );
		$suspicious = self::suspicious_username( $user->user_login );

		NYMS_Log::record(
			$privileged ? 'admin_created' : 'user_created',
			$privileged ? NYMS_Log::CRITICAL : NYMS_Log::NOTICE,
			$privileged
				? sprintf(
					/* translators: 1: user login, 2: roles. */
					__( 'A new account with administrative access was created: %1$s (%2$s)', 'newyorkmechanics-security' ),
					$user->user_login,
					implode( ', ', (array) $user->roles )
				)
				: sprintf( /* translators: %s: user login. */ __( 'New account registered: %s', 'newyorkmechanics-security' ), $user->user_login ),
			array(
				'user_id'    => $user_id,
				'email'      => $user->user_email,
				'roles'      => (array) $user->roles,
				'created_by' => get_current_user_id(),
				'suspicious' => $suspicious ? $suspicious : false,
			)
		);

		if ( $suspicious ) {
			NYMS_Log::record(
				'suspicious_username',
				NYMS_Log::WARNING,
				sprintf(
					/* translators: 1: user login, 2: reason. */
					__( 'The account %1$s has a suspicious name: %2$s', 'newyorkmechanics-security' ),
					$user->user_login,
					$suspicious
				),
				array( 'user_id' => $user_id )
			);
		}
	}

	/**
	 * Watch for privilege escalation.
	 *
	 * @param int    $user_id   User ID.
	 * @param string $role      New role.
	 * @param array  $old_roles Previous roles.
	 * @return void
	 */
	public function on_role_change( $user_id, $role, $old_roles ) {
		$user = get_userdata( $user_id );

		if ( ! $user ) {
			return;
		}

		$was_privileged = (bool) array_intersect( (array) $old_roles, $this->privileged_roles() );
		$now_privileged = in_array( $role, $this->privileged_roles(), true );
		$escalation     = $now_privileged && ! $was_privileged;

		NYMS_Log::record(
			$escalation ? 'privilege_escalation' : 'role_changed',
			$escalation ? NYMS_Log::CRITICAL : NYMS_Log::NOTICE,
			sprintf(
				/* translators: 1: user login, 2: old roles, 3: new role. */
				__( 'Role of %1$s changed from %2$s to %3$s', 'newyorkmechanics-security' ),
				$user->user_login,
				$old_roles ? implode( ', ', (array) $old_roles ) : __( 'none', 'newyorkmechanics-security' ),
				$role
			),
			array(
				'user_id'    => $user_id,
				'changed_by' => get_current_user_id(),
				'old'        => (array) $old_roles,
				'new'        => $role,
			)
		);
	}

	/**
	 * Watch for a second role being stacked onto an account.
	 *
	 * @param int    $user_id User ID.
	 * @param string $role    Added role.
	 * @return void
	 */
	public function on_role_added( $user_id, $role ) {
		if ( ! in_array( $role, $this->privileged_roles(), true ) ) {
			return;
		}

		$user = get_userdata( $user_id );

		NYMS_Log::record(
			'privilege_escalation',
			NYMS_Log::CRITICAL,
			sprintf(
				/* translators: 1: user login, 2: role. */
				__( 'The role %2$s was added to %1$s', 'newyorkmechanics-security' ),
				$user ? $user->user_login : $user_id,
				$role
			),
			array( 'user_id' => $user_id, 'changed_by' => get_current_user_id() )
		);
	}

	/**
	 * Note changes to an address or a password.
	 *
	 * @param int     $user_id User ID.
	 * @param WP_User $old     User before the change.
	 * @return void
	 */
	public function on_profile_update( $user_id, $old ) {
		$user = get_userdata( $user_id );

		if ( ! $user || ! $old instanceof WP_User ) {
			return;
		}

		if ( $user->user_email !== $old->user_email ) {
			NYMS_Log::record(
				'email_changed',
				$this->is_privileged( $user ) ? NYMS_Log::WARNING : NYMS_Log::NOTICE,
				sprintf(
					/* translators: 1: user login, 2: old address, 3: new address. */
					__( 'The address for %1$s changed from %2$s to %3$s', 'newyorkmechanics-security' ),
					$user->user_login,
					$old->user_email,
					$user->user_email
				),
				array( 'user_id' => $user_id, 'changed_by' => get_current_user_id() )
			);
		}

		if ( $user->user_pass !== $old->user_pass ) {
			NYMS_Log::record(
				'password_changed',
				NYMS_Log::NOTICE,
				sprintf( /* translators: %s: user login. */ __( 'The password for %s was changed.', 'newyorkmechanics-security' ), $user->user_login ),
				array( 'user_id' => $user_id, 'changed_by' => get_current_user_id() )
			);
		}
	}

	/**
	 * Note a deleted account.
	 *
	 * @param int $user_id User ID.
	 * @return void
	 */
	public function on_delete_user( $user_id ) {
		$user = get_userdata( $user_id );

		NYMS_Log::record(
			'user_deleted',
			NYMS_Log::WARNING,
			sprintf( /* translators: %s: user login. */ __( 'Account deleted: %s', 'newyorkmechanics-security' ), $user ? $user->user_login : $user_id ),
			array( 'user_id' => $user_id, 'deleted_by' => get_current_user_id() )
		);
	}

	/**
	 * Record a sign-in and look for a session that does not fit.
	 *
	 * @param string  $login User name.
	 * @param WP_User $user  User object.
	 * @return void
	 */
	public function on_login( $login, $user = null ) {
		if ( ! $user instanceof WP_User ) {
			$user = get_user_by( 'login', $login );
		}

		if ( ! $user ) {
			return;
		}

		$ip       = NYMS_Helpers::client_ip();
		$previous = get_user_meta( $user->ID, self::LAST_LOGIN, true );
		$previous = is_array( $previous ) ? $previous : array();

		$known_ips = isset( $previous['ips'] ) ? (array) $previous['ips'] : array();
		$new_place = $known_ips && ! in_array( $ip, $known_ips, true );

		$known_ips[] = $ip;
		$known_ips   = array_slice( array_unique( $known_ips ), -10 );

		update_user_meta(
			$user->ID,
			self::LAST_LOGIN,
			array(
				'time'  => time(),
				'ip'    => $ip,
				'agent' => isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ), 0, 200 ) : '',
				'ips'   => $known_ips,
			)
		);

		$privileged = $this->is_privileged( $user );

		NYMS_Log::record(
			'login',
			$privileged ? NYMS_Log::NOTICE : NYMS_Log::INFO,
			sprintf( /* translators: %s: user login. */ __( 'Signed in: %s', 'newyorkmechanics-security' ), $user->user_login ),
			array( 'user_id' => $user->ID, 'roles' => (array) $user->roles )
		);

		if ( $privileged && $new_place ) {
			NYMS_Log::record(
				'login_new_location',
				NYMS_Log::WARNING,
				sprintf(
					/* translators: 1: user login, 2: address. */
					__( 'The administrator %1$s signed in from an address never seen before: %2$s', 'newyorkmechanics-security' ),
					$user->user_login,
					$ip
				),
				array( 'user_id' => $user->ID )
			);
		}

		$sessions = $this->session_count( $user->ID );

		if ( $privileged && $sessions > (int) NYMS_MAX_SESSIONS ) {
			NYMS_Log::record(
				'concurrent_sessions',
				NYMS_Log::WARNING,
				sprintf(
					/* translators: 1: user login, 2: session count. */
					__( '%1$s has %2$d sessions open at once.', 'newyorkmechanics-security' ),
					$user->user_login,
					$sessions
				),
				array( 'user_id' => $user->ID )
			);
		}
	}

	/**
	 * Record a failed attempt.
	 *
	 * @param string $login Attempted user name.
	 * @return void
	 */
	public function on_login_failed( $login ) {
		NYMS_Log::record(
			'login_failed',
			NYMS_Log::NOTICE,
			sprintf( /* translators: %s: attempted user name. */ __( 'Failed sign-in for %s', 'newyorkmechanics-security' ), sanitize_user( (string) $login, true ) ),
			array( 'agent' => isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ), 0, 200 ) : '' )
		);

		$firewall = NYMS_Plugin::instance()->module( 'firewall' );

		if ( $firewall instanceof NYMS_Firewall ) {
			$firewall->register_violation( NYMS_Helpers::client_ip(), __( 'repeated failed sign-ins', 'newyorkmechanics-security' ) );
		}
	}

	/**
	 * Note a sign-out.
	 *
	 * @param int $user_id User ID.
	 * @return void
	 */
	public function on_logout( $user_id = 0 ) {
		if ( ! $user_id ) {
			return;
		}

		$user = get_userdata( $user_id );

		if ( $user && $this->is_privileged( $user ) ) {
			NYMS_Log::record(
				'logout',
				NYMS_Log::INFO,
				sprintf( /* translators: %s: user login. */ __( 'Signed out: %s', 'newyorkmechanics-security' ), $user->user_login ),
				array( 'user_id' => $user_id )
			);
		}
	}

	/**
	 * Refuse a sign-in for a disabled account.
	 *
	 * @param null|WP_User|WP_Error $user     Current result.
	 * @param string                $username Submitted name.
	 * @param string                $password Submitted password.
	 * @return null|WP_User|WP_Error
	 */
	public function block_disabled_accounts( $user, $username, $password ) {
		unset( $username, $password );

		if ( ! $user instanceof WP_User ) {
			return $user;
		}

		if ( ! get_user_meta( $user->ID, self::DISABLED, true ) ) {
			return $user;
		}

		NYMS_Log::record(
			'login_disabled_account',
			NYMS_Log::WARNING,
			sprintf( /* translators: %s: user login. */ __( 'A sign-in was attempted on the disabled account %s.', 'newyorkmechanics-security' ), $user->user_login ),
			array( 'user_id' => $user->ID )
		);

		return new WP_Error(
			'nyms_account_disabled',
			__( '<strong>Error</strong>: This account has been disabled. Contact the site administrator.', 'newyorkmechanics-security' )
		);
	}

	/**
	 * Turn an account off without deleting its content.
	 *
	 * @param int  $user_id User ID.
	 * @param bool $state   True to disable, false to enable.
	 * @return void
	 */
	public static function set_disabled( $user_id, $state ) {
		$user = get_userdata( $user_id );

		if ( ! $user ) {
			return;
		}

		if ( $state ) {
			update_user_meta( $user_id, self::DISABLED, time() );

			self::force_logout( $user_id );
		} else {
			delete_user_meta( $user_id, self::DISABLED );
		}

		NYMS_Log::record(
			$state ? 'account_disabled' : 'account_enabled',
			NYMS_Log::WARNING,
			sprintf(
				/* translators: %s: user login. */
				$state
					? __( 'Account disabled: %s', 'newyorkmechanics-security' )
					: __( 'Account re-enabled: %s', 'newyorkmechanics-security' ),
				$user->user_login
			),
			array( 'user_id' => $user_id, 'by' => get_current_user_id() )
		);
	}

	/**
	 * End every session an account has open.
	 *
	 * @param int $user_id User ID.
	 * @return void
	 */
	public static function force_logout( $user_id ) {
		if ( ! class_exists( 'WP_Session_Tokens' ) ) {
			return;
		}

		$manager = WP_Session_Tokens::get_instance( (int) $user_id );

		$manager->destroy_all();

		NYMS_Log::record(
			'sessions_destroyed',
			NYMS_Log::WARNING,
			sprintf( /* translators: %d: user ID. */ __( 'All sessions for user %d were ended.', 'newyorkmechanics-security' ), (int) $user_id ),
			array( 'by' => get_current_user_id() )
		);
	}

	/**
	 * How many sessions an account has open.
	 *
	 * @param int $user_id User ID.
	 * @return int
	 */
	public function session_count( $user_id ) {
		if ( ! class_exists( 'WP_Session_Tokens' ) ) {
			return 0;
		}

		$manager = WP_Session_Tokens::get_instance( (int) $user_id );

		return count( (array) $manager->get_all() );
	}

	/**
	 * Keep only the newest sessions when an account has too many.
	 *
	 * @param string  $login User name.
	 * @param WP_User $user  User object.
	 * @return void
	 */
	public function enforce_session_limit( $login, $user = null ) {
		unset( $login );

		if ( ! $user instanceof WP_User || ! class_exists( 'WP_Session_Tokens' ) ) {
			return;
		}

		$limit = (int) NYMS_MAX_SESSIONS;

		if ( $limit < 1 ) {
			return;
		}

		$manager  = WP_Session_Tokens::get_instance( $user->ID );
		$sessions = (array) $manager->get_all();

		if ( count( $sessions ) <= $limit ) {
			return;
		}

		// destroy_others() keeps the session this request is using.
		$token = function_exists( 'wp_get_session_token' ) ? wp_get_session_token() : '';

		if ( $token ) {
			$manager->destroy_others( $token );

			NYMS_Log::record(
				'session_limit',
				NYMS_Log::NOTICE,
				sprintf(
					/* translators: %s: user login. */
					__( 'Older sessions for %s were ended because the session limit was reached.', 'newyorkmechanics-security' ),
					$user->user_login
				),
				array( 'user_id' => $user->ID )
			);
		}
	}

	/**
	 * Note a theme switch.
	 *
	 * @param string $name New theme name.
	 * @return void
	 */
	public function on_theme_switch( $name ) {
		NYMS_Log::record(
			'theme_switched',
			NYMS_Log::WARNING,
			sprintf( /* translators: %s: theme name. */ __( 'The active theme was changed to %s.', 'newyorkmechanics-security' ), $name ),
			array( 'by' => get_current_user_id() )
		);
	}

	/**
	 * Options whose value decides who can get in.
	 *
	 * @return array
	 */
	private function watched_options() {
		return array(
			'siteurl'                 => NYMS_Log::CRITICAL,
			'home'                    => NYMS_Log::CRITICAL,
			'admin_email'             => NYMS_Log::CRITICAL,
			'users_can_register'      => NYMS_Log::CRITICAL,
			'default_role'            => NYMS_Log::CRITICAL,
			'active_plugins'          => NYMS_Log::NOTICE,
			'template'                => NYMS_Log::WARNING,
			'stylesheet'              => NYMS_Log::WARNING,
			'mailserver_url'          => NYMS_Log::WARNING,
			'blog_public'             => NYMS_Log::NOTICE,
			'upload_path'             => NYMS_Log::CRITICAL,
			'upload_url_path'         => NYMS_Log::CRITICAL,
			'nyms_settings'           => NYMS_Log::WARNING,
			'cron'                    => NYMS_Log::INFO,
		);
	}

	/**
	 * Note a change to a watched option.
	 *
	 * @param string $option Option name.
	 * @param mixed  $old    Old value.
	 * @param mixed  $value  New value.
	 * @return void
	 */
	public function on_option_change( $option, $old, $value ) {
		$watched = $this->watched_options();

		if ( ! isset( $watched[ $option ] ) || 'cron' === $option ) {
			return;
		}

		if ( is_scalar( $old ) && is_scalar( $value ) && (string) $old === (string) $value ) {
			return;
		}

		NYMS_Log::record(
			'option_changed',
			$watched[ $option ],
			sprintf( /* translators: %s: option name. */ __( 'The setting %s was changed.', 'newyorkmechanics-security' ), $option ),
			array(
				'option' => $option,
				'from'   => is_scalar( $old ) ? (string) $old : '(complex value)',
				'to'     => is_scalar( $value ) ? (string) $value : '(complex value)',
				'by'     => get_current_user_id(),
			)
		);
	}

	/**
	 * Note a watched option being created.
	 *
	 * @param string $option Option name.
	 * @param mixed  $value  Value.
	 * @return void
	 */
	public function on_option_added( $option, $value ) {
		$this->on_option_change( $option, '', $value );
	}

	/**
	 * Note a new application password.
	 *
	 * @param int    $user_id  User ID.
	 * @param array  $item     Password record.
	 * @param string $password The generated password.
	 * @param array  $args     Arguments.
	 * @return void
	 */
	public function on_app_password( $user_id, $item, $password, $args ) {
		unset( $password, $args );

		$user = get_userdata( $user_id );

		NYMS_Log::record(
			'app_password_created',
			NYMS_Log::CRITICAL,
			sprintf(
				/* translators: 1: user login, 2: password label. */
				__( 'An application password named "%2$s" was created for %1$s. These survive a password change.', 'newyorkmechanics-security' ),
				$user ? $user->user_login : $user_id,
				isset( $item['name'] ) ? $item['name'] : '?'
			),
			array( 'user_id' => $user_id, 'by' => get_current_user_id() )
		);
	}

	/**
	 * Roles that can change the site.
	 *
	 * @return array
	 */
	public function privileged_roles() {
		/**
		 * Filter the roles treated as privileged.
		 *
		 * @param array $roles Role slugs.
		 */
		return (array) apply_filters( 'nyms_privileged_roles', array( 'administrator', 'editor', 'shop_manager' ) );
	}

	/**
	 * Whether a user can change the site.
	 *
	 * @param WP_User $user User.
	 * @return bool
	 */
	public function is_privileged( $user ) {
		if ( ! $user instanceof WP_User ) {
			return false;
		}

		if ( array_intersect( (array) $user->roles, $this->privileged_roles() ) ) {
			return true;
		}

		return user_can( $user, 'manage_options' ) || user_can( $user, 'edit_others_posts' );
	}

	/**
	 * The list of accounts that can administer the site.
	 *
	 * @return array
	 */
	public function administrators() {
		$users = get_users(
			array(
				'role__in' => $this->privileged_roles(),
				'number'   => 200,
				'fields'   => array( 'ID', 'user_login', 'user_email', 'user_registered' ),
			)
		);

		$out = array();

		foreach ( $users as $user ) {
			$meta = get_user_meta( $user->ID, self::LAST_LOGIN, true );
			$full = get_userdata( $user->ID );

			$out[] = array(
				'id'         => (int) $user->ID,
				'login'      => $user->user_login,
				'email'      => $user->user_email,
				'registered' => $user->user_registered,
				'roles'      => $full ? (array) $full->roles : array(),
				'last_login' => is_array( $meta ) && ! empty( $meta['time'] ) ? (int) $meta['time'] : 0,
				'last_ip'    => is_array( $meta ) && ! empty( $meta['ip'] ) ? $meta['ip'] : '',
				'sessions'   => $this->session_count( $user->ID ),
				'disabled'   => (bool) get_user_meta( $user->ID, self::DISABLED, true ),
				'suspicious' => self::suspicious_username( $user->user_login ),
				'2fa'        => (bool) get_user_meta( $user->ID, NYMS_Two_Factor::SECRET, true ),
			);
		}

		return $out;
	}

	/**
	 * The scheduled account audit.
	 *
	 * @return array
	 */
	public function audit() {
		$admins   = $this->administrators();
		$inactive = array();
		$cutoff   = time() - ( (int) NYMS_INACTIVE_DAYS * DAY_IN_SECONDS );

		foreach ( $admins as $admin ) {
			if ( $admin['suspicious'] ) {
				NYMS_Log::record(
					'suspicious_username',
					NYMS_Log::WARNING,
					sprintf(
						/* translators: 1: user login, 2: reason. */
						__( 'The privileged account %1$s has a suspicious name: %2$s', 'newyorkmechanics-security' ),
						$admin['login'],
						$admin['suspicious']
					),
					array( 'user_id' => $admin['id'] )
				);
			}

			if ( $admin['disabled'] ) {
				continue;
			}

			$reference = $admin['last_login'] ? $admin['last_login'] : strtotime( $admin['registered'] );

			if ( $reference && $reference < $cutoff ) {
				$inactive[] = $admin;

				if ( NYMS_DISABLE_INACTIVE ) {
					self::set_disabled( $admin['id'], true );
				} else {
					NYMS_Log::record(
						'inactive_admin',
						NYMS_Log::WARNING,
						sprintf(
							/* translators: 1: user login, 2: number of days. */
							__( 'The privileged account %1$s has not signed in for more than %2$d days.', 'newyorkmechanics-security' ),
							$admin['login'],
							(int) NYMS_INACTIVE_DAYS
						),
						array( 'user_id' => $admin['id'] )
					);
				}
			}
		}

		update_option(
			'nyms_user_audit',
			array(
				'at'       => time(),
				'admins'   => count( $admins ),
				'inactive' => count( $inactive ),
			),
			false
		);

		return array( 'admins' => $admins, 'inactive' => $inactive );
	}
}

<?php
/**
 * Security event log.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A single, append-only record of everything the plugin saw and did.
 *
 * Every other module writes here. The table is owned by the plugin and is
 * covered by the self-protection module, so tampering is detectable.
 */
class NYMS_Log {

	/**
	 * Severity levels, lowest first.
	 */
	const INFO     = 0;
	const NOTICE   = 1;
	const WARNING  = 2;
	const CRITICAL = 3;

	/**
	 * Database schema version for this table.
	 */
	const SCHEMA = 3;

	/**
	 * Fully qualified table name.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;

		return $wpdb->prefix . 'nyms_log';
	}

	/**
	 * Create or upgrade the table.
	 *
	 * @return void
	 */
	public static function install() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table   = self::table();
		$collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			logged_at datetime NOT NULL,
			event_type varchar(40) NOT NULL DEFAULT '',
			severity tinyint(1) unsigned NOT NULL DEFAULT 0,
			ip varchar(45) NOT NULL DEFAULT '',
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			message text NOT NULL,
			context longtext NULL,
			fingerprint varchar(32) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			KEY logged_at (logged_at),
			KEY event_type (event_type),
			KEY severity (severity),
			KEY fingerprint (fingerprint)
		) {$collate};";

		dbDelta( $sql );

		update_option( 'nyms_log_schema', self::SCHEMA, false );
	}

	/**
	 * Whether the table is present.
	 *
	 * @return bool
	 */
	public static function ready() {
		global $wpdb;

		static $ready = null;

		if ( null !== $ready ) {
			return $ready;
		}

		$table = self::table();
		$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ); // phpcs:ignore WordPress.DB

		$ready = ( $found === $table );

		return $ready;
	}

	/**
	 * Write one event.
	 *
	 * Identical events inside a short window are collapsed so a flood of the
	 * same probe cannot fill the table.
	 *
	 * @param string $type     Machine readable event type.
	 * @param int    $severity One of the class constants.
	 * @param string $message  Human readable summary.
	 * @param array  $context  Extra structured detail.
	 * @return void
	 */
	public static function record( $type, $severity, $message, $context = array() ) {
		if ( ! defined( 'NYMS_LOGGING' ) || ! NYMS_LOGGING || ! self::ready() ) {
			return;
		}

		global $wpdb;

		$severity    = max( 0, min( 3, (int) $severity ) );
		$fingerprint = substr( md5( $type . '|' . $message . '|' . wp_json_encode( $context ) ), 0, 32 );

		// Collapse a repeat of the same event within five minutes.
		$recent = $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				'SELECT id FROM ' . self::table() . ' WHERE fingerprint = %s AND logged_at > %s LIMIT 1',
				$fingerprint,
				gmdate( 'Y-m-d H:i:s', time() - 300 )
			)
		);

		if ( $recent ) {
			return;
		}

		$wpdb->insert( // phpcs:ignore WordPress.DB
			self::table(),
			array(
				'logged_at'   => gmdate( 'Y-m-d H:i:s' ),
				'event_type'  => substr( (string) $type, 0, 40 ),
				'severity'    => $severity,
				'ip'          => NYMS_Helpers::client_ip(),
				'user_id'     => function_exists( 'get_current_user_id' ) ? get_current_user_id() : 0,
				'message'     => (string) $message,
				'context'     => wp_json_encode( $context ),
				'fingerprint' => $fingerprint,
			),
			array( '%s', '%s', '%d', '%s', '%d', '%s', '%s', '%s' )
		);

		if ( self::CRITICAL === $severity ) {
			self::notify( $type, $message, $context );
		}
	}

	/**
	 * Send an alert for a critical event, throttled to one mail an hour.
	 *
	 * @param string $type    Event type.
	 * @param string $message Summary.
	 * @param array  $context Detail.
	 * @return void
	 */
	private static function notify( $type, $message, $context ) {
		if ( ! NYMS_ALERT_EMAIL ) {
			return;
		}

		$to = get_option( 'nyms_alert_address' );

		if ( ! is_email( $to ) ) {
			$to = get_option( 'admin_email' );
		}

		if ( ! is_email( $to ) ) {
			return;
		}

		$throttle = 'nyms_alert_' . substr( md5( $type ), 0, 12 );

		if ( get_transient( $throttle ) ) {
			return;
		}

		set_transient( $throttle, 1, HOUR_IN_SECONDS );

		$body = array(
			sprintf(
				/* translators: %s: site name. */
				__( 'A critical security event was recorded on %s.', 'newyorkmechanics-security' ),
				get_bloginfo( 'name' )
			),
			'',
			__( 'Event:', 'newyorkmechanics-security' ) . ' ' . $type,
			__( 'Detail:', 'newyorkmechanics-security' ) . ' ' . wp_strip_all_tags( $message ),
			__( 'Client IP:', 'newyorkmechanics-security' ) . ' ' . NYMS_Helpers::client_ip(),
			__( 'Time (UTC):', 'newyorkmechanics-security' ) . ' ' . gmdate( 'Y-m-d H:i:s' ),
			'',
			wp_json_encode( $context ),
			'',
			admin_url( 'tools.php?page=nyms-security&tab=events' ),
		);

		wp_mail(
			$to,
			sprintf(
				/* translators: %s: site name. */
				__( '[%s] Critical security event', 'newyorkmechanics-security' ),
				get_bloginfo( 'name' )
			),
			implode( "\n", $body )
		);
	}

	/**
	 * Read events, newest first.
	 *
	 * @param array $args Query arguments: type, severity, limit, offset, since.
	 * @return array
	 */
	public static function query( $args = array() ) {
		if ( ! self::ready() ) {
			return array();
		}

		global $wpdb;

		$args = wp_parse_args(
			$args,
			array(
				'type'     => '',
				'severity' => -1,
				'limit'    => 50,
				'offset'   => 0,
				'since'    => '',
			)
		);

		$where  = array( '1=1' );
		$params = array();

		if ( '' !== $args['type'] ) {
			$where[]  = 'event_type = %s';
			$params[] = $args['type'];
		}

		if ( $args['severity'] >= 0 ) {
			$where[]  = 'severity >= %d';
			$params[] = (int) $args['severity'];
		}

		if ( '' !== $args['since'] ) {
			$where[]  = 'logged_at >= %s';
			$params[] = $args['since'];
		}

		$params[] = (int) $args['limit'];
		$params[] = (int) $args['offset'];

		$sql = 'SELECT * FROM ' . self::table() . ' WHERE ' . implode( ' AND ', $where ) . ' ORDER BY id DESC LIMIT %d OFFSET %d';

		return (array) $wpdb->get_results( $wpdb->prepare( $sql, $params ) ); // phpcs:ignore WordPress.DB
	}

	/**
	 * Count events by severity for a period.
	 *
	 * @param int $days Days to look back.
	 * @return array
	 */
	public static function counts( $days = 7 ) {
		$counts = array( 0 => 0, 1 => 0, 2 => 0, 3 => 0 );

		if ( ! self::ready() ) {
			return $counts;
		}

		global $wpdb;

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				'SELECT severity, COUNT(*) AS total FROM ' . self::table() . ' WHERE logged_at >= %s GROUP BY severity',
				gmdate( 'Y-m-d H:i:s', time() - ( (int) $days * DAY_IN_SECONDS ) )
			)
		);

		foreach ( (array) $rows as $row ) {
			$counts[ (int) $row->severity ] = (int) $row->total;
		}

		return $counts;
	}

	/**
	 * Delete rows older than the retention window.
	 *
	 * @return void
	 */
	public static function prune() {
		if ( ! self::ready() ) {
			return;
		}

		global $wpdb;

		$wpdb->query( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				'DELETE FROM ' . self::table() . ' WHERE logged_at < %s',
				gmdate( 'Y-m-d H:i:s', time() - ( (int) NYMS_LOG_RETENTION_DAYS * DAY_IN_SECONDS ) )
			)
		);
	}

	/**
	 * Empty the log.
	 *
	 * @return void
	 */
	public static function clear() {
		if ( ! self::ready() ) {
			return;
		}

		global $wpdb;

		$wpdb->query( 'TRUNCATE TABLE ' . self::table() ); // phpcs:ignore WordPress.DB
	}

	/**
	 * Human label for a severity level.
	 *
	 * @param int $severity Severity.
	 * @return string
	 */
	public static function severity_label( $severity ) {
		$labels = array(
			self::INFO     => __( 'Info', 'newyorkmechanics-security' ),
			self::NOTICE   => __( 'Notice', 'newyorkmechanics-security' ),
			self::WARNING  => __( 'Warning', 'newyorkmechanics-security' ),
			self::CRITICAL => __( 'Critical', 'newyorkmechanics-security' ),
		);

		$severity = (int) $severity;

		return isset( $labels[ $severity ] ) ? $labels[ $severity ] : (string) $severity;
	}

	/**
	 * Colour for a severity level.
	 *
	 * @param int $severity Severity.
	 * @return string
	 */
	public static function severity_colour( $severity ) {
		$colours = array(
			self::INFO     => '#50575e',
			self::NOTICE   => '#2271b1',
			self::WARNING  => '#996800',
			self::CRITICAL => '#8a2424',
		);

		$severity = (int) $severity;

		return isset( $colours[ $severity ] ) ? $colours[ $severity ] : '#50575e';
	}
}

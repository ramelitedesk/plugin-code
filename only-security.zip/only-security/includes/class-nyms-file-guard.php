<?php
/**
 * Filesystem guard.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Keeps the protective files on disk in place and blocks PHP execution in
 * writable directories.
 */
class NYMS_File_Guard {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_init', array( $this, 'verify_protection' ) );
		add_action( 'nyms_verify_protection', array( $this, 'verify_protection' ) );

		// Re-drop the guards after a media upload creates a new month folder.
		add_filter( 'upload_dir', array( $this, 'protect_upload_dir' ) );
	}

	/**
	 * Re-install the protective files if something removed them.
	 *
	 * Throttled with a transient so it costs one option read per hour.
	 *
	 * @return void
	 */
	public function verify_protection() {
		if ( get_transient( 'nyms_protection_checked' ) ) {
			return;
		}

		set_transient( 'nyms_protection_checked', 1, HOUR_IN_SECONDS );

		NYMS_Htaccess::install();
	}

	/**
	 * Drop a silence index into freshly created upload folders.
	 *
	 * @param array $dirs Upload directory data.
	 * @return array
	 */
	public function protect_upload_dir( $dirs ) {
		if ( ! NYMS_BLOCK_PHP_IN_UPLOADS || empty( $dirs['path'] ) || ! is_dir( $dirs['path'] ) ) {
			return $dirs;
		}

		$index = trailingslashit( $dirs['path'] ) . 'index.php';

		if ( ! file_exists( $index ) && is_writable( $dirs['path'] ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			@file_put_contents( $index, "<?php\n// Silence is golden.\n" );
		}

		return $dirs;
	}
}

<?php
/**
 * Security response headers.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds the browser-side defences: clickjacking, MIME sniffing, referrer leak
 * and mixed content.
 *
 * A full Content-Security-Policy is intentionally not shipped enabled: an
 * incorrect one breaks a live site silently. Opt in with the filter below once
 * a policy has been tested in report-only mode.
 */
class NYMS_Headers {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! NYMS_SECURITY_HEADERS ) {
			return;
		}

		add_filter( 'wp_headers', array( $this, 'filter_headers' ), 99 );
		add_action( 'send_headers', array( $this, 'send_headers' ), 99 );
		add_action( 'login_init', array( $this, 'send_headers' ), 99 );
		add_action( 'admin_init', array( $this, 'send_headers' ), 99 );

		// Do not let the login or admin screens end up in a search index or
		// in a referrer sent to a third party.
		add_action( 'login_head', array( $this, 'noindex_meta' ) );
		add_action( 'admin_head', array( $this, 'noindex_meta' ) );
	}

	/**
	 * Build the header list.
	 *
	 * @return array
	 */
	private function headers() {
		$frame = NYMS_FRAME_POLICY;

		if ( ! in_array( $frame, array( 'DENY', 'SAMEORIGIN' ), true ) ) {
			$frame = 'SAMEORIGIN';
		}

		$headers = array(
			'X-Frame-Options'        => $frame,
			'X-Content-Type-Options' => 'nosniff',
			'Referrer-Policy'        => 'strict-origin-when-cross-origin',
			'X-XSS-Protection'       => '0',
			'Permissions-Policy'     => 'geolocation=(), microphone=(), camera=(), payment=(), usb=(), interest-cohort=()',
			'Cross-Origin-Resource-Policy' => 'same-origin',
		);

		if ( is_ssl() ) {
			$headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains';
		}

		/**
		 * Filter the security headers. Add 'Content-Security-Policy' here once
		 * a policy has been validated against the live theme.
		 *
		 * @param array $headers Header name => value.
		 */
		return (array) apply_filters( 'nyms_security_headers', $headers );
	}

	/**
	 * Merge the headers into the WordPress header bag.
	 *
	 * @param array $headers Existing headers.
	 * @return array
	 */
	public function filter_headers( $headers ) {
		if ( ! is_array( $headers ) ) {
			$headers = array();
		}

		return array_merge( $headers, $this->headers() );
	}

	/**
	 * Send the headers directly on screens that bypass wp_headers.
	 *
	 * @return void
	 */
	public function send_headers() {
		if ( headers_sent() ) {
			return;
		}

		foreach ( $this->headers() as $name => $value ) {
			header( $name . ': ' . $value );
		}

		// Never advertise the PHP build.
		if ( function_exists( 'header_remove' ) ) {
			@header_remove( 'X-Powered-By' );
		}
	}

	/**
	 * Keep admin and login screens out of indexes and referrers.
	 *
	 * @return void
	 */
	public function noindex_meta() {
		echo '<meta name="robots" content="noindex,nofollow,noarchive" />' . "\n";
		echo '<meta name="referrer" content="strict-origin-when-cross-origin" />' . "\n";
	}
}

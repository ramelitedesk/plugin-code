<?php
/**
 * SVG inspection and sanitisation.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * SVG is a document format, not an image format.
 *
 * A browser will happily run a script inside one, which is why the upload
 * guard refuses SVG by default. When a site genuinely needs SVG logos this
 * class is the compromise: the file is parsed, every element and attribute is
 * checked against an allow list, and only the drawing survives.
 */
class NYMS_Svg {

	/**
	 * Elements that may stay.
	 *
	 * @var array
	 */
	private static $elements = array(
		'svg', 'g', 'defs', 'symbol', 'use', 'title', 'desc', 'metadata',
		'path', 'rect', 'circle', 'ellipse', 'line', 'polyline', 'polygon',
		'text', 'tspan', 'textpath', 'marker', 'pattern', 'mask', 'clippath',
		'lineargradient', 'radialgradient', 'stop', 'switch', 'style',
		'filter', 'fegaussianblur', 'feoffset', 'feblend', 'feflood',
		'fecolormatrix', 'femerge', 'femergenode', 'fecomposite', 'image',
	);

	/**
	 * Attributes that may stay, beyond the presentation attributes.
	 *
	 * @var array
	 */
	private static $attributes = array(
		'id', 'class', 'style', 'transform', 'viewbox', 'version', 'xmlns',
		'xmlns:xlink', 'width', 'height', 'x', 'y', 'x1', 'x2', 'y1', 'y2',
		'cx', 'cy', 'r', 'rx', 'ry', 'd', 'points', 'fill', 'fill-opacity',
		'fill-rule', 'stroke', 'stroke-width', 'stroke-linecap', 'stroke-dasharray',
		'stroke-linejoin', 'stroke-opacity', 'stroke-miterlimit', 'stroke-dashoffset',
		'opacity', 'offset', 'stop-color', 'stop-opacity', 'gradientunits',
		'gradienttransform', 'patternunits', 'patterncontenttunits', 'clip-path',
		'clip-rule', 'mask', 'filter', 'preserveaspectratio', 'font-family',
		'font-size', 'font-weight', 'font-style', 'text-anchor', 'letter-spacing',
		'display', 'visibility', 'color', 'stddeviation', 'result', 'in', 'in2',
		'dx', 'dy', 'markerwidth', 'markerheight', 'refx', 'refy', 'orient',
		'spreadmethod', 'fr', 'href', 'xlink:href', 'aria-hidden', 'role', 'focusable',
	);

	/**
	 * Whether the markup contains anything a browser would execute.
	 *
	 * This is a structural question about SVG - does the document use the
	 * parts of the format that run code - not a judgement about what that
	 * code does.
	 *
	 * @param string $markup SVG source.
	 * @return bool
	 */
	public static function has_active_content( $markup ) {
		$markup = (string) $markup;

		$tests = array(
			'/<\s*(script|foreignObject|handler|set)\b/i',
			'/\son[a-z]{3,20}\s*=\s*[\'"]/i',
			'/(xlink:href|href)\s*=\s*[\'"]\s*(javascript|data|https?):/i',
			'/<!ENTITY|<!DOCTYPE[^>]+(SYSTEM|PUBLIC)/i',
			'/<\?php\s|<\?=|<script\s+language\s*=\s*[\'"]?php/i',
		);

		foreach ( $tests as $test ) {
			if ( preg_match( $test, $markup ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Rewrite SVG markup with everything active removed.
	 *
	 * @param string $markup SVG source.
	 * @return string|false Clean markup, or false when it cannot be parsed.
	 */
	public static function sanitize( $markup ) {
		$markup = (string) $markup;

		if ( '' === trim( $markup ) || ! class_exists( 'DOMDocument' ) ) {
			return false;
		}

		// Entity declarations are how an SVG reads /etc/passwd. There is no
		// legitimate use for one in an uploaded image, so they go first.
		$markup = preg_replace( '/<!DOCTYPE[^>]*(\[[\s\S]*?\])?[^>]*>/i', '', $markup );
		$markup = preg_replace( '/<\?php[\s\S]*?(\?>|$)/i', '', $markup );
		$markup = preg_replace( '/<!ENTITY[\s\S]*?>/i', '', $markup );

		$previous = libxml_use_internal_errors( true );

		if ( function_exists( 'libxml_disable_entity_loader' ) && PHP_VERSION_ID < 80000 ) {
			// phpcs:ignore PHPCompatibility.FunctionUse.RemovedFunctions.libxml_disable_entity_loaderDeprecated
			$loader = libxml_disable_entity_loader( true );
		}

		$doc                     = new DOMDocument();
		$doc->preserveWhiteSpace = false;
		$doc->strictErrorChecking = false;
		$doc->formatOutput       = false;

		$flags = 0;

		if ( defined( 'LIBXML_NONET' ) ) {
			$flags |= LIBXML_NONET;
		}

		if ( defined( 'LIBXML_NOENT' ) ) {
			$flags |= LIBXML_NOENT;
		}

		$loaded = $doc->loadXML( $markup, $flags );

		libxml_clear_errors();
		libxml_use_internal_errors( $previous );

		if ( isset( $loader ) && function_exists( 'libxml_disable_entity_loader' ) && PHP_VERSION_ID < 80000 ) {
			// phpcs:ignore PHPCompatibility.FunctionUse.RemovedFunctions.libxml_disable_entity_loaderDeprecated
			libxml_disable_entity_loader( $loader );
		}

		if ( ! $loaded || ! $doc->documentElement ) {
			return false;
		}

		if ( 'svg' !== strtolower( $doc->documentElement->nodeName ) ) {
			return false;
		}

		self::clean_node( $doc->documentElement );

		$output = $doc->saveXML( $doc->documentElement );

		return false === $output ? false : $output;
	}

	/**
	 * Recursively strip a node.
	 *
	 * @param DOMNode $node Node to clean.
	 * @return void
	 */
	private static function clean_node( $node ) {
		if ( ! $node instanceof DOMElement ) {
			return;
		}

		// Walk backwards: removing a child renumbers the live node list.
		for ( $i = $node->childNodes->length - 1; $i >= 0; $i-- ) {
			$child = $node->childNodes->item( $i );

			if ( $child instanceof DOMElement ) {
				if ( ! in_array( strtolower( $child->nodeName ), self::$elements, true ) ) {
					$node->removeChild( $child );
					continue;
				}

				self::clean_node( $child );

				continue;
			}

			// Processing instructions can carry PHP; comments can carry markup.
			if ( XML_PI_NODE === $child->nodeType ) {
				$node->removeChild( $child );
			}
		}

		if ( ! $node->hasAttributes() ) {
			return;
		}

		for ( $i = $node->attributes->length - 1; $i >= 0; $i-- ) {
			$attribute = $node->attributes->item( $i );

			if ( ! $attribute ) {
				continue;
			}

			$name  = strtolower( $attribute->nodeName );
			$value = (string) $attribute->nodeValue;

			// Every event handler, without exception.
			if ( 0 === strpos( $name, 'on' ) ) {
				$node->removeAttribute( $attribute->nodeName );
				continue;
			}

			if ( ! in_array( $name, self::$attributes, true ) && 0 !== strpos( $name, 'data-' ) ) {
				$node->removeAttribute( $attribute->nodeName );
				continue;
			}

			// A reference may point inside this document and nowhere else.
			if ( in_array( $name, array( 'href', 'xlink:href', 'src' ), true ) && '#' !== substr( trim( $value ), 0, 1 ) ) {
				$node->removeAttribute( $attribute->nodeName );
				continue;
			}

			if ( preg_match( '/(javascript|vbscript|data)\s*:/i', $value ) || preg_match( '/expression\s*\(|url\s*\(\s*[\'"]?\s*(https?:|\/\/)/i', $value ) ) {
				$node->removeAttribute( $attribute->nodeName );
			}
		}
	}

	/**
	 * Sanitise an SVG file in place.
	 *
	 * @param string $path Absolute path.
	 * @return bool Whether the file is safe afterwards.
	 */
	public static function sanitize_file( $path ) {
		if ( ! is_file( $path ) || ! is_writable( $path ) ) {
			return false;
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_get_contents
		$markup = (string) @file_get_contents( $path );

		if ( '' === $markup ) {
			return false;
		}

		// A gzipped SVG has to be unpacked, cleaned and repacked.
		$gzipped = ( "\x1f\x8b" === substr( $markup, 0, 2 ) );

		if ( $gzipped ) {
			if ( ! function_exists( 'gzdecode' ) ) {
				return false;
			}

			$markup = (string) @gzdecode( $markup );
		}

		$clean = self::sanitize( $markup );

		if ( false === $clean ) {
			return false;
		}

		if ( $gzipped && function_exists( 'gzencode' ) ) {
			$clean = gzencode( $clean );
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		return false !== @file_put_contents( $path, $clean );
	}
}

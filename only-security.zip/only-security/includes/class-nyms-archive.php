<?php
/**
 * Archive inspection.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Checks the shape of a ZIP before anything is written to disk.
 *
 * This is structural, not a scanner: it asks where each entry would land, what
 * type it is and how much it would expand to. It never decides whether the
 * contents of a file are malicious - that is a malware scanner's job, and this
 * plugin deliberately leaves it to one.
 *
 * The one exception is a PHP open tag inside a file that is not a script,
 * because that is a property of the file's type rather than a judgement about
 * its code.
 */
class NYMS_Archive {

	/**
	 * Inspect an archive.
	 *
	 * @param string $path  Absolute path to the archive.
	 * @param int    $depth Recursion depth for nested archives.
	 * @return array {
	 *     @type bool  $ok     Whether the archive is acceptable.
	 *     @type array $errors Fatal problems, as translated strings.
	 *     @type array $stats  entries, compressed, uncompressed, ratio.
	 * }
	 */
	public static function inspect( $path, $depth = 0 ) {
		$result = array(
			'ok'     => true,
			'errors' => array(),
			'stats'  => array( 'entries' => 0, 'compressed' => 0, 'uncompressed' => 0, 'ratio' => 0 ),
		);

		if ( ! is_file( $path ) || ! is_readable( $path ) ) {
			$result['ok']       = false;
			$result['errors'][] = __( 'The archive could not be read.', 'newyorkmechanics-security' );

			return $result;
		}

		if ( ! class_exists( 'ZipArchive' ) ) {
			// Without the zip extension the archive cannot be inspected. Say so
			// rather than pretending it passed.
			$result['errors'][] = __( 'The PHP zip extension is not available, so the archive could not be inspected.', 'newyorkmechanics-security' );

			return $result;
		}

		$zip = new ZipArchive();

		if ( true !== $zip->open( $path ) ) {
			$result['ok']       = false;
			$result['errors'][] = __( 'The archive is corrupt or is not a ZIP file.', 'newyorkmechanics-security' );

			return $result;
		}

		$entries      = $zip->numFiles;
		$uncompressed = 0;
		$compressed   = 0;
		$temp_dir     = get_temp_dir();

		if ( $entries > (int) NYMS_ARCHIVE_MAX_ENTRIES ) {
			$result['ok']       = false;
			$result['errors'][] = sprintf(
				/* translators: 1: entry count, 2: allowed maximum. */
				__( 'The archive holds %1$d files, more than the %2$d allowed.', 'newyorkmechanics-security' ),
				$entries,
				(int) NYMS_ARCHIVE_MAX_ENTRIES
			);
		}

		for ( $i = 0; $i < $entries; $i++ ) {
			$stat = $zip->statIndex( $i );

			if ( ! $stat ) {
				continue;
			}

			$name          = (string) $stat['name'];
			$size          = (int) $stat['size'];
			$uncompressed += $size;
			$compressed   += (int) $stat['comp_size'];

			// A directory entry.
			if ( '/' === substr( $name, -1 ) ) {
				continue;
			}

			$problem = self::entry_problem( $name );

			if ( $problem ) {
				$result['ok']       = false;
				$result['errors'][] = sprintf(
					/* translators: 1: entry name, 2: reason. */
					__( '%1$s: %2$s', 'newyorkmechanics-security' ),
					$name,
					$problem
				);

				continue;
			}

			if ( $size > (int) NYMS_ARCHIVE_MAX_FILE_MB * 1048576 ) {
				$result['ok']       = false;
				$result['errors'][] = sprintf(
					/* translators: %s: entry name. */
					__( '%s is larger than the per-file limit.', 'newyorkmechanics-security' ),
					$name
				);

				continue;
			}

			$kind = NYMS_Helpers::file_kind( $name );

			// Nested archive: open it too, up to two levels down.
			if ( 'archive' === $kind ) {
				if ( $depth >= 2 ) {
					$result['ok']       = false;
					$result['errors'][] = sprintf(
						/* translators: %s: entry name. */
						__( '%s is an archive nested too deeply to inspect.', 'newyorkmechanics-security' ),
						$name
					);

					continue;
				}

				$nested = self::inspect_nested( $zip, $i, $name, $temp_dir, $depth );

				if ( ! $nested['ok'] ) {
					$result['ok']     = false;
					$result['errors'] = array_merge( $result['errors'], $nested['errors'] );
				}

				continue;
			}

			// A picture, a stylesheet or a font that carries a PHP open tag is
			// not that type of file at all.
			if ( in_array( $kind, array( 'image', 'other', 'html', 'svg' ), true ) ) {
				$contents = $zip->getFromIndex( $i, 262144 );

				if ( false !== $contents && '' !== $contents && preg_match( '/<\?php\s|<\?=\s|<script\s+language\s*=\s*[\'"]?php/i', $contents ) ) {
					$result['ok']       = false;
					$result['errors'][] = sprintf(
						/* translators: %s: entry name. */
						__( '%s is not a script but contains PHP code.', 'newyorkmechanics-security' ),
						$name
					);
				}
			}
		}

		$zip->close();

		$ratio = $compressed > 0 ? round( $uncompressed / max( 1, $compressed ), 1 ) : 0;

		$result['stats'] = array(
			'entries'      => $entries,
			'compressed'   => $compressed,
			'uncompressed' => $uncompressed,
			'ratio'        => $ratio,
		);

		if ( $uncompressed > (int) NYMS_ARCHIVE_MAX_TOTAL_MB * 1048576 ) {
			$result['ok']       = false;
			$result['errors'][] = sprintf(
				/* translators: %s: size in megabytes. */
				__( 'The archive expands to %s MB, which is above the limit.', 'newyorkmechanics-security' ),
				number_format_i18n( $uncompressed / 1048576, 1 )
			);
		}

		// A zip bomb is small on disk and enormous once expanded.
		if ( $ratio > (int) NYMS_ARCHIVE_MAX_RATIO && $uncompressed > 10485760 ) {
			$result['ok']       = false;
			$result['errors'][] = sprintf(
				/* translators: %s: compression ratio. */
				__( 'The archive expands %sx its own size, which is the signature of a decompression bomb.', 'newyorkmechanics-security' ),
				$ratio
			);
		}

		return $result;
	}

	/**
	 * Write a nested archive to a temporary file and inspect it.
	 *
	 * @param ZipArchive $zip      Open archive.
	 * @param int        $index    Entry index.
	 * @param string     $name     Entry name.
	 * @param string     $temp_dir Temporary directory.
	 * @param int        $depth    Current depth.
	 * @return array
	 */
	private static function inspect_nested( $zip, $index, $name, $temp_dir, $depth ) {
		$contents = $zip->getFromIndex( $index, (int) NYMS_ARCHIVE_MAX_FILE_MB * 1048576 );

		if ( false === $contents ) {
			return array( 'ok' => true, 'errors' => array() );
		}

		$temp = trailingslashit( $temp_dir ) . 'nyms-nested-' . wp_generate_password( 12, false ) . '.zip';

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		if ( false === @file_put_contents( $temp, $contents ) ) {
			return array( 'ok' => true, 'errors' => array() );
		}

		$nested = self::inspect( $temp, $depth + 1 );

		// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
		@unlink( $temp );

		$prefixed = array();

		foreach ( $nested['errors'] as $error ) {
			$prefixed[] = $name . ' > ' . $error;
		}

		$nested['errors'] = $prefixed;

		return $nested;
	}

	/**
	 * Whether an entry name is acceptable.
	 *
	 * @param string $name Entry name as stored in the archive.
	 * @return string|false Reason, or false when the name is fine.
	 */
	public static function entry_problem( $name ) {
		if ( false !== strpos( $name, "\0" ) ) {
			return __( 'the entry name contains a null byte', 'newyorkmechanics-security' );
		}

		$normalised = str_replace( '\\', '/', $name );

		if ( '/' === substr( $normalised, 0, 1 ) || preg_match( '#^[a-z]:/#i', $normalised ) ) {
			return __( 'the entry uses an absolute path', 'newyorkmechanics-security' );
		}

		if ( preg_match( '#(^|/)\.\.(/|$)#', $normalised ) ) {
			return __( 'the entry escapes its own folder (path traversal)', 'newyorkmechanics-security' );
		}

		if ( strlen( $normalised ) > 250 ) {
			return __( 'the entry name is unreasonably long', 'newyorkmechanics-security' );
		}

		$base = basename( $normalised );

		if ( in_array( strtolower( $base ), array( '.htaccess', '.user.ini', 'php.ini', 'web.config' ), true ) ) {
			return __( 'the archive would overwrite a server configuration file', 'newyorkmechanics-security' );
		}

		$suspicious = NYMS_Helpers::suspicious_name( $base );

		if ( $suspicious ) {
			return $suspicious;
		}

		$ext = strtolower( pathinfo( $base, PATHINFO_EXTENSION ) );

		$never = array( 'exe', 'dll', 'so', 'com', 'bat', 'cmd', 'msi', 'scr', 'jar', 'vbs', 'ps1', 'hta', 'pif', 'apk', 'phar' );

		if ( in_array( $ext, $never, true ) ) {
			return __( 'the entry is an executable file', 'newyorkmechanics-security' );
		}

		return false;
	}
}

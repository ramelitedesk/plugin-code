<?php
/**
 * Plugin and theme installation guard.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Decides what is allowed to become code on this site.
 *
 * Most WordPress break-ins arrive as a plugin: a nulled premium copy with a
 * shell in it, an abandoned plugin with a known hole, or a legitimate plugin
 * downloaded from somewhere that is not wordpress.org. Everything an installer
 * is about to write passes through here first.
 */
class NYMS_Plugin_Guard {

	/**
	 * Option names.
	 */
	const ALLOWLIST = 'nyms_plugin_allowlist';
	const BLOCKLIST = 'nyms_plugin_blocklist';
	const SOURCES   = 'nyms_plugin_sources';
	const PENDING   = 'nyms_plugin_pending';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! NYMS_PLUGIN_GUARD ) {
			return;
		}

		// Where a package may be downloaded from.
		add_filter( 'upgrader_pre_download', array( $this, 'check_source' ), 10, 4 );

		// The uploaded ZIP itself, before WordPress unpacks it.
		add_filter( 'wp_handle_upload_prefilter', array( $this, 'check_uploaded_package' ), 5 );

		// The unpacked folder, before it is moved into wp-content.
		add_filter( 'upgrader_source_selection', array( $this, 'check_unpacked_source' ), 5, 4 );

		// Nothing unapproved may be switched on.
		add_filter( 'pre_update_option_active_plugins', array( $this, 'filter_activation' ), 10, 2 );
		add_filter( 'option_active_plugins', array( $this, 'filter_loaded' ), 5 );

		add_action( 'activated_plugin', array( $this, 'record_activation' ), 10, 2 );
		add_action( 'deactivated_plugin', array( $this, 'record_deactivation' ), 10, 2 );
		add_action( 'deleted_plugin', array( $this, 'record_deletion' ), 10, 2 );

		// Periodic health check of what is already installed.
		add_action( 'nyms_plugin_audit', array( $this, 'audit' ) );

		add_filter( 'plugin_action_links', array( $this, 'flag_unapproved' ), 99, 2 );
	}

	/**
	 * The current policy: off, monitor or enforce.
	 *
	 * @return string
	 */
	public function policy() {
		$policy = NYMS_PLUGIN_POLICY;

		return in_array( $policy, array( 'off', 'monitor', 'enforce' ), true ) ? $policy : 'monitor';
	}

	/**
	 * Approved plugins, slug => record.
	 *
	 * @return array
	 */
	public static function allowlist() {
		$list = get_option( self::ALLOWLIST, array() );

		return is_array( $list ) ? $list : array();
	}

	/**
	 * Refused plugins, slug => reason.
	 *
	 * @return array
	 */
	public static function blocklist() {
		$list = get_option( self::BLOCKLIST, array() );

		return is_array( $list ) ? $list : array();
	}

	/**
	 * Hosts a package may be downloaded from.
	 *
	 * @return array
	 */
	public static function sources() {
		$list = get_option( self::SOURCES, array() );

		if ( ! is_array( $list ) || ! $list ) {
			$list = array( 'downloads.wordpress.org', 'wordpress.org', 'api.wordpress.org' );
		}

		return $list;
	}

	/**
	 * Plugins waiting for approval.
	 *
	 * @return array
	 */
	public static function pending() {
		$list = get_option( self::PENDING, array() );

		return is_array( $list ) ? $list : array();
	}

	/**
	 * Approve a plugin, pinning the version and the hash that was reviewed.
	 *
	 * @param string $slug   Plugin slug (folder name).
	 * @param array  $extra  Extra record fields.
	 * @return void
	 */
	public static function approve( $slug, $extra = array() ) {
		$slug = sanitize_key( $slug );

		if ( '' === $slug ) {
			return;
		}

		$list = self::allowlist();

		$list[ $slug ] = array_merge(
			array(
				'slug'        => $slug,
				'version'     => '',
				'hash'        => '',
				'approved_by' => get_current_user_id(),
				'approved_at' => time(),
				'source'      => 'manual',
			),
			$extra
		);

		update_option( self::ALLOWLIST, $list, false );

		$pending = self::pending();

		unset( $pending[ $slug ] );

		update_option( self::PENDING, $pending, false );

		NYMS_Log::record(
			'plugin_approved',
			NYMS_Log::NOTICE,
			sprintf( /* translators: %s: plugin slug. */ __( 'Plugin %s was approved.', 'newyorkmechanics-security' ), $slug ),
			$list[ $slug ]
		);
	}

	/**
	 * Remove a plugin from the allowlist.
	 *
	 * @param string $slug Plugin slug.
	 * @return void
	 */
	public static function revoke( $slug ) {
		$slug = sanitize_key( $slug );
		$list = self::allowlist();

		if ( ! isset( $list[ $slug ] ) ) {
			return;
		}

		unset( $list[ $slug ] );

		update_option( self::ALLOWLIST, $list, false );

		NYMS_Log::record(
			'plugin_revoked',
			NYMS_Log::WARNING,
			sprintf( /* translators: %s: plugin slug. */ __( 'Approval for plugin %s was withdrawn.', 'newyorkmechanics-security' ), $slug )
		);
	}

	/**
	 * Add or remove a blocklist entry.
	 *
	 * @param string $slug   Plugin slug.
	 * @param string $reason Why, empty string to remove the entry.
	 * @return void
	 */
	public static function block( $slug, $reason ) {
		$slug = sanitize_key( $slug );
		$list = self::blocklist();

		if ( '' === $reason ) {
			unset( $list[ $slug ] );
		} else {
			$list[ $slug ] = $reason;
		}

		update_option( self::BLOCKLIST, $list, false );
	}

	/**
	 * Whether a slug is approved.
	 *
	 * @param string $slug Plugin slug.
	 * @return bool
	 */
	public function is_approved( $slug ) {
		$slug = sanitize_key( $slug );

		if ( 'enforce' !== $this->policy() ) {
			return true;
		}

		// The security plugin cannot lock itself out.
		if ( $slug === basename( dirname( NYMS_FILE ) ) ) {
			return true;
		}

		$list = self::allowlist();

		return isset( $list[ $slug ] );
	}

	/**
	 * Refuse a download from a host that is not on the source list.
	 *
	 * @param bool|WP_Error $reply   Short-circuit value.
	 * @param string        $package Package URL or path.
	 * @param WP_Upgrader   $upgrader Upgrader.
	 * @param array         $extra   Hook extras.
	 * @return bool|WP_Error
	 */
	public function check_source( $reply, $package, $upgrader, $extra = array() ) {
		unset( $upgrader, $extra );

		if ( ! is_string( $package ) || ! preg_match( '#^https?://#i', $package ) ) {
			return $reply;
		}

		$host = strtolower( (string) wp_parse_url( $package, PHP_URL_HOST ) );

		if ( '' === $host ) {
			return $reply;
		}

		foreach ( self::sources() as $allowed ) {
			$allowed = strtolower( trim( $allowed ) );

			if ( '' === $allowed ) {
				continue;
			}

			if ( $host === $allowed || substr( $host, - ( strlen( $allowed ) + 1 ) ) === '.' . $allowed ) {
				return $reply;
			}
		}

		NYMS_Log::record(
			'package_source_blocked',
			NYMS_Log::WARNING,
			sprintf( /* translators: %s: host name. */ __( 'A package download from %s was refused: the host is not on the approved source list.', 'newyorkmechanics-security' ), $host ),
			array( 'url' => $package )
		);

		if ( 'enforce' !== $this->policy() ) {
			return $reply;
		}

		return new WP_Error(
			'nyms_bad_source',
			sprintf(
				/* translators: %s: host name. */
				__( 'Downloads from %s are not allowed. Add the host to the approved sources on the Security screen if you trust it.', 'newyorkmechanics-security' ),
				$host
			)
		);
	}

	/**
	 * Inspect a plugin or theme ZIP the moment it is uploaded.
	 *
	 * @param array $file $_FILES entry.
	 * @return array
	 */
	public function check_uploaded_package( $file ) {
		if ( empty( $file['tmp_name'] ) || ! empty( $file['error'] ) ) {
			return $file;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$action = isset( $_POST['action'] ) ? sanitize_key( wp_unslash( $_POST['action'] ) ) : '';

		if ( ! in_array( $action, array( 'upload-plugin', 'upload-theme' ), true ) ) {
			return $file;
		}

		$report = NYMS_Archive::inspect( $file['tmp_name'] );

		if ( $report['ok'] ) {
			return $file;
		}

		NYMS_Log::record(
			'package_rejected',
			NYMS_Log::WARNING,
			sprintf( /* translators: %s: file name. */ __( 'The uploaded package %s was refused.', 'newyorkmechanics-security' ), $file['name'] ),
			array( 'problems' => array_slice( $report['errors'], 0, 30 ) )
		);

		$file['error'] = sprintf(
			/* translators: %s: list of problems. */
			__( 'This package was refused: %s', 'newyorkmechanics-security' ),
			implode( '; ', array_slice( $report['errors'], 0, 5 ) )
		);

		return $file;
	}

	/**
	 * Inspect the unpacked folder before it is copied into wp-content.
	 *
	 * This is the last point at which an install can be stopped, and it covers
	 * every route: the repository, an upload, or a plugin calling the upgrader
	 * on its own.
	 *
	 * @param string      $source        Unpacked directory.
	 * @param string      $remote_source Parent directory.
	 * @param WP_Upgrader $upgrader      Upgrader.
	 * @param array       $extra         Hook extras.
	 * @return string|WP_Error
	 */
	public function check_unpacked_source( $source, $remote_source, $upgrader, $extra = array() ) {
		unset( $remote_source, $upgrader );

		if ( is_wp_error( $source ) || ! is_string( $source ) || ! is_dir( $source ) ) {
			return $source;
		}

		$type = 'plugin';

		if ( isset( $extra['theme'] ) || ( isset( $extra['type'] ) && 'theme' === $extra['type'] ) ) {
			$type = 'theme';
		}

		$slug     = sanitize_key( basename( untrailingslashit( $source ) ) );
		$problems = array();
		$scanned  = 0;

		$blocklist = self::blocklist();

		if ( isset( $blocklist[ $slug ] ) ) {
			return new WP_Error(
				'nyms_blocklisted',
				sprintf(
					/* translators: 1: slug, 2: reason. */
					__( '%1$s is on the blocklist for this site (%2$s).', 'newyorkmechanics-security' ),
					$slug,
					$blocklist[ $slug ]
				)
			);
		}

		try {
			$iterator = new RecursiveIteratorIterator(
				new RecursiveDirectoryIterator( $source, FilesystemIterator::SKIP_DOTS | FilesystemIterator::UNIX_PATHS ),
				RecursiveIteratorIterator::LEAVES_ONLY,
				RecursiveIteratorIterator::CATCH_GET_CHILD
			);
		} catch ( Exception $e ) {
			return $source;
		}

		foreach ( $iterator as $file ) {
			if ( ! $file->isFile() || $scanned > 8000 ) {
				continue;
			}

			$path     = wp_normalize_path( $file->getPathname() );
			$relative = ltrim( str_replace( wp_normalize_path( $source ), '', $path ), '/' );

			$scanned++;

			$name_problem = NYMS_Helpers::suspicious_name( basename( $path ) );

			if ( $name_problem ) {
				$problems[] = sprintf(
					/* translators: 1: file name, 2: reason. */
					__( '%1$s: %2$s', 'newyorkmechanics-security' ),
					$relative,
					$name_problem
				);
			}

			// An archive shipped inside a package is a place to hide a second
			// payload, so its shape is checked the same way.
			if ( 'archive' === NYMS_Helpers::file_kind( $path ) ) {
				$nested = NYMS_Archive::inspect( $path );

				if ( ! $nested['ok'] ) {
					$problems = array_merge( $problems, $nested['errors'] );
				}
			}
		}

		$context = array(
			'slug'     => $slug,
			'type'     => $type,
			'files'    => $scanned,
			'problems' => array_slice( $problems, 0, 30 ),
		);

		if ( $problems ) {
			NYMS_Log::record(
				'package_rejected',
				NYMS_Log::WARNING,
				sprintf( /* translators: 1: type, 2: slug. */ __( 'The %1$s %2$s contains files that are not allowed on this site.', 'newyorkmechanics-security' ), $type, $slug ),
				$context
			);

			if ( 'off' !== $this->policy() ) {
				return new WP_Error(
					'nyms_package_rejected',
					sprintf(
						/* translators: 1: slug, 2: list of reasons. */
						__( 'Installation of %1$s was stopped: %2$s', 'newyorkmechanics-security' ),
						$slug,
						implode( '; ', array_slice( $problems, 0, 6 ) )
					)
				);
			}
		}

		if ( 'plugin' === $type ) {
			$health = $this->repository_health( $slug );

			if ( $health['blocked'] && 'enforce' === $this->policy() ) {
				return new WP_Error( 'nyms_plugin_health', $health['message'] );
			}

			if ( '' !== $health['message'] ) {
				NYMS_Log::record( 'plugin_health', NYMS_Log::WARNING, $health['message'], $health );
			}

			$this->queue_for_approval( $slug, $source );
		}

		return $source;
	}

	/**
	 * Ask wordpress.org what it knows about a plugin.
	 *
	 * @param string $slug Plugin slug.
	 * @return array {
	 *     @type bool   $blocked Whether installation should stop.
	 *     @type string $message Explanation, empty when nothing is wrong.
	 *     @type string $state   known, unknown, closed or abandoned.
	 * }
	 */
	public function repository_health( $slug ) {
		$out = array( 'blocked' => false, 'message' => '', 'state' => 'known', 'last_updated' => '' );

		$info = $this->plugin_info( $slug );

		if ( false === $info ) {
			$out['state'] = 'unknown';

			if ( NYMS_BLOCK_UNKNOWN_PLUGINS ) {
				$out['blocked'] = true;
				$out['message'] = sprintf(
					/* translators: %s: plugin slug. */
					__( '%s is not published on wordpress.org, so its code cannot be verified. Approve it explicitly on the Security screen to install it.', 'newyorkmechanics-security' ),
					$slug
				);
			}

			return $out;
		}

		if ( ! empty( $info['closed'] ) ) {
			$out['state']   = 'closed';
			$out['blocked'] = true;
			$out['message'] = sprintf(
				/* translators: %s: plugin slug. */
				__( '%s has been removed from the WordPress plugin directory, which usually means an unfixed security problem.', 'newyorkmechanics-security' ),
				$slug
			);

			return $out;
		}

		$updated = isset( $info['last_updated'] ) ? strtotime( $info['last_updated'] ) : 0;

		$out['last_updated'] = $updated ? gmdate( 'Y-m-d', $updated ) : '';

		if ( $updated && $updated < ( time() - ( (int) NYMS_ABANDONED_MONTHS * 30 * DAY_IN_SECONDS ) ) ) {
			$out['state']   = 'abandoned';
			$out['blocked'] = (bool) NYMS_BLOCK_ABANDONED_PLUGINS;
			$out['message'] = sprintf(
				/* translators: 1: plugin slug, 2: date. */
				__( '%1$s has not been updated since %2$s. Abandoned plugins are the most common way a site is broken into.', 'newyorkmechanics-security' ),
				$slug,
				$out['last_updated']
			);
		}

		return $out;
	}

	/**
	 * Read plugin information from the repository, cached for a day.
	 *
	 * @param string $slug Plugin slug.
	 * @return array|false
	 */
	public function plugin_info( $slug ) {
		$slug = sanitize_key( $slug );
		$key  = 'nyms_pinfo_' . substr( md5( $slug ), 0, 16 );

		$cached = get_transient( $key );

		if ( is_array( $cached ) ) {
			return empty( $cached['missing'] ) ? $cached : false;
		}

		$response = wp_remote_get(
			'https://api.wordpress.org/plugins/info/1.2/?action=plugin_information&request[slug]=' . rawurlencode( $slug ),
			array( 'timeout' => 12 )
		);

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 404 === $code || ( is_array( $body ) && isset( $body['error'] ) ) ) {
			set_transient( $key, array( 'missing' => true ), DAY_IN_SECONDS );

			return false;
		}

		if ( ! is_array( $body ) ) {
			return false;
		}

		set_transient( $key, $body, DAY_IN_SECONDS );

		return $body;
	}

	/**
	 * Compare an installed plugin against the checksums wordpress.org publishes.
	 *
	 * @param string $slug    Plugin slug.
	 * @param string $version Installed version.
	 * @return array {
	 *     @type string $state   verified, modified, unavailable.
	 *     @type array  $changed Relative paths that differ.
	 * }
	 */
	public function verify_plugin_files( $slug, $version ) {
		$out = array( 'state' => 'unavailable', 'changed' => array() );

		$slug    = sanitize_key( $slug );
		$version = preg_replace( '/[^0-9a-zA-Z\.\-_]/', '', (string) $version );

		if ( '' === $slug || '' === $version ) {
			return $out;
		}

		$key    = 'nyms_pchk_' . substr( md5( $slug . $version ), 0, 16 );
		$cached = get_transient( $key );

		if ( is_array( $cached ) ) {
			$checksums = $cached;
		} else {
			$response = wp_remote_get(
				'https://downloads.wordpress.org/plugin-checksums/' . $slug . '/' . $version . '.json',
				array( 'timeout' => 15 )
			);

			if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
				return $out;
			}

			$body = json_decode( wp_remote_retrieve_body( $response ), true );

			if ( ! is_array( $body ) || empty( $body['files'] ) ) {
				return $out;
			}

			$checksums = $body['files'];

			set_transient( $key, $checksums, WEEK_IN_SECONDS );
		}

		$root = trailingslashit( WP_PLUGIN_DIR ) . $slug;

		if ( ! is_dir( $root ) ) {
			return $out;
		}

		foreach ( $checksums as $relative => $sums ) {
			$path = trailingslashit( $root ) . $relative;

			if ( ! file_exists( $path ) ) {
				$out['changed'][] = $relative . ' ' . __( '(missing)', 'newyorkmechanics-security' );
				continue;
			}

			$expected = isset( $sums['sha256'] ) ? (array) $sums['sha256'] : array();

			if ( ! $expected ) {
				continue;
			}

			$actual = @hash_file( 'sha256', $path );

			if ( ! in_array( $actual, $expected, true ) ) {
				$out['changed'][] = $relative;
			}
		}

		// Files the author never shipped.
		$root_normalised = wp_normalize_path( trailingslashit( $root ) );

		try {
			$iterator = new RecursiveIteratorIterator(
				new RecursiveDirectoryIterator( $root, FilesystemIterator::SKIP_DOTS | FilesystemIterator::UNIX_PATHS ),
				RecursiveIteratorIterator::LEAVES_ONLY,
				RecursiveIteratorIterator::CATCH_GET_CHILD
			);

			foreach ( $iterator as $file ) {
				if ( ! $file->isFile() || ! NYMS_Helpers::is_executable_name( $file->getPathname() ) ) {
					continue;
				}

				$relative = str_replace( $root_normalised, '', wp_normalize_path( $file->getPathname() ) );

				if ( ! isset( $checksums[ $relative ] ) ) {
					$out['changed'][] = $relative . ' ' . __( '(not shipped by the author)', 'newyorkmechanics-security' );
				}
			}
		} catch ( Exception $e ) {
			// A directory that cannot be walked is reported as unavailable.
			return $out;
		}

		$out['state'] = $out['changed'] ? 'modified' : 'verified';

		return $out;
	}

	/**
	 * Put a newly installed plugin in the approval queue.
	 *
	 * @param string $slug   Plugin slug.
	 * @param string $source Unpacked directory.
	 * @return void
	 */
	private function queue_for_approval( $slug, $source ) {
		if ( 'off' === $this->policy() || $this->is_approved( $slug ) ) {
			return;
		}

		$pending = self::pending();

		$pending[ $slug ] = array(
			'slug'       => $slug,
			'queued_at'  => time(),
			'queued_by'  => get_current_user_id(),
			'hash'       => $this->directory_hash( $source ),
		);

		update_option( self::PENDING, $pending, false );

		NYMS_Log::record(
			'plugin_pending',
			NYMS_Log::NOTICE,
			sprintf( /* translators: %s: plugin slug. */ __( 'Plugin %s is installed but not approved, so it cannot be activated.', 'newyorkmechanics-security' ), $slug )
		);
	}

	/**
	 * A single hash covering every PHP file in a directory.
	 *
	 * @param string $dir Directory.
	 * @return string
	 */
	public function directory_hash( $dir ) {
		if ( ! is_dir( $dir ) ) {
			return '';
		}

		$hashes = array();

		try {
			$iterator = new RecursiveIteratorIterator(
				new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS | FilesystemIterator::UNIX_PATHS ),
				RecursiveIteratorIterator::LEAVES_ONLY,
				RecursiveIteratorIterator::CATCH_GET_CHILD
			);
		} catch ( Exception $e ) {
			return '';
		}

		$root = wp_normalize_path( trailingslashit( $dir ) );

		foreach ( $iterator as $file ) {
			if ( ! $file->isFile() ) {
				continue;
			}

			$path = wp_normalize_path( $file->getPathname() );

			if ( ! NYMS_Helpers::is_executable_name( $path ) ) {
				continue;
			}

			$hashes[ str_replace( $root, '', $path ) ] = (string) @hash_file( 'sha256', $path );
		}

		ksort( $hashes );

		return hash( 'sha256', wp_json_encode( $hashes ) );
	}

	/**
	 * Refuse to save an activation for something that is not approved.
	 *
	 * @param array $value Plugins about to be active.
	 * @param array $old   Plugins currently active.
	 * @return array
	 */
	public function filter_activation( $value, $old ) {
		if ( 'enforce' !== $this->policy() || ! is_array( $value ) ) {
			return $value;
		}

		$old     = is_array( $old ) ? $old : array();
		$allowed = array();

		foreach ( $value as $file ) {
			$slug = sanitize_key( dirname( $file ) );

			if ( '.' === $slug ) {
				$slug = sanitize_key( basename( $file, '.php' ) );
			}

			if ( $this->is_approved( $slug ) || in_array( $file, $old, true ) ) {
				$allowed[] = $file;
				continue;
			}

			NYMS_Log::record(
				'plugin_activation_blocked',
				NYMS_Log::WARNING,
				sprintf( /* translators: %s: plugin file. */ __( 'Activation of %s was blocked: the plugin is not on the approved list.', 'newyorkmechanics-security' ), $file )
			);
		}

		return $allowed;
	}

	/**
	 * Never load a blocklisted plugin, even if the option still names it.
	 *
	 * @param array $plugins Active plugin files.
	 * @return array
	 */
	public function filter_loaded( $plugins ) {
		if ( ! is_array( $plugins ) ) {
			return $plugins;
		}

		$blocklist = self::blocklist();

		if ( ! $blocklist ) {
			return $plugins;
		}

		$out = array();

		foreach ( $plugins as $file ) {
			$slug = sanitize_key( dirname( $file ) );

			if ( isset( $blocklist[ $slug ] ) ) {
				continue;
			}

			$out[] = $file;
		}

		return $out;
	}

	/**
	 * Note an activation in the log.
	 *
	 * @param string $plugin  Plugin file.
	 * @param bool   $network Network wide.
	 * @return void
	 */
	public function record_activation( $plugin, $network ) {
		NYMS_Log::record(
			'plugin_activated',
			NYMS_Log::NOTICE,
			sprintf( /* translators: %s: plugin file. */ __( 'Plugin activated: %s', 'newyorkmechanics-security' ), $plugin ),
			array( 'network' => (bool) $network, 'user' => get_current_user_id() )
		);
	}

	/**
	 * Note a deactivation in the log.
	 *
	 * @param string $plugin  Plugin file.
	 * @param bool   $network Network wide.
	 * @return void
	 */
	public function record_deactivation( $plugin, $network ) {
		$severity = ( $plugin === NYMS_BASENAME ) ? NYMS_Log::CRITICAL : NYMS_Log::NOTICE;

		NYMS_Log::record(
			'plugin_deactivated',
			$severity,
			sprintf( /* translators: %s: plugin file. */ __( 'Plugin deactivated: %s', 'newyorkmechanics-security' ), $plugin ),
			array( 'network' => (bool) $network, 'user' => get_current_user_id() )
		);
	}

	/**
	 * Note a deletion in the log.
	 *
	 * @param string $plugin  Plugin file.
	 * @param bool   $deleted Whether it worked.
	 * @return void
	 */
	public function record_deletion( $plugin, $deleted ) {
		NYMS_Log::record(
			'plugin_deleted',
			NYMS_Log::WARNING,
			sprintf( /* translators: %s: plugin file. */ __( 'Plugin deleted: %s', 'newyorkmechanics-security' ), $plugin ),
			array( 'ok' => (bool) $deleted )
		);
	}

	/**
	 * Mark unapproved plugins in the plugin list.
	 *
	 * @param array  $links Action links.
	 * @param string $file  Plugin file.
	 * @return array
	 */
	public function flag_unapproved( $links, $file ) {
		if ( 'off' === $this->policy() ) {
			return $links;
		}

		$slug = sanitize_key( dirname( $file ) );

		if ( $this->is_approved( $slug ) && ! isset( self::pending()[ $slug ] ) ) {
			return $links;
		}

		$blocklist = self::blocklist();

		if ( isset( $blocklist[ $slug ] ) ) {
			$links['nyms'] = '<span style="color:#8a2424;font-weight:600;">' . esc_html__( 'Blocked', 'newyorkmechanics-security' ) . '</span>';

			return $links;
		}

		if ( ! isset( self::allowlist()[ $slug ] ) ) {
			$links['nyms'] = '<span style="color:#996800;font-weight:600;">' . esc_html__( 'Not approved', 'newyorkmechanics-security' ) . '</span>';
		}

		return $links;
	}

	/**
	 * The scheduled audit of everything already installed.
	 *
	 * @return array Report, slug => details.
	 */
	public function audit() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$report  = array();
		$plugins = get_plugins();

		foreach ( $plugins as $file => $data ) {
			$slug = sanitize_key( dirname( $file ) );

			if ( '.' === $slug || '' === $slug ) {
				$slug = sanitize_key( basename( $file, '.php' ) );
			}

			$health = $this->repository_health( $slug );
			$files  = array( 'state' => 'unavailable', 'changed' => array() );

			if ( 'unknown' !== $health['state'] && NYMS_VERIFY_PLUGIN_FILES ) {
				$files = $this->verify_plugin_files( $slug, isset( $data['Version'] ) ? $data['Version'] : '' );
			}

			$report[ $slug ] = array(
				'name'         => isset( $data['Name'] ) ? $data['Name'] : $slug,
				'version'      => isset( $data['Version'] ) ? $data['Version'] : '',
				'file'         => $file,
				'active'       => is_plugin_active( $file ),
				'approved'     => isset( self::allowlist()[ $slug ] ),
				'state'        => $health['state'],
				'last_updated' => $health['last_updated'],
				'files'        => $files['state'],
				'changed'      => array_slice( $files['changed'], 0, 25 ),
			);

			if ( 'modified' === $files['state'] ) {
				NYMS_Log::record(
					'plugin_modified',
					NYMS_Log::CRITICAL,
					sprintf(
						/* translators: 1: plugin name, 2: number of files. */
						__( '%1$s does not match the copy published by its author: %2$d files differ.', 'newyorkmechanics-security' ),
						$report[ $slug ]['name'],
						count( $files['changed'] )
					),
					array( 'files' => array_slice( $files['changed'], 0, 25 ) )
				);
			}

			if ( 'closed' === $health['state'] ) {
				NYMS_Log::record( 'plugin_closed', NYMS_Log::CRITICAL, $health['message'] );
			}
		}

		update_option( 'nyms_plugin_audit', array( 'at' => time(), 'report' => $report ), false );

		return $report;
	}

	/**
	 * The last audit result.
	 *
	 * @return array
	 */
	public static function last_audit() {
		$audit = get_option( 'nyms_plugin_audit', array() );

		return is_array( $audit ) ? $audit : array();
	}

}

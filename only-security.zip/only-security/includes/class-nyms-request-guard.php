<?php
/**
 * Request guard.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A small, deliberately conservative request filter.
 *
 * It inspects the URL and the query string only - never post bodies - and it
 * stands down for logged-in editors, so it cannot break normal content work.
 * Its job is to stop the automated probes that precede an injection.
 */
class NYMS_Request_Guard {

	/**
	 * Maximum accepted request URI length.
	 */
	const MAX_URI_LENGTH = 4096;

	/**
	 * Patterns that have no legitimate place in a URL on this site.
	 *
	 * @var array
	 */
	private $patterns = array(
		// PHP code injection.
		'/<\?(php|=)/i',
		'/\b(eval|assert|create_function|shell_exec|passthru|proc_open|popen|system|exec)\s*\(/i',
		'/\bbase64_(en|de)code\s*\(/i',
		'/\b(gzinflate|str_rot13|gzuncompress)\s*\(/i',
		'/\b(call_user_func|preg_replace)\s*\(.*\/e/i',

		// Stream and file wrappers used to pull in remote payloads.
		'/(php|data|expect|zip|phar|glob):\/\//i',

		// Local file inclusion and traversal.
		'/(\.\.\/|\.\.\\\\){2,}/',
		'/\/(etc\/passwd|proc\/self\/environ|boot\.ini)/i',
		'/wp-config(-sample)?\.php/i',

		// Superglobal tampering.
		'/(GLOBALS|_SERVER|_REQUEST|_ENV|_COOKIE|_SESSION|HTTP_RAW_POST_DATA)\s*(\[|%5B)/i',

		// Script injection reflected through the query string.
		'/<\s*script\b/i',
		'/\bon(error|load|click|mouseover|focus)\s*=/i',
		'/javascript\s*:/i',
		'/<\s*(iframe|object|embed|applet|svg|base|meta)\b/i',

		// SQL injection probes.
		'/\bunion\b[\s\/\*]+\bselect\b/i',
		'/\bselect\b.{0,60}?\bfrom\b\s+[`\'"(]*(wp_|information_schema|mysql\.)/i',
		'/\b(drop|truncate)\s+table\b/i',
		'/\binformation_schema\b/i',
		'/\/\*!\d+/',
		'/\b(sleep|benchmark|extractvalue|updatexml)\s*\(/i',

		// PHP object injection.
		'/O:\d+:"[a-z_\\\\]+":\d+:\{/i',
	);

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! NYMS_REQUEST_GUARD ) {
			return;
		}

		// plugins_loaded is the earliest point where the pluggable user
		// functions are dependable across every WordPress version.
		add_action( 'plugins_loaded', array( $this, 'inspect' ), 0 );
	}

	/**
	 * Inspect the current request and stop it when it is clearly hostile.
	 *
	 * @return void
	 */
	public function inspect() {
		if ( ( defined( 'WP_CLI' ) && WP_CLI ) || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) {
			return;
		}

		/**
		 * Allow the filter to be switched off for a specific request.
		 *
		 * @param bool $skip Whether to skip inspection.
		 */
		if ( apply_filters( 'nyms_skip_request_guard', false ) ) {
			return;
		}

		if ( NYMS_Helpers::is_trusted_user() ) {
			return;
		}

		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';

		if ( strlen( $uri ) > self::MAX_URI_LENGTH ) {
			NYMS_Helpers::forbid();
		}

		// A null byte in a path or query is always an attack.
		if ( false !== strpos( $uri, "\0" ) || NYMS_Helpers::has( rawurldecode( $uri ), "\0" ) ) {
			NYMS_Helpers::forbid();
		}

		$self = $this;

		$callback = function ( $value ) use ( $self ) {
			return $self->is_hostile( $value );
		};

		if ( '' !== $uri && $this->is_hostile( rawurldecode( $uri ) ) ) {
			NYMS_Helpers::forbid();
		}

		if ( ! empty( $_GET ) && NYMS_Helpers::walk( wp_unslash( $_GET ), $callback ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			NYMS_Helpers::forbid();
		}

		$this->inspect_headers( $callback );
	}

	/**
	 * Inspect the handful of headers that reach application code.
	 *
	 * @param callable $callback Matcher.
	 * @return void
	 */
	private function inspect_headers( $callback ) {
		$headers = array( 'HTTP_USER_AGENT', 'HTTP_REFERER', 'HTTP_X_FORWARDED_FOR', 'HTTP_CLIENT_IP' );

		foreach ( $headers as $header ) {
			if ( empty( $_SERVER[ $header ] ) ) {
				continue;
			}

			$value = (string) wp_unslash( $_SERVER[ $header ] );

			if ( false !== strpos( $value, "\0" ) || call_user_func( $callback, $value ) ) {
				NYMS_Helpers::forbid();
			}
		}
	}

	/**
	 * Match a single string against the pattern list.
	 *
	 * @param string $value Value to test.
	 * @return bool
	 */
	public function is_hostile( $value ) {
		$value = (string) $value;

		if ( '' === $value ) {
			return false;
		}

		// No legitimate query value on this site is 20 KB long.
		if ( strlen( $value ) > 20000 ) {
			return true;
		}

		// Test the raw value and one decode pass: attackers encode twice.
		$candidates = array( $value, rawurldecode( $value ) );

		foreach ( $candidates as $candidate ) {
			foreach ( $this->patterns as $pattern ) {
				if ( preg_match( $pattern, $candidate ) ) {
					return true;
				}
			}
		}

		return false;
	}
}

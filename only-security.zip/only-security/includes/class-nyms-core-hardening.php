<?php
/**
 * WordPress core hardening.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Locks down core behaviour that is commonly abused to plant backdoors.
 */
class NYMS_Core_Hardening {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register() {
		// The built-in file editors are the fastest route from a stolen
		// password to a persistent PHP backdoor.
		if ( NYMS_DISALLOW_FILE_EDIT && ! defined( 'DISALLOW_FILE_EDIT' ) ) {
			define( 'DISALLOW_FILE_EDIT', true );
		}

		if ( NYMS_DISALLOW_FILE_MODS && ! defined( 'DISALLOW_FILE_MODS' ) ) {
			define( 'DISALLOW_FILE_MODS', true );
		}

		add_filter( 'map_meta_cap', array( $this, 'filter_caps' ), 10, 2 );

		// Never advertise the exact core version.
		remove_action( 'wp_head', 'wp_generator' );
		add_filter( 'the_generator', '__return_empty_string' );
		add_filter( 'update_footer', array( $this, 'hide_version_footer' ), 99 );

		// Remove discovery endpoints that only exist for legacy publishing tools.
		remove_action( 'wp_head', 'rsd_link' );
		remove_action( 'wp_head', 'wlwmanifest_link' );

		if ( NYMS_MINOR_AUTO_UPDATES ) {
			add_filter( 'allow_minor_auto_core_updates', '__return_true', 99 );
			add_filter( 'auto_update_translation', '__return_true', 99 );
		}

		// Do not leak the PHP/WP version to third parties via the UA string.
		add_filter( 'http_headers_useragent', array( $this, 'filter_user_agent' ), 99 );

		// Block outbound requests to the local network from within WordPress.
		add_filter( 'http_request_host_is_external', array( $this, 'block_internal_hosts' ), 99, 3 );

		// The name of the software that issued a redirect is free reconnaissance.
		add_filter( 'x_redirect_by', '__return_false' );

		if ( NYMS_DISABLE_FEEDS ) {
			foreach ( array( 'do_feed', 'do_feed_rdf', 'do_feed_rss', 'do_feed_rss2', 'do_feed_atom', 'do_feed_rss2_comments', 'do_feed_atom_comments' ) as $feed ) {
				add_action( $feed, array( $this, 'kill_feed' ), 1 );
			}

			remove_action( 'wp_head', 'feed_links', 2 );
			remove_action( 'wp_head', 'feed_links_extra', 3 );
		}

		add_action( 'admin_init', array( $this, 'guard_editor_screens' ) );
	}

	/**
	 * Answer a feed request with nothing at all.
	 *
	 * Feeds are a convenient way to enumerate every post, author and comment
	 * on a site that never intended to publish one.
	 *
	 * @return void
	 */
	public function kill_feed() {
		wp_die(
			esc_html__( 'No feed is available on this site.', 'newyorkmechanics-security' ),
			'',
			array( 'response' => 410 )
		);
	}

	/**
	 * Strip dangerous capabilities.
	 *
	 * `unfiltered_html` lets a user store raw <script> in post content. That is
	 * exactly the payload attackers plant after taking over an admin account,
	 * so it is removed for everybody unless explicitly re-enabled.
	 *
	 * @param array  $caps Required primitive capabilities.
	 * @param string $cap  Capability being checked.
	 * @return array
	 */
	public function filter_caps( $caps, $cap ) {
		if ( NYMS_FORCE_KSES && 'unfiltered_html' === $cap ) {
			return array( 'do_not_allow' );
		}

		if ( NYMS_DISALLOW_FILE_EDIT && ( 'edit_files' === $cap || 'edit_plugins' === $cap || 'edit_themes' === $cap ) ) {
			return array( 'do_not_allow' );
		}

		if ( NYMS_DISALLOW_FILE_MODS ) {
			$blocked = array(
				'install_plugins',
				'install_themes',
				'update_plugins',
				'update_themes',
				'update_core',
				'upload_plugins',
				'upload_themes',
				'delete_plugins',
				'delete_themes',
			);

			if ( in_array( $cap, $blocked, true ) ) {
				return array( 'do_not_allow' );
			}
		}

		return $caps;
	}

	/**
	 * Hide the version string in the admin footer.
	 *
	 * @param string $content Footer content.
	 * @return string
	 */
	public function hide_version_footer( $content ) {
		return current_user_can( 'update_core' ) ? $content : '';
	}

	/**
	 * Replace the default outbound user agent.
	 *
	 * @return string
	 */
	public function filter_user_agent() {
		return 'WordPress';
	}

	/**
	 * Refuse WordPress-initiated HTTP requests aimed at private ranges.
	 *
	 * This is the standard SSRF guard: a compromised plugin should not be able
	 * to use wp_remote_get() to reach the metadata service or an internal host.
	 *
	 * @param bool   $is_external Whether the host is considered external.
	 * @param string $host        Host name.
	 * @param string $url         Full URL.
	 * @return bool
	 */
	public function block_internal_hosts( $is_external, $host, $url ) {
		unset( $url );

		$ip = filter_var( $host, FILTER_VALIDATE_IP );

		if ( ! $ip ) {
			return $is_external;
		}

		$public = filter_var(
			$ip,
			FILTER_VALIDATE_IP,
			FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
		);

		return $public ? $is_external : false;
	}

	/**
	 * Send anyone who deep-links the file editors back to the dashboard.
	 *
	 * @return void
	 */
	public function guard_editor_screens() {
		if ( ! NYMS_DISALLOW_FILE_EDIT ) {
			return;
		}

		global $pagenow;

		if ( in_array( $pagenow, array( 'plugin-editor.php', 'theme-editor.php' ), true ) ) {
			wp_safe_redirect( admin_url() );
			exit;
		}
	}
}

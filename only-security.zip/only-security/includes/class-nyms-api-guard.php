<?php
/**
 * XML-RPC, REST and enumeration guard.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Closes the machine interfaces that are only ever used against this site,
 * and stops the user-name harvesting that precedes a brute-force run.
 */
class NYMS_Api_Guard {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register() {
		if ( NYMS_DISABLE_XMLRPC ) {
			add_filter( 'xmlrpc_enabled', '__return_false', 99 );
			add_filter( 'pre_option_enable_xmlrpc', '__return_zero', 99 );
			add_filter( 'xmlrpc_methods', array( $this, 'remove_methods' ), 99 );
			add_filter( 'wp_headers', array( $this, 'remove_pingback_header' ), 99 );
			add_filter( 'bloginfo_url', array( $this, 'hide_pingback_url' ), 99, 2 );
			add_action( 'plugins_loaded', array( $this, 'block_xmlrpc_requests' ), 1 );

			// Pingbacks are the classic reflective DDoS amplifier.
			add_filter( 'pings_open', '__return_false', 99 );
			remove_action( 'do_pings', 'do_all_pings', 10 );
		}

		if ( NYMS_DISABLE_APP_PASSWORDS ) {
			add_filter( 'wp_is_application_passwords_available', '__return_false', 99 );
		}

		if ( NYMS_RESTRICT_REST ) {
			add_filter( 'rest_authentication_errors', array( $this, 'require_authentication' ), 99 );
		}

		if ( NYMS_BLOCK_ENUMERATION ) {
			add_filter( 'rest_endpoints', array( $this, 'restrict_user_endpoints' ), 99 );
			add_action( 'parse_request', array( $this, 'block_author_probe' ), 1 );
			add_filter( 'redirect_canonical', array( $this, 'stop_author_redirect' ), 99, 2 );
			add_filter( 'wp_sitemaps_add_provider', array( $this, 'drop_user_sitemap' ), 99, 2 );
			add_filter( 'oembed_response_data', array( $this, 'strip_oembed_author' ), 99 );
			add_filter( 'rest_prepare_user', array( $this, 'strip_user_fields' ), 99 );
		}
	}

	/**
	 * Empty the XML-RPC method table.
	 *
	 * @param array $methods Registered methods.
	 * @return array
	 */
	public function remove_methods( $methods ) {
		unset( $methods );

		return array();
	}

	/**
	 * Drop the X-Pingback response header.
	 *
	 * @param array $headers Response headers.
	 * @return array
	 */
	public function remove_pingback_header( $headers ) {
		if ( is_array( $headers ) ) {
			unset( $headers['X-Pingback'], $headers['x-pingback'] );
		}

		return $headers;
	}

	/**
	 * Stop bloginfo() from printing the pingback endpoint.
	 *
	 * @param string $output Value.
	 * @param string $show   Requested property.
	 * @return string
	 */
	public function hide_pingback_url( $output, $show ) {
		return 'pingback_url' === $show ? '' : $output;
	}

	/**
	 * Refuse direct hits on xmlrpc.php.
	 *
	 * Disabling the methods still leaves the endpoint answering, which is
	 * enough for an attacker to keep hammering it.
	 *
	 * @return void
	 */
	public function block_xmlrpc_requests() {
		$path = NYMS_Helpers::request_path();

		if ( '' === $path ) {
			return;
		}

		if ( 'xmlrpc.php' === strtolower( basename( $path ) ) ) {
			NYMS_Helpers::forbid();
		}
	}

	/**
	 * Require a signed-in user for the REST API.
	 *
	 * A handful of routes have to stay open or the site itself breaks: oEmbed,
	 * the block editor's public data, and anything a theme fetches from the
	 * front end. Everything else is closed to anonymous callers.
	 *
	 * @param WP_Error|null|true $result Current authentication result.
	 * @return WP_Error|null|true
	 */
	public function require_authentication( $result ) {
		if ( ! empty( $result ) ) {
			return $result;
		}

		if ( is_user_logged_in() ) {
			return $result;
		}

		$route = '';

		if ( isset( $GLOBALS['wp'] ) && ! empty( $GLOBALS['wp']->query_vars['rest_route'] ) ) {
			$route = (string) $GLOBALS['wp']->query_vars['rest_route'];
		}

		/**
		 * Filter the routes that stay open to anonymous callers.
		 *
		 * @param array  $open  Route prefixes.
		 * @param string $route The route being requested.
		 */
		$open = apply_filters(
			'nyms_public_rest_routes',
			array(
				'/oembed/',
				'/wp/v2/pages',
				'/wp/v2/posts',
				'/wp/v2/media',
				'/wp/v2/categories',
				'/wp/v2/tags',
				'/wp/v2/comments',
				'/wp/v2/search',
				'/contact-form-7/',
				'/wc/store/',
			),
			$route
		);

		foreach ( (array) $open as $prefix ) {
			if ( '' !== $route && 0 === strpos( $route, $prefix ) ) {
				return $result;
			}
		}

		// The index itself lists every route on the site, which is a map.
		return new WP_Error(
			'nyms_rest_forbidden',
			__( 'The REST API on this site is only available to signed-in users.', 'newyorkmechanics-security' ),
			array( 'status' => rest_authorization_required_code() )
		);
	}

	/**
	 * Hide the user routes from anonymous callers.
	 *
	 * Logged-in editors keep them: the block editor needs the author list.
	 *
	 * @param array $endpoints REST endpoints.
	 * @return array
	 */
	public function restrict_user_endpoints( $endpoints ) {
		if ( is_user_logged_in() ) {
			return $endpoints;
		}

		unset( $endpoints['/wp/v2/users'] );
		unset( $endpoints['/wp/v2/users/(?P<id>[\d]+)'] );

		return $endpoints;
	}

	/**
	 * Block the ?author=1 probe that maps user IDs to login names.
	 *
	 * @param WP $wp Current request object.
	 * @return void
	 */
	public function block_author_probe( $wp ) {
		if ( is_admin() || NYMS_Helpers::is_trusted_user() ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$author = isset( $_GET['author'] ) ? wp_unslash( $_GET['author'] ) : '';

		if ( '' === $author || is_array( $author ) ) {
			return;
		}

		if ( preg_match( '/^\d+$/', (string) $author ) ) {
			unset( $wp->query_vars['author'] );

			NYMS_Helpers::forbid();
		}
	}

	/**
	 * Keep canonical redirects from turning an ID into a user slug.
	 *
	 * @param string $redirect Proposed URL.
	 * @param string $request  Requested URL.
	 * @return string|false
	 */
	public function stop_author_redirect( $redirect, $request ) {
		unset( $request );

		if ( is_author() && ! NYMS_Helpers::is_trusted_user() ) {
			return false;
		}

		return $redirect;
	}

	/**
	 * Remove the users provider from the core sitemap.
	 *
	 * @param mixed  $provider Sitemap provider.
	 * @param string $name     Provider name.
	 * @return mixed
	 */
	public function drop_user_sitemap( $provider, $name ) {
		return 'users' === $name ? false : $provider;
	}

	/**
	 * Strip author identity from oEmbed responses.
	 *
	 * @param array $data Response data.
	 * @return array
	 */
	public function strip_oembed_author( $data ) {
		if ( is_array( $data ) ) {
			unset( $data['author_name'], $data['author_url'] );
		}

		return $data;
	}

	/**
	 * Remove the login-derived fields from any user response that still runs.
	 *
	 * @param mixed $response REST response.
	 * @return mixed
	 */
	public function strip_user_fields( $response ) {
		if ( is_object( $response ) && isset( $response->data ) && is_array( $response->data ) && ! current_user_can( 'list_users' ) ) {
			unset( $response->data['slug'], $response->data['link'] );
		}

		return $response;
	}
}

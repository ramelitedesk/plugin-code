<?php
/**
 * HTTP request firewall.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Everything that decides whether a request is answered at all.
 *
 * The request guard looks at what a request contains. This looks at who is
 * sending it and how often: rate limits, address lists, user-agent filtering
 * and the automatic block that follows a run of refused requests.
 */
class NYMS_Firewall {

	/**
	 * Option names.
	 */
	const BLOCKS    = 'nyms_ip_blocks';
	const ALLOWED   = 'nyms_ip_allowlist';
	const DENIED    = 'nyms_ip_blocklist';
	const COUNTRIES = 'nyms_blocked_countries';
	const AGENTS    = 'nyms_blocked_agents';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! NYMS_FIREWALL ) {
			return;
		}

		add_action( 'plugins_loaded', array( $this, 'inspect' ), 1 );
		add_action( 'nyms_prune_blocks', array( $this, 'prune' ) );

		// A 404 storm is reconnaissance; count it.
		add_action( 'template_redirect', array( $this, 'watch_not_found' ), 1 );
	}

	/**
	 * Run every check for the current request.
	 *
	 * @return void
	 */
	public function inspect() {
		if ( ( defined( 'WP_CLI' ) && WP_CLI ) || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) {
			return;
		}

		$ip = NYMS_Helpers::client_ip();

		if ( $this->is_allowlisted( $ip ) ) {
			return;
		}

		if ( $this->is_denied( $ip ) ) {
			$this->refuse( 'ip_blocklist', __( 'the address is on the blocklist', 'newyorkmechanics-security' ), $ip );
		}

		$block = $this->active_block( $ip );

		if ( $block ) {
			$this->refuse( 'ip_autoblock', $block['reason'], $ip, false );
		}

		if ( $this->country_blocked() ) {
			$this->refuse( 'country_blocked', __( 'requests from this country are not accepted', 'newyorkmechanics-security' ), $ip );
		}

		if ( $this->agent_blocked() ) {
			$this->refuse( 'agent_blocked', __( 'the user agent is not accepted', 'newyorkmechanics-security' ), $ip );
		}

		$this->apply_rate_limits( $ip );
	}

	/**
	 * Whether an address is exempt from every rule.
	 *
	 * @param string $ip Client address.
	 * @return bool
	 */
	public function is_allowlisted( $ip ) {
		$list = self::list_option( self::ALLOWED );

		if ( ! $list ) {
			return false;
		}

		return $this->matches_any( $ip, $list );
	}

	/**
	 * Whether an address is permanently refused.
	 *
	 * @param string $ip Client address.
	 * @return bool
	 */
	public function is_denied( $ip ) {
		return $this->matches_any( $ip, self::list_option( self::DENIED ) );
	}

	/**
	 * Compare an address against a list of addresses and CIDR ranges.
	 *
	 * @param string $ip   Address.
	 * @param array  $list Entries.
	 * @return bool
	 */
	public function matches_any( $ip, $list ) {
		foreach ( (array) $list as $entry ) {
			$entry = trim( $entry );

			if ( '' === $entry ) {
				continue;
			}

			if ( $entry === $ip ) {
				return true;
			}

			if ( false !== strpos( $entry, '/' ) && $this->in_cidr( $ip, $entry ) ) {
				return true;
			}

			// Trailing wildcard: 203.0.113.*
			if ( false !== strpos( $entry, '*' ) ) {
				$pattern = '/^' . str_replace( array( '.', '*' ), array( '\.', '.*' ), $entry ) . '$/';

				if ( preg_match( $pattern, $ip ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * IPv4 and IPv6 CIDR test.
	 *
	 * @param string $ip    Address.
	 * @param string $range CIDR range.
	 * @return bool
	 */
	public function in_cidr( $ip, $range ) {
		$parts = explode( '/', $range, 2 );

		if ( count( $parts ) !== 2 ) {
			return false;
		}

		$subnet = $parts[0];
		$bits   = (int) $parts[1];

		$ip_bin     = @inet_pton( $ip );
		$subnet_bin = @inet_pton( $subnet );

		if ( false === $ip_bin || false === $subnet_bin || strlen( $ip_bin ) !== strlen( $subnet_bin ) ) {
			return false;
		}

		$bytes = (int) floor( $bits / 8 );
		$rest  = $bits % 8;

		if ( $bytes > 0 && strncmp( $ip_bin, $subnet_bin, $bytes ) !== 0 ) {
			return false;
		}

		if ( 0 === $rest ) {
			return true;
		}

		$mask = chr( 0xff << ( 8 - $rest ) & 0xff );

		return ( $ip_bin[ $bytes ] & $mask ) === ( $subnet_bin[ $bytes ] & $mask );
	}

	/**
	 * Whether the request comes from a blocked country.
	 *
	 * The country is only known when a proxy in front of the site says so -
	 * Cloudflare's CF-IPCountry header is the common case. Without it this
	 * check stands down rather than guessing.
	 *
	 * @return bool
	 */
	public function country_blocked() {
		$blocked = self::list_option( self::COUNTRIES );

		if ( ! $blocked ) {
			return false;
		}

		$country = $this->country_code();

		if ( '' === $country ) {
			return false;
		}

		foreach ( $blocked as $code ) {
			if ( strtoupper( trim( $code ) ) === $country ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Read the country code the edge network reported.
	 *
	 * @return string Two-letter code, or an empty string.
	 */
	public function country_code() {
		$headers = array( 'HTTP_CF_IPCOUNTRY', 'HTTP_X_COUNTRY_CODE', 'HTTP_CLOUDFRONT_VIEWER_COUNTRY', 'HTTP_X_GEOIP_COUNTRY', 'GEOIP_COUNTRY_CODE' );

		foreach ( $headers as $header ) {
			if ( empty( $_SERVER[ $header ] ) ) {
				continue;
			}

			$value = strtoupper( substr( (string) wp_unslash( $_SERVER[ $header ] ), 0, 2 ) );

			if ( preg_match( '/^[A-Z]{2}$/', $value ) ) {
				return $value;
			}
		}

		return '';
	}

	/**
	 * Whether the user agent is refused.
	 *
	 * @return bool
	 */
	public function agent_blocked() {
		$agent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) : '';

		if ( '' === trim( $agent ) ) {
			return (bool) NYMS_BLOCK_EMPTY_AGENT && ! $this->is_admin_request();
		}

		$defaults = array(
			'sqlmap', 'nikto', 'nmap', 'masscan', 'zgrab', 'nessus', 'acunetix',
			'havij', 'wpscan', 'dirbuster', 'gobuster', 'feroxbuster', 'arachni',
			'commix', 'xsser', 'metasploit', 'skipfish', 'w3af', 'hydra',
		);

		$custom = self::list_option( self::AGENTS );
		$list   = array_merge( $defaults, $custom );

		foreach ( $list as $needle ) {
			$needle = trim( $needle );

			if ( '' !== $needle && false !== stripos( $agent, $needle ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether this request is an authenticated admin request.
	 *
	 * @return bool
	 */
	private function is_admin_request() {
		return NYMS_Helpers::is_trusted_user();
	}

	/**
	 * Apply the per-endpoint rate limits.
	 *
	 * @param string $ip Client address.
	 * @return void
	 */
	private function apply_rate_limits( $ip ) {
		$path = strtolower( NYMS_Helpers::request_path() );
		$base = basename( $path );

		$buckets = array();

		if ( 'wp-login.php' === $base ) {
			$buckets['login'] = array( (int) NYMS_RATE_LOGIN, 300 );
		} elseif ( 'xmlrpc.php' === $base ) {
			$buckets['xmlrpc'] = array( 10, 300 );
		} elseif ( 'admin-ajax.php' === $base ) {
			$buckets['ajax'] = array( (int) NYMS_RATE_GENERAL * 2, 60 );
		} elseif ( false !== strpos( $path, '/wp-json/' ) || isset( $_GET['rest_route'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$buckets['rest'] = array( (int) NYMS_RATE_REST, 60 );
		}

		$buckets['all'] = array( (int) NYMS_RATE_GENERAL, 60 );

		foreach ( $buckets as $name => $bucket ) {
			list( $limit, $window ) = $bucket;

			if ( $limit <= 0 ) {
				continue;
			}

			$key   = 'nyms_rl_' . $name . '_' . NYMS_Helpers::ip_key( $ip );
			$count = (int) get_transient( $key );

			$count++;

			set_transient( $key, $count, $window );

			if ( $count > $limit ) {
				$this->register_violation( $ip, sprintf( /* translators: %s: bucket name. */ __( 'rate limit exceeded on %s', 'newyorkmechanics-security' ), $name ) );

				$this->refuse(
					'rate_limited',
					sprintf( /* translators: %s: bucket name. */ __( 'too many requests to %s', 'newyorkmechanics-security' ), $name ),
					$ip,
					true,
					429
				);
			}
		}
	}

	/**
	 * Count 404s: a scanner hunting for a backdoor generates hundreds.
	 *
	 * @return void
	 */
	public function watch_not_found() {
		if ( ! is_404() || ! NYMS_AUTO_BLOCK ) {
			return;
		}

		$ip = NYMS_Helpers::client_ip();

		if ( $this->is_allowlisted( $ip ) || NYMS_Helpers::is_trusted_user() ) {
			return;
		}

		$key   = 'nyms_404_' . NYMS_Helpers::ip_key( $ip );
		$count = (int) get_transient( $key ) + 1;

		set_transient( $key, $count, 300 );

		if ( $count > (int) NYMS_MAX_NOT_FOUND ) {
			$this->register_violation( $ip, __( 'scanning for files that do not exist', 'newyorkmechanics-security' ) );
		}
	}

	/**
	 * Record a violation and block the address once they add up.
	 *
	 * @param string $ip     Client address.
	 * @param string $reason Why.
	 * @return void
	 */
	public function register_violation( $ip, $reason ) {
		if ( ! NYMS_AUTO_BLOCK || $this->is_allowlisted( $ip ) ) {
			return;
		}

		$key   = 'nyms_viol_' . NYMS_Helpers::ip_key( $ip );
		$count = (int) get_transient( $key ) + 1;

		set_transient( $key, $count, HOUR_IN_SECONDS );

		if ( $count < (int) NYMS_BLOCK_THRESHOLD ) {
			return;
		}

		// Each repeat block lasts longer than the last.
		$blocks   = self::blocks();
		$previous = isset( $blocks[ $ip ]['strikes'] ) ? (int) $blocks[ $ip ]['strikes'] : 0;
		$duration = min( WEEK_IN_SECONDS, (int) NYMS_BLOCK_MINUTES * MINUTE_IN_SECONDS * pow( 2, $previous ) );

		$this->block_ip( $ip, $reason, $duration, $previous + 1 );
	}

	/**
	 * Block an address for a period.
	 *
	 * @param string $ip       Address.
	 * @param string $reason   Why.
	 * @param int    $duration Seconds.
	 * @param int    $strikes  Repeat count.
	 * @return void
	 */
	public function block_ip( $ip, $reason, $duration, $strikes = 1 ) {
		$blocks = self::blocks();

		$blocks[ $ip ] = array(
			'reason'  => (string) $reason,
			'until'   => time() + (int) $duration,
			'since'   => time(),
			'strikes' => (int) $strikes,
		);

		// Keep the list bounded: drop the oldest entries first.
		if ( count( $blocks ) > 500 ) {
			uasort(
				$blocks,
				function ( $a, $b ) {
					return $a['until'] - $b['until'];
				}
			);

			$blocks = array_slice( $blocks, -500, null, true );
		}

		update_option( self::BLOCKS, $blocks, false );

		NYMS_Log::record(
			'ip_blocked',
			NYMS_Log::WARNING,
			sprintf(
				/* translators: 1: address, 2: reason, 3: minutes. */
				__( 'Blocked %1$s for %3$d minutes: %2$s', 'newyorkmechanics-security' ),
				$ip,
				$reason,
				max( 1, (int) round( $duration / 60 ) )
			),
			array( 'strikes' => $strikes )
		);
	}

	/**
	 * Lift a block.
	 *
	 * @param string $ip Address.
	 * @return void
	 */
	public static function unblock( $ip ) {
		$blocks = self::blocks();

		if ( ! isset( $blocks[ $ip ] ) ) {
			return;
		}

		unset( $blocks[ $ip ] );

		update_option( self::BLOCKS, $blocks, false );
	}

	/**
	 * The block currently in force for an address.
	 *
	 * @param string $ip Address.
	 * @return array|false
	 */
	public function active_block( $ip ) {
		$blocks = self::blocks();

		if ( ! isset( $blocks[ $ip ] ) ) {
			return false;
		}

		if ( $blocks[ $ip ]['until'] < time() ) {
			return false;
		}

		return $blocks[ $ip ];
	}

	/**
	 * Every recorded block.
	 *
	 * @return array
	 */
	public static function blocks() {
		$blocks = get_option( self::BLOCKS, array() );

		return is_array( $blocks ) ? $blocks : array();
	}

	/**
	 * Drop expired blocks.
	 *
	 * @return void
	 */
	public function prune() {
		$blocks = self::blocks();
		$now    = time();
		$keep   = array();

		foreach ( $blocks as $ip => $block ) {
			// Expired entries are kept for a day so the strike count survives.
			if ( $block['until'] > ( $now - DAY_IN_SECONDS ) ) {
				$keep[ $ip ] = $block;
			}
		}

		if ( count( $keep ) !== count( $blocks ) ) {
			update_option( self::BLOCKS, $keep, false );
		}
	}

	/**
	 * Read a stored list option.
	 *
	 * @param string $name Option name.
	 * @return array
	 */
	public static function list_option( $name ) {
		$value = get_option( $name, array() );

		if ( is_string( $value ) ) {
			$value = preg_split( '/[\r\n,]+/', $value );
		}

		if ( ! is_array( $value ) ) {
			return array();
		}

		return array_values( array_filter( array_map( 'trim', $value ) ) );
	}

	/**
	 * Store a list option from a textarea.
	 *
	 * @param string $name Option name.
	 * @param string $raw  Raw textarea contents.
	 * @return void
	 */
	public static function save_list( $name, $raw ) {
		$items = preg_split( '/[\r\n,]+/', (string) $raw );
		$clean = array();

		foreach ( (array) $items as $item ) {
			$item = trim( sanitize_text_field( $item ) );

			if ( '' !== $item ) {
				$clean[] = $item;
			}
		}

		update_option( $name, array_slice( array_unique( $clean ), 0, 2000 ), false );
	}

	/**
	 * End the request.
	 *
	 * @param string $type   Event type.
	 * @param string $reason Human reason.
	 * @param string $ip     Client address.
	 * @param bool   $log    Whether to log it.
	 * @param int    $status HTTP status to send.
	 * @return void
	 */
	private function refuse( $type, $reason, $ip, $log = true, $status = 403 ) {
		if ( $log ) {
			NYMS_Log::record(
				$type,
				NYMS_Log::NOTICE,
				sprintf(
					/* translators: 1: address, 2: reason. */
					__( 'Refused a request from %1$s: %2$s', 'newyorkmechanics-security' ),
					$ip,
					$reason
				),
				array( 'path' => NYMS_Helpers::request_path() )
			);
		}

		if ( ! headers_sent() ) {
			status_header( $status );
			nocache_headers();

			if ( 429 === $status ) {
				header( 'Retry-After: 60' );
			}

			header( 'Content-Type: text/plain; charset=utf-8' );
		}

		echo 429 === $status ? 'Too Many Requests' : 'Forbidden';
		exit;
	}
}

<?php
/**
 * Outbound request control.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Watches what this site talks to.
 *
 * A backdoor has to phone home: to fetch its next payload, to report the
 * credentials it has stolen, or to pull in the spam it is about to publish.
 * Every request WordPress makes goes through the HTTP API, so this is a
 * choke point worth standing in.
 */
class NYMS_Network_Guard {

	/**
	 * Option names.
	 */
	const ALLOWED = 'nyms_domain_allowlist';
	const DENIED  = 'nyms_domain_blocklist';
	const SEEN    = 'nyms_domains_seen';

	/**
	 * Hosts WordPress itself needs.
	 *
	 * @return array
	 */
	public static function core_hosts() {
		return array(
			'api.wordpress.org',
			'downloads.wordpress.org',
			'wordpress.org',
			'core.svn.wordpress.org',
			'plugins.svn.wordpress.org',
			'ps.w.org',
			's.w.org',
			'api.w.org',
			'gravatar.com',
			'secure.gravatar.com',
			'0.gravatar.com',
			'1.gravatar.com',
			'2.gravatar.com',
		);
	}

	/**
	 * Domains known to be used by WordPress malware.
	 *
	 * A short, curated list: it is a tripwire, not an antivirus database.
	 *
	 * @return array
	 */
	public static function known_bad() {
		return array(
			'wp-security.org', 'wpsecurity.tools', 'cdn-wp.link', 'wp-stats.info',
			'code.wp-cdn.pw', 'stats-wp.com', 'wordpresscore.com', 'wp-code.org',
			'coinhive.com', 'coin-hive.com', 'jsecoin.com', 'crypto-loot.com',
			'webminepool.com', 'minero.cc', 'sslsecurecdn.com', 'cdn.jsdelivr.link',
		);
	}

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! NYMS_NETWORK_GUARD ) {
			return;
		}

		add_filter( 'pre_http_request', array( $this, 'inspect_request' ), 5, 3 );
		add_action( 'nyms_prune_blocks', array( $this, 'prune_seen' ) );
	}

	/**
	 * Decide whether an outbound request may go out.
	 *
	 * @param false|array|WP_Error $pre  Short-circuit value.
	 * @param array                $args Request arguments.
	 * @param string               $url  Target URL.
	 * @return false|array|WP_Error
	 */
	public function inspect_request( $pre, $args, $url ) {
		unset( $args );

		if ( false !== $pre ) {
			return $pre;
		}

		$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );

		if ( '' === $host ) {
			return $pre;
		}

		$site = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );

		if ( $host === $site || 'localhost' === $host ) {
			return $pre;
		}

		// An explicit refusal always wins.
		if ( $this->host_in( $host, NYMS_Firewall::list_option( self::DENIED ) ) || $this->host_in( $host, self::known_bad() ) ) {
			NYMS_Log::record(
				'outbound_blocked',
				NYMS_Log::CRITICAL,
				sprintf( /* translators: %s: host name. */ __( 'An outgoing request to %s was blocked.', 'newyorkmechanics-security' ), $host ),
				array( 'url' => $this->safe_url( $url ) )
			);

			return new WP_Error( 'nyms_domain_blocked', __( 'This site is not allowed to contact that address.', 'newyorkmechanics-security' ) );
		}

		$this->remember_host( $host, $url );

		// In allowlist mode nothing outside the list goes anywhere.
		if ( NYMS_DOMAIN_ALLOWLIST_MODE ) {
			$allowed = array_merge( self::core_hosts(), NYMS_Firewall::list_option( self::ALLOWED ) );

			if ( ! $this->host_in( $host, $allowed ) ) {
				NYMS_Log::record(
					'outbound_blocked',
					NYMS_Log::WARNING,
					sprintf(
						/* translators: %s: host name. */
						__( 'An outgoing request to %s was blocked: the host is not on the allowlist.', 'newyorkmechanics-security' ),
						$host
					),
					array( 'url' => $this->safe_url( $url ) )
				);

				return new WP_Error(
					'nyms_domain_not_allowed',
					sprintf(
						/* translators: %s: host name. */
						__( 'Outgoing requests to %s are not allowed. Add the host to the allowlist on the Security screen.', 'newyorkmechanics-security' ),
						$host
					)
				);
			}
		}

		if ( NYMS_DNS_REPUTATION && $this->has_bad_reputation( $host ) ) {
			NYMS_Log::record(
				'outbound_reputation',
				NYMS_Log::CRITICAL,
				sprintf(
					/* translators: %s: host name. */
					__( '%s is listed on a public abuse blocklist and the request was refused.', 'newyorkmechanics-security' ),
					$host
				),
				array( 'url' => $this->safe_url( $url ) )
			);

			return new WP_Error( 'nyms_bad_reputation', __( 'That address is listed on an abuse blocklist.', 'newyorkmechanics-security' ) );
		}

		return $pre;
	}

	/**
	 * Match a host against a list, allowing subdomains.
	 *
	 * @param string $host Host name.
	 * @param array  $list Entries.
	 * @return bool
	 */
	public function host_in( $host, $list ) {
		foreach ( (array) $list as $entry ) {
			$entry = strtolower( trim( $entry ) );

			if ( '' === $entry ) {
				continue;
			}

			if ( $host === $entry ) {
				return true;
			}

			if ( strlen( $host ) > strlen( $entry ) && substr( $host, - ( strlen( $entry ) + 1 ) ) === '.' . $entry ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Note a host, and say something the first time one appears.
	 *
	 * @param string $host Host name.
	 * @param string $url  Full URL.
	 * @return void
	 */
	private function remember_host( $host, $url ) {
		$seen = get_option( self::SEEN, array() );

		if ( ! is_array( $seen ) ) {
			$seen = array();
		}

		if ( isset( $seen[ $host ] ) ) {
			$seen[ $host ]['count']++;
			$seen[ $host ]['last'] = time();

			// Writing on every request would be wasteful; every tenth is enough.
			if ( 0 === $seen[ $host ]['count'] % 10 ) {
				update_option( self::SEEN, $seen, false );
			}

			return;
		}

		$seen[ $host ] = array(
			'first' => time(),
			'last'  => time(),
			'count' => 1,
			'url'   => $this->safe_url( $url ),
		);

		if ( count( $seen ) > 400 ) {
			$seen = array_slice( $seen, -400, null, true );
		}

		update_option( self::SEEN, $seen, false );

		$expected = array_merge( self::core_hosts(), NYMS_Firewall::list_option( self::ALLOWED ) );

		if ( ! $this->host_in( $host, $expected ) ) {
			NYMS_Log::record(
				'outbound_new_host',
				NYMS_Log::NOTICE,
				sprintf(
					/* translators: %s: host name. */
					__( 'This site contacted %s for the first time.', 'newyorkmechanics-security' ),
					$host
				),
				array( 'url' => $this->safe_url( $url ) )
			);
		}
	}

	/**
	 * Look a host up in the public DNS blocklists.
	 *
	 * Spamhaus DBL for names and ZEN for addresses. Results are cached for a
	 * day: these are free services and hammering them gets a site banned.
	 *
	 * @param string $host Host name.
	 * @return bool
	 */
	public function has_bad_reputation( $host ) {
		if ( ! function_exists( 'checkdnsrr' ) ) {
			return false;
		}

		$key    = 'nyms_rep_' . substr( md5( $host ), 0, 16 );
		$cached = get_transient( $key );

		if ( false !== $cached ) {
			return (bool) $cached;
		}

		$listed = false;

		// A name that is not an address goes to the domain blocklist.
		if ( ! filter_var( $host, FILTER_VALIDATE_IP ) ) {
			$listed = @checkdnsrr( $host . '.dbl.spamhaus.org', 'A' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors

			$ip = @gethostbyname( $host ); // phpcs:ignore WordPress.PHP.NoSilencedErrors

			if ( $ip && $ip !== $host ) {
				$host = $ip;
			}
		}

		if ( ! $listed && filter_var( $host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
			$reversed = implode( '.', array_reverse( explode( '.', $host ) ) );
			$listed   = @checkdnsrr( $reversed . '.zen.spamhaus.org', 'A' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}

		set_transient( $key, $listed ? 1 : 0, DAY_IN_SECONDS );

		return (bool) $listed;
	}

	/**
	 * Check the address a visitor is arriving from.
	 *
	 * @param string $ip Address.
	 * @return bool
	 */
	public function ip_has_bad_reputation( $ip ) {
		if ( ! NYMS_DNS_REPUTATION || ! filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
			return false;
		}

		return $this->has_bad_reputation( $ip );
	}

	/**
	 * Everything this site has contacted.
	 *
	 * @return array
	 */
	public static function seen() {
		$seen = get_option( self::SEEN, array() );

		return is_array( $seen ) ? $seen : array();
	}

	/**
	 * Forget hosts that have not been contacted in a long time.
	 *
	 * @return void
	 */
	public function prune_seen() {
		$seen   = self::seen();
		$cutoff = time() - ( 90 * DAY_IN_SECONDS );
		$keep   = array();

		foreach ( $seen as $host => $record ) {
			if ( isset( $record['last'] ) && $record['last'] > $cutoff ) {
				$keep[ $host ] = $record;
			}
		}

		if ( count( $keep ) !== count( $seen ) ) {
			update_option( self::SEEN, $keep, false );
		}
	}

	/**
	 * A URL with its query string removed, so credentials never reach the log.
	 *
	 * @param string $url URL.
	 * @return string
	 */
	private function safe_url( $url ) {
		$parts = wp_parse_url( $url );

		if ( ! is_array( $parts ) || empty( $parts['host'] ) ) {
			return '';
		}

		$scheme = isset( $parts['scheme'] ) ? $parts['scheme'] : 'https';
		$path   = isset( $parts['path'] ) ? $parts['path'] : '';

		return $scheme . '://' . $parts['host'] . substr( $path, 0, 120 );
	}
}

<?php
/**
 * Upload guard.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Rejects uploads that could become executable code.
 *
 * The server rules already refuse to run PHP from wp-content/uploads. This is
 * the second layer, and it works in three passes: the name, the declared type,
 * and the bytes themselves. A file has to survive all three.
 */
class NYMS_Upload_Guard {

	/**
	 * Extensions that must never be stored, in any position of the name.
	 *
	 * @var array
	 */
	private $blocked_extensions = array(
		'php', 'php2', 'php3', 'php4', 'php5', 'php6', 'php7', 'php8',
		'phps', 'phtml', 'phtm', 'pht', 'phar', 'inc', 'module',
		'shtml', 'shtm', 'stm',
		'cgi', 'pl', 'py', 'rb', 'sh', 'bash', 'ksh',
		'asp', 'aspx', 'ashx', 'asmx', 'ascx', 'cer', 'jsp', 'jspx', 'cfm',
		'exe', 'dll', 'so', 'com', 'bat', 'cmd', 'msi', 'scr', 'jar', 'vbs', 'ps1',
		'htaccess', 'htpasswd', 'user', 'ini', 'env', 'conf', 'sql', 'hta', 'pif',
	);

	/**
	 * Names that are dangerous regardless of extension.
	 *
	 * @var array
	 */
	private $blocked_names = array( '.htaccess', '.htpasswd', '.user.ini', 'php.ini', 'web.config', '.env', 'wp-config.php' );

	/**
	 * The first bytes each format must start with.
	 *
	 * @var array
	 */
	private $magic = array(
		'jpg'  => array( "\xFF\xD8\xFF" ),
		'jpeg' => array( "\xFF\xD8\xFF" ),
		'png'  => array( "\x89PNG\x0d\x0a\x1a\x0a" ),
		'gif'  => array( 'GIF87a', 'GIF89a' ),
		'bmp'  => array( 'BM' ),
		'webp' => array( 'RIFF' ),
		'pdf'  => array( '%PDF-' ),
		'zip'  => array( "PK\x03\x04", "PK\x05\x06", "PK\x07\x08" ),
		'gz'   => array( "\x1f\x8b" ),
		'mp3'  => array( 'ID3', "\xFF\xFB", "\xFF\xF3", "\xFF\xF2" ),
		'mp4'  => array( 'ftyp' ),
		'ico'  => array( "\x00\x00\x01\x00" ),
		'rar'  => array( 'Rar!' ),
		'7z'   => array( "7z\xBC\xAF\x27\x1C" ),
		'ttf'  => array( "\x00\x01\x00\x00", 'true' ),
		'woff' => array( 'wOFF' ),
		'woff2' => array( 'wOF2' ),
	);

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! NYMS_UPLOAD_GUARD ) {
			return;
		}

		add_filter( 'upload_mimes', array( $this, 'filter_mimes' ), 99 );
		add_filter( 'wp_handle_upload_prefilter', array( $this, 'inspect_upload' ), 10 );
		add_filter( 'wp_handle_sideload_prefilter', array( $this, 'inspect_upload' ), 10 );
		add_filter( 'sanitize_file_name', array( $this, 'sanitize_name' ), 99 );

		// Force WordPress to verify that the bytes match the extension.
		add_filter( 'wp_check_filetype_and_ext', array( $this, 'verify_real_type' ), 99, 4 );

		// Anything that reaches the uploads folder by another route.
		add_action( 'add_attachment', array( $this, 'inspect_attachment' ) );
	}

	/**
	 * Remove executable and ambiguous types from the allow list.
	 *
	 * @param array $mimes Allowed mime types keyed by extension pattern.
	 * @return array
	 */
	public function filter_mimes( $mimes ) {
		if ( ! is_array( $mimes ) ) {
			return $mimes;
		}

		foreach ( array_keys( $mimes ) as $pattern ) {
			foreach ( explode( '|', (string) $pattern ) as $ext ) {
				if ( in_array( strtolower( $ext ), $this->blocked_extensions, true ) ) {
					unset( $mimes[ $pattern ] );
					break;
				}
			}
		}

		/**
		 * SVG is XML: it can carry <script> and event handlers. It stays off
		 * unless the site explicitly opts back in, and even then every file is
		 * sanitised on the way in.
		 *
		 * @param bool $allow Whether SVG uploads are permitted.
		 */
		if ( ! apply_filters( 'nyms_allow_svg_uploads', NYMS_ALLOW_SVG_UPLOADS ) ) {
			unset( $mimes['svg'], $mimes['svgz'] );
		}

		if ( ! NYMS_ALLOW_HTML_UPLOADS ) {
			unset( $mimes['htm|html'], $mimes['html'], $mimes['htm'], $mimes['xhtml'] );
		}

		if ( ! NYMS_ALLOW_JS_UPLOADS ) {
			unset( $mimes['js'], $mimes['mjs'] );
		}

		if ( ! NYMS_ALLOW_ARCHIVE_UPLOADS ) {
			foreach ( array( 'zip', 'rar', '7z', 'tar', 'gz', 'gzip', 'bz2' ) as $ext ) {
				unset( $mimes[ $ext ] );
			}
		}

		return $mimes;
	}

	/**
	 * Inspect a file before WordPress moves it into the uploads folder.
	 *
	 * @param array $file Entry from $_FILES.
	 * @return array
	 */
	public function inspect_upload( $file ) {
		if ( empty( $file['name'] ) || ! empty( $file['error'] ) ) {
			return $file;
		}

		$name = (string) $file['name'];

		// A null byte truncates the name for the filesystem but not for PHP.
		if ( false !== strpos( $name, "\0" ) ) {
			return $this->reject( $file, __( 'This file was rejected for security reasons.', 'newyorkmechanics-security' ), 'null_byte' );
		}

		// Unicode that reorders the visible name: photo‮gnp.php shows as
		// photo.php.png in every file listing.
		$normalised = $this->normalise( $name );

		if ( $normalised !== $name ) {
			$file['name'] = $normalised;
			$name         = $normalised;
		}

		if ( in_array( strtolower( basename( $name ) ), $this->blocked_names, true ) ) {
			return $this->reject( $file, __( 'This file name is not allowed.', 'newyorkmechanics-security' ), 'reserved_name' );
		}

		$suspicious = NYMS_Helpers::suspicious_name( $name );

		if ( $suspicious ) {
			return $this->reject(
				$file,
				sprintf(
					/* translators: %s: reason. */
					__( 'This file was rejected because %s.', 'newyorkmechanics-security' ),
					$suspicious
				),
				'suspicious_name'
			);
		}

		// Check every segment: shell.php.jpg and shell.jpg.php both die here.
		$segments = explode( '.', strtolower( $name ) );
		array_shift( $segments );

		foreach ( $segments as $segment ) {
			$segment = preg_replace( '/[^a-z0-9]/', '', $segment );

			if ( '' !== $segment && in_array( $segment, $this->blocked_extensions, true ) ) {
				return $this->reject( $file, __( 'Executable file types cannot be uploaded.', 'newyorkmechanics-security' ), 'executable_extension' );
			}
		}

		$extension = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
		$size      = isset( $file['size'] ) ? (int) $file['size'] : 0;

		if ( NYMS_MAX_UPLOAD_MB > 0 && $size > ( (int) NYMS_MAX_UPLOAD_MB * 1048576 ) ) {
			return $this->reject(
				$file,
				sprintf(
					/* translators: %d: size in megabytes. */
					__( 'Files larger than %d MB are not accepted.', 'newyorkmechanics-security' ),
					(int) NYMS_MAX_UPLOAD_MB
				),
				'oversized'
			);
		}

		if ( empty( $file['tmp_name'] ) || ! is_readable( $file['tmp_name'] ) ) {
			return $file;
		}

		// The declared type must agree with the extension and with the bytes.
		$declared = isset( $file['type'] ) ? strtolower( (string) $file['type'] ) : '';
		$mismatch = $this->type_mismatch( $file['tmp_name'], $extension, $declared );

		if ( $mismatch ) {
			return $this->reject( $file, $mismatch, 'type_mismatch' );
		}

		if ( 'archive' === NYMS_Helpers::file_kind( $name ) && NYMS_SCAN_ARCHIVES ) {
			$report = NYMS_Archive::inspect( $file['tmp_name'] );

			if ( ! $report['ok'] ) {
				return $this->reject(
					$file,
					sprintf(
						/* translators: %s: list of problems. */
						__( 'This archive was rejected: %s', 'newyorkmechanics-security' ),
						implode( '; ', array_slice( $report['errors'], 0, 3 ) )
					),
					'archive_rejected'
				);
			}
		}

		if ( in_array( $extension, array( 'svg', 'svgz' ), true ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_get_contents
			$markup = (string) @file_get_contents( $file['tmp_name'] );

			if ( "\x1f\x8b" === substr( $markup, 0, 2 ) && function_exists( 'gzdecode' ) ) {
				$markup = (string) @gzdecode( $markup );
			}

			$active = NYMS_Svg::has_active_content( $markup );

			if ( $active && ! NYMS_SANITIZE_SVG ) {
				return $this->reject( $file, __( 'This SVG contains active content and was rejected.', 'newyorkmechanics-security' ), 'svg_active' );
			}

			if ( NYMS_SANITIZE_SVG && ! NYMS_Svg::sanitize_file( $file['tmp_name'] ) ) {
				return $this->reject( $file, __( 'This SVG could not be cleaned and was rejected.', 'newyorkmechanics-security' ), 'svg_unsafe' );
			}
		}

		if ( $this->contains_code( $file['tmp_name'], $name ) ) {
			return $this->reject( $file, __( 'This file contains executable code and was rejected.', 'newyorkmechanics-security' ), 'executable_content' );
		}

		return $file;
	}

	/**
	 * Compare extension, declared type and the actual first bytes.
	 *
	 * @param string $path      Temporary path.
	 * @param string $extension Lower-case extension.
	 * @param string $declared  The type the browser claimed.
	 * @return string|false Message, or false when everything agrees.
	 */
	public function type_mismatch( $path, $extension, $declared ) {
		$handle = @fopen( $path, 'rb' );

		if ( ! $handle ) {
			return false;
		}

		$head = (string) fread( $handle, 32 );

		fclose( $handle );

		if ( isset( $this->magic[ $extension ] ) ) {
			$matched = false;

			foreach ( $this->magic[ $extension ] as $signature ) {
				// The mp4 marker sits at offset four, not at the start.
				if ( 'ftyp' === $signature ) {
					if ( 'ftyp' === substr( $head, 4, 4 ) ) {
						$matched = true;
						break;
					}

					continue;
				}

				if ( 0 === strncmp( $head, $signature, strlen( $signature ) ) ) {
					$matched = true;
					break;
				}
			}

			if ( ! $matched ) {
				return __( 'The contents of this file do not match its extension.', 'newyorkmechanics-security' );
			}
		}

		// What the server thinks it is, read from the bytes.
		$detected = $this->detect_type( $path );

		if ( $detected && $declared && $this->families_differ( $detected, $declared ) ) {
			return sprintf(
				/* translators: 1: declared type, 2: detected type. */
				__( 'This file claims to be %1$s but its contents are %2$s.', 'newyorkmechanics-security' ),
				$declared,
				$detected
			);
		}

		// PHP hidden behind an image extension: the classic upload bypass.
		if ( in_array( $extension, array( 'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'ico', 'avif' ), true ) ) {
			if ( function_exists( 'getimagesize' ) && false === @getimagesize( $path ) ) {
				return __( 'This file has an image extension but is not an image.', 'newyorkmechanics-security' );
			}
		}

		return false;
	}

	/**
	 * Read the type of a file from its contents.
	 *
	 * @param string $path Path.
	 * @return string Empty string when it cannot be determined.
	 */
	public function detect_type( $path ) {
		if ( function_exists( 'finfo_open' ) ) {
			$finfo = @finfo_open( FILEINFO_MIME_TYPE );

			if ( $finfo ) {
				$type = @finfo_file( $finfo, $path );

				finfo_close( $finfo );

				if ( $type ) {
					return strtolower( $type );
				}
			}
		}

		if ( function_exists( 'mime_content_type' ) ) {
			$type = @mime_content_type( $path );

			if ( $type ) {
				return strtolower( $type );
			}
		}

		return '';
	}

	/**
	 * Whether two mime types are meaningfully different.
	 *
	 * Only the top-level family is compared: browsers disagree constantly
	 * about the exact subtype and blocking on that would reject real files.
	 *
	 * @param string $detected Detected type.
	 * @param string $declared Declared type.
	 * @return bool
	 */
	private function families_differ( $detected, $declared ) {
		$forgiving = array( 'application/octet-stream', 'text/plain', 'application/x-empty', 'inode/x-empty' );

		if ( in_array( $detected, $forgiving, true ) || in_array( $declared, $forgiving, true ) ) {
			return false;
		}

		$a = strtok( $detected, '/' );
		$b = strtok( $declared, '/' );

		if ( $a === $b ) {
			return false;
		}

		// text/xml against image/svg+xml, application/zip against a document.
		$pairs = array(
			'text|image'        => true,
			'application|text'  => true,
			'application|video' => true,
			'application|audio' => true,
			'text|application'  => true,
		);

		return ! isset( $pairs[ $a . '|' . $b ] );
	}

	/**
	 * Look for script markers inside the uploaded bytes.
	 *
	 * Reads a bounded window from the head and the tail so a large media file
	 * does not blow up memory.
	 *
	 * @param string $path Temporary file path.
	 * @param string $name Reported name.
	 * @return bool
	 */
	private function contains_code( $path, $name = '' ) {
		$size = @filesize( $path );

		if ( ! $size ) {
			return false;
		}

		$handle = @fopen( $path, 'rb' );

		if ( ! $handle ) {
			return false;
		}

		$limit  = 512000;
		$chunks = array( (string) fread( $handle, $limit ) );

		if ( $size > $limit && 0 === fseek( $handle, -$limit, SEEK_END ) ) {
			$chunks[] = (string) fread( $handle, $limit );
		}

		fclose( $handle );

		$haystack = strtolower( implode( "\n", $chunks ) );

		$markers = array(
			'<?php',
			'<?=',
			'<script language="php"',
			"<script language='php'",
			'#!/usr/bin/php',
			'#!/usr/bin/env php',
		);

		foreach ( $markers as $marker ) {
			if ( false !== strpos( $haystack, $marker ) ) {
				return true;
			}
		}

		// Classic webshell wrappers, flagged only when the call is paired with
		// an obfuscation or superglobal source, to avoid binary false hits.
		$shell = '/(eval|assert|create_function|passthru|shell_exec|proc_open|popen)\s*\(\s*'
			. '(base64_decode|gzinflate|str_rot13|gzuncompress|\$_(get|post|request|cookie|server))/';

		if ( preg_match( $shell, $haystack ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Strip characters that confuse the filesystem or the web server.
	 *
	 * @param string $name Sanitised file name.
	 * @return string
	 */
	public function sanitize_name( $name ) {
		$name = $this->normalise( (string) $name );
		$name = str_replace( chr( 0 ), '', $name );
		$name = preg_replace( '/[^A-Za-z0-9._-]/', '-', $name );
		$name = preg_replace( '/\.{2,}/', '.', $name );
		$name = preg_replace( '/-{2,}/', '-', $name );
		$name = ltrim( $name, '.-' );

		if ( strlen( $name ) > 180 ) {
			$extension = pathinfo( $name, PATHINFO_EXTENSION );
			$name      = substr( pathinfo( $name, PATHINFO_FILENAME ), 0, 170 ) . ( $extension ? '.' . $extension : '' );
		}

		return '' === $name ? 'file' : $name;
	}

	/**
	 * Fold a name to a predictable form before anything is decided about it.
	 *
	 * @param string $name File name.
	 * @return string
	 */
	private function normalise( $name ) {
		// Direction overrides and zero-width characters exist in a file name
		// for one reason only.
		$name = preg_replace( '/[\x{200b}-\x{200f}\x{202a}-\x{202e}\x{2066}-\x{2069}\x{feff}]/u', '', $name );

		if ( class_exists( 'Normalizer' ) ) {
			$folded = Normalizer::normalize( $name, Normalizer::FORM_KC );

			if ( is_string( $folded ) ) {
				$name = $folded;
			}
		}

		return $name;
	}

	/**
	 * Reject files whose real type does not match their extension.
	 *
	 * @param array      $data     Type data: ext, type, proper_filename.
	 * @param string     $file     Full path to the file.
	 * @param string     $filename The name of the file.
	 * @param array|null $mimes    Allowed mime types.
	 * @return array
	 */
	public function verify_real_type( $data, $file, $filename, $mimes ) {
		unset( $mimes, $filename );

		if ( empty( $data['ext'] ) || empty( $data['type'] ) ) {
			return $data;
		}

		$rejected = array(
			'ext'             => false,
			'type'            => false,
			'proper_filename' => false,
		);

		if ( in_array( strtolower( $data['ext'] ), $this->blocked_extensions, true ) ) {
			return $rejected;
		}

		// Anything served as an image must actually decode as one.
		if ( 0 === strpos( $data['type'], 'image/' ) && ! NYMS_Helpers::has( $data['type'], 'svg' ) ) {
			if ( file_exists( $file ) && function_exists( 'getimagesize' ) && false === @getimagesize( $file ) ) {
				return $rejected;
			}
		}

		return $data;
	}

	/**
	 * Refuse an attachment whose file is executable, whatever created it.
	 *
	 * The prefilter covers the normal upload routes. This covers the rest:
	 * an importer, a REST call, or a plugin sideloading something of its own.
	 * The test is the extension, not the contents - what is inside a file is a
	 * malware scanner's question, and this plugin does not ask it.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @return void
	 */
	public function inspect_attachment( $attachment_id ) {
		$path = get_attached_file( $attachment_id );

		if ( ! $path || ! is_file( $path ) ) {
			return;
		}

		if ( ! NYMS_Helpers::is_executable_name( $path ) ) {
			return;
		}

		NYMS_Log::record(
			'upload_executable',
			NYMS_Log::CRITICAL,
			sprintf(
				/* translators: %s: file name. */
				__( 'An executable file reached the media library and was removed: %s', 'newyorkmechanics-security' ),
				basename( $path )
			),
			array( 'attachment' => (int) $attachment_id )
		);

		wp_delete_attachment( $attachment_id, true );
	}

	/**
	 * Refuse a file and write it down.
	 *
	 * @param array  $file   File array.
	 * @param string $reason Message shown to the person uploading.
	 * @param string $rule   Rule identifier for the log.
	 * @return array
	 */
	private function reject( $file, $reason, $rule ) {
		$file['error'] = $reason;

		NYMS_Log::record(
			'upload_rejected',
			NYMS_Log::WARNING,
			sprintf(
				/* translators: 1: file name, 2: reason. */
				__( 'Upload refused: %1$s (%2$s)', 'newyorkmechanics-security' ),
				isset( $file['name'] ) ? $file['name'] : '?',
				$reason
			),
			array( 'rule' => $rule, 'user' => get_current_user_id() )
		);

		return $file;
	}
}

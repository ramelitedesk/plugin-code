<?php
/**
 * Upload guard.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Rejects uploads that could become executable code.
 *
 * The server rules already refuse to run PHP from wp-content/uploads. This is
 * the second layer: the file never reaches disk in the first place.
 */
class NYMS_Upload_Guard {

	/**
	 * Extensions that must never be stored, in any position of the name.
	 *
	 * @var array
	 */
	private $blocked_extensions = array(
		'php', 'php2', 'php3', 'php4', 'php5', 'php6', 'php7', 'php8',
		'phps', 'phtml', 'phtm', 'pht', 'phar', 'inc', 'module',
		'shtml', 'shtm', 'stm',
		'cgi', 'pl', 'py', 'rb', 'sh', 'bash', 'ksh',
		'asp', 'aspx', 'ashx', 'asmx', 'ascx', 'cer', 'jsp', 'jspx', 'cfm',
		'exe', 'dll', 'so', 'com', 'bat', 'cmd', 'msi', 'scr', 'jar', 'vbs', 'ps1',
		'htaccess', 'htpasswd', 'user', 'ini', 'env', 'conf', 'sql',
	);

	/**
	 * Names that are dangerous regardless of extension.
	 *
	 * @var array
	 */
	private $blocked_names = array( '.htaccess', '.htpasswd', '.user.ini', 'php.ini', 'web.config', '.env' );

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! NYMS_UPLOAD_GUARD ) {
			return;
		}

		add_filter( 'upload_mimes', array( $this, 'filter_mimes' ), 99 );
		add_filter( 'wp_handle_upload_prefilter', array( $this, 'inspect_upload' ), 1 );
		add_filter( 'wp_handle_sideload_prefilter', array( $this, 'inspect_upload' ), 1 );
		add_filter( 'sanitize_file_name', array( $this, 'sanitize_name' ), 99 );

		// Force WordPress to verify that the bytes match the extension.
		add_filter( 'wp_check_filetype_and_ext', array( $this, 'verify_real_type' ), 99, 4 );
	}

	/**
	 * Remove executable and ambiguous types from the allow list.
	 *
	 * @param array $mimes Allowed mime types keyed by extension pattern.
	 * @return array
	 */
	public function filter_mimes( $mimes ) {
		if ( ! is_array( $mimes ) ) {
			return $mimes;
		}

		foreach ( array_keys( $mimes ) as $pattern ) {
			foreach ( explode( '|', (string) $pattern ) as $ext ) {
				if ( in_array( strtolower( $ext ), $this->blocked_extensions, true ) ) {
					unset( $mimes[ $pattern ] );
					break;
				}
			}
		}

		/**
		 * SVG is XML: it can carry <script> and event handlers. It stays off
		 * unless the site explicitly opts back in.
		 *
		 * @param bool $allow Whether SVG uploads are permitted.
		 */
		if ( ! apply_filters( 'nyms_allow_svg_uploads', NYMS_ALLOW_SVG_UPLOADS ) ) {
			unset( $mimes['svg'], $mimes['svgz'] );
		}

		return $mimes;
	}

	/**
	 * Inspect a file before WordPress moves it into the uploads folder.
	 *
	 * @param array $file Entry from $_FILES.
	 * @return array
	 */
	public function inspect_upload( $file ) {
		if ( empty( $file['name'] ) || ! empty( $file['error'] ) ) {
			return $file;
		}

		$name = (string) $file['name'];

		// A null byte truncates the name for the filesystem but not for PHP.
		if ( false !== strpos( $name, "\0" ) ) {
			$file['error'] = __( 'This file was rejected for security reasons.', 'newyorkmechanics-security' );

			return $file;
		}

		if ( in_array( strtolower( basename( $name ) ), $this->blocked_names, true ) ) {
			$file['error'] = __( 'This file name is not allowed.', 'newyorkmechanics-security' );

			return $file;
		}

		// Check every segment: shell.php.jpg and shell.jpg.php both die here.
		$segments = explode( '.', strtolower( $name ) );
		array_shift( $segments );

		foreach ( $segments as $segment ) {
			$segment = preg_replace( '/[^a-z0-9]/', '', $segment );

			if ( '' !== $segment && in_array( $segment, $this->blocked_extensions, true ) ) {
				$file['error'] = __( 'Executable file types cannot be uploaded.', 'newyorkmechanics-security' );

				return $file;
			}
		}

		if ( ! empty( $file['tmp_name'] ) && is_readable( $file['tmp_name'] ) && $this->contains_code( $file['tmp_name'] ) ) {
			$file['error'] = __( 'This file contains executable code and was rejected.', 'newyorkmechanics-security' );
		}

		return $file;
	}

	/**
	 * Look for script markers inside the uploaded bytes.
	 *
	 * Reads a bounded window from the head and the tail so a large media file
	 * does not blow up memory.
	 *
	 * @param string $path Temporary file path.
	 * @return bool
	 */
	private function contains_code( $path ) {
		$size = @filesize( $path );

		if ( ! $size ) {
			return false;
		}

		$handle = @fopen( $path, 'rb' );

		if ( ! $handle ) {
			return false;
		}

		$limit  = 512000;
		$chunks = array( (string) fread( $handle, $limit ) );

		if ( $size > $limit && 0 === fseek( $handle, -$limit, SEEK_END ) ) {
			$chunks[] = (string) fread( $handle, $limit );
		}

		fclose( $handle );

		$haystack = strtolower( implode( "\n", $chunks ) );

		$markers = array(
			'<?php',
			'<?=',
			'<script language="php"',
			"<script language='php'",
			'#!/usr/bin/php',
			'#!/usr/bin/env php',
		);

		foreach ( $markers as $marker ) {
			if ( false !== strpos( $haystack, $marker ) ) {
				return true;
			}
		}

		// Classic webshell wrappers, flagged only when the call is paired with
		// an obfuscation or superglobal source, to avoid binary false hits.
		$shell = '/(eval|assert|create_function|passthru|shell_exec|proc_open|popen)\s*\(\s*'
			. '(base64_decode|gzinflate|str_rot13|gzuncompress|\$_(get|post|request|cookie|server))/';

		return (bool) preg_match( $shell, $haystack );
	}

	/**
	 * Strip characters that confuse the filesystem or the web server.
	 *
	 * @param string $name Sanitised file name.
	 * @return string
	 */
	public function sanitize_name( $name ) {
		$name = str_replace( chr( 0 ), '', (string) $name );
		$name = preg_replace( '/[^A-Za-z0-9._-]/', '-', $name );
		$name = preg_replace( '/\.{2,}/', '.', $name );
		$name = ltrim( $name, '.' );

		return '' === $name ? 'file' : $name;
	}

	/**
	 * Reject files whose real type does not match their extension.
	 *
	 * @param array      $data     Type data: ext, type, proper_filename.
	 * @param string     $file     Full path to the file.
	 * @param string     $filename The name of the file.
	 * @param array|null $mimes    Allowed mime types.
	 * @return array
	 */
	public function verify_real_type( $data, $file, $filename, $mimes ) {
		unset( $mimes, $filename );

		if ( empty( $data['ext'] ) || empty( $data['type'] ) ) {
			return $data;
		}

		$rejected = array(
			'ext'             => false,
			'type'            => false,
			'proper_filename' => false,
		);

		if ( in_array( strtolower( $data['ext'] ), $this->blocked_extensions, true ) ) {
			return $rejected;
		}

		// Anything served as an image must actually decode as one.
		if ( 0 === strpos( $data['type'], 'image/' ) && ! NYMS_Helpers::has( $data['type'], 'svg' ) ) {
			if ( file_exists( $file ) && function_exists( 'getimagesize' ) && false === @getimagesize( $file ) ) {
				return $rejected;
			}
		}

		return $data;
	}
}

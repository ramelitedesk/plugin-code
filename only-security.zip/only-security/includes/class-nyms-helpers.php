<?php
/**
 * Shared helpers.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Small utilities used across modules. Written for PHP 5.6+ compatibility.
 */
class NYMS_Helpers {

	/**
	 * Resolve the client IP address.
	 *
	 * Proxy headers are spoofable, so they are only honoured when the site
	 * owner opts in with NYMS_TRUST_PROXY.
	 *
	 * @return string
	 */
	public static function client_ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? wp_unslash( $_SERVER['REMOTE_ADDR'] ) : '';

		if ( NYMS_TRUST_PROXY ) {
			$headers = array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP' );

			foreach ( $headers as $header ) {
				if ( empty( $_SERVER[ $header ] ) ) {
					continue;
				}

				$parts     = explode( ',', wp_unslash( $_SERVER[ $header ] ) );
				$candidate = trim( $parts[0] );

				if ( filter_var( $candidate, FILTER_VALIDATE_IP ) ) {
					$ip = $candidate;
					break;
				}
			}
		}

		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '0.0.0.0';
	}

	/**
	 * Stable, non-reversible key for an IP address.
	 *
	 * @param string $ip IP address.
	 * @return string
	 */
	public static function ip_key( $ip ) {
		return substr( md5( $ip . '|' . self::salt() ), 0, 20 );
	}

	/**
	 * A salt that exists on every WordPress version.
	 *
	 * @return string
	 */
	private static function salt() {
		if ( defined( 'AUTH_SALT' ) && AUTH_SALT ) {
			return AUTH_SALT;
		}

		if ( defined( 'AUTH_KEY' ) && AUTH_KEY ) {
			return AUTH_KEY;
		}

		return ABSPATH;
	}

	/**
	 * Walk a value (string or nested array) and hand every scalar to a callback.
	 *
	 * @param mixed    $value    Value to walk.
	 * @param callable $callback Receives a string, returns bool. true stops the walk.
	 * @param int      $depth    Internal recursion guard.
	 * @return bool True when the callback matched.
	 */
	public static function walk( $value, $callback, $depth = 0 ) {
		if ( $depth > 8 ) {
			return false;
		}

		if ( is_array( $value ) ) {
			foreach ( $value as $key => $item ) {
				if ( is_string( $key ) && call_user_func( $callback, $key ) ) {
					return true;
				}

				if ( self::walk( $item, $callback, $depth + 1 ) ) {
					return true;
				}
			}

			return false;
		}

		if ( is_scalar( $value ) ) {
			return (bool) call_user_func( $callback, (string) $value );
		}

		return false;
	}

	/**
	 * Case-insensitive substring test (str_contains is PHP 8 only).
	 *
	 * @param string $haystack Haystack.
	 * @param string $needle   Needle.
	 * @return bool
	 */
	public static function has( $haystack, $needle ) {
		return '' !== $needle && false !== stripos( $haystack, $needle );
	}

	/**
	 * Terminate the request with a neutral 403.
	 *
	 * The message is deliberately generic: it must not tell an attacker
	 * which rule fired.
	 *
	 * @return void
	 */
	public static function forbid() {
		if ( ! headers_sent() ) {
			status_header( 403 );
			nocache_headers();
			header( 'Content-Type: text/plain; charset=utf-8' );
		}

		echo 'Forbidden';
		exit;
	}

	/**
	 * Whether the current user is trusted enough to bypass content filters.
	 *
	 * @return bool
	 */
	public static function is_trusted_user() {
		return function_exists( 'is_user_logged_in' )
			&& is_user_logged_in()
			&& current_user_can( 'edit_posts' );
	}

	/**
	 * The plugin's display name, built from the site name.
	 *
	 * WordPress reads "Plugin Name:" straight out of the file header, so the
	 * header cannot itself be dynamic. This is what the plugin list, the menu
	 * and the settings screen actually show.
	 *
	 * @return string
	 */
	public static function plugin_name() {
		$site = get_bloginfo( 'name', 'display' );
		$site = wp_specialchars_decode( (string) $site, ENT_QUOTES );
		$site = trim( preg_replace( '/\s+/', ' ', $site ) );

		if ( '' === $site ) {
			return __( 'Site Security', 'newyorkmechanics-security' );
		}

		// A site already called "... Security" must not become "... Security Security".
		if ( preg_match( '/\bsecurity$/i', $site ) ) {
			return $site;
		}

		return sprintf(
			/* translators: %s: the site name. */
			__( '%s Security', 'newyorkmechanics-security' ),
			$site
		);
	}

	/**
	 * The folder name this plugin would have if it matched the site name.
	 *
	 * Shown on the settings screen; renaming the folder is a manual step,
	 * because a plugin that renamed its own directory would deactivate itself
	 * mid-request.
	 *
	 * @return string
	 */
	public static function plugin_slug() {
		$slug = sanitize_title( self::plugin_name() );

		return '' === $slug ? 'site-security' : $slug;
	}

	/**
	 * Read the raw request path without the query string.
	 *
	 * @return string
	 */
	public static function request_path() {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$uri = (string) $uri;
		$pos = strpos( $uri, '?' );

		return false === $pos ? $uri : substr( $uri, 0, $pos );
	}
}

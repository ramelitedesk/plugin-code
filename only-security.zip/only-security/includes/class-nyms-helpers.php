<?php
/**
 * Shared helpers.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Small utilities used across modules. Written for PHP 5.6+ compatibility.
 */
class NYMS_Helpers {

	/**
	 * Resolve the client IP address.
	 *
	 * Proxy headers are spoofable, so they are only honoured when the site
	 * owner opts in with NYMS_TRUST_PROXY.
	 *
	 * @return string
	 */
	public static function client_ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? wp_unslash( $_SERVER['REMOTE_ADDR'] ) : '';

		if ( NYMS_TRUST_PROXY ) {
			$headers = array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP' );

			foreach ( $headers as $header ) {
				if ( empty( $_SERVER[ $header ] ) ) {
					continue;
				}

				$parts     = explode( ',', wp_unslash( $_SERVER[ $header ] ) );
				$candidate = trim( $parts[0] );

				if ( filter_var( $candidate, FILTER_VALIDATE_IP ) ) {
					$ip = $candidate;
					break;
				}
			}
		}

		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '0.0.0.0';
	}

	/**
	 * Stable, non-reversible key for an IP address.
	 *
	 * @param string $ip IP address.
	 * @return string
	 */
	public static function ip_key( $ip ) {
		return substr( md5( $ip . '|' . self::salt() ), 0, 20 );
	}

	/**
	 * A salt that exists on every WordPress version.
	 *
	 * @return string
	 */
	private static function salt() {
		if ( defined( 'AUTH_SALT' ) && AUTH_SALT ) {
			return AUTH_SALT;
		}

		if ( defined( 'AUTH_KEY' ) && AUTH_KEY ) {
			return AUTH_KEY;
		}

		return ABSPATH;
	}

	/**
	 * Walk a value (string or nested array) and hand every scalar to a callback.
	 *
	 * @param mixed    $value    Value to walk.
	 * @param callable $callback Receives a string, returns bool. true stops the walk.
	 * @param int      $depth    Internal recursion guard.
	 * @return bool True when the callback matched.
	 */
	public static function walk( $value, $callback, $depth = 0 ) {
		if ( $depth > 8 ) {
			return false;
		}

		if ( is_array( $value ) ) {
			foreach ( $value as $key => $item ) {
				if ( is_string( $key ) && call_user_func( $callback, $key ) ) {
					return true;
				}

				if ( self::walk( $item, $callback, $depth + 1 ) ) {
					return true;
				}
			}

			return false;
		}

		if ( is_scalar( $value ) ) {
			return (bool) call_user_func( $callback, (string) $value );
		}

		return false;
	}

	/**
	 * Case-insensitive substring test (str_contains is PHP 8 only).
	 *
	 * @param string $haystack Haystack.
	 * @param string $needle   Needle.
	 * @return bool
	 */
	public static function has( $haystack, $needle ) {
		return '' !== $needle && false !== stripos( $haystack, $needle );
	}

	/**
	 * Terminate the request with a neutral 403.
	 *
	 * The message is deliberately generic: it must not tell an attacker
	 * which rule fired.
	 *
	 * @return void
	 */
	public static function forbid() {
		if ( ! headers_sent() ) {
			status_header( 403 );
			nocache_headers();
			header( 'Content-Type: text/plain; charset=utf-8' );
		}

		echo 'Forbidden';
		exit;
	}

	/**
	 * Whether the current user is trusted enough to bypass content filters.
	 *
	 * @return bool
	 */
	public static function is_trusted_user() {
		return function_exists( 'is_user_logged_in' )
			&& is_user_logged_in()
			&& current_user_can( 'edit_posts' );
	}

	/**
	 * The plugin's display name, built from the site name.
	 *
	 * WordPress reads "Plugin Name:" straight out of the file header, so the
	 * header cannot itself be dynamic. This is what the plugin list, the menu
	 * and the settings screen actually show.
	 *
	 * @return string
	 */
	public static function plugin_name() {
		$site = get_bloginfo( 'name', 'display' );
		$site = wp_specialchars_decode( (string) $site, ENT_QUOTES );
		$site = trim( preg_replace( '/\s+/', ' ', $site ) );

		if ( '' === $site ) {
			return __( 'Site Security', 'newyorkmechanics-security' );
		}

		// A site already called "... Security" must not become "... Security Security".
		if ( preg_match( '/\bsecurity$/i', $site ) ) {
			return $site;
		}

		return sprintf(
			/* translators: %s: the site name. */
			__( '%s Security', 'newyorkmechanics-security' ),
			$site
		);
	}

	/**
	 * The folder name this plugin would have if it matched the site name.
	 *
	 * Shown on the settings screen; renaming the folder is a manual step,
	 * because a plugin that renamed its own directory would deactivate itself
	 * mid-request.
	 *
	 * @return string
	 */
	public static function plugin_slug() {
		$slug = sanitize_title( self::plugin_name() );

		return '' === $slug ? 'site-security' : $slug;
	}

	/**
	 * Extensions that a web server may be persuaded to execute.
	 *
	 * This is a list of file types, not a malware signature list: the plugin
	 * refuses these on structure alone, without ever inspecting what is
	 * inside a file. Finding malicious code in a file that is already on the
	 * site is a scanner's job and is deliberately left to one.
	 *
	 * @var array
	 */
	private static $executable = array(
		'php', 'php2', 'php3', 'php4', 'php5', 'php6', 'php7', 'php8', 'phps',
		'phtml', 'phtm', 'pht', 'phar', 'shtml', 'shtm', 'stm', 'cgi', 'pl', 'py',
		'rb', 'sh', 'bash', 'ksh', 'asp', 'aspx', 'ashx', 'asmx', 'ascx', 'cer',
		'jsp', 'jspx', 'cfm', 'exe', 'dll', 'so', 'com', 'bat', 'cmd', 'msi',
		'scr', 'jar', 'vbs', 'ps1', 'hta', 'pif', 'apk', 'elf', 'bin',
	);

	/**
	 * The executable extension list.
	 *
	 * @return array
	 */
	public static function executable_extensions() {
		return self::$executable;
	}

	/**
	 * Whether a name ends in an executable extension.
	 *
	 * @param string $filename File name or path.
	 * @return bool
	 */
	public static function is_executable_name( $filename ) {
		$ext = strtolower( pathinfo( (string) $filename, PATHINFO_EXTENSION ) );

		return in_array( $ext, self::$executable, true );
	}

	/**
	 * Classify a file by its name.
	 *
	 * @param string $filename File name or path.
	 * @return string One of php, js, html, svg, image, archive, other.
	 */
	public static function file_kind( $filename ) {
		$ext = strtolower( pathinfo( (string) $filename, PATHINFO_EXTENSION ) );

		if ( in_array( $ext, array( 'php', 'php3', 'php4', 'php5', 'php7', 'php8', 'phtml', 'phar', 'inc', 'module' ), true ) ) {
			return 'php';
		}

		if ( in_array( $ext, array( 'js', 'mjs', 'cjs', 'jsx', 'ts' ), true ) ) {
			return 'js';
		}

		if ( in_array( $ext, array( 'html', 'htm', 'xhtml', 'shtml' ), true ) ) {
			return 'html';
		}

		if ( in_array( $ext, array( 'svg', 'svgz' ), true ) ) {
			return 'svg';
		}

		if ( in_array( $ext, array( 'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'ico', 'tif', 'tiff', 'avif', 'heic' ), true ) ) {
			return 'image';
		}

		if ( in_array( $ext, array( 'zip', 'tar', 'gz', 'tgz', 'rar', '7z', 'bz2', 'xz' ), true ) ) {
			return 'archive';
		}

		return 'other';
	}

	/**
	 * Whether a file name is shaped like an attempt to smuggle code in.
	 *
	 * Every test here is about the name itself - hidden executables, second
	 * extensions, invisible characters that reorder what a listing shows.
	 * Nothing is read from the file.
	 *
	 * @param string $filename File name.
	 * @return string|false Reason, or false when the name is fine.
	 */
	public static function suspicious_name( $filename ) {
		$base = strtolower( basename( (string) $filename ) );

		if ( '' === $base ) {
			return false;
		}

		if ( false !== strpos( $filename, "\0" ) ) {
			return __( 'the name contains a null byte', 'newyorkmechanics-security' );
		}

		// Hidden PHP: .config.php, .well-known/x.php.
		if ( '.' === substr( $base, 0, 1 ) && self::is_executable_name( $base ) ) {
			return __( 'it is a hidden executable file', 'newyorkmechanics-security' );
		}

		// Double extension: invoice.pdf.php, photo.php.jpg.
		$parts = explode( '.', $base );

		if ( count( $parts ) > 2 ) {
			array_shift( $parts );
			array_pop( $parts );

			foreach ( $parts as $middle ) {
				if ( in_array( $middle, self::$executable, true ) ) {
					return __( 'the name carries a second, executable extension', 'newyorkmechanics-security' );
				}
			}
		}

		// Characters that reorder the visible name so photo<RLO>gnp.php reads
		// as photo.png in every file listing.
		if ( preg_match( '/[\x{200b}-\x{200f}\x{202a}-\x{202e}\x{2066}-\x{2069}]/u', $filename ) ) {
			return __( 'the name contains invisible direction-changing characters', 'newyorkmechanics-security' );
		}

		return false;
	}

	/**
	 * Read the raw request path without the query string.
	 *
	 * @return string
	 */
	public static function request_path() {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$uri = (string) $uri;
		$pos = strpos( $uri, '?' );

		return false === $pos ? $uri : substr( $uri, 0, $pos );
	}
}

<?php
/**
 * Apache rule management.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Writes the server-level rules that stop an uploaded file from ever being
 * executed as PHP, and hides sensitive files from the web.
 *
 * Everything written here is fenced with markers so it can be removed cleanly.
 * On nginx these files are inert; see readme.txt for the equivalent config.
 */
class NYMS_Htaccess {

	const MARKER = 'New York Mechanics Security';

	/**
	 * Install every managed rule set.
	 *
	 * @return void
	 */
	public static function install() {
		if ( ! NYMS_MANAGE_HTACCESS || ! self::is_apache() ) {
			return;
		}

		self::write( self::root_file(), self::root_rules() );

		if ( NYMS_BLOCK_PHP_IN_UPLOADS ) {
			$uploads = wp_upload_dir();

			if ( empty( $uploads['error'] ) && ! empty( $uploads['basedir'] ) ) {
				self::write( trailingslashit( $uploads['basedir'] ) . '.htaccess', self::no_php_rules() );
			}
		}
	}

	/**
	 * Remove every managed rule set.
	 *
	 * @return void
	 */
	public static function uninstall() {
		self::write( self::root_file(), array() );

		$uploads = wp_upload_dir();

		if ( empty( $uploads['error'] ) && ! empty( $uploads['basedir'] ) ) {
			self::write( trailingslashit( $uploads['basedir'] ) . '.htaccess', array() );
		}
	}

	/**
	 * Report where the managed rules currently stand.
	 *
	 * @return array {
	 *     @type bool      $apache  Whether .htaccess is honoured at all.
	 *     @type bool|null $root    Block present in the site root, null if unknown.
	 *     @type bool|null $uploads Block present in the uploads folder.
	 * }
	 */
	public static function status() {
		$uploads = wp_upload_dir();
		$path    = ( empty( $uploads['error'] ) && ! empty( $uploads['basedir'] ) )
			? trailingslashit( $uploads['basedir'] ) . '.htaccess'
			: '';

		return array(
			'apache'  => self::is_apache(),
			'root'    => self::has_block( self::root_file() ),
			'uploads' => '' === $path ? null : self::has_block( $path ),
		);
	}

	/**
	 * Whether a file carries our marker block.
	 *
	 * @param string $file Target file.
	 * @return bool|null Null when the file cannot be read.
	 */
	private static function has_block( $file ) {
		if ( ! file_exists( $file ) || ! is_readable( $file ) ) {
			return false;
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_get_contents
		$contents = @file_get_contents( $file );

		if ( false === $contents ) {
			return null;
		}

		return false !== strpos( $contents, '# BEGIN ' . self::MARKER )
			&& false !== strpos( $contents, 'Options -Indexes' );
	}

	/**
	 * Whether the server understands .htaccess.
	 *
	 * @return bool
	 */
	public static function is_apache() {
		$software = isset( $_SERVER['SERVER_SOFTWARE'] ) ? strtolower( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) : '';

		if ( '' === $software ) {
			return false;
		}

		return NYMS_Helpers::has( $software, 'apache' ) || NYMS_Helpers::has( $software, 'litespeed' );
	}

	/**
	 * Path to the site root .htaccess.
	 *
	 * @return string
	 */
	private static function root_file() {
		$home_path = function_exists( 'get_home_path' ) ? get_home_path() : ABSPATH;

		return trailingslashit( $home_path ) . '.htaccess';
	}

	/**
	 * Write a marked block, creating the file when needed.
	 *
	 * @param string $file  Target file.
	 * @param array  $lines Rule lines. Empty array removes the block.
	 * @return bool
	 */
	private static function write( $file, $lines ) {
		if ( ! function_exists( 'insert_with_markers' ) ) {
			require_once ABSPATH . 'wp-admin/includes/misc.php';
		}

		if ( ! file_exists( $file ) ) {
			if ( empty( $lines ) ) {
				return true;
			}

			$dir = dirname( $file );

			if ( ! is_dir( $dir ) || ! is_writable( $dir ) ) {
				return false;
			}

			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			if ( false === @file_put_contents( $file, '' ) ) {
				return false;
			}
		}

		if ( ! is_writable( $file ) ) {
			return false;
		}

		// insert_with_markers() appends, which would put these rules after the
		// terminal "RewriteRule . /index.php [L]" that WordPress writes - and
		// they would never run. Seed an empty block at the top of the file the
		// first time so the rules land ahead of it.
		if ( ! empty( $lines ) ) {
			self::seed_block( $file );
		}

		return (bool) insert_with_markers( $file, self::MARKER, $lines );
	}

	/**
	 * Put an empty marker block at the top of a file if it has none yet.
	 *
	 * @param string $file Target file.
	 * @return void
	 */
	private static function seed_block( $file ) {
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_get_contents
		$contents = (string) @file_get_contents( $file );

		if ( false !== strpos( $contents, '# BEGIN ' . self::MARKER ) ) {
			return;
		}

		$block = '# BEGIN ' . self::MARKER . "\n# END " . self::MARKER . "\n\n";

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		@file_put_contents( $file, $block . $contents );
	}

	/**
	 * Rules for the site root.
	 *
	 * @return array
	 */
	private static function root_rules() {
		$rules = array(
			'# Directory listings leak file names an attacker can use.',
			'Options -Indexes',
			'',
			'# Never serve configuration, logs, backups or VCS metadata.',
			'<FilesMatch "(?i)^(wp-config\.php|wp-config-sample\.php|\.htaccess|\.htpasswd|\.env|\.env\..*|readme\.html|license\.txt|error_log|debug\.log|.*\.(bak|old|orig|save|swp|sql|sql\.gz|tar|tar\.gz|tgz|zip|log|ini|sh|inc)|.*~)$">',
		);

		$rules = array_merge( $rules, self::deny_block( 1 ) );

		$rules = array_merge(
			$rules,
			array(
				'</FilesMatch>',
				'',
				'# Uploaded files are data. They must never execute.',
				'RedirectMatch 403 (?i)^.*/wp-content/uploads/.*\.(php|php[0-9]?|phtml|phps|phar|pht|shtml|cgi|pl|py|asp|aspx|jsp|htaccess)$',
				'',
				'<IfModule mod_rewrite.c>',
				'RewriteEngine On',
				'',
				'# wp-includes holds no legitimate web entry points but these two.',
				'RewriteCond %{REQUEST_URI} !/wp-includes/ms-files\.php$',
				'RewriteCond %{REQUEST_URI} !/wp-includes/js/tinymce/wp-tinymce\.php$',
				'RewriteCond %{REQUEST_URI} /wp-includes/.*\.php$ [NC]',
				'RewriteRule .* - [F,L]',
				'',
				'# Hidden files and folders: .git, .svn, .env, editor state.',
				'# .well-known stays reachable so certificate renewal keeps working.',
				'RewriteRule (^|/)\.(?!well-known(/|$))[^/]+ - [F,L]',
				'',
				'# Classic path-traversal, null-byte and code-injection probes.',
				'RewriteCond %{QUERY_STRING} (\.\./\.\.|%00|%2e%2e%2f) [NC,OR]',
				'RewriteCond %{QUERY_STRING} (base64_(en|de)code|eval\s*\(|GLOBALS(=|\[|%)|_REQUEST(=|\[|%)) [NC]',
				'RewriteRule .* - [F,L]',
				'</IfModule>',
			)
		);

		return $rules;
	}

	/**
	 * Rules for a writable directory that must never execute code.
	 *
	 * @return array
	 */
	private static function no_php_rules() {
		$rules = array(
			'# Nothing in this directory may run as code.',
			'<FilesMatch "(?i)\.(php|php[0-9]?|phtml|phps|phar|pht|shtml|cgi|pl|py|asp|aspx|jsp|htaccess|htm|html)$">',
		);

		$rules = array_merge( $rules, self::deny_block( 1 ) );

		return array_merge(
			$rules,
			array(
				'</FilesMatch>',
				'',
				'<IfModule mod_php.c>',
				'php_flag engine off',
				'</IfModule>',
				'<IfModule mod_php7.c>',
				'php_flag engine off',
				'</IfModule>',
				'<IfModule mod_php8.c>',
				'php_flag engine off',
				'</IfModule>',
				'',
				'Options -Indexes -ExecCGI',
				'RemoveHandler .php .phtml .phar .cgi .pl .py',
				'RemoveType .php .phtml .phar .cgi .pl .py',
			)
		);
	}

	/**
	 * A deny directive that works on both Apache 2.2 and 2.4.
	 *
	 * @param int $indent Indent level.
	 * @return array
	 */
	private static function deny_block( $indent = 0 ) {
		$pad = str_repeat( "\t", max( 0, (int) $indent ) );

		return array(
			$pad . '<IfModule mod_authz_core.c>',
			$pad . "\tRequire all denied",
			$pad . '</IfModule>',
			$pad . '<IfModule !mod_authz_core.c>',
			$pad . "\tOrder allow,deny",
			$pad . "\tDeny from all",
			$pad . '</IfModule>',
		);
	}
}

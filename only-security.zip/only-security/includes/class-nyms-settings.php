<?php
/**
 * Settings store and the single source of truth for every switch.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Holds the definition of every protection, resolves its current value and
 * turns it into a constant.
 *
 * Precedence, highest first:
 *   1. A constant defined in wp-config.php  - locked, the screen cannot change it.
 *   2. The saved setting from the admin screen.
 *   3. The hardened default below.
 */
class NYMS_Settings {

	/**
	 * Option name.
	 */
	const OPTION = 'nyms_settings';

	/**
	 * Cached saved values.
	 *
	 * @var array|null
	 */
	private static $saved = null;

	/**
	 * Keys that were already set in wp-config.php.
	 *
	 * @var array
	 */
	private static $locked = array();

	/**
	 * Every switch, in the order the admin screen shows them.
	 *
	 * @return array
	 */
	public static function definitions() {
		return array(
			'NYMS_DISALLOW_FILE_EDIT'    => array(
				'group'   => 'core',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Disable the plugin and theme file editors', 'newyorkmechanics-security' ),
				'help'    => __( 'The fastest route from a stolen password to a permanent PHP backdoor. Leave this on.', 'newyorkmechanics-security' ),
			),
			'NYMS_FORCE_KSES'            => array(
				'group'   => 'core',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Strip raw HTML and script tags from all content', 'newyorkmechanics-security' ),
				'help'    => __( 'Removes the unfiltered_html capability from every role, including administrators, so injected &lt;script&gt; cannot be stored in a post. Turn off only if an editor needs to paste raw embed code.', 'newyorkmechanics-security' ),
			),
			'NYMS_DISALLOW_FILE_MODS'    => array(
				'group'   => 'core',
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Block plugin and theme installs and updates from wp-admin', 'newyorkmechanics-security' ),
				'help'    => __( 'Strongest possible setting, but you will have to update plugins over SFTP or WP-CLI. Off by default for that reason.', 'newyorkmechanics-security' ),
			),
			'NYMS_MINOR_AUTO_UPDATES'    => array(
				'group'   => 'core',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Install minor (security) core updates automatically', 'newyorkmechanics-security' ),
				'help'    => __( 'Most WordPress break-ins use a hole that was patched months earlier.', 'newyorkmechanics-security' ),
			),
			'NYMS_MANAGE_HTACCESS'       => array(
				'group'   => 'files',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Write the protective .htaccess rules', 'newyorkmechanics-security' ),
				'help'    => __( 'Denies the web access to wp-config.php, .env, logs, database dumps, hidden folders and wp-includes, and turns off directory listings. Removed cleanly when switched off.', 'newyorkmechanics-security' ),
			),
			'NYMS_BLOCK_PHP_IN_UPLOADS'  => array(
				'group'   => 'files',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Refuse to execute PHP and scripts inside wp-content/uploads', 'newyorkmechanics-security' ),
				'help'    => __( 'The single most valuable rule here: even if a shell reaches the uploads folder, the server will not run it.', 'newyorkmechanics-security' ),
			),
			'NYMS_UPLOAD_GUARD'          => array(
				'group'   => 'uploads',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Inspect every upload and reject executable content', 'newyorkmechanics-security' ),
				'help'    => __( 'Blocks executable extensions in any position of the name, reads the bytes for PHP tags and webshell patterns, and requires images to decode as images.', 'newyorkmechanics-security' ),
			),
			'NYMS_ALLOW_SVG_UPLOADS'     => array(
				'group'   => 'uploads',
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Allow SVG uploads', 'newyorkmechanics-security' ),
				'help'    => __( 'SVG is XML and can carry scripts. Only enable if you genuinely need SVG logos or icons in the media library.', 'newyorkmechanics-security' ),
			),
			'NYMS_REQUEST_GUARD'         => array(
				'group'   => 'requests',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Filter the URL and query string for attack patterns', 'newyorkmechanics-security' ),
				'help'    => __( 'PHP tags, php:// and data:// wrappers, path traversal, superglobal tampering, reflected script injection, SQL injection and PHP object injection. Post bodies are never inspected and logged-in editors are exempt.', 'newyorkmechanics-security' ),
			),
			'NYMS_TRUST_PROXY'           => array(
				'group'   => 'requests',
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Trust proxy headers for the visitor IP address', 'newyorkmechanics-security' ),
				'help'    => __( 'Enable ONLY behind Cloudflare or another known proxy. On a directly reachable server these headers are forged trivially, which would let an attacker dodge the login lockout.', 'newyorkmechanics-security' ),
			),
			'NYMS_SECURITY_HEADERS'      => array(
				'group'   => 'headers',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Send the browser security headers', 'newyorkmechanics-security' ),
				'help'    => __( 'Clickjacking, MIME sniffing, referrer leakage and feature permissions, plus HSTS when the site is on HTTPS.', 'newyorkmechanics-security' ),
			),
			'NYMS_FRAME_POLICY'          => array(
				'group'   => 'headers',
				'type'    => 'choice',
				'default' => 'SAMEORIGIN',
				'choices' => array(
					'SAMEORIGIN' => 'SAMEORIGIN',
					'DENY'       => 'DENY',
				),
				'label'   => __( 'Who may put this site in a frame', 'newyorkmechanics-security' ),
				'help'    => __( 'SAMEORIGIN allows your own pages to frame each other. DENY blocks all framing, which can break some embeds and preview tools.', 'newyorkmechanics-security' ),
			),
			'NYMS_LOGIN_GUARD'           => array(
				'group'   => 'login',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Lock out repeated failed sign-ins and hide which half was wrong', 'newyorkmechanics-security' ),
				'help'    => __( 'Also stops the lost-password form confirming whether an address is registered.', 'newyorkmechanics-security' ),
			),
			'NYMS_LOGIN_MAX_ATTEMPTS'    => array(
				'group'   => 'login',
				'type'    => 'int',
				'default' => 5,
				'min'     => 1,
				'max'     => 100,
				'label'   => __( 'Failed attempts before lockout', 'newyorkmechanics-security' ),
				'help'    => __( 'Counted per IP address.', 'newyorkmechanics-security' ),
			),
			'NYMS_LOGIN_LOCKOUT'         => array(
				'group'   => 'login',
				'type'    => 'int',
				'default' => 900,
				'min'     => 60,
				'max'     => 86400,
				'label'   => __( 'Lockout length in seconds', 'newyorkmechanics-security' ),
				'help'    => __( '900 is fifteen minutes. Long enough to make guessing pointless, short enough that a real customer is not stranded.', 'newyorkmechanics-security' ),
			),
			'NYMS_STRONG_PASSWORDS'      => array(
				'group'   => 'login',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Require strong passwords', 'newyorkmechanics-security' ),
				'help'    => __( 'Fourteen characters for administrators, editors and authors, ten for everyone else, mixing at least three character types.', 'newyorkmechanics-security' ),
			),
			'NYMS_DISABLE_XMLRPC'        => array(
				'group'   => 'interfaces',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Disable XML-RPC and close pingbacks', 'newyorkmechanics-security' ),
				'help'    => __( 'Only needed by the WordPress mobile app and some legacy publishing tools. It is the usual entry point for password guessing at scale.', 'newyorkmechanics-security' ),
			),
			'NYMS_DISABLE_APP_PASSWORDS' => array(
				'group'   => 'interfaces',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Disable application passwords', 'newyorkmechanics-security' ),
				'help'    => __( 'Application passwords survive a normal password change, so one issued by an intruder is a lasting back door.', 'newyorkmechanics-security' ),
			),
			'NYMS_BLOCK_ENUMERATION'     => array(
				'group'   => 'interfaces',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Block user name harvesting', 'newyorkmechanics-security' ),
				'help'    => __( 'Closes the REST user routes, the ?author=N probe, the user sitemap and oEmbed author fields to anonymous visitors.', 'newyorkmechanics-security' ),
			),
		);
	}

	/**
	 * Group titles for the admin screen.
	 *
	 * @return array
	 */
	public static function groups() {
		return array(
			'core'       => __( 'Core', 'newyorkmechanics-security' ),
			'files'      => __( 'Server rules and files', 'newyorkmechanics-security' ),
			'uploads'    => __( 'Uploads', 'newyorkmechanics-security' ),
			'requests'   => __( 'Requests', 'newyorkmechanics-security' ),
			'headers'    => __( 'Browser headers', 'newyorkmechanics-security' ),
			'login'      => __( 'Login', 'newyorkmechanics-security' ),
			'interfaces' => __( 'Machine interfaces', 'newyorkmechanics-security' ),
		);
	}

	/**
	 * The saved values, loaded once.
	 *
	 * @return array
	 */
	public static function saved() {
		if ( null === self::$saved ) {
			$stored = get_option( self::OPTION, array() );

			self::$saved = is_array( $stored ) ? $stored : array();
		}

		return self::$saved;
	}

	/**
	 * Resolve one switch: wp-config, then saved value, then default.
	 *
	 * @param string $key Constant name.
	 * @return mixed
	 */
	public static function value( $key ) {
		$definitions = self::definitions();

		if ( ! isset( $definitions[ $key ] ) ) {
			return null;
		}

		if ( defined( $key ) ) {
			return constant( $key );
		}

		$saved = self::saved();

		if ( array_key_exists( $key, $saved ) ) {
			return self::sanitize( $definitions[ $key ], $saved[ $key ] );
		}

		return $definitions[ $key ]['default'];
	}

	/**
	 * Whether wp-config.php has taken this switch out of the screen's hands.
	 *
	 * @param string $key Constant name.
	 * @return bool
	 */
	public static function is_locked( $key ) {
		return ! empty( self::$locked[ $key ] );
	}

	/**
	 * Turn every switch into a constant, once, before the modules load.
	 *
	 * @return void
	 */
	public static function define_constants() {
		foreach ( self::definitions() as $key => $definition ) {
			if ( defined( $key ) ) {
				// Set in wp-config.php: it wins and the screen shows it locked.
				self::$locked[ $key ] = true;
				continue;
			}

			define( $key, self::value( $key ) );
		}
	}

	/**
	 * Validate a submitted value against its definition.
	 *
	 * @param array $definition Field definition.
	 * @param mixed $value      Raw value.
	 * @return mixed
	 */
	public static function sanitize( $definition, $value ) {
		switch ( $definition['type'] ) {
			case 'int':
				$value = (int) $value;

				return max( (int) $definition['min'], min( (int) $definition['max'], $value ) );

			case 'choice':
				$value = (string) $value;

				return isset( $definition['choices'][ $value ] ) ? $value : $definition['default'];

			case 'bool':
			default:
				return (bool) $value;
		}
	}

	/**
	 * Store a submitted set of values.
	 *
	 * Locked keys are ignored: a value set in wp-config.php cannot be changed
	 * from the browser.
	 *
	 * @param array $input Raw submitted values, keyed by constant name.
	 * @return void
	 */
	public static function save( $input ) {
		$clean = array();

		foreach ( self::definitions() as $key => $definition ) {
			if ( self::is_locked( $key ) ) {
				continue;
			}

			if ( 'bool' === $definition['type'] ) {
				$clean[ $key ] = ! empty( $input[ $key ] );
				continue;
			}

			if ( isset( $input[ $key ] ) ) {
				$clean[ $key ] = self::sanitize( $definition, $input[ $key ] );
			}
		}

		self::$saved = $clean;

		update_option( self::OPTION, $clean );
	}
}

<?php
/**
 * Settings store and the single source of truth for every switch.
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Holds the definition of every protection, resolves its current value and
 * turns it into a constant.
 *
 * Precedence, highest first:
 *   1. A constant defined in wp-config.php  - locked, the screen cannot change it.
 *   2. The saved setting from the admin screen.
 *   3. The hardened default below.
 */
class NYMS_Settings {

	/**
	 * Option name.
	 */
	const OPTION = 'nyms_settings';

	/**
	 * Cached saved values.
	 *
	 * @var array|null
	 */
	private static $saved = null;

	/**
	 * Keys that were already set in wp-config.php.
	 *
	 * @var array
	 */
	private static $locked = array();

	/**
	 * Every switch, in the order the admin screen shows them.
	 *
	 * @return array
	 */
	public static function definitions() {
		return array(
			'NYMS_DISALLOW_FILE_EDIT'    => array(
				'group'   => 'core',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Disable the plugin and theme file editors', 'newyorkmechanics-security' ),
				'help'    => __( 'The fastest route from a stolen password to a permanent PHP backdoor. Leave this on.', 'newyorkmechanics-security' ),
			),
			'NYMS_FORCE_KSES'            => array(
				'group'   => 'core',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Strip raw HTML and script tags from all content', 'newyorkmechanics-security' ),
				'help'    => __( 'Removes the unfiltered_html capability from every role, including administrators, so injected &lt;script&gt; cannot be stored in a post. Turn off only if an editor needs to paste raw embed code.', 'newyorkmechanics-security' ),
			),
			'NYMS_DISALLOW_FILE_MODS'    => array(
				'group'   => 'core',
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Block plugin and theme installs and updates from wp-admin', 'newyorkmechanics-security' ),
				'help'    => __( 'Strongest possible setting, but you will have to update plugins over SFTP or WP-CLI. Off by default for that reason.', 'newyorkmechanics-security' ),
			),
			'NYMS_MINOR_AUTO_UPDATES'    => array(
				'group'   => 'core',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Install minor (security) core updates automatically', 'newyorkmechanics-security' ),
				'help'    => __( 'Most WordPress break-ins use a hole that was patched months earlier.', 'newyorkmechanics-security' ),
			),
			'NYMS_MANAGE_HTACCESS'       => array(
				'group'   => 'files',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Write the protective .htaccess rules', 'newyorkmechanics-security' ),
				'help'    => __( 'Denies the web access to wp-config.php, .env, logs, database dumps, hidden folders and wp-includes, and turns off directory listings. Removed cleanly when switched off.', 'newyorkmechanics-security' ),
			),
			'NYMS_BLOCK_PHP_IN_UPLOADS'  => array(
				'group'   => 'files',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Refuse to execute PHP and scripts inside wp-content/uploads', 'newyorkmechanics-security' ),
				'help'    => __( 'The single most valuable rule here: even if a shell reaches the uploads folder, the server will not run it.', 'newyorkmechanics-security' ),
			),
			'NYMS_UPLOAD_GUARD'          => array(
				'group'   => 'uploads',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Inspect every upload and reject executable content', 'newyorkmechanics-security' ),
				'help'    => __( 'Blocks executable extensions in any position of the name, checks the first bytes against the extension, refuses a file whose declared type disagrees with its contents, and requires images to decode as images.', 'newyorkmechanics-security' ),
			),
			'NYMS_ALLOW_SVG_UPLOADS'     => array(
				'group'   => 'uploads',
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Allow SVG uploads', 'newyorkmechanics-security' ),
				'help'    => __( 'SVG is XML and can carry scripts. Only enable if you genuinely need SVG logos or icons in the media library.', 'newyorkmechanics-security' ),
			),
			'NYMS_REQUEST_GUARD'         => array(
				'group'   => 'requests',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Filter the URL and query string for attack patterns', 'newyorkmechanics-security' ),
				'help'    => __( 'PHP tags, php:// and data:// wrappers, path traversal, superglobal tampering, reflected script injection, SQL injection and PHP object injection. Post bodies are never inspected and logged-in editors are exempt.', 'newyorkmechanics-security' ),
			),
			'NYMS_TRUST_PROXY'           => array(
				'group'   => 'requests',
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Trust proxy headers for the visitor IP address', 'newyorkmechanics-security' ),
				'help'    => __( 'Enable ONLY behind Cloudflare or another known proxy. On a directly reachable server these headers are forged trivially, which would let an attacker dodge the login lockout.', 'newyorkmechanics-security' ),
			),
			'NYMS_SECURITY_HEADERS'      => array(
				'group'   => 'headers',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Send the browser security headers', 'newyorkmechanics-security' ),
				'help'    => __( 'Clickjacking, MIME sniffing, referrer leakage and feature permissions, plus HSTS when the site is on HTTPS.', 'newyorkmechanics-security' ),
			),
			'NYMS_FRAME_POLICY'          => array(
				'group'   => 'headers',
				'type'    => 'choice',
				'default' => 'SAMEORIGIN',
				'choices' => array(
					'SAMEORIGIN' => 'SAMEORIGIN',
					'DENY'       => 'DENY',
				),
				'label'   => __( 'Who may put this site in a frame', 'newyorkmechanics-security' ),
				'help'    => __( 'SAMEORIGIN allows your own pages to frame each other. DENY blocks all framing, which can break some embeds and preview tools.', 'newyorkmechanics-security' ),
			),
			'NYMS_LOGIN_GUARD'           => array(
				'group'   => 'login',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Lock out repeated failed sign-ins and hide which half was wrong', 'newyorkmechanics-security' ),
				'help'    => __( 'Also stops the lost-password form confirming whether an address is registered.', 'newyorkmechanics-security' ),
			),
			'NYMS_LOGIN_MAX_ATTEMPTS'    => array(
				'group'   => 'login',
				'type'    => 'int',
				'default' => 5,
				'min'     => 1,
				'max'     => 100,
				'label'   => __( 'Failed attempts before lockout', 'newyorkmechanics-security' ),
				'help'    => __( 'Counted per IP address.', 'newyorkmechanics-security' ),
			),
			'NYMS_LOGIN_LOCKOUT'         => array(
				'group'   => 'login',
				'type'    => 'int',
				'default' => 900,
				'min'     => 60,
				'max'     => 86400,
				'label'   => __( 'Lockout length in seconds', 'newyorkmechanics-security' ),
				'help'    => __( '900 is fifteen minutes. Long enough to make guessing pointless, short enough that a real customer is not stranded.', 'newyorkmechanics-security' ),
			),
			'NYMS_STRONG_PASSWORDS'      => array(
				'group'   => 'login',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Require strong passwords', 'newyorkmechanics-security' ),
				'help'    => __( 'Fourteen characters for administrators, editors and authors, ten for everyone else, mixing at least three character types.', 'newyorkmechanics-security' ),
			),
			'NYMS_DISABLE_XMLRPC'        => array(
				'group'   => 'interfaces',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Disable XML-RPC and close pingbacks', 'newyorkmechanics-security' ),
				'help'    => __( 'Only needed by the WordPress mobile app and some legacy publishing tools. It is the usual entry point for password guessing at scale.', 'newyorkmechanics-security' ),
			),
			'NYMS_DISABLE_APP_PASSWORDS' => array(
				'group'   => 'interfaces',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Disable application passwords', 'newyorkmechanics-security' ),
				'help'    => __( 'Application passwords survive a normal password change, so one issued by an intruder is a lasting back door.', 'newyorkmechanics-security' ),
			),
			'NYMS_BLOCK_ENUMERATION'     => array(
				'group'   => 'interfaces',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Block user name harvesting', 'newyorkmechanics-security' ),
				'help'    => __( 'Closes the REST user routes, the ?author=N probe, the user sitemap and oEmbed author fields to anonymous visitors.', 'newyorkmechanics-security' ),
			),
			'NYMS_RESTRICT_REST'         => array(
				'group'   => 'interfaces',
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Require a sign-in for the REST API', 'newyorkmechanics-security' ),
				'help'    => __( 'Leaves the routes a public site genuinely needs open - posts, pages, media, search, oEmbed - and closes the rest. Test the front end after switching this on; some plugins fetch their own data anonymously.', 'newyorkmechanics-security' ),
			),
			'NYMS_DISABLE_FEEDS'         => array(
				'group'   => 'interfaces',
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Disable RSS and Atom feeds', 'newyorkmechanics-security' ),
				'help'    => __( 'A feed lists every post, author and comment in one request. Turn this on only if nothing subscribes to the site.', 'newyorkmechanics-security' ),
			),

			// -------------------------------------------------------------
			// Monitoring.
			// -------------------------------------------------------------
			'NYMS_LOGGING'               => array(
				'group'   => 'monitoring',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Keep a security event log', 'newyorkmechanics-security' ),
				'help'    => __( 'Every block, every rejected upload, every change of role. Without a log there is no way to answer "when did this start".', 'newyorkmechanics-security' ),
			),
			'NYMS_LOG_RETENTION_DAYS'    => array(
				'group'   => 'monitoring',
				'type'    => 'int',
				'default' => 60,
				'min'     => 7,
				'max'     => 730,
				'label'   => __( 'Days of log history to keep', 'newyorkmechanics-security' ),
				'help'    => __( 'Older entries are deleted once a day. Sixty days covers the gap between a break-in and someone noticing.', 'newyorkmechanics-security' ),
			),
			'NYMS_ALERT_EMAIL'           => array(
				'group'   => 'monitoring',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'E-mail an alert on critical events', 'newyorkmechanics-security' ),
				'help'    => __( 'At most one message an hour per kind of event, sent to the address below.', 'newyorkmechanics-security' ),
			),
			'NYMS_SELF_PROTECT'          => array(
				'group'   => 'monitoring',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Protect this plugin from being switched off', 'newyorkmechanics-security' ),
				'help'    => __( 'Watches its own files, table and options, and refuses deactivation or deletion until you unlock it deliberately on this screen.', 'newyorkmechanics-security' ),
			),

			// -------------------------------------------------------------
			// Plugins and themes.
			// -------------------------------------------------------------
			'NYMS_PLUGIN_GUARD'          => array(
				'group'   => 'plugins',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Inspect plugins and themes before they are installed', 'newyorkmechanics-security' ),
				'help'    => __( 'Reads every file inside the package - including files inside archives inside the package - and refuses anything carrying a shell, a dropper or an unauthenticated entry point.', 'newyorkmechanics-security' ),
			),
			'NYMS_PLUGIN_POLICY'         => array(
				'group'   => 'plugins',
				'type'    => 'choice',
				'default' => 'monitor',
				'choices' => array(
					'off'     => __( 'Off', 'newyorkmechanics-security' ),
					'monitor' => __( 'Monitor - allow, but record everything', 'newyorkmechanics-security' ),
					'enforce' => __( 'Enforce - only approved plugins may be installed or activated', 'newyorkmechanics-security' ),
				),
				'label'   => __( 'Plugin approval policy', 'newyorkmechanics-security' ),
				'help'    => __( 'Enforce mode is the strongest setting on this screen: a plugin has to be approved by name before it can run. Approve everything you already use before turning it on.', 'newyorkmechanics-security' ),
			),
			'NYMS_BLOCK_UNKNOWN_PLUGINS' => array(
				'group'   => 'plugins',
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Refuse plugins that are not published on wordpress.org', 'newyorkmechanics-security' ),
				'help'    => __( 'Code that is not in the directory cannot be checked against anything. Leave this off if you use paid plugins, and approve those by hand instead.', 'newyorkmechanics-security' ),
			),
			'NYMS_BLOCK_ABANDONED_PLUGINS' => array(
				'group'   => 'plugins',
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Refuse plugins that have been abandoned', 'newyorkmechanics-security' ),
				'help'    => __( 'A plugin whose author stopped updating it will never be patched. Plugins pulled from the directory for a security problem are always refused, whatever this is set to.', 'newyorkmechanics-security' ),
			),
			'NYMS_ABANDONED_MONTHS'      => array(
				'group'   => 'plugins',
				'type'    => 'int',
				'default' => 24,
				'min'     => 6,
				'max'     => 120,
				'label'   => __( 'Months without an update before a plugin counts as abandoned', 'newyorkmechanics-security' ),
				'help'    => __( 'Two years is the usual line. Small, finished plugins can sit untouched for good reasons, so this is a warning by default.', 'newyorkmechanics-security' ),
			),
			'NYMS_VERIFY_PLUGIN_FILES'   => array(
				'group'   => 'plugins',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Check installed plugins against the copy their author published', 'newyorkmechanics-security' ),
				'help'    => __( 'Uses the checksums wordpress.org publishes for each release. A file that differs, or a file the author never shipped, is exactly what a backdoor looks like.', 'newyorkmechanics-security' ),
			),

			// -------------------------------------------------------------
			// Firewall.
			// -------------------------------------------------------------
			'NYMS_FIREWALL'              => array(
				'group'   => 'firewall',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Rate limit and block abusive clients', 'newyorkmechanics-security' ),
				'help'    => __( 'Per-address limits on the site, the sign-in form, XML-RPC and the REST API, plus the address lists below.', 'newyorkmechanics-security' ),
			),
			'NYMS_RATE_GENERAL'          => array(
				'group'   => 'firewall',
				'type'    => 'int',
				'default' => 240,
				'min'     => 30,
				'max'     => 5000,
				'label'   => __( 'Requests a minute from one address', 'newyorkmechanics-security' ),
				'help'    => __( 'Count generously: a single page view with thirty images is thirty requests.', 'newyorkmechanics-security' ),
			),
			'NYMS_RATE_LOGIN'            => array(
				'group'   => 'firewall',
				'type'    => 'int',
				'default' => 12,
				'min'     => 3,
				'max'     => 200,
				'label'   => __( 'Sign-in page requests per five minutes', 'newyorkmechanics-security' ),
				'help'    => __( 'This counts page loads, not failed passwords, so it stops the flood before the lockout has to.', 'newyorkmechanics-security' ),
			),
			'NYMS_RATE_REST'             => array(
				'group'   => 'firewall',
				'type'    => 'int',
				'default' => 120,
				'min'     => 10,
				'max'     => 2000,
				'label'   => __( 'REST API requests a minute', 'newyorkmechanics-security' ),
				'help'    => __( 'The block editor is talkative. Do not set this below about sixty on a site people write on.', 'newyorkmechanics-security' ),
			),
			'NYMS_AUTO_BLOCK'            => array(
				'group'   => 'firewall',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Block an address automatically after repeated refusals', 'newyorkmechanics-security' ),
				'help'    => __( 'Each repeat block lasts twice as long as the last one, up to a week.', 'newyorkmechanics-security' ),
			),
			'NYMS_BLOCK_THRESHOLD'       => array(
				'group'   => 'firewall',
				'type'    => 'int',
				'default' => 10,
				'min'     => 3,
				'max'     => 200,
				'label'   => __( 'Refused requests an hour before an address is blocked', 'newyorkmechanics-security' ),
				'help'    => __( 'Failed sign-ins, blocked probes and missing-file storms all count towards this.', 'newyorkmechanics-security' ),
			),
			'NYMS_BLOCK_MINUTES'         => array(
				'group'   => 'firewall',
				'type'    => 'int',
				'default' => 30,
				'min'     => 1,
				'max'     => 10080,
				'label'   => __( 'Length of the first block, in minutes', 'newyorkmechanics-security' ),
				'help'    => __( 'Short is fine: the point is to make automated guessing too slow to be worth it.', 'newyorkmechanics-security' ),
			),
			'NYMS_MAX_NOT_FOUND'         => array(
				'group'   => 'firewall',
				'type'    => 'int',
				'default' => 30,
				'min'     => 5,
				'max'     => 500,
				'label'   => __( 'Missing-page hits in five minutes before an address counts as scanning', 'newyorkmechanics-security' ),
				'help'    => __( 'A scanner hunting for a forgotten backdoor generates hundreds of these; a person generates two.', 'newyorkmechanics-security' ),
			),
			'NYMS_BLOCK_EMPTY_AGENT'     => array(
				'group'   => 'firewall',
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Refuse requests that send no user agent', 'newyorkmechanics-security' ),
				'help'    => __( 'Most of these are scripts, but a few legitimate monitors and cron services send nothing either. Check your uptime monitor still works after switching this on.', 'newyorkmechanics-security' ),
			),

			// -------------------------------------------------------------
			// Accounts.
			// -------------------------------------------------------------
			'NYMS_USER_GUARD'            => array(
				'group'   => 'accounts',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Watch accounts, roles and sessions', 'newyorkmechanics-security' ),
				'help'    => __( 'New administrators, promoted accounts, changed addresses, sign-ins from somewhere new, and application passwords - all recorded, and the critical ones e-mailed.', 'newyorkmechanics-security' ),
			),
			'NYMS_TWO_FACTOR'            => array(
				'group'   => 'accounts',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Offer two-factor authentication', 'newyorkmechanics-security' ),
				'help'    => __( 'An authenticator app or an e-mailed code, set up per person on their own profile page, with single-use recovery codes.', 'newyorkmechanics-security' ),
			),
			'NYMS_REQUIRE_2FA_ADMINS'    => array(
				'group'   => 'accounts',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Remind administrators who have not set up a second factor', 'newyorkmechanics-security' ),
				'help'    => __( 'A notice on every admin screen until it is done. It never locks anyone out.', 'newyorkmechanics-security' ),
			),
			'NYMS_BLOCK_WEAK_USERNAMES'  => array(
				'group'   => 'accounts',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Refuse obvious user names', 'newyorkmechanics-security' ),
				'help'    => __( 'admin, administrator, test, root and the machine-generated names that malware creates.', 'newyorkmechanics-security' ),
			),
			'NYMS_LIMIT_SESSIONS'        => array(
				'group'   => 'accounts',
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Limit how many places an account can be signed in at once', 'newyorkmechanics-security' ),
				'help'    => __( 'Signing in beyond the limit ends the older sessions. It also ends a session an intruder is holding.', 'newyorkmechanics-security' ),
			),
			'NYMS_MAX_SESSIONS'          => array(
				'group'   => 'accounts',
				'type'    => 'int',
				'default' => 5,
				'min'     => 1,
				'max'     => 50,
				'label'   => __( 'Sessions allowed per account', 'newyorkmechanics-security' ),
				'help'    => __( 'Phone, laptop and desktop is three. Anything above this is also reported even when the limit is not enforced.', 'newyorkmechanics-security' ),
			),
			'NYMS_INACTIVE_DAYS'         => array(
				'group'   => 'accounts',
				'type'    => 'int',
				'default' => 180,
				'min'     => 30,
				'max'     => 1095,
				'label'   => __( 'Days before a privileged account counts as inactive', 'newyorkmechanics-security' ),
				'help'    => __( 'The forgotten administrator account from a developer who left three years ago is a standing risk.', 'newyorkmechanics-security' ),
			),
			'NYMS_DISABLE_INACTIVE'      => array(
				'group'   => 'accounts',
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Disable inactive privileged accounts automatically', 'newyorkmechanics-security' ),
				'help'    => __( 'The account is switched off and its sessions ended; nothing is deleted and you can re-enable it in one click. Off by default because it can lock out a seasonal user.', 'newyorkmechanics-security' ),
			),

			// -------------------------------------------------------------
			// Outbound network.
			// -------------------------------------------------------------
			'NYMS_NETWORK_GUARD'         => array(
				'group'   => 'network',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Watch what this site connects out to', 'newyorkmechanics-security' ),
				'help'    => __( 'Every host WordPress contacts is recorded, first contact with a new one is reported, and known malware hosts are refused.', 'newyorkmechanics-security' ),
			),
			'NYMS_DOMAIN_ALLOWLIST_MODE' => array(
				'group'   => 'network',
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Only allow outgoing requests to hosts on the allowlist', 'newyorkmechanics-security' ),
				'help'    => __( 'The strongest anti-backdoor setting there is: a shell that cannot phone home is nearly useless. Watch the recorded host list for a week first, then add what belongs there.', 'newyorkmechanics-security' ),
			),
			'NYMS_DNS_REPUTATION'        => array(
				'group'   => 'network',
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Check hosts against the public abuse blocklists', 'newyorkmechanics-security' ),
				'help'    => __( 'Looks a host up in the Spamhaus DBL and ZEN lists over DNS and caches the answer for a day. Only switch this on if the server can make outgoing DNS queries.', 'newyorkmechanics-security' ),
			),

			// -------------------------------------------------------------
			// Uploads, continued.
			// -------------------------------------------------------------
			'NYMS_SANITIZE_SVG'          => array(
				'group'   => 'uploads',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Clean SVG files instead of refusing them', 'newyorkmechanics-security' ),
				'help'    => __( 'Applies when SVG uploads are allowed: scripts, event handlers and external references are stripped and only the drawing is kept.', 'newyorkmechanics-security' ),
			),
			'NYMS_ALLOW_HTML_UPLOADS'    => array(
				'group'   => 'uploads',
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Allow HTML uploads', 'newyorkmechanics-security' ),
				'help'    => __( 'An uploaded HTML page runs on your domain, which means it can read your cookies. Almost no site needs this.', 'newyorkmechanics-security' ),
			),
			'NYMS_ALLOW_JS_UPLOADS'      => array(
				'group'   => 'uploads',
				'type'    => 'bool',
				'default' => false,
				'label'   => __( 'Allow JavaScript uploads', 'newyorkmechanics-security' ),
				'help'    => __( 'Same problem as HTML, with no upside for a media library.', 'newyorkmechanics-security' ),
			),
			'NYMS_ALLOW_ARCHIVE_UPLOADS' => array(
				'group'   => 'uploads',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Allow ZIP and other archives', 'newyorkmechanics-security' ),
				'help'    => __( 'Archives are inspected entry by entry when the setting below is on.', 'newyorkmechanics-security' ),
			),
			'NYMS_SCAN_ARCHIVES'         => array(
				'group'   => 'uploads',
				'type'    => 'bool',
				'default' => true,
				'label'   => __( 'Look inside uploaded archives', 'newyorkmechanics-security' ),
				'help'    => __( 'Path traversal, absolute paths, executables, server configuration files, decompression bombs and nested archives. Nothing is extracted to disk to check it.', 'newyorkmechanics-security' ),
			),
			'NYMS_MAX_UPLOAD_MB'         => array(
				'group'   => 'uploads',
				'type'    => 'int',
				'default' => 64,
				'min'     => 1,
				'max'     => 2048,
				'label'   => __( 'Largest accepted upload, in megabytes', 'newyorkmechanics-security' ),
				'help'    => __( 'Applied on top of the server limit, so it can only ever be stricter.', 'newyorkmechanics-security' ),
			),
			'NYMS_ARCHIVE_MAX_ENTRIES'   => array(
				'group'   => 'uploads',
				'type'    => 'int',
				'default' => 20000,
				'min'     => 100,
				'max'     => 200000,
				'label'   => __( 'Most files allowed inside one archive', 'newyorkmechanics-security' ),
				'help'    => __( 'A normal plugin has a few hundred. A hundred thousand tiny entries is an attack on the unpacker.', 'newyorkmechanics-security' ),
			),
			'NYMS_ARCHIVE_MAX_FILE_MB'   => array(
				'group'   => 'uploads',
				'type'    => 'int',
				'default' => 50,
				'min'     => 1,
				'max'     => 1024,
				'label'   => __( 'Largest single file inside an archive, in megabytes', 'newyorkmechanics-security' ),
				'help'    => __( 'Entries above this are refused rather than unpacked.', 'newyorkmechanics-security' ),
			),
			'NYMS_ARCHIVE_MAX_TOTAL_MB'  => array(
				'group'   => 'uploads',
				'type'    => 'int',
				'default' => 500,
				'min'     => 5,
				'max'     => 10240,
				'label'   => __( 'Largest total unpacked size of an archive, in megabytes', 'newyorkmechanics-security' ),
				'help'    => __( 'The number that stops a ten-kilobyte file from filling the disk.', 'newyorkmechanics-security' ),
			),
			'NYMS_ARCHIVE_MAX_RATIO'     => array(
				'group'   => 'uploads',
				'type'    => 'int',
				'default' => 120,
				'min'     => 10,
				'max'     => 10000,
				'label'   => __( 'Largest allowed compression ratio', 'newyorkmechanics-security' ),
				'help'    => __( 'Real content compresses perhaps twenty times. A thousand times means the archive is built to explode.', 'newyorkmechanics-security' ),
			),
		);
	}

	/**
	 * Group titles for the admin screen.
	 *
	 * @return array
	 */
	public static function groups() {
		return array(
			'core'       => __( 'Core', 'newyorkmechanics-security' ),
			'files'      => __( 'Server rules and files', 'newyorkmechanics-security' ),
			'monitoring' => __( 'Logging and self-protection', 'newyorkmechanics-security' ),
			'plugins'    => __( 'Plugins and themes', 'newyorkmechanics-security' ),
			'uploads'    => __( 'Uploads', 'newyorkmechanics-security' ),
			'requests'   => __( 'Requests', 'newyorkmechanics-security' ),
			'firewall'   => __( 'Firewall and rate limits', 'newyorkmechanics-security' ),
			'headers'    => __( 'Browser headers', 'newyorkmechanics-security' ),
			'login'      => __( 'Login', 'newyorkmechanics-security' ),
			'accounts'   => __( 'Accounts and sessions', 'newyorkmechanics-security' ),
			'network'    => __( 'Outbound network', 'newyorkmechanics-security' ),
			'interfaces' => __( 'Machine interfaces', 'newyorkmechanics-security' ),
		);
	}

	/**
	 * The saved values, loaded once.
	 *
	 * @return array
	 */
	public static function saved() {
		if ( null === self::$saved ) {
			$stored = get_option( self::OPTION, array() );

			self::$saved = is_array( $stored ) ? $stored : array();
		}

		return self::$saved;
	}

	/**
	 * Resolve one switch: wp-config, then saved value, then default.
	 *
	 * @param string $key Constant name.
	 * @return mixed
	 */
	public static function value( $key ) {
		$definitions = self::definitions();

		if ( ! isset( $definitions[ $key ] ) ) {
			return null;
		}

		if ( defined( $key ) ) {
			return constant( $key );
		}

		$saved = self::saved();

		if ( array_key_exists( $key, $saved ) ) {
			return self::sanitize( $definitions[ $key ], $saved[ $key ] );
		}

		return $definitions[ $key ]['default'];
	}

	/**
	 * Whether wp-config.php has taken this switch out of the screen's hands.
	 *
	 * @param string $key Constant name.
	 * @return bool
	 */
	public static function is_locked( $key ) {
		return ! empty( self::$locked[ $key ] );
	}

	/**
	 * Turn every switch into a constant, once, before the modules load.
	 *
	 * @return void
	 */
	public static function define_constants() {
		foreach ( self::definitions() as $key => $definition ) {
			if ( defined( $key ) ) {
				// Set in wp-config.php: it wins and the screen shows it locked.
				self::$locked[ $key ] = true;
				continue;
			}

			define( $key, self::value( $key ) );
		}
	}

	/**
	 * Validate a submitted value against its definition.
	 *
	 * @param array $definition Field definition.
	 * @param mixed $value      Raw value.
	 * @return mixed
	 */
	public static function sanitize( $definition, $value ) {
		switch ( $definition['type'] ) {
			case 'int':
				$value = (int) $value;

				return max( (int) $definition['min'], min( (int) $definition['max'], $value ) );

			case 'choice':
				$value = (string) $value;

				return isset( $definition['choices'][ $value ] ) ? $value : $definition['default'];

			case 'bool':
			default:
				return (bool) $value;
		}
	}

	/**
	 * Store a submitted set of values.
	 *
	 * Locked keys are ignored: a value set in wp-config.php cannot be changed
	 * from the browser.
	 *
	 * @param array $input Raw submitted values, keyed by constant name.
	 * @return void
	 */
	public static function save( $input ) {
		$clean = array();

		foreach ( self::definitions() as $key => $definition ) {
			if ( self::is_locked( $key ) ) {
				continue;
			}

			if ( 'bool' === $definition['type'] ) {
				$clean[ $key ] = ! empty( $input[ $key ] );
				continue;
			}

			if ( isset( $input[ $key ] ) ) {
				$clean[ $key ] = self::sanitize( $definition, $input[ $key ] );
			}
		}

		self::$saved = $clean;

		update_option( self::OPTION, $clean );
	}
}

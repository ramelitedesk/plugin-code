<?php
/**
 * Uninstall routine.
 *
 * Removes every trace the plugin left behind: the managed .htaccess blocks,
 * its tables, its options, its scheduled jobs and its user meta. The
 * quarantine folder is deliberately left on disk - deleting files somebody
 * may still want as evidence is not a thing an uninstaller should do quietly.
 *
 * @package NYMS
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

if ( ! defined( 'NYMS_PATH' ) ) {
	define( 'NYMS_PATH', plugin_dir_path( __FILE__ ) );
}

foreach ( array( 'NYMS_MANAGE_HTACCESS', 'NYMS_BLOCK_PHP_IN_UPLOADS', 'NYMS_TRUST_PROXY' ) as $nyms_const ) {
	if ( ! defined( $nyms_const ) ) {
		define( $nyms_const, true );
	}
}
unset( $nyms_const );

require_once NYMS_PATH . 'includes/class-nyms-helpers.php';
require_once NYMS_PATH . 'includes/class-nyms-htaccess.php';

// Remove the managed rules whatever the saved settings said.
NYMS_Htaccess::uninstall();

global $wpdb;

$nyms_options = array(
	'nyms_version',
	'nyms_settings',
	'nyms_log_schema',
	'nyms_baseline_at',
	'nyms_last_scan',
	'nyms_db_scan',
	'nyms_plugin_audit',
	'nyms_user_audit',
	'nyms_self_status',
	'nyms_self_hashes',
	'nyms_allow_deactivation',
	'nyms_alert_address',
	'nyms_known_host',
	'nyms_quarantine',
	'nyms_quarantine_dir',
	'nyms_plugin_allowlist',
	'nyms_plugin_blocklist',
	'nyms_plugin_pending',
	'nyms_plugin_sources',
	'nyms_ip_blocks',
	'nyms_ip_allowlist',
	'nyms_ip_blocklist',
	'nyms_blocked_countries',
	'nyms_blocked_agents',
	'nyms_domain_allowlist',
	'nyms_domain_blocklist',
	'nyms_domains_seen',
);

foreach ( $nyms_options as $nyms_option ) {
	delete_option( $nyms_option );
}
unset( $nyms_option, $nyms_options );

foreach ( array( 'nyms_integrity_scan', 'nyms_db_scan', 'nyms_plugin_audit', 'nyms_user_audit', 'nyms_self_check', 'nyms_prune_blocks', 'nyms_maintenance', 'nyms_verify_protection' ) as $nyms_hook ) {
	wp_clear_scheduled_hook( $nyms_hook );
}
unset( $nyms_hook );

// The plugin's own tables.
$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'nyms_log' ); // phpcs:ignore WordPress.DB
$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'nyms_hashes' ); // phpcs:ignore WordPress.DB

// Per-user data: two-factor secrets, recovery codes, sign-in history.
$wpdb->query( // phpcs:ignore WordPress.DB
	$wpdb->prepare(
		"DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE %s",
		$wpdb->esc_like( 'nyms_' ) . '%'
	)
);

// Any outstanding lockout, rate-limit or cache entry.
$wpdb->query( // phpcs:ignore WordPress.DB
	$wpdb->prepare(
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
		$wpdb->esc_like( '_transient_nyms_' ) . '%',
		$wpdb->esc_like( '_transient_timeout_nyms_' ) . '%'
	)
);

<?php
/**
 * Uninstall routine.
 *
 * Removes every trace the plugin left behind: the managed .htaccess blocks,
 * the version option and the lockout counters.
 *
 * @package NYMS
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

if ( ! defined( 'NYMS_PATH' ) ) {
	define( 'NYMS_PATH', plugin_dir_path( __FILE__ ) );
}

foreach ( array( 'NYMS_MANAGE_HTACCESS', 'NYMS_BLOCK_PHP_IN_UPLOADS', 'NYMS_TRUST_PROXY' ) as $nyms_const ) {
	if ( ! defined( $nyms_const ) ) {
		define( $nyms_const, true );
	}
}
unset( $nyms_const );

require_once NYMS_PATH . 'includes/class-nyms-helpers.php';
require_once NYMS_PATH . 'includes/class-nyms-htaccess.php';

// Remove the managed rules whatever the saved settings said.
NYMS_Htaccess::uninstall();

delete_option( 'nyms_version' );
delete_option( 'nyms_settings' );
delete_transient( 'nyms_protection_checked' );

global $wpdb;

// Clear any outstanding login lockout counters.
$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
		$wpdb->esc_like( '_transient_nyms_' ) . '%',
		$wpdb->esc_like( '_transient_timeout_nyms_' ) . '%'
	)
);

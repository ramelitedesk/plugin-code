<?php
/*
Plugin Name: Blog Tracker Dashboard
Description: Custom blog visitor tracking dashboard
Version: 2.0
Author: rk
*/

if (!defined('ABSPATH')) exit;

/* -------------------------------------------------
   1️⃣ CREATE TABLE
--------------------------------------------------*/
function blog_tracker_create_table()
{
    global $wpdb;

    $table = $wpdb->prefix . 'blog_tracker';
    $charset = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table (
        id BIGINT(20) NOT NULL AUTO_INCREMENT,
        post_id BIGINT(20) NOT NULL,
        ip_address VARCHAR(100) NOT NULL,
        user_agent TEXT NOT NULL,
        visit_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY post_id (post_id),
        KEY visit_date (visit_date)
    ) $charset;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'blog_tracker_create_table');


/* -------------------------------------------------
   2️⃣ TRACK VISITS
--------------------------------------------------*/
function blog_tracker_track_visit()
{
    if (!is_single()) return;
    if (is_user_logged_in() && current_user_can('manage_options')) return;

    global $wpdb;

    $table = $wpdb->prefix . 'blog_tracker';

    $post_id   = get_the_ID();
    $ip        = $_SERVER['REMOTE_ADDR'];
    $userAgent = $_SERVER['HTTP_USER_AGENT'];

    // 🔥 Check if same IP visited same post within last 30 minutes
    $existing = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT id FROM $table
             WHERE post_id = %d
             AND ip_address = %s
             AND visit_date >= (NOW() - INTERVAL 30 MINUTE)
             LIMIT 1",
            $post_id,
            $ip
        )
    );

    // If no recent visit found → insert new record
    if (!$existing) {
        $wpdb->insert($table, [
            'post_id'    => $post_id,
            'ip_address' => $ip,
            'user_agent' => $userAgent,
            'visit_date' => current_time('mysql')
        ]);
    }
}
add_action('wp', 'blog_tracker_track_visit');


/* -------------------------------------------------
   3️⃣ ADMIN MENU
--------------------------------------------------*/
function blog_tracker_admin_menu()
{
    add_menu_page(
        'Blog Tracker',
        'Blog Tracker',
        'manage_options',
        'blog-tracker',
        'blog_tracker_dashboard',
        'dashicons-chart-bar',
        6
    );
}
add_action('admin_menu', 'blog_tracker_admin_menu');


/* -------------------------------------------------
   4️⃣ ENQUEUE SCRIPTS
--------------------------------------------------*/
function blog_tracker_admin_scripts($hook)
{
    if ($hook !== 'toplevel_page_blog-tracker') return;

    wp_enqueue_style(
        'blog-tracker-admin-style',
        plugin_dir_url(__FILE__) . 'admin.css',
        [],
        time()
    );

    wp_enqueue_script('chart-js', 'https://cdn.jsdelivr.net/npm/chart.js', [], null, true);

    wp_enqueue_script(
        'blog-tracker-admin',
        plugin_dir_url(__FILE__) . 'admin.js',
        ['jquery', 'chart-js'],
        time(),
        true
    );

    wp_localize_script('blog-tracker-admin', 'blogTracker', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('blog_tracker_nonce')
    ]);
}
add_action('admin_enqueue_scripts', 'blog_tracker_admin_scripts');


/* -------------------------------------------------
   5️⃣ DASHBOARD UI
--------------------------------------------------*/
function blog_tracker_dashboard()
{
    global $wpdb;
    $table = $wpdb->prefix . 'blog_tracker';

    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table");
?>
    <div class="wrap">
        <h1>📊 Blog Visitor Dashboard</h1>

        <h2>Total Visits: <?php echo esc_html($total); ?></h2>

        <h3>Date Range & Blog Filter</h3>

        <input type="date" id="startDate">
        <input type="date" id="endDate">

        <select id="postSelect">
            <option value="">Select Blog</option>
            <?php
            $posts = get_posts([
                'post_type'      => 'post',
                'posts_per_page' => -1,
                'post_status'    => 'publish'
            ]);

            foreach ($posts as $post) {
                echo '<option value="' . esc_attr($post->ID) . '">'
                    . esc_html($post->post_title) .
                    '</option>';
            }
            ?>
        </select>

        <button class="button button-primary" id="filterBtn">Filter</button>

        <h3>Visitor Chart (All Blogs)</h3>
        <canvas id="visitorChart" height="100"></canvas>

        <hr>

        <h3 id="singlePostChartTitle" style="display:none;">
            Selected Blog Visitor Chart
        </h3>
        <p id="noVisitorMessage" style="display:none;"></p>
        <canvas id="singlePostChart" height="100" style="display:none;"></canvas>

        <hr>

        <h3>Export CSV</h3>
        <a href="<?php echo admin_url('admin-ajax.php?action=blog_tracker_export_csv'); ?>"
            class="button button-secondary">
            Download CSV
        </a>
    </div>
<?php
}


/* -------------------------------------------------
   6️⃣ AJAX: CHART DATA
--------------------------------------------------*/
add_action('wp_ajax_blog_tracker_chart_data', 'blog_tracker_chart_data');

function blog_tracker_chart_data()
{

    check_ajax_referer('blog_tracker_nonce', 'nonce');

    global $wpdb;
    $table = $wpdb->prefix . 'blog_tracker';

    $start = sanitize_text_field($_POST['start_date'] ?? '');
    $end   = sanitize_text_field($_POST['end_date'] ?? '');

    $where = "WHERE 1=1";

    if ($start && $end) {
        $where .= $wpdb->prepare(" AND DATE(visit_date) BETWEEN %s AND %s", $start, $end);
    }

    $results = $wpdb->get_results("
        SELECT DATE(visit_date) as visit_day, COUNT(*) as total
        FROM $table
        $where
        GROUP BY visit_day
        ORDER BY visit_day ASC
    ");

    $labels = [];
    $data   = [];

    foreach ($results as $row) {
        $labels[] = $row->visit_day;
        $data[]   = (int) $row->total;
    }

    wp_send_json([
        'labels' => $labels,
        'data'   => $data
    ]);
}

add_action('wp_ajax_blog_tracker_single_post_chart', 'blog_tracker_single_post_chart');

function blog_tracker_single_post_chart() {

    check_ajax_referer('blog_tracker_nonce', 'nonce');

    global $wpdb;
    $table = $wpdb->prefix . 'blog_tracker';

    $post_id = intval($_POST['post_id']);
    $start   = sanitize_text_field($_POST['start_date'] ?? '');
    $end     = sanitize_text_field($_POST['end_date'] ?? '');

    if (!$post_id) wp_send_json([]);

    $where = $wpdb->prepare("WHERE post_id = %d", $post_id);

    if ($start && $end) {
        $where .= $wpdb->prepare(" AND DATE(visit_date) BETWEEN %s AND %s", $start, $end);
    }

    $results = $wpdb->get_results("
        SELECT DATE(visit_date) as visit_day, COUNT(*) as total
        FROM $table
        $where
        GROUP BY visit_day
        ORDER BY visit_day ASC
    ");

    $labels = [];
    $data   = [];

    foreach ($results as $row) {
        $labels[] = $row->visit_day;
        $data[]   = (int) $row->total;
    }

    wp_send_json([
        'labels' => $labels,
        'data'   => $data
    ]);
}



/* -------------------------------------------------
   7️⃣ EXPORT CSV
--------------------------------------------------*/
add_action('wp_ajax_blog_tracker_export_csv', 'blog_tracker_export_csv');

function blog_tracker_export_csv()
{

    if (!current_user_can('manage_options')) return;

    global $wpdb;

    $tracker_table = $wpdb->prefix . 'blog_tracker';
    $posts_table   = $wpdb->prefix . 'posts';

    // Join posts table to get title
    $results = $wpdb->get_results("
        SELECT 
            bt.id,
            bt.post_id,
            p.post_title,
            bt.ip_address,
            bt.user_agent,
            bt.visit_date
        FROM $tracker_table bt
        LEFT JOIN $posts_table p 
            ON bt.post_id = p.ID
        ORDER BY bt.visit_date DESC
    ", ARRAY_A);

    if (empty($results)) {
        wp_die('No data available.');
    }

    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename=blog-tracker.csv');

    $output = fopen('php://output', 'w');

    // Add column headers
    fputcsv($output, [
        'ID',
        'Post ID',
        'Post Title',
        'IP Address',
        'User Agent',
        'Visit Date'
    ]);

    foreach ($results as $row) {
        fputcsv($output, $row);
    }

    fclose($output);
    exit;
}

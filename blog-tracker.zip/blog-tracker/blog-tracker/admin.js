jQuery(document).ready(function ($) {

    function loadChart(startDate = '', endDate = '') {

        $.post(blogTracker.ajax_url, {
            action: 'blog_tracker_chart_data',
            nonce: blogTracker.nonce,
            start_date: startDate,
            end_date: endDate
        }, function (response) {

            const ctx = document.getElementById('visitorChart').getContext('2d');

            if (window.visitorChartInstance) {
                window.visitorChartInstance.destroy();
            }

            window.visitorChartInstance = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: response.labels,
                    datasets: [{
                        label: 'Daily Visitors',
                        data: response.data,
                        borderWidth: 2,
                        fill: false
                    }]
                }
            });
        });
    }


function loadSinglePostChart(postId, blogName = '', startDate = '', endDate = '') {

    if (!postId) {
        $('#singlePostChart').hide();
        $('#singlePostChartTitle').hide();
        return;
    }

    $.post(blogTracker.ajax_url, {
        action: 'blog_tracker_single_post_chart',
        nonce: blogTracker.nonce,
        post_id: postId,
        start_date: startDate,
        end_date: endDate
    }, function (response) {

        if (!response.labels.length) {

    $('#singlePostChartTitle')
        .text(blogName + ' Blog Visitor Chart')
        .show();

    $('#singlePostChart').hide();

    $('#noVisitorMessage')
        .text('No visitor activity recorded for "' + blogName + '" during this period.')
        .show();

    return;
}

        $('#singlePostChartTitle')
            .text(blogName + ' Visitor Chart')
            .show();
            $('#noVisitorMessage').hide();

        $('#singlePostChart').show();

        const ctx = document.getElementById('singlePostChart').getContext('2d');

        if (window.singlePostChartInstance) {
            window.singlePostChartInstance.destroy();
        }

        window.singlePostChartInstance = new Chart(ctx, {
            type: 'line',
            data: {
                labels: response.labels,
                datasets: [{
                    label: 'Visitors',
                    data: response.data,
                    borderWidth: 2,
                    fill: false
                }]
            }
        });
    });
}

    // Initial load
    loadChart();


    // Filter button click
    $('#filterBtn').on('click', function () {

        const start = $('#startDate').val();
        const end   = $('#endDate').val();
        const post  = $('#postSelect').val();
         const blogName = $('#postSelect option:selected').text();

        loadChart(start, end);
       loadSinglePostChart(post, blogName, start, end);
    });

});

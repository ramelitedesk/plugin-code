<?php
/**
 * Plugin Name: Stripe Class Subscriptions
 * Description: Stripe subscriptions with dynamic products
 * Version: 1.0
 * Author: RKB
 * Text Domain: stripe-class-subscriptions
 * Domain Path: /languages
 * Requires at least: 5.0
 * Requires PHP: 7.4
 */



/**
 * FOLDER STRUCTURE:
 * 
 * stripe-class-subscriptions/
 * ├── stripe-class-subscriptions.php (main plugin file)
 * ├── includes/
 * │   ├── class-stripe-plugin.php
 * │   ├── class-stripe-subscription-handler.php
 * │   ├── class-stripe-shortcode.php
 * │   └── class-stripe-assets.php
 * ├── vendor/
 * │   └── autoload.php
 * └── config/
 *     └── stripe-config.php
 */

// ============================================
// FILE: stripe-class-subscriptions.php
// ============================================
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('SCS_VERSION', '1.0.0');
define('SCS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('SCS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('SCS_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Load configuration
require_once SCS_PLUGIN_DIR . 'config/stripe-config.php';

// Load Stripe library with conflict prevention
if (!class_exists('\Stripe\Stripe')) {
    $autoload_file = SCS_PLUGIN_DIR . 'vendor/autoload.php';
    if (file_exists($autoload_file)) {
        require_once $autoload_file;
    } else {
        add_action('admin_notices', function() {
            echo '<div class="error"><p><strong>Stripe Class Subscriptions:</strong> Stripe library not found. Please run <code>composer install</code> in the plugin directory.</p></div>';
        });
        return;
    }
}

// Autoload classes with unique prefix
spl_autoload_register(function ($class) {
    $prefix = 'SCS\\';
    $base_dir = SCS_PLUGIN_DIR . 'includes/';
    
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }
    
    $relative_class = substr($class, $len);
    $class_name = str_replace('_', '-', strtolower($relative_class));
    $file = $base_dir . 'class-' . $class_name . '.php';
    
    if (file_exists($file)) {
        require_once $file;
    }
});

// Initialize plugin
require_once SCS_PLUGIN_DIR . 'includes/class-stripe-plugin.php';

/**
 * Initialize the plugin
 */
function scs_init_plugin() {
    SCS\Stripe_Plugin::get_instance();
}
add_action('plugins_loaded', 'scs_init_plugin');

/**
 * Activation hook
 */
register_activation_hook(__FILE__, function() {
    // Check PHP version
    if (version_compare(PHP_VERSION, '7.4', '<')) {
        deactivate_plugins(SCS_PLUGIN_BASENAME);
        wp_die(__('This plugin requires PHP 7.4 or higher.', 'stripe-class-subscriptions'));
    }
    
    // Check if Stripe keys are set
    if (!defined('SCS_STRIPE_SECRET_KEY') || empty(SCS_STRIPE_SECRET_KEY)) {
        add_option('scs_activation_notice', 'stripe_keys_missing');
    }
});

/**
 * Deactivation hook
 */
register_deactivation_hook(__FILE__, function() {
    // Clean up transients
    delete_transient('scs_stripe_prices');
});

<?php

/**
 * Stripe Configuration
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 🔑 ADD YOUR STRIPE KEYS HERE
 * For production, consider using wp-config.php or environment variables
 */
if (!defined('SCS_STRIPE_SECRET_KEY')) {
    define('SCS_STRIPE_SECRET_KEY', 'sk_test_51SiSHPAKd6xmpSrbFR4H7l2Gt1zPfpeayYMWMUXLJlmv4Egp54goj94QpXC7QyQyvNEuj7BxSdai7CH00oQ39SuJ00tJVYAzzI');
}

if (!defined('SCS_STRIPE_PUBLISHABLE_KEY')) {
    define('SCS_STRIPE_PUBLISHABLE_KEY', 'pk_test_51SiSHPAKd6xmpSrbhmgEeKZ4GxF1CtBtrHRqE4mjVgNXjwFuZUEnpMjcHOB5lOf9cg76b7AMDHz5pUcrZXp6zUsi00wi33snyp');
}

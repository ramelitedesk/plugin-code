(function($) {
    'use strict';
    
    // Initialize Stripe
    const stripe = Stripe(scsConfig.stripeKey);
    
    /**
     * Handle subscription button click
     */
    $(document).on('click', '.scs-subscribe-btn', function(e) {
        e.preventDefault();
        
        const $btn = $(this);
        const classId = $btn.data('class-id');
        const $emailInput = $('#scs-email-' + classId);
        const email = $emailInput.val().trim();
        
        // Validate email
        if (!email || !isValidEmail(email)) {
            alert(scsConfig.i18n.emailRequired);
            $emailInput.focus();
            return;
        }
        
        // Prevent double submission
        if ($btn.prop('disabled')) {
            return;
        }
        
        // Update button state
        const originalText = $btn.text();
        $btn.text(scsConfig.i18n.processing)
            .prop('disabled', true)
            .addClass('processing');
        
        // Prepare data
        const formData = new FormData();
        formData.append('action', 'scs_stripe_subscribe');
        formData.append('nonce', $btn.data('nonce'));
        formData.append('title', $btn.data('title'));
        formData.append('image', $btn.data('image'));
        formData.append('price', $btn.data('price'));
        formData.append('description', $btn.data('description'));
        formData.append('time', $btn.data('time'));
        formData.append('email', email);
        
        // Make AJAX request
        fetch(scsConfig.ajaxUrl, {
            method: 'POST',
            body: formData,
            credentials: 'same-origin'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success && data.data.id) {
                // Redirect to Stripe Checkout
                return stripe.redirectToCheckout({
                    sessionId: data.data.id
                });
            } else {
                throw new Error(data.data.message || scsConfig.i18n.error);
            }
        })
        .then(result => {
            if (result && result.error) {
                alert(result.error.message);
                resetButton($btn, originalText);
            }
        })
        .catch(error => {
            console.error('Subscription error:', error);
            alert(error.message || scsConfig.i18n.error);
            resetButton($btn, originalText);
        });
    });
    
    /**
     * Reset button to original state
     */
    function resetButton($btn, originalText) {
        $btn.text(originalText)
            .prop('disabled', false)
            .removeClass('processing');
    }
    
    /**
     * Validate email format
     */
    function isValidEmail(email) {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }
    
})(jQuery);
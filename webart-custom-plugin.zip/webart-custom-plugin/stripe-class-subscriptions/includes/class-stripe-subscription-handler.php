<?php

namespace SCS;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Stripe_Subscription_Handler
{

    /**
     * Initialize hooks
     */
    public function init()
    {
        add_action('wp_ajax_scs_stripe_subscribe', [$this, 'handle_subscription']);
        add_action('wp_ajax_nopriv_scs_stripe_subscribe', [$this, 'handle_subscription']);
    }

    /**
     * Handle subscription AJAX request
     */
    public function handle_subscription()
    {
        // Verify nonce for security
        if (!check_ajax_referer('scs_stripe_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => 'Security verification failed.'], 403);
            return;
        }

        // Validate and sanitize inputs
        $title = isset($_POST['title']) ? sanitize_text_field(wp_unslash($_POST['title'])) : '';
        $price = isset($_POST['price']) ? absint($_POST['price']) : 0;
        $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';

        // Validate required fields
        if (empty($title) || empty($price) || empty($email)) {
            wp_send_json_error(['message' => 'Missing required fields.'], 400);
            return;
        }

        // Validate email
        if (!is_email($email)) {
            wp_send_json_error(['message' => 'Invalid email address.'], 400);
            return;
        }

        // Validate price range (prevent abuse)
        if ($price < 1 || $price > 999999) {
            wp_send_json_error(['message' => 'Invalid price amount.'], 400);
            return;
        }

        try {
            $customer = $this->get_or_create_customer($email);

            if ($customer) {
                $has_active = $this->check_active_subscription($customer->id, $title);
                if ($has_active) {
                    wp_send_json_error([
                        'message' => 'You already have an active subscription for this class.'
                    ], 409);
                    return;
                }
            }

            $price_id = $this->create_product_and_price($title, $price);
            $session = $this->create_checkout_session($email, $price_id);

            wp_send_json_success(['id' => $session->id]);
        } catch (\Stripe\Exception\ApiErrorException $e) {
            error_log('SCS Stripe API Error: ' . $e->getMessage());
            wp_send_json_error([
                'message' => 'Payment processing error. Please try again.'
            ], 500);
        } catch (\Exception $e) {
            error_log('SCS Error: ' . $e->getMessage());
            wp_send_json_error([
                'message' => 'An unexpected error occurred. Please try again.'
            ], 500);
        }
    }

    /**
     * Get existing customer or return null
     */
    private function get_or_create_customer($email)
    {
        $customers = \Stripe\Customer::all([
            'email' => $email,
            'limit' => 1
        ]);

        if (!empty($customers->data)) {
            return $customers->data[0];
        }

        return null;
    }

    /**
     * Check if customer has active subscription for the class
     */
    private function check_active_subscription($customer_id, $title)
    {
        $subscriptions = \Stripe\Subscription::all([
            'customer' => $customer_id,
            'status' => 'active',
            'limit' => 100
        ]);

        foreach ($subscriptions->data as $subscription) {
            foreach ($subscription->items->data as $item) {
                $product = \Stripe\Product::retrieve($item->price->product);

                if ($product->name === $title) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Create Stripe product and price
     */
    private function create_product_and_price($title, $amount)
    {
        $product = \Stripe\Product::create([
            'name' => sanitize_text_field($title),
        ]);

        $price = \Stripe\Price::create([
            'unit_amount' => absint($amount) * 100,
            'currency' => 'usd',
            'recurring' => ['interval' => 'month'],
            'product' => $product->id,
        ]);

        return $price->id;
    }

    /**
     * Create Stripe checkout session
     */
    private function create_checkout_session($email, $price_id)
    {
        // Sanitize URLs
        $success_url = esc_url_raw(site_url('/classes'));
        $cancel_url = esc_url_raw(site_url('/payment-cancelled'));

        $session = \Stripe\Checkout\Session::create([
            'mode' => 'subscription',
            'customer_email' => sanitize_email($email),
            'line_items' => [[
                'price' => $price_id,
                'quantity' => 1,
            ]],
            'success_url' => $success_url,
            'cancel_url' => $cancel_url,
        ]);

        return $session;
    }
}

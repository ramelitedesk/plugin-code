<?php

namespace SCS;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Stripe_Assets
{

    /**
     * Initialize hooks
     */
    public function init()
    {
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
    }

    /**
     * Enqueue scripts and styles
     */
    public function enqueue_scripts()
    {
        // Enqueue Stripe.js with SRI (Subresource Integrity) for security
        wp_enqueue_script(
            'scs-stripe-js',
            'https://js.stripe.com/v3/',
            [],
            null,
            true
        );

        // Enqueue custom script
        wp_enqueue_script(
            'scs-subscription-handler',
            SCS_PLUGIN_URL . 'assets/js/subscription-handler.js',
            ['scs-stripe-js', 'jquery'],
            SCS_VERSION,
            true
        );

        // Localize script with secure data
        wp_localize_script('scs-subscription-handler', 'scsConfig', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'stripeKey' => SCS_STRIPE_PUBLISHABLE_KEY,
            'i18n' => [
                'emailRequired' => __('Please enter your email', 'stripe-class-subscriptions'),
                'processing' => __('Processing...', 'stripe-class-subscriptions'),
                'error' => __('Something went wrong. Please try again.', 'stripe-class-subscriptions'),
                'proceedPayment' => __('Proceed to payment', 'stripe-class-subscriptions')
            ]
        ]);
    }
}

<?php

namespace SCS;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Stripe_Plugin
{

    private static $instance = null;
    private $subscription_handler;
    private $shortcode;
    private $assets;

    /**
     * Private constructor (Singleton pattern)
     */
    private function __construct()
    {
        $this->init_stripe();
        $this->load_dependencies();
        $this->init_hooks();
    }

    /**
     * Prevent cloning
     */
    private function __clone() {}

    /**
     * Prevent unserialization
     */
    public function __wakeup()
    {
        throw new \Exception("Cannot unserialize singleton");
    }

    /**
     * Get singleton instance
     */
    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Initialize Stripe with error handling
     */
    private function init_stripe()
    {
        try {
            if (class_exists('\Stripe\Stripe')) {
                \Stripe\Stripe::setApiKey(SCS_STRIPE_SECRET_KEY);
                \Stripe\Stripe::setAppInfo(
                    'WordPress Stripe Class Subscriptions',
                    SCS_VERSION,
                    site_url()
                );
            }
        } catch (\Exception $e) {
            error_log('Stripe Class Subscriptions: Failed to initialize Stripe - ' . $e->getMessage());
        }
    }

    /**
     * Load plugin dependencies
     */
    private function load_dependencies()
    {
        require_once SCS_PLUGIN_DIR . 'includes/class-stripe-subscription-handler.php';
        require_once SCS_PLUGIN_DIR . 'includes/class-stripe-shortcode.php';
        require_once SCS_PLUGIN_DIR . 'includes/class-stripe-assets.php';

        $this->subscription_handler = new Stripe_Subscription_Handler();
        $this->shortcode = new Stripe_Shortcode();
        $this->assets = new Stripe_Assets();
    }

    /**
     * Initialize hooks
     */
    private function init_hooks()
    {
        $this->subscription_handler->init();
        $this->shortcode->init();
        $this->assets->init();

        // Admin notices
        add_action('admin_notices', [$this, 'admin_notices']);
    }

    /**
     * Display admin notices
     */
    public function admin_notices()
    {
        $notice = get_option('scs_activation_notice');

        if ($notice === 'stripe_keys_missing') {
            echo '<div class="notice notice-warning is-dismissible">';
            echo '<p><strong>Stripe Class Subscriptions:</strong> Please configure your Stripe API keys in the config file.</p>';
            echo '</div>';
            delete_option('scs_activation_notice');
        }
    }
}

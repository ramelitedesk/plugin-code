<?php

namespace SCS;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Stripe_Shortcode
{

    /**
     * Initialize shortcode
     */
    public function init()
    {
        add_shortcode('class_subscription', [$this, 'render_shortcode']);
    }

    /**
     * Render shortcode
     */
    public function render_shortcode($atts)
    {
        $atts = shortcode_atts([
            'class_id' => get_the_ID(),
            'title' => '',
            'price' => '',
            'hours' => '',
            'description' => ''
        ], $atts, 'class_subscription');

        $class_id = absint($atts['class_id']);
        $class_post = get_post($class_id);

        if (!$class_post || $class_post->post_status !== 'publish') {
            return '<p>' . esc_html__('Class not found.', 'stripe-class-subscriptions') . '</p>';
        }

        $data = $this->get_class_data($atts, $class_post, $class_id);

        return $this->render_subscription_form($data);
    }

    /**
     * Get class data with proper sanitization
     */
    private function get_class_data($atts, $class_post, $class_id)
    {
        $title = !empty($atts['title']) ? sanitize_text_field($atts['title']) : sanitize_text_field($class_post->post_title);

        $description = !empty($atts['description'])
            ? sanitize_textarea_field($atts['description'])
            : (function_exists('get_field') ? get_field('description', $class_id) : '');

        $price = !empty($atts['price']) ? absint($atts['price']) : (function_exists('get_field') ? absint(get_field('price', $class_id)) : 0);
        $time  = !empty($atts['hours']) ? sanitize_text_field($atts['hours']) : (function_exists('get_field') ? sanitize_text_field(get_field('time', $class_id)) : '');

        $image_url = '';
        if (function_exists('get_field')) {
            $image = get_field('image', $class_id);
            $image_url = is_array($image) && isset($image['url']) ? esc_url($image['url']) : '';
        }

        if (empty($description)) {
            $description = wp_trim_words(wp_strip_all_tags($class_post->post_content), 20, '...');
        }

        return [
            'class_id' => $class_id,
            'title' => $title,
            'description' => $description,
            'price' => $price,
            'time' => $time,
            'image_url' => $image_url
        ];
    }

    /**
     * Render subscription form with security measures
     */
    private function render_subscription_form($data)
    {
        $nonce = wp_create_nonce('scs_stripe_nonce');

        ob_start(); ?>

        <div class="scs-subscription-form" data-class-id="<?php echo esc_attr($data['class_id']); ?>">
            <input type="email"
                placeholder="<?php echo esc_attr__('Your email', 'stripe-class-subscriptions'); ?>"
                id="scs-email-<?php echo esc_attr($data['class_id']); ?>"
                class="scs-email-input"
                required
                style="width:100%;padding:10px;margin:10px 0;border:1px solid #ddd;border-radius:6px;">

            <button
                type="button"
                class="btn-orange scs-subscribe-btn"
                data-nonce="<?php echo esc_attr($nonce); ?>"
                data-title="<?php echo esc_attr($data['title']); ?>"
                data-image="<?php echo esc_attr($data['image_url']); ?>"
                data-price="<?php echo esc_attr($data['price']); ?>"
                data-description="<?php echo esc_attr(wp_strip_all_tags($data['description'])); ?>"
                data-time="<?php echo esc_attr($data['time']); ?>"
                data-class-id="<?php echo esc_attr($data['class_id']); ?>">
                <?php echo esc_html__('Proceed to payment', 'stripe-class-subscriptions'); ?>
            </button>
        </div>

<?php return ob_get_clean();
    }
}

<?php
namespace Image_Converter_MVC\Controllers;

use Image_Converter_MVC\Models\ConversionModel;
use Image_Converter_MVC\Views\admin_page;

class AdminController {
    public function add_admin_menu_page() {
        add_menu_page(
            'Convert Webp',
            'Convert Webp',
            'manage_options',
            'convert-webp',
            [$this, 'display_admin_page'],
            'dashicons-format-image',
            20
        );
    }

    public function enqueue_scripts($hook) {
        if ($hook !== 'toplevel_page_convert-webp') return;

        wp_enqueue_style('wct-toggle-style', plugin_dir_url(dirname(__FILE__, 2)) . 'assets/css/toggle-style.css');
        wp_enqueue_script('convert-webp-js', plugin_dir_url(dirname(__FILE__, 2)) . 'assets/js/bulk-convert.js', ['jquery'], '1.0', true);
        wp_localize_script('convert-webp-js', 'convertWebp', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('convert_webp_nonce'),
        ]);
    }

    public function display_admin_page() {
        require_once plugin_dir_path(dirname(__FILE__)) . 'Views/admin-page.php';
    }
    
    public function register_settings() {
        register_setting('webp_converter_options_group', 'webp_converter_enable_on_upload');
    }

    public function ajax_bulk_convert() {
        check_ajax_referer('convert_webp_nonce', 'security');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permission denied.');
        }

        ob_start();
        ConversionModel::bulk_convert_all_images();
        $output = ob_get_clean();
        wp_send_json_success($output);
    }
}


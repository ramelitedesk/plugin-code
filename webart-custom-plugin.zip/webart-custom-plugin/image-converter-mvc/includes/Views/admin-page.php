<!-- plugin folder structure
/wp-content/plugins/
└── image-converter-mvc/
    ├── image-converter-mvc.php (main plugin file)
    ├── assets/
    │   └── css/
    │       └── toggle-style.css
    │   └── js/
    │       └── bulk-convert.js
    ├── includes/
    │   ├── Controllers/
    │   │   ├── AdminController.php
    │   ├── Models/
    │   │   ├── ConversionModel.php
    │   ├── Views/
    │   │   ├── admin-page.php
    │   ├── ImageConverter.php (main plugin class)
    
-->

<div class="wrap">
    <h1>Image Converter</h1>

    <h2>Bulk Convert All Existing Images</h2>
    <p>Click the button below to convert all existing JPEG and PNG images in your media library to WebP format. This process may take some time depending on the number of images.</p>
    <button id="convert-btn" class="button button-primary">Convert All</button>
    <div id="convert-loader" style="display:none;margin-top:10px;">⏳ Converting... Please wait.</div>
    <div id="convert-result" style="margin-top:20px;"></div>

    <hr style="margin: 40px 0;">

    <h2>Automatic On-Upload Conversion</h2>
    <form method="post" action="options.php">
        <?php settings_fields('webp_converter_options_group'); ?>
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row">Enable Automatic WebP Conversion on Upload</th>
                    <td>
                        <label class="switch">
                            <input type="checkbox" name="webp_converter_enable_on_upload" value="1" <?php checked(get_option('webp_converter_enable_on_upload'), '1'); ?>>
                            <span class="slider round"></span>
                        </label>
                        <p class="description">If enabled, all newly uploaded JPEG and PNG images will be automatically converted to WebP.</p>
                    </td>
                </tr>
            </tbody>
        </table>
        <?php submit_button('Save Settings'); ?>
    </form>
</div>
<?php

namespace Image_Converter_MVC;

use Image_Converter_MVC\Controllers\AdminController;
use Image_Converter_MVC\Models\ConversionModel;

class ImageConverter
{
    public function run()
    {
        $this->define_admin_hooks();
    }

    private function define_admin_hooks()
    {
        $admin_controller = new AdminController();

        // Admin menu and page.
        add_action('admin_menu', [$admin_controller, 'add_admin_menu_page']);
        add_action('admin_enqueue_scripts', [$admin_controller, 'enqueue_scripts']);

        // Register settings for the toggle.
        add_action('admin_init', [$admin_controller, 'register_settings']);

        // AJAX handler for bulk conversion.
        add_action('wp_ajax_webp_converter', [$admin_controller, 'ajax_bulk_convert']);

        // Filter for automatic on-upload conversion.
        add_filter('wp_handle_upload', [ConversionModel::class, 'convert_on_upload'], 10, 2);

        // Action for deleting WebP files.
        add_action('delete_attachment', [ConversionModel::class, 'delete_webp_on_attachment_delete']);
    }
}

<?php

namespace Image_Converter_MVC\Models;

class ConversionModel
{
    /**
     * Converts a single image file during upload if the setting is enabled.
     *
     * @param array $file
     * @return array
     */
    public static function convert_on_upload($file)
    {
        if (get_option('webp_converter_enable_on_upload') !== '1') {
            return $file;
        }

        $extension = strtolower(pathinfo($file['file'], PATHINFO_EXTENSION));
        if (!in_array($extension, ['jpg', 'jpeg', 'png'])) {
            return $file;
        }

        if (!function_exists('imagewebp')) {
            return $file;
        }

        $new_filename = pathinfo($file['file'], PATHINFO_FILENAME) . '.webp';
        $new_filepath = str_replace(basename($file['file']), $new_filename, $file['file']);

        $image_resource = null;
        if (in_array($extension, ['jpg', 'jpeg'])) {
            $image_resource = imagecreatefromjpeg($file['file']);
        } elseif ('png' === $extension) {
            $image_resource = imagecreatefrompng($file['file']);
            imagepalettetotruecolor($image_resource);
            imagealphablending($image_resource, true);
            imagesavealpha($image_resource, true);
        }

        if ($image_resource) {
            imagewebp($image_resource, $new_filepath, 80);
            imagedestroy($image_resource);

            $file['file'] = $new_filepath;
            $file['url'] = str_replace(basename($file['url']), $new_filename, $file['url']);
            $file['type'] = 'image/webp';
        }

        return $file;
    }

    /**
     * Converts all existing JPEG and PNG images to WebP format.
     */
    public static function bulk_convert_all_images()
    {
        $args = [
            'post_type'      => 'attachment',
            'post_mime_type' => ['image/jpeg', 'image/png'],
            'numberposts'    => -1,
            'post_status'    => 'inherit',
        ];
        $images = get_posts($args);

        if (empty($images)) {
            echo 'No images found to convert.';
            return;
        }

        $converted_count = 0;
        foreach ($images as $image) {
            $file_path = get_attached_file($image->ID);
            if (false === $file_path) {
                continue;
            }

            $file_info = pathinfo($file_path);
            $extension = strtolower($file_info['extension']);
            $new_file_path = $file_info['dirname'] . '/' . $file_info['filename'] . '.webp';

            if (file_exists($new_file_path)) {
                echo "Skipping {$file_info['basename']}: WebP version already exists.<br>";
                continue;
            }

            $image_resource = null;
            if ('png' === $extension) {
                $image_resource = imagecreatefrompng($file_path);
            } elseif (in_array($extension, ['jpg', 'jpeg'])) {
                $image_resource = imagecreatefromjpeg($file_path);
            }

            if ($image_resource) {
                if ('png' === $extension) {
                    imagepalettetotruecolor($image_resource);
                    imagealphablending($image_resource, true);
                    imagesavealpha($image_resource, true);
                }

                if (imagewebp($image_resource, $new_file_path, 80)) {
                    echo "Converted {$file_info['basename']} to WebP successfully.<br>";
                    $converted_count++;

                    //replace all dynamic images into it's converted webp format image
                    $metadata = wp_generate_attachment_metadata($image->ID, $new_file_path);

                    if (!is_wp_error($metadata)) {
                        $metadata['file'] = str_replace(basename($file_path), basename($new_file_path), $metadata['file']);

                        wp_update_post([
                            'ID'             => $image->ID,
                            'post_mime_type' => 'image/webp',
                        ]);

                        wp_update_attachment_metadata($image->ID, $metadata);

                        update_post_meta($image->ID, '_wp_attached_file', str_replace(basename($file_path), basename($new_file_path), get_post_meta($image->ID, '_wp_attached_file', true)));
                    } else {
                        echo "Failed to generate metadata for {$file_info['basename']}.<br>";
                    }
                } else {
                    echo "Failed to convert {$file_info['basename']} to WebP.<br>";
                }
                imagedestroy($image_resource);
            } else {
                echo "Could not create image resource for {$file_info['basename']}.<br>";
            }
        }
        echo "<p>Bulk conversion complete. Converted $converted_count images to WebP.</p>";
    }

    /**
     * Deletes the corresponding WebP file when an attachment is removed.
     *
     * @param int $post_id
     */
    public static function delete_webp_on_attachment_delete($post_id)
    {
        $file_path = get_attached_file($post_id);
        if ($file_path) {
            $webp_path = str_replace(['.jpeg', '.jpg', '.png'], '.webp', $file_path);
            if (file_exists($webp_path)) {
                @unlink($webp_path);
            }
        }
    }
}

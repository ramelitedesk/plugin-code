<?php
/**
 * Plugin Name: Image Converter MVC
 * Description: Convert all images in the media library to WebP and automatically convert new uploads with a toggle.
 * Version: 1.1
 * Author: rk
 */

if (!defined('ABSPATH')) {
    exit;
}

// Manually include the main plugin class files to ensure they are available
// when the plugin is initialized.
require_once plugin_dir_path(__FILE__) . 'includes/ImageConverter.php';
require_once plugin_dir_path(__FILE__) . 'includes/Controllers/AdminController.php';
require_once plugin_dir_path(__FILE__) . 'includes/Models/ConversionModel.php';

// Initialize the plugin on a reliable hook to ensure all files are loaded.
function run_image_converter_mvc() {
    $plugin = new Image_Converter_MVC\ImageConverter();
    $plugin->run();
}
add_action('plugins_loaded', 'run_image_converter_mvc');


jQuery(document).ready(function($) {
    $('#convert-btn').on('click', function() {
        $('#convert-btn').prop('disabled', true);
        $('#convert-loader').show();
        $('#convert-result').html('');

        $.ajax({
            url: convertWebp.ajax_url,
            type: 'POST',
            data: {
                action: 'webp_converter',
                security: convertWebp.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('#convert-result').html(response.data);
                } else {
                    $('#convert-result').html('<p style="color:red;">Error: ' + (response.data || 'Unknown error occurred.') + '</p>');
                }
            },
            error: function() {
                $('#convert-result').html('<p style="color:red;">An error occurred during the AJAX request.</p>');
            },
            complete: function() {
                $('#convert-btn').prop('disabled', false);
                $('#convert-loader').hide();
            }
        });
    });
});

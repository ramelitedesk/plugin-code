<?php

/**
 * Plugin Name: Stripe Class Subscriptions
 * Description: Stripe subscriptions with dynamic products
 * Version: 1.0
 */

if (!defined('ABSPATH')) exit;

/**
 * 🔑 ADD YOUR STRIPE KEYS HERE
 */
define('STRIPE_SECRET_KEY', 'sk_test_51SiSHPAKd6xmpSrbFR4H7l2Gt1zPfpeayYMWMUXLJlmv4Egp54goj94QpXC7QyQyvNEuj7BxSdai7CH00oQ39SuJ00tJVYAzzI');
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_51SiSHPAKd6xmpSrbhmgEeKZ4GxF1CtBtrHRqE4mjVgNXjwFuZUEnpMjcHOB5lOf9cg76b7AMDHz5pUcrZXp6zUsi00wi33snyp');

/**
 * ✅ LOAD STRIPE FROM VENDOR
 */
if (!class_exists('\Stripe\Stripe')) {
    require_once plugin_dir_path(__FILE__) . 'vendor/autoload.php';
}
\Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);

/**
 * ✅ CREATE PRODUCT + PRICE AUTOMATICALLY
 */
function stripe_create_price($title, $amount)
{

    $product = \Stripe\Product::create([
        'name' => $title,
    ]);

    $price = \Stripe\Price::create([
        'unit_amount' => $amount * 100,
        'currency' => 'usd',
        'recurring' => ['interval' => 'month'],
        'product' => $product->id,
    ]);

    return $price->id;
}

/**
 * ✅ AJAX SUBSCRIPTION
 */
add_action('wp_ajax_stripe_subscribe', 'stripe_subscribe');
add_action('wp_ajax_nopriv_stripe_subscribe', 'stripe_subscribe');

function stripe_subscribe()
{

    $title = sanitize_text_field($_POST['title']);
    $price = intval($_POST['price']);
    $email = sanitize_email($_POST['email']);

    // 🔍 Check existing Stripe customer
    $customers = \Stripe\Customer::all([
        'email' => $email,
        'limit' => 1
    ]);

    if (!empty($customers->data)) {
        $customer = $customers->data[0];

        // 🔍 Check active subscriptions
        $subscriptions = \Stripe\Subscription::all([
            'customer' => $customer->id,
            'status' => 'active'
        ]);

        foreach ($subscriptions->data as $subscription) {
            foreach ($subscription->items->data as $item) {
                $product = \Stripe\Product::retrieve($item->price->product);

                // 🚫 SAME CLASS ALREADY ACTIVE
                if ($product->name === $title) {
                    wp_send_json([
                        'error' => 'You already have an active subscription for this class.'
                    ]);
                }
            }
        }

        // $subscriptions = \Stripe\Subscription::all([
        //     'customer' => $customer->id,
        //     'status' => 'all'
        // ]);

        // foreach ($subscriptions->data as $subscription) {
        //     if (in_array($subscription->status, ['active', 'past_due', 'unpaid'])) {
        //         foreach ($subscription->items->data as $item) {
        //             $product = \Stripe\Product::retrieve($item->price->product);
        //             if ($product->name === $title) {
        //                 wp_send_json([
        //                     'error' => 'You already have a subscription for this class.'
        //                 ]);
        //             }
        //         }
        //     }
        // }
    }

    // ✅ Create product & price
    $product = \Stripe\Product::create([
        'name' => $title,
    ]);

    $priceObj = \Stripe\Price::create([
        'unit_amount' => $price * 100,
        'currency' => 'usd',
        'recurring' => ['interval' => 'month'],
        'product' => $product->id,
    ]);

    // ✅ Create checkout session
    $session = \Stripe\Checkout\Session::create([
        'mode' => 'subscription',
        'customer_email' => $email,
        'line_items' => [[
            'price' => $priceObj->id,
            'quantity' => 1,
        ]],
        'success_url' => site_url('/classes'),
        'cancel_url' => site_url('/payment-cancelled'),
    ]);

    wp_send_json(['id' => $session->id]);
}

/**
 * ✅ LOAD STRIPE JS
 */
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_script('stripe-js', 'https://js.stripe.com/v3/');
});

/**
 * ✅ SHORTCODE FOR CLASS CARD
 */
add_shortcode('class_subscription', function ($atts) {

    $atts = shortcode_atts([
        'class_id' => get_the_ID(),
        'title' => '',
        'price' => '',
        'hours' => '',
        'description' => ''
    ], $atts);

    $class_id = $atts['class_id'];
    $class_post = get_post($class_id);

    if (!$class_post || $class_post->post_status !== 'publish') {
        return '<p>Class not found.</p>';
    }

    // Get post data
    $title = !empty($atts['title']) ? $atts['title'] : $class_post->post_title;
    $description = !empty($atts['description'])
        ? $atts['description']
        : get_field('description', $class_id);

    $price = !empty($atts['price']) ? $atts['price'] : get_field('price', $class_id);
    $time  = !empty($atts['hours']) ? $atts['hours'] : get_field('time', $class_id);

    $image = get_field('image', $class_id);
    $image_url = is_array($image) ? $image['url'] : '';

    if (empty($description)) {
        $description = wp_trim_words($class_post->post_content, 20, '...');
    }

    ob_start(); ?>

    <input type="email"
        placeholder="Your email"
        id="email-<?php echo esc_attr($class_id); ?>"
        required
        style="width:100%;padding:10px;margin:10px 0;border:1px solid #ddd;border-radius:6px;">

    <button
        type="button"
        class="btn-orange"
        onclick="stripeSubscribe(this,
                '<?php echo esc_js($title); ?>',
                '<?php echo esc_js($image_url); ?>',
                '<?php echo esc_js($price); ?>',
                '<?php echo esc_js(wp_strip_all_tags($description)); ?>',
                '<?php echo esc_js($time); ?>',
                document.getElementById('email-<?php echo esc_attr($class_id); ?>').value
            )">
        Proceed to payment
    </button>

<?php return ob_get_clean();
});

/**
 * ✅ FOOTER SCRIPT
 */
add_action('wp_footer', function () { ?>
    <script>
        const stripe = Stripe('<?php echo STRIPE_PUBLISHABLE_KEY; ?>');

        function stripeSubscribe(btn, title, image, price, description, time, email) {
            if (!email) {
                alert('Please enter your email');
                return;
            }

            btn.innerText = 'Processing...';
            btn.disabled = true;
            btn.classList.add('processing');

            const data = new FormData();
            data.append('action', 'stripe_subscribe');
            data.append('title', title);
            data.append('image', image);
            data.append('price', price);
            data.append('description', description);
            data.append('time', time);
            data.append('email', email);

            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    body: data
                })
                .then(res => res.json())
                .then(data => {
                    if (data.error) {
                        alert(data.error);
                    } else {
                        stripe.redirectToCheckout({
                            sessionId: data.id
                        });
                    }
                })
                .catch(err => {
                    alert('Something went wrong. Please try again.');
                    btn.innerText = 'Proceed to payment';
                    btn.disabled = false;
                    btn.classList.remove('processing');
                });
        }
    </script>

<?php });

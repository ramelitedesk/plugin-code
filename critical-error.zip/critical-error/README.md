# WPD Critical Error Reporter

Finds out **which file and which plugin** caused a WordPress critical error, and shows it to you — in the dashboard when the dashboard works, and over a token-protected URL when it does not.

WordPress's white screen tells you that a critical error happened and nothing about which of your forty plugins caused it. The information exists — PHP knows the exact file and line — it simply is not shown to you, because printing raw paths and source code to visitors would be a disclosure problem. This plugin captures it, attributes it, and puts it somewhere safe.

---

## What you get

- **The name of the plugin or theme responsible.** Not "a plugin crashed" — the actual folder, so you can rename it over FTP and have the site back in thirty seconds.
- **The failing line, quoted in context**, with eight lines either side and the culprit highlighted.
- **The call stack**, for uncaught exceptions.
- **A recovery URL** that works when wp-admin will not open.
- **A clear button**, in both places.
- **A gate on the theme and plugin file editors** that refuses to save code which would crash the site — see below.
- Warnings and notices too, if you want them — off by default, because they would bury the fatal you came to find.

---

## The theme file editor

**Appearance → Theme File Editor** is where most self-inflicted white screens come from: a snippet gets pasted into `functions.php`, **Update File** gets pressed, and the site is gone — along with the dashboard you would use to undo it.

WordPress is not defenceless here. Since 4.9 it writes the file, makes a loopback request to see whether the site still answers, and puts the old content back if it does not. Two things it does not do:

1. **Show you the code.** It reports a line number, a filename and a message. Finding the line it means is left to you.
2. **Work without a loopback.** Local installs, staging behind basic auth, hosts that block requests to themselves — when the loopback cannot run, WordPress reverts the change and says *"Unable to communicate back with site."* That diagnoses nothing, and your edit is gone anyway.

So this checks the code **before anything is written**, with no loopback involved:

| Caught | How |
| --- | --- |
| Syntax errors — missing semicolon, unclosed brace, a stray `<?php` in a pasted snippet | A real PHP parse via `token_get_all( …, TOKEN_PARSE )`, which applies the language's own grammar |
| `Cannot redeclare` — the same snippet pasted in twice, or a function name another plugin already owns | Top-level declarations read from the token stream, checked against what is actually loaded |
| `Call to undefined function` / `Class not found` — the runtime fatal that is perfectly valid syntax | Every name the file uses, resolved against the running site: core, every active plugin, the theme, and the file's own `require`d files |
| `TypeError: Return value must be of type …` | Literal `return`s checked against the declared return type, modelling PHP's coercion rather than comparing names |
| `Call to undefined method` / `Non-static method … cannot be called statically` / `Cannot assign … to property` | The members of classes declared in the same file, where the whole set of them can be read |
| `Call to a member function … on null` | A method called on a variable its own scope never gives a value to — the missing `global $wpdb;` |
| `Failed opening required …` | An unconditional `require` whose path resolves in full and points at nothing |

If any of them fails, **the save does not happen.** Nothing is written to disk, nothing is lost from the editor, and the notice shows the offending lines with the failing one marked — and puts your cursor on it.

The check runs twice, on purpose. The browser runs it before submitting, which is the version that gives a good answer: it never loses your work and it can move your cursor. The server runs it again on `admin_init`, before `wp_edit_theme_plugin_file()` is reached — and that one is not optional. JavaScript off, `admin-ajax.php` unreachable, a request made by something that is not the editor: the file is still never written.

### The one that is valid PHP and still kills the site

```php
function test_custom_plugin_fatal_error() {
    undefined_test_function();
}

add_action( 'init', 'test_custom_plugin_fatal_error' );
```

Nothing is wrong with that syntactically. It parses, `php -l` accepts it, and the dashboard is blank on the next request. A parser cannot help you here, because there is nothing to parse wrong.

So the check resolves names instead of grammar. It runs inside a fully booted WordPress, where `function_exists()` gives the same answer PHP will give when the file loads — and it reads the file well enough to know whether the call is one that actually runs:

The question is never only *is this name missing* — it is *does this code run*. So calls are followed. The top level of the file runs by definition; whatever it calls runs; whatever that calls runs; and a method runs if something makes the object and calls it.

| Where the problem is | What happens |
| --- | --- |
| At the top of the file, so including it runs it | **The save is stopped**, and the lines are shown |
| In a function the file calls — directly, or three calls down | **The save is stopped** |
| In a method reached through `new Thing()`, `$thing->run()`, `Thing::run()` or `$this->run()` | **The save is stopped** |
| In a function the file hooks by name, or a closure handed to `add_action()` | **The save is stopped** — scheduled code, not dead code |
| Anywhere nothing appears to reach, or in a file whose loading depends on something outside it | A **warning** with the same detail, and **Save anyway** next to it |

All nine of these are refused, and not one of them is a parse error:

```php
function test_type_error(): int { return "invalid integer"; }
test_type_error();                       // TypeError

function test_fatal_error() { undefined_function_for_testing(); }
test_fatal_error();                      // Call to undefined function

class TestCriticalError {
    public function run() { return new ClassThatDoesNotExist(); }
}
$test = new TestCriticalError();
$test->run();                            // Class not found

class TestClass {
    public int $value;
    public function run() { return "OK"; }
}
$test = new TestClass();
$test->value = "invalid";                // Cannot assign string to property … of type int
$test->missingMethod();                  // Call to undefined method
TestClass::run();                        // Non-static method cannot be called statically

add_action( 'init', function () {
    $wpdb->some_method();                 // Call to a member function … on null
} );

function wp_test_function( $value ): string { return $value; }
wp_test_function( [] );                  // Return value must be of type string, array returned

require_once __DIR__ . '/file-that-does-not-exist.php';   // Failed opening required
```

### What it will not vouch for

A class is only judged when its whole membership can be read from the file being saved. Extend anything, implement an interface, pull in a trait, or declare `__call`, `__callStatic` or `__set`, and the checks go quiet — an inherited method is not a missing one.

`$this->method()` is **never** checked for existence, whatever the class looks like. `$this` is whatever the object turned out to be, which may be a subclass in a file that has not been written yet. Sweeping WordPress core produced 128 findings of exactly that shape before this rule existed, and every one of them was correct code.

A property that was never declared is left alone too: assigning to one is deprecated in PHP 8.2, and a check that stops a save over a deprecation is a check in the way.

A variable counts as having a value if it appears anywhere in its scope in any position other than `$var->something` — assignment, a parameter, `global`, `use`, `foreach`, or being passed to something like `preg_match()` that fills it in by reference. What is left is a variable used *only* as the object of a method call and never given a value at all.

A `require` is only refused when it is unconditional. Every optional drop-in in WordPress — `db.php`, `object-cache.php`, `sunrise.php` — is loaded inside an `if`, and sweeping the installation turned up thirteen of them before that rule and the `file_exists()` one existed.

A false positive that blocks is worse than a miss, so anything it cannot settle by reading the file — a namespace, a `use` import, a deactivated plugin, a file WordPress does not load by itself — warns rather than refuses. Typos get a *did you mean* against the names that do exist.

**PHP is not strict about types, and that is the difficulty.** `function f(): int { return "5"; }` returns `int(5)` and is perfectly fine; so is `function f(): string { return 5; }`. A check that compared type names would refuse both. What is modelled is coercion, so only a value PHP genuinely cannot convert is reported — and only for a literal written directly in the body, never for an expression, and never for a `return` inside a branch that may not be taken.

**Includes are followed, not surrendered to.** The easy rule would be "this file includes something, so the missing name might be in there — warn". It is even true, and it is useless: every `functions.php` ends with a run of `require get_template_directory() . '/inc/…'` lines, so that rule disarms the check on the one file it exists for. Instead the include paths are worked out — literals, `__DIR__`, `dirname( __FILE__ )`, defined constants, WordPress's own directory functions — and those files are read for what they declare, two levels deep. Only a path that cannot be worked out at all, such as one built from a variable, falls back to warning.

It still cannot see intent: a misspelled hook name, a function called before it is defined, a wrong query. Those reach WordPress's loopback — and when the loopback reverts the save, this fills in what WordPress leaves out and shows the code around the failing line, taken from the crash it recorded inside that very request.

### What happens when the browser check cannot run

The save is refused on the server instead, with the same diagnosis, the same excerpt, and your code printed back on the page so that nothing is lost. WordPress's own loopback protection is still behind that, untouched.

Only *certain* fatals are refused this way. A warning is a statement about code whose reachability could not be determined, and refusing a save over one would make the browser's **Save anyway** button a lie — so warnings never block, in either place.

Switch it off under **Tools → Critical Errors → What gets captured**. If `DISALLOW_FILE_EDIT` is set on your site the editors do not exist at all, which is the safer configuration; leave it that way.

---

## Getting back in when the dashboard is gone

The recovery link has an awkward property worth stating plainly: **you get it from the dashboard, and the dashboard is what a critical error takes away.** If you never saved it, and you have no FTP and no database client, a token is not much use. So there are three ways in, and only the first one needs anything saved in advance.

| | Needs | Works when |
| --- | --- | --- |
| `?wpdce-report=TOKEN` | The link, saved beforehand | Always — no login, no database, nothing |
| `?wpdce-report=1` | Being signed in as an administrator in that browser | A fatal in a theme, or in any plugin loading after this one |
| The email WordPress sends | Nothing | Whenever mail leaves your server |

The second is the answer to *"I did not save the link."* Your login cookie is already in the browser you are holding, so it is checked instead of a token; to anyone else the address is a plain 404. It works because the report is rendered from a plugin, which WordPress loads well before it loads the theme{Q}s `functions.php` — the file the theme editor writes, and therefore the file most likely to be the one crashing.

The third needs nothing at all. WordPress already emails the site administrator when a site fatals; both links are added to that email, so the way back arrives on its own.

**And the real answer is the one above this section:** none of it is needed if the save that would have broken the site is refused in the first place.

---

## Install

1. Copy the folder to `wp-content/plugins/critical-error/` and activate.
2. Go to **Tools → Critical Errors** and copy the recovery link somewhere outside the site. A password manager, not a note on the desktop. (If you skip this, you are not locked out — see above.)
3. **Install the must-use loader** — see below. Without it the plugin is blind to most crashes.

### The must-use loader is not optional

```bash
cp config/mu-loader.php wp-content/mu-plugins/wpd-critical-error-loader.php
```

WordPress loads regular plugins **in alphabetical order**, and a crash reporter can only report crashes that happen after it loads. As a regular plugin in a folder starting with `c`, it is blind to a fatal in anything alphabetically before it — which is most plugins.

Must-use plugins load before all of that. The admin screen shows a warning until this is in place.

Leave the plugin deactivated on the Plugins screen if you use the loader.

---

## When the dashboard will not open

This is the case the plugin exists for. The report is reachable without logging in:

```
https://example.com/?wpdce-report=YOUR_TOKEN
```

That is an unauthenticated endpoint that prints file paths and source code, so it is treated as hostile ground:

| Protection | Detail |
| --- | --- |
| Token | 64 hex characters from `random_bytes()` |
| Comparison | `hash_equals()` — no timing oracle |
| Throttle | 8 failures per IP per hour, counted **in a file** because the database may be what failed |
| Response without a token | Plain `404` — it does not admit the endpoint exists |
| Headers | `noindex, nofollow, noarchive`, `no-store` |

**Stronger still**, put the token in `wp-config.php`:

```php
define( 'WPDCE_RECOVERY_KEY', 'a-long-random-string' );
```

A constant cannot be read out of the database by SQL injection or an option dump, and it keeps working when the database itself is the thing that has failed.

Regenerate the link from **Tools → Critical Errors** once the site is healthy. The old one stops working immediately.

---

## Structure

```
critical-error/
├── wpd-critical-error.php        Bootstrap — registers the handler first, does nothing else early
├── includes/
│   ├── class-wpdce-settings.php  Settings, readable without a database
│   ├── class-wpdce-log.php       File-backed storage
│   ├── class-wpdce-handler.php   Capture and attribution
│   ├── class-wpdce-report.php    Token-gated recovery report
│   ├── class-wpdce-admin.php     Tools → Critical Errors
│   ├── class-wpdce-editor.php    The gate on the theme/plugin file editors
│   └── class-wpdce-runtime.php   Names resolved against the running site
├── views/
│   ├── admin.php                 Dashboard screen
│   └── report.php                Standalone recovery page
├── assets/
│   ├── admin.css
│   ├── editor.css
│   └── editor.js                 Blocks the save before it happens
├── config/mu-loader.php          Load before every regular plugin
└── tests/                        Runnable without WordPress
```

---

## Design notes

**Storage is a file, not an option.** The errors most worth capturing are the ones that take a site down, and a site that is down is often down *because* the database is unreachable — at which point `update_option()` cannot record the very failure you need to read afterwards.

**Repeats are folded into a count.** A warning inside a loop can fire ten thousand times in one request. Ten thousand identical rows are strictly less informative than one row with `× 10000` on it.

**Errors are passed onward, never swallowed.** The handler chains to whatever handler it displaced, and returns `false` when there was none, so PHP's own handling still runs and `WP_DEBUG_LOG`, Query Monitor and your host's error log all keep receiving everything. This plugin adds a record; it does not take one away.

**The exit code is preserved.** Installing an exception handler makes PHP consider the exception handled, and the process then exits `0` — a crashed script reporting success. WP-CLI, cron and deploy scripts read that status, so the handler explicitly restores PHP's normal outcome. This was a real bug during development, caught by the end-to-end test.

---

## Tests

```bash
cd critical-error/tests
php test.php          # 26 unit cases
php editor-test.php   # 51 cases on the file-editor gate
php runtime-test.php  # 148 cases on the runtime-fatal checks
php end-to-end.php    # crashes a real PHP process and checks the crash was recorded
```

No WordPress, no database, no PHPUnit.

`end-to-end.php` is the one that matters for capture. Every other test exercises the pieces; this one crashes a real process with a real undefined-function fatal and asserts that the record names the function, the file, the line, and quotes the failing source. It is the only claim that actually matters, and a unit test cannot make it.

`editor-test.php` is weighted towards the failure that would make the editor gate worse than useless. A false negative just means it added nothing — WordPress's loopback is still behind it. A **false positive** refuses to save code that was fine, cannot be worked around from the editor, and gets the whole plugin switched off. So "this must still save" is asserted as hard as "this must be caught": `function_exists()` guards, closures, anonymous classes, `::class`, methods, conditional declarations, a file re-saving its own functions, and braces inside strings, heredocs and comments.

`runtime-test.php` carries the same weighting for the undefined-name check, where the temptation to guess is strongest. Roughly half its cases are code that must go through untouched: method calls, variable functions, language constructs, `self`/`static`/`parent`, names inside strings, `function_exists()` guards, a function declared further down the same file. The rest divide what must be refused from what may only be warned about — and the difference between those two is the whole design.

---

## Honest limits

- **It cannot catch what happens before it loads.** Hence the must-use loader. Even then, a fatal in `wp-config.php` or in WordPress core before `mu-plugins` are read is out of reach — nothing running inside WordPress can catch that.
- **A parse error in a file is caught, but not always attributed usefully.** PHP reports the file it failed to compile, which is right, but there is no stack to explain who included it.
- **The editor gate reads code, not intent.** It catches code that will not compile, names that are already taken, and names that are not there at all. It cannot tell you that a hook name is misspelled, that your query is wrong, or that the function you called exists and does the wrong thing — those are behaviour, and WordPress's loopback is what catches them.
- **The undefined-name check answers for this request.** A name is resolved against what is loaded during the check, which is an admin request. Code that only ever runs on the front end, in a file WordPress does not load by itself, is reported as a warning rather than refused — the check knows what it cannot know.
- **It is not a monitoring service.** There are no alerts and no outbound requests. It records locally and waits for you to look.
- **The recovery URL is a password.** Anyone holding it can read source excerpts from your site. Rotate it after use. The token-free `?wpdce-report=1` address is not — it is checked against your login cookie, and is a 404 to everyone else.
- **The token-free link needs the plugin to have loaded.** A fatal in `wp-config.php`, in core, or in a must-use plugin ahead of this one happens before there is anything to answer with. That is the case the saved token and the email are for.

## Requirements

WordPress 5.8+, PHP 7.4+. No dependencies, no build step, no outbound calls.

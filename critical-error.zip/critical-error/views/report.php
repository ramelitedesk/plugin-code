<?php
/**
 * Standalone recovery report.
 *
 * Rendered outside the admin, usually on a site that is otherwise fatal, so it
 * assumes nothing: no admin CSS, no jQuery, no wp_head(). Everything is inline
 * and self-contained, and every escape uses htmlspecialchars() rather than
 * esc_html() because the failure may have happened before wp-includes finished
 * loading.
 *
 * @var array $errors Error records, newest first.
 *
 * @package WPD_Critical_Error
 */

defined( 'ABSPATH' ) || exit;

$wpdce_fatals = array_filter(
	$errors,
	static function ( $e ) {
		return ! empty( $e['fatal'] );
	}
);

$wpdce_e = static function ( $value ) {
	return htmlspecialchars( (string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8' );
};
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow, noarchive">
<title>Error report</title>
<style>
	:root {
		--bg:#f4f6f9; --card:#fff; --line:#d6dbe4; --ink:#12161d; --soft:#464e5c;
		--mute:#6d7686; --accent:#14479e; --stop:#a32620; --stop-bg:#fae9e8;
		--warn:#8a5a05; --warn-bg:#fbf1dc; --code:#1d2327; --code-ink:#e2e4e7;
		--hl:#4a2c00; --hl-line:#f0c33c;
	}
	@media (prefers-color-scheme: dark) {
		:root {
			--bg:#0d1016; --card:#141922; --line:#2b3340; --ink:#e8ecf3; --soft:#b3bccb;
			--mute:#8a93a3; --accent:#7fa6ee; --stop:#ee8b85; --stop-bg:#2c1817;
			--warn:#e0ac55; --warn-bg:#2a2113; --code:#10141b; --code-ink:#dbe1ea;
		}
	}
	*{box-sizing:border-box}
	body{margin:0;background:var(--bg);color:var(--ink);padding:2rem 1rem 5rem;
		font:15px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}
	.wrap{max-width:60rem;margin:0 auto}
	h1{font-size:1.5rem;margin:0 0 .3rem}
	.lede{color:var(--soft);margin:0 0 1.5rem;max-width:46rem}
	.card{background:var(--card);border:1px solid var(--line);border-radius:4px;
		margin:0 0 1.25rem;overflow:hidden}
	.card--fatal{border-left:4px solid var(--stop)}
	.card--warn{border-left:4px solid var(--warn)}
	.card__head{padding:1rem 1.2rem;border-bottom:1px solid var(--line)}
	.card__body{padding:1rem 1.2rem}
	.tag{display:inline-block;font-size:.7rem;font-weight:700;text-transform:uppercase;
		letter-spacing:.05em;padding:.15rem .5rem;border-radius:2px}
	.tag--fatal{background:var(--stop-bg);color:var(--stop)}
	.tag--warn{background:var(--warn-bg);color:var(--warn)}
	.msg{font-weight:600;margin:.6rem 0 .4rem;word-break:break-word}
	.meta{font-size:.85rem;color:var(--mute);margin:.3rem 0 0;word-break:break-all}
	.meta b{color:var(--soft)}
	.blame{display:inline-block;margin:.55rem 0 0;padding:.28rem .65rem;
		background:var(--stop-bg);color:var(--stop);border-radius:2px;
		font-size:.85rem;font-weight:600}
	pre.code{margin:.9rem 0 0;padding:0;background:var(--code);color:var(--code-ink);
		border-radius:3px;overflow-x:auto;font-size:.8rem;line-height:1.65;
		font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
	pre.code table{border-collapse:collapse;width:100%}
	pre.code td{padding:0 .55rem;white-space:pre;vertical-align:top}
	pre.code td.n{color:var(--mute);text-align:right;user-select:none;width:1%;
		border-right:1px solid rgba(255,255,255,.12);padding-right:.7rem}
	pre.code tr.bad{background:var(--hl)}
	pre.code tr.bad td.n{color:var(--hl-line);font-weight:700;border-right-color:var(--hl-line)}
	ol.trace{margin:.9rem 0 0;padding-left:1.3rem;font-size:.84rem;color:var(--soft)}
	ol.trace code{word-break:break-all}
	.note{background:var(--warn-bg);border-left:4px solid var(--warn);padding:.9rem 1.1rem;
		border-radius:3px;margin:0 0 1.5rem;font-size:.92rem}
	.empty{padding:2.5rem 1.2rem;text-align:center;color:var(--mute)}
	button{font:inherit;font-size:.9rem;padding:.55rem 1.1rem;cursor:pointer;
		background:var(--card);color:var(--ink);border:1px solid var(--line);border-radius:3px}
	button:hover{border-color:var(--accent);color:var(--accent)}
	footer{color:var(--mute);font-size:.85rem;margin-top:2.5rem}
	code.inline{background:var(--stop-bg);color:var(--stop);padding:.1rem .35rem;border-radius:2px}
</style>
</head>
<body>
<div class="wrap">

	<h1>Error report</h1>
	<p class="lede">
		Recorded by WPD Critical Error Reporter. This page works without logging in, so that it
		still works when the dashboard does not &mdash; treat the link like a password, and
		regenerate it once the site is healthy again.
	</p>

	<?php if ( ! $errors ) : ?>

		<div class="card">
			<div class="empty">
				<p><strong>Nothing recorded.</strong></p>
				<p>
					If the site is showing a critical error but nothing appears here, the failure happened
					<em>before this plugin loaded</em>. Plugins load alphabetically, so a fatal in a plugin
					earlier in the list is invisible to a plugin later in it.
				</p>
				<p>
					Copy <code class="inline">config/mu-loader.php</code> into
					<code class="inline">wp-content/mu-plugins/</code> and it will load ahead of every
					regular plugin. Then reproduce the error and reload this page.
				</p>
			</div>
		</div>

	<?php else : ?>

		<?php if ( $wpdce_fatals ) : ?>
			<div class="note">
				<strong><?php echo count( $wpdce_fatals ); ?> fatal error<?php echo 1 === count( $wpdce_fatals ) ? '' : 's'; ?> on record.</strong>
				The <em>Responsible</em> line on each card names the plugin or theme that owns the failing
				file. Renaming that folder over FTP deactivates it and will usually bring the site straight
				back.
			</div>
		<?php endif; ?>

		<?php foreach ( $errors as $wpdce_err ) : ?>
			<?php $wpdce_is_fatal = ! empty( $wpdce_err['fatal'] ); ?>
			<div class="card <?php echo $wpdce_is_fatal ? 'card--fatal' : 'card--warn'; ?>">
				<div class="card__head">
					<span class="tag <?php echo $wpdce_is_fatal ? 'tag--fatal' : 'tag--warn'; ?>"><?php echo $wpdce_e( $wpdce_err['label'] ); ?></span>
					<?php if ( (int) $wpdce_err['count'] > 1 ) : ?>
						<span class="meta" style="display:inline">&nbsp;&times; <?php echo (int) $wpdce_err['count']; ?></span>
					<?php endif; ?>

					<p class="msg"><?php echo $wpdce_e( $wpdce_err['message'] ); ?></p>

					<p class="meta">
						<b>File:</b> <?php echo $wpdce_e( $wpdce_err['relative'] ); ?>
						&nbsp;<b>Line <?php echo (int) $wpdce_err['line']; ?></b>
					</p>

					<?php if ( ! empty( $wpdce_err['blame']['name'] ) ) : ?>
						<span class="blame">
							Responsible: <?php echo $wpdce_e( $wpdce_err['blame']['type'] ); ?>
							&mdash; <?php echo $wpdce_e( $wpdce_err['blame']['name'] ); ?>
						</span>
					<?php endif; ?>
				</div>

				<div class="card__body">
					<?php if ( ! empty( $wpdce_err['excerpt'] ) ) : ?>
						<pre class="code"><table><?php foreach ( $wpdce_err['excerpt'] as $wpdce_n => $wpdce_src ) : ?><tr class="<?php echo (int) $wpdce_n === (int) $wpdce_err['line'] ? 'bad' : ''; ?>"><td class="n"><?php echo (int) $wpdce_n; ?></td><td><?php echo $wpdce_e( $wpdce_src ); ?></td></tr><?php endforeach; ?></table></pre>
					<?php else : ?>
						<p class="meta">Source excerpt unavailable &mdash; the file could not be read.</p>
					<?php endif; ?>

					<?php if ( ! empty( $wpdce_err['trace'] ) ) : ?>
						<ol class="trace">
							<?php foreach ( $wpdce_err['trace'] as $wpdce_frame ) : ?>
								<li>
									<code><?php echo $wpdce_e( $wpdce_frame['function'] ); ?>()</code>
									<?php if ( ! empty( $wpdce_frame['file'] ) ) : ?>
										&mdash; <?php echo $wpdce_e( $wpdce_frame['file'] ); ?>:<?php echo (int) $wpdce_frame['line']; ?>
									<?php endif; ?>
								</li>
							<?php endforeach; ?>
						</ol>
					<?php endif; ?>

					<p class="meta" style="margin-top:.9rem">
						<b>Last seen:</b> <?php echo $wpdce_e( gmdate( 'Y-m-d H:i:s', (int) $wpdce_err['last_seen'] ) ); ?> UTC
						&nbsp;<b>PHP:</b> <?php echo $wpdce_e( $wpdce_err['php'] ); ?>
						<?php if ( ! empty( $wpdce_err['request']['uri'] ) ) : ?>
							<br><b>Request:</b> <?php echo $wpdce_e( trim( $wpdce_err['request']['method'] . ' ' . $wpdce_err['request']['uri'] ) ); ?>
						<?php endif; ?>
					</p>
				</div>
			</div>
		<?php endforeach; ?>

		<form method="post" action="">
			<input type="hidden" name="wpdce_clear" value="1" />
			<?php
			// With a token in the URL the token is the credential. Without one,
			// this page was opened with a login cookie — and a cookie alone
			// would let any other site make your browser post this form.
			if ( ! empty( $wpdce_authenticated ) && function_exists( 'wp_nonce_field' ) ) {
				wp_nonce_field( 'wpdce_clear', 'wpdce_nonce' );
			}
			?>
			<button type="submit">Clear the error log</button>
		</form>

	<?php endif; ?>

	<footer>
		Generated <?php echo $wpdce_e( gmdate( 'Y-m-d H:i:s' ) ); ?> UTC.
		Once the site works again, regenerate this link from <strong>Tools &rarr; Critical Errors</strong>
		so the old one stops working.
	</footer>

</div>
</body>
</html>

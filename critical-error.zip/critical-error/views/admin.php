<?php
/**
 * Tools → Critical Errors.
 *
 * @var array $errors   Records, newest first.
 * @var int   $fatals   How many are fatal.
 * @var array $settings Capture settings.
 * @var bool  $is_mu    Whether the must-use loader is installed.
 *
 * @package WPD_Critical_Error
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wrap wpdce-wrap">
	<h1><?php esc_html_e( 'Critical Errors', 'wpd-critical-error' ); ?></h1>

	<?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
	<?php if ( isset( $_GET['done'] ) ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Done.', 'wpd-critical-error' ); ?></p></div>
	<?php endif; ?>

	<?php if ( ! $is_mu ) : ?>
		<div class="notice notice-warning">
			<p>
				<strong><?php esc_html_e( 'Errors that happen before this plugin loads cannot be captured.', 'wpd-critical-error' ); ?></strong>
				<?php esc_html_e( 'WordPress loads plugins in alphabetical order, so a fatal error inside a plugin that loads earlier happens before this handler exists. Copy config/mu-loader.php into wp-content/mu-plugins/ and it will load ahead of every regular plugin.', 'wpd-critical-error' ); ?>
			</p>
		</div>
	<?php endif; ?>

	<div class="wpdce-panel">
		<h2><?php esc_html_e( 'Is it running?', 'wpd-critical-error' ); ?></h2>
		<p class="description">
			<?php esc_html_e( 'An empty error log has two possible meanings — your site is healthy, or this plugin is not actually capturing anything — and they look identical from here. This tells them apart.', 'wpd-critical-error' ); ?>
		</p>

		<table class="wpdce-status">
			<tr>
				<td class="dot"><span class="<?php echo WPDCE_Settings::enabled( 'capture' ) ? 'ok' : 'fail'; ?>"></span></td>
				<th><?php esc_html_e( 'Capture', 'wpd-critical-error' ); ?></th>
				<td><?php echo WPDCE_Settings::enabled( 'capture' ) ? esc_html__( 'Switched on.', 'wpd-critical-error' ) : esc_html__( 'Switched off — nothing will be recorded.', 'wpd-critical-error' ); ?></td>
			</tr>
			<tr>
				<td class="dot"><span class="<?php echo $is_mu ? 'ok' : 'warn'; ?>"></span></td>
				<th><?php esc_html_e( 'Loads early', 'wpd-critical-error' ); ?></th>
				<td>
					<?php
					echo $is_mu
						? esc_html__( 'The must-use loader is installed, so this runs before every other plugin.', 'wpd-critical-error' )
						: esc_html__( 'Not installed. Crashes in plugins that load before this one cannot be seen.', 'wpd-critical-error' );
					?>
				</td>
			</tr>
			<tr>
				<?php $wpdce_dir = WPDCE_Log::dir(); ?>
				<td class="dot"><span class="<?php echo ( $wpdce_dir && is_writable( $wpdce_dir ) ) ? 'ok' : 'fail'; ?>"></span></td>
				<th><?php esc_html_e( 'Storage', 'wpd-critical-error' ); ?></th>
				<td>
					<?php if ( $wpdce_dir && is_writable( $wpdce_dir ) ) : ?>
						<code><?php echo esc_html( WPDCE_Handler::relative( $wpdce_dir ) ); ?></code>
					<?php else : ?>
						<?php esc_html_e( 'Not writable — errors cannot be saved.', 'wpd-critical-error' ); ?>
					<?php endif; ?>
				</td>
			</tr>
		</table>

		<?php $wpdce_test = get_transient( 'wpdce_selftest_result' ); ?>
		<?php if ( is_array( $wpdce_test ) ) : ?>
			<?php delete_transient( 'wpdce_selftest_result' ); ?>
			<div class="notice notice-<?php echo ( $wpdce_test['warning'] && $wpdce_test['fatal'] ) ? 'success' : 'warning'; ?> inline">
				<p>
					<strong><?php esc_html_e( 'Self-test result', 'wpd-critical-error' ); ?></strong><br>
					<?php echo $wpdce_test['warning'] ? '✅' : '❌'; ?>
					<?php esc_html_e( 'Warnings are being captured.', 'wpd-critical-error' ); ?><br>
					<?php echo $wpdce_test['fatal'] ? '✅' : '❌'; ?>
					<?php esc_html_e( 'Fatal errors are being captured.', 'wpd-critical-error' ); ?>
					<?php if ( ! $wpdce_test['fatal'] && $wpdce_test['fatal_note'] ) : ?>
						<br>
						<span class="description">
							<?php echo esc_html( $wpdce_test['fatal_note'] ); ?>
							<?php esc_html_e( 'This stage needs the site to be able to make an HTTP request to itself, which some local and firewalled setups cannot do. It does not necessarily mean capture is broken.', 'wpd-critical-error' ); ?>
						</span>
					<?php endif; ?>
				</p>
			</div>
		<?php endif; ?>

		<p>
			<?php
			WPDCE_Admin::button(
				'selftest',
				__( 'Run a self-test', 'wpd-critical-error' ),
				'button button-primary'
			);
			?>
			<span class="description"><?php esc_html_e( 'Records one harmless test warning and crashes one internal request on purpose. The page you are on is unaffected.', 'wpd-critical-error' ); ?></span>
		</p>
	</div>

	<div class="wpdce-panel">
		<h2><?php esc_html_e( 'Recovery link', 'wpd-critical-error' ); ?></h2>
		<p class="description">
			<?php esc_html_e( 'When a critical error stops the dashboard from opening, this link still shows the report. Save it somewhere outside the site — a password manager, not a note on the desktop. Anyone holding it can read file paths and source code from your site.', 'wpd-critical-error' ); ?>
		</p>

		<p>
			<input
				type="text"
				class="large-text code"
				readonly
				onclick="this.select()"
				value="<?php echo esc_attr( WPDCE_Report::url() ); ?>"
			/>
		</p>

		<p>
			<?php
			WPDCE_Admin::button(
				'new_token',
				__( 'Generate a new link', 'wpd-critical-error' ),
				'button',
				__( 'The current link will stop working immediately. Continue?', 'wpd-critical-error' )
			);
			?>
			<span class="description"><?php esc_html_e( 'Invalidates the old link at once.', 'wpd-critical-error' ); ?></span>
		</p>

		<h3><?php esc_html_e( 'If you never saved that link', 'wpd-critical-error' ); ?></h3>
		<p class="description">
			<?php esc_html_e( 'The link above has an awkward property: you get it from here, and here is the screen a critical error takes away. So there is a second way in that needs nothing saved in advance — while you are still signed in as an administrator in this browser, this address opens the same report with no token in it:', 'wpd-critical-error' ); ?>
		</p>

		<p>
			<input
				type="text"
				class="large-text code"
				readonly
				onclick="this.select()"
				value="<?php echo esc_attr( WPDCE_Report::login_url() ); ?>"
			/>
		</p>

		<p class="description">
			<?php esc_html_e( 'It is checked against your login cookie, so it is safe to bookmark and safe to paste into a support ticket — to anyone not signed in as an administrator here, it is a 404. It works for a fatal error in a theme or in any plugin that loads after this one, which is nearly all of them. Both links are also added to the email WordPress sends you when the site goes down.', 'wpd-critical-error' ); ?>
		</p>

		<?php if ( defined( 'WPDCE_RECOVERY_KEY' ) ) : ?>
			<p class="wpdce-good">
				<?php esc_html_e( 'WPDCE_RECOVERY_KEY is set in wp-config.php, so the link above is that constant. This is the safest arrangement — it works even when the database is the thing that has failed.', 'wpd-critical-error' ); ?>
			</p>
		<?php else : ?>
			<p class="description">
				<?php
				printf(
					/* translators: %s: PHP snippet, already escaped. */
					esc_html__( 'Stronger still: define the token in wp-config.php as %s. A constant cannot be read out of the database, and it keeps working when the database does not.', 'wpd-critical-error' ),
					'<code>define( \'WPDCE_RECOVERY_KEY\', \'a-long-random-string\' );</code>'
				);
				?>
			</p>
		<?php endif; ?>
	</div>

	<div class="wpdce-panel">
		<h2>
			<?php esc_html_e( 'Recorded errors', 'wpd-critical-error' ); ?>
			<?php if ( $fatals ) : ?>
				<span class="wpdce-badge wpdce-badge--fatal">
					<?php
					printf(
						/* translators: %d: count. */
						esc_html( _n( '%d fatal', '%d fatal', $fatals, 'wpd-critical-error' ) ),
						(int) $fatals
					);
					?>
				</span>
			<?php endif; ?>
		</h2>

		<?php if ( ! $errors ) : ?>

			<p>
				<?php esc_html_e( 'Nothing recorded. Either the site has not thrown a PHP error since capture was switched on, or the failure happened before this plugin loaded.', 'wpd-critical-error' ); ?>
			</p>

		<?php else : ?>

			<?php foreach ( $errors as $wpdce_err ) : ?>
				<div class="wpdce-error <?php echo ! empty( $wpdce_err['fatal'] ) ? 'wpdce-error--fatal' : ''; ?>">
					<p class="wpdce-error__head">
						<span class="wpdce-badge wpdce-badge--<?php echo ! empty( $wpdce_err['fatal'] ) ? 'fatal' : 'warn'; ?>">
							<?php echo esc_html( $wpdce_err['label'] ); ?>
						</span>
						<?php if ( (int) $wpdce_err['count'] > 1 ) : ?>
							<span class="description">&times;&nbsp;<?php echo (int) $wpdce_err['count']; ?></span>
						<?php endif; ?>
						<strong><?php echo esc_html( $wpdce_err['message'] ); ?></strong>
					</p>

					<?php if ( ! empty( $wpdce_err['blame']['name'] ) ) : ?>
						<p class="wpdce-blame">
							<?php esc_html_e( 'Responsible:', 'wpd-critical-error' ); ?>
							<strong><?php echo esc_html( $wpdce_err['blame']['type'] ); ?></strong>
							&mdash; <?php echo esc_html( $wpdce_err['blame']['name'] ); ?>
						</p>
					<?php endif; ?>

					<p class="wpdce-error__meta">
						<code><?php echo esc_html( $wpdce_err['relative'] ); ?></code>
						<?php
						printf(
							/* translators: %d: line number. */
							esc_html__( 'line %d', 'wpd-critical-error' ),
							(int) $wpdce_err['line']
						);
						?>
					</p>

					<?php if ( ! empty( $wpdce_err['excerpt'] ) ) : ?>
						<details <?php echo ! empty( $wpdce_err['fatal'] ) ? 'open' : ''; ?>>
							<summary><?php esc_html_e( 'The code that failed', 'wpd-critical-error' ); ?></summary>
							<pre class="wpdce-src"><?php
							foreach ( $wpdce_err['excerpt'] as $wpdce_n => $wpdce_src ) {
								printf(
									'<span class="%s"><span class="n">%4d</span> %s</span>' . "\n",
									(int) $wpdce_n === (int) $wpdce_err['line'] ? 'bad' : '',
									(int) $wpdce_n,
									esc_html( $wpdce_src )
								);
							}
							?></pre>
						</details>
					<?php endif; ?>

					<?php if ( ! empty( $wpdce_err['trace'] ) ) : ?>
						<details>
							<summary><?php esc_html_e( 'Call stack', 'wpd-critical-error' ); ?></summary>
							<ol class="wpdce-trace">
								<?php foreach ( $wpdce_err['trace'] as $wpdce_frame ) : ?>
									<li>
										<code><?php echo esc_html( $wpdce_frame['function'] ); ?>()</code>
										<?php if ( ! empty( $wpdce_frame['file'] ) ) : ?>
											&mdash; <?php echo esc_html( $wpdce_frame['file'] . ':' . $wpdce_frame['line'] ); ?>
										<?php endif; ?>
									</li>
								<?php endforeach; ?>
							</ol>
						</details>
					<?php endif; ?>

					<p class="wpdce-error__meta">
						<?php
						printf(
							/* translators: 1: time ago, 2: request, 3: PHP version. */
							esc_html__( 'Last seen %1$s ago · %2$s · PHP %3$s', 'wpd-critical-error' ),
							esc_html( human_time_diff( (int) $wpdce_err['last_seen'] ) ),
							esc_html( trim( $wpdce_err['request']['method'] . ' ' . $wpdce_err['request']['uri'] ) ),
							esc_html( $wpdce_err['php'] )
						);
						?>
					</p>
				</div>
			<?php endforeach; ?>

			<p>
				<?php
				WPDCE_Admin::button(
					'clear',
					__( 'Clear the error log', 'wpd-critical-error' ),
					'button',
					__( 'This permanently deletes every recorded error. Continue?', 'wpd-critical-error' )
				);
				?>
			</p>

		<?php endif; ?>
	</div>

	<div class="wpdce-panel">
		<h2><?php esc_html_e( 'What gets captured', 'wpd-critical-error' ); ?></h2>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="wpdce_action" />
			<input type="hidden" name="do" value="save" />
			<?php wp_nonce_field( WPDCE_Admin::NONCE ); ?>

			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Fatal errors and warnings', 'wpd-critical-error' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="capture" value="1" <?php checked( ! empty( $settings['capture'] ) ); ?> />
							<?php esc_html_e( 'Record what crashed, where, and which plugin owns it', 'wpd-critical-error' ); ?>
						</label>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Notices and deprecations', 'wpd-critical-error' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="capture_notices" value="1" <?php checked( ! empty( $settings['capture_notices'] ) ); ?> />
							<?php esc_html_e( 'Also record notices, deprecations and strict warnings', 'wpd-critical-error' ); ?>
						</label>
						<p class="description"><?php esc_html_e( 'Off by default. On most sites these are constant background noise and would bury the fatal you came here to find.', 'wpd-critical-error' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Theme &amp; plugin file editor', 'wpd-critical-error' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="editor_guard" value="1" <?php checked( ! empty( $settings['editor_guard'] ) ); ?> />
							<?php esc_html_e( 'Check pasted code for fatal errors before Update File writes it', 'wpd-critical-error' ); ?>
						</label>
						<p class="description">
							<?php esc_html_e( 'Appearance → Theme File Editor, and the plugin editor. The code is parsed before anything is written: if it would not compile, or it redeclares a function that already exists, the save is stopped and the offending lines are shown. Nothing is written to disk and nothing is lost from the editor.', 'wpd-critical-error' ); ?>
						</p>
						<label>
							<input type="checkbox" name="editor_runtime" value="1" <?php checked( ! empty( $settings['editor_runtime'] ) ); ?> />
							<?php esc_html_e( 'Also check that every function and class the code calls actually exists', 'wpd-critical-error' ); ?>
						</label>
						<p class="description">
							<?php esc_html_e( 'A parse check cannot see runtime failures — calling a function that does not exist is valid syntax, and it is the mistake that blanks a dashboard. This resolves every name in the file against the running site instead. If the call is one that is certain to run — at the top of the file, or inside a function the same file hooks by name — the save is stopped and the lines are shown. If it might never run, you get a warning and the choice.', 'wpd-critical-error' ); ?>
						</p>
						<p class="description">
							<?php esc_html_e( 'Anything it cannot settle by reading the file — a namespace, a use import, an include that may define the missing name — is reported as a warning rather than blocking, because a check that blocks on guesses is one people learn to ignore.', 'wpd-critical-error' ); ?>
						</p>
						<?php if ( defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT ) : ?>
							<p class="description">
								<strong><?php esc_html_e( 'DISALLOW_FILE_EDIT is set on this site, so the editors do not exist and this setting does nothing.', 'wpd-critical-error' ); ?></strong>
								<?php esc_html_e( 'That is the safer configuration. Leave it as it is unless you deliberately want the editors back.', 'wpd-critical-error' ); ?>
							</p>
						<?php endif; ?>
					</td>
				</tr>
			</table>

			<?php submit_button( __( 'Save', 'wpd-critical-error' ) ); ?>
		</form>

		<p class="description">
			<?php esc_html_e( 'Errors are also passed through to PHP\'s own handling, so WP_DEBUG_LOG and your host\'s error log keep receiving them. This plugin adds a record; it does not take one away.', 'wpd-critical-error' ); ?>
		</p>
	</div>
</div>

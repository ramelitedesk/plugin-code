/**
 * Check the code before the editor is allowed to save it.
 *
 * The whole value of doing this in the browser is that nothing is written. The
 * server-side alternative is what WordPress already does: write the file, make
 * a loopback request, and put the old content back if the site stopped
 * answering. That works, but it needs a loopback that many installs cannot
 * make, and it means a broken file existed on a live site for a second or two.
 *
 * Here the save simply does not happen, and — the part that matters when you
 * have just typed forty lines — the editor is never touched, so nothing is lost
 * and there is nothing to retype.
 *
 * Progressive enhancement, deliberately. If this file fails to load, or the
 * request to the checker fails, the save proceeds exactly as it always did and
 * WordPress's own protection is still in place. This adds a gate; it never
 * becomes the only one.
 *
 * @package WPD_Critical_Error
 */
( function () {
	'use strict';

	var form = document.getElementById( 'template' );

	if ( ! form || 'undefined' === typeof window.wpdceEditor || ! window.fetch ) {
		return;
	}

	var settings = window.wpdceEditor;
	var cleared  = false;

	/**
	 * The code as it stands right now.
	 *
	 * CodeMirror keeps its own document and only writes back to the textarea on
	 * submit, so reading the textarea alone would check the code as it was when
	 * the page loaded — which is exactly the code we already know is fine.
	 *
	 * @return {string} Source.
	 */
	function currentCode() {
		try {
			var editor = window.wp && window.wp.themePluginEditor;

			if ( editor && editor.instance && editor.instance.codemirror ) {
				return editor.instance.codemirror.getValue();
			}
		} catch ( e ) {
			// Fall through to the textarea.
		}

		var area = document.getElementById( 'newcontent' );

		return area ? area.value : '';
	}

	/**
	 * @return {Object} The hidden fields identifying what is being edited.
	 */
	function target() {
		var fields = {};

		[ 'file', 'theme', 'plugin' ].forEach( function ( name ) {
			var input = form.querySelector( '[name="' + name + '"]' );

			if ( input && input.value ) {
				fields[ name ] = input.value;
			}
		} );

		return fields;
	}

	/**
	 * @param {string} action Endpoint action.
	 * @param {string} code   Source to send.
	 * @return {Promise} Resolves with the response payload's data.
	 */
	function ask( action, code ) {
		var body = new FormData();

		body.append( 'action', action );
		body.append( 'nonce', settings.nonce );
		body.append( 'code', code );

		var fields = target();

		Object.keys( fields ).forEach( function ( name ) {
			body.append( name, fields[ name ] );
		} );

		return window.fetch( settings.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: body
		} ).then( function ( response ) {
			return response.json();
		} ).then( function ( payload ) {
			if ( ! payload || ! payload.success || ! payload.data ) {
				throw new Error( 'unusable response' );
			}

			return payload.data;
		} );
	}

	/* ---------------------------------------------------------------- *
	 * Rendering
	 * ---------------------------------------------------------------- */

	function removeNotice() {
		var existing = document.getElementById( 'wpdce-editor-notice' );

		if ( existing && existing.parentNode ) {
			existing.parentNode.removeChild( existing );
		}
	}

	/**
	 * @param {string} className Notice modifier.
	 * @return {HTMLElement} The inserted notice.
	 */
	function notice( className ) {
		removeNotice();

		var el = document.createElement( 'div' );
		el.id = 'wpdce-editor-notice';
		el.className = 'notice ' + className + ' wpdce-editor-notice';
		el.setAttribute( 'role', 'alert' );

		var heading = document.querySelector( '.wrap h1' );

		if ( heading && heading.parentNode ) {
			heading.parentNode.insertBefore( el, heading.nextSibling );
		} else {
			form.parentNode.insertBefore( el, form );
		}

		el.scrollIntoView( { block: 'center', behavior: 'smooth' } );

		return el;
	}

	/**
	 * Render a diagnosis: what broke, on which line, and the code around it.
	 *
	 * Built with createElement and textContent throughout. What is being
	 * described here is arbitrary PHP that may well contain markup, and
	 * innerHTML would render it into the page rather than show it.
	 *
	 * @param {Object} verdict  Response from the checker.
	 * @param {string} headline Bold first line.
	 */
	function showFailure( verdict, headline ) {
		var el = notice( 'notice-error' );

		var head = document.createElement( 'p' );
		var strong = document.createElement( 'strong' );
		strong.textContent = headline;
		head.appendChild( strong );
		el.appendChild( head );

		var what = document.createElement( 'p' );
		what.className = 'wpdce-editor-notice__what';

		var badge = document.createElement( 'span' );
		badge.className = 'wpdce-badge wpdce-badge--fatal';
		badge.textContent = verdict.label;
		what.appendChild( badge );

		if ( verdict.line ) {
			var line = document.createElement( 'span' );
			line.className = 'wpdce-editor-notice__line';
			line.textContent = settings.i18n.lineLabel.replace( '%d', verdict.line );
			what.appendChild( line );
		}

		var message = document.createElement( 'code' );
		message.textContent = verdict.message;
		what.appendChild( message );

		el.appendChild( what );

		if ( verdict.excerpt ) {
			el.appendChild( sourceBlock( verdict.excerpt, verdict.line ) );
		}

		if ( verdict.hint ) {
			var hint = document.createElement( 'p' );
			hint.className = 'description';
			hint.textContent = verdict.hint;
			el.appendChild( hint );
		}

		appendAlso( el, verdict.warnings );

		jumpTo( verdict.line );
	}

	/**
	 * The rest of what the check found, as a list.
	 *
	 * Only the first problem gets the full treatment — badge, source, hint —
	 * because that is the one being fixed. The others are worth knowing about
	 * and not worth three inches of screen each.
	 *
	 * @param {HTMLElement} el      Notice to append to.
	 * @param {Array}       extras  Remaining findings.
	 */
	function appendAlso( el, extras ) {
		if ( ! extras || ! extras.length ) {
			return;
		}

		var head = document.createElement( 'p' );
		head.className = 'wpdce-editor-notice__also';
		var strong = document.createElement( 'strong' );
		strong.textContent = settings.i18n.also;
		head.appendChild( strong );
		el.appendChild( head );

		var list = document.createElement( 'ul' );
		list.className = 'wpdce-editor-notice__list';

		extras.forEach( function ( item ) {
			var row = document.createElement( 'li' );

			var badge = document.createElement( 'span' );
			badge.className = 'wpdce-badge ' + ( 'fatal' === item.severity ? 'wpdce-badge--fatal' : 'wpdce-badge--warn' );
			badge.textContent = item.label;
			row.appendChild( badge );

			var where = document.createElement( 'button' );
			where.type = 'button';
			where.className = 'button-link wpdce-editor-notice__jump';
			where.textContent = settings.i18n.lineLabel.replace( '%d', item.line );
			where.addEventListener( 'click', function () {
				jumpTo( item.line );
			} );
			row.appendChild( where );

			var message = document.createElement( 'code' );
			message.textContent = item.message;
			row.appendChild( message );

			list.appendChild( row );
		} );

		el.appendChild( list );
	}

	/**
	 * Something in the code does not exist, but whether it ever runs is not
	 * decidable from this file alone.
	 *
	 * Blocking here would be dishonest — the check does not know that this will
	 * break. So it says what it found, shows the lines, and leaves the decision
	 * where it belongs. The save is one click away, and it is a click the
	 * author makes having read what is wrong, which is the whole point.
	 *
	 * @param {Object} verdict Response from the checker.
	 * @param {string} code    The code that would be saved.
	 */
	function showRisky( verdict, code ) {
		var findings = verdict.warnings.slice();
		var first    = findings.shift();
		var el       = notice( 'notice-warning' );

		var head = document.createElement( 'p' );
		var strong = document.createElement( 'strong' );
		strong.textContent = settings.i18n.warned;
		head.appendChild( strong );
		el.appendChild( head );

		var what = document.createElement( 'p' );
		what.className = 'wpdce-editor-notice__what';

		var badge = document.createElement( 'span' );
		badge.className = 'wpdce-badge wpdce-badge--warn';
		badge.textContent = first.label;
		what.appendChild( badge );

		if ( first.line ) {
			var line = document.createElement( 'span' );
			line.className = 'wpdce-editor-notice__line';
			line.textContent = settings.i18n.lineLabel.replace( '%d', first.line );
			what.appendChild( line );
		}

		var message = document.createElement( 'code' );
		message.textContent = first.message;
		what.appendChild( message );

		el.appendChild( what );

		if ( first.excerpt ) {
			el.appendChild( sourceBlock( first.excerpt, first.line ) );
		}

		if ( first.hint ) {
			var hint = document.createElement( 'p' );
			hint.className = 'description';
			hint.textContent = first.hint;
			el.appendChild( hint );
		}

		appendAlso( el, findings );

		var actions = document.createElement( 'p' );
		actions.className = 'wpdce-editor-notice__actions';

		var go = document.createElement( 'button' );
		go.type = 'button';
		go.className = 'button';
		go.textContent = settings.i18n.saveAnyway;
		go.title = settings.i18n.saveAnyway2;
		go.addEventListener( 'click', function () {
			removeNotice();
			watchForRevert( code );
			proceed();
		} );
		actions.appendChild( go );

		var back = document.createElement( 'button' );
		back.type = 'button';
		back.className = 'button button-primary';
		back.textContent = settings.i18n.cancel;
		back.addEventListener( 'click', function () {
			removeNotice();
			jumpTo( first.line );
		} );
		actions.appendChild( back );

		el.appendChild( actions );

		jumpTo( first.line );
	}

	/**
	 * @param {Object} excerpt Line number => source.
	 * @param {number} bad     The failing line.
	 * @return {HTMLElement} A <pre> of numbered source.
	 */
	function sourceBlock( excerpt, bad ) {
		var pre = document.createElement( 'pre' );
		pre.className = 'wpdce-src';

		Object.keys( excerpt ).forEach( function ( number ) {
			var row = document.createElement( 'span' );

			if ( parseInt( number, 10 ) === parseInt( bad, 10 ) ) {
				row.className = 'bad';
			}

			var gutter = document.createElement( 'span' );
			gutter.className = 'n';
			gutter.textContent = ( '     ' + number ).slice( -5 );
			row.appendChild( gutter );

			row.appendChild( document.createTextNode( ' ' + excerpt[ number ] + '\n' ) );
			pre.appendChild( row );
		} );

		return pre;
	}

	/**
	 * Put the cursor on the offending line. Being told "line 412" and then
	 * having to go and find line 412 is most of the annoyance this removes.
	 *
	 * @param {number} line Line number.
	 */
	function jumpTo( line ) {
		if ( ! line ) {
			return;
		}

		try {
			var editor = window.wp && window.wp.themePluginEditor;

			if ( editor && editor.instance && editor.instance.codemirror ) {
				editor.instance.codemirror.setCursor( { line: line - 1, ch: 0 } );
			}
		} catch ( e ) {
			// A cursor that did not move is not worth reporting.
		}
	}

	/**
	 * @param {string} message Text.
	 */
	function showWarning( message ) {
		var el = notice( 'notice-warning' );
		var p = document.createElement( 'p' );
		p.textContent = message;
		el.appendChild( p );
	}

	/* ---------------------------------------------------------------- *
	 * After a save we let through
	 * ---------------------------------------------------------------- */

	/**
	 * Fill in what WordPress leaves out when its own check reverts a save.
	 *
	 * A runtime fatal — calling a function that does not exist, say — is valid
	 * syntax, so the pre-flight passes it and WordPress catches it with its
	 * loopback instead. What WordPress then shows is a message and nothing
	 * else. But the request that crashed was a request to this same site, and
	 * this plugin's handler was running inside it, so the file, the line and
	 * the source are already recorded. This goes and gets them.
	 *
	 * @param {string} code The code that was submitted.
	 */
	function watchForRevert( code ) {
		var container = form.querySelector( '.editor-notices' );

		if ( ! container || 'undefined' === typeof window.MutationObserver ) {
			return;
		}

		var done = false;

		var observer = new window.MutationObserver( function () {
			if ( done || ! container.querySelector( '.notice-error' ) ) {
				return;
			}

			done = true;
			observer.disconnect();

			ask( settings.afterAction, code ).then( function ( data ) {
				if ( data && data.found ) {
					showFailure( data, settings.i18n.reverted );
				}
			} ).catch( function () {
				// WordPress has already said the save failed. Adding "and the
				// explanation also failed" helps nobody.
			} );
		} );

		observer.observe( container, { childList: true, subtree: true } );

		// Core allows its loopback up to 100 seconds. Stop watching a little
		// after that rather than leave an observer running for the session.
		window.setTimeout( function () {
			done = true;
			observer.disconnect();
		}, 120000 );
	}

	/* ---------------------------------------------------------------- *
	 * The gate
	 * ---------------------------------------------------------------- */

	/**
	 * Hand the form back to WordPress's own submit handler.
	 *
	 * requestSubmit() rather than submit(): the update button is named
	 * "submit", which shadows the form's submit() method and makes calling it a
	 * TypeError. requestSubmit also re-fires the submit event, so the editor's
	 * own handler — the one that actually performs the save over Ajax — still
	 * runs, along with its spinner, its notices and its dirty-state tracking.
	 */
	function proceed() {
		cleared = true;

		if ( 'function' === typeof form.requestSubmit ) {
			form.requestSubmit( form.querySelector( '#submit' ) || undefined );
			return;
		}

		HTMLFormElement.prototype.submit.call( form );
	}

	/*
	 * Bound to the document in the capture phase, not to the form.
	 *
	 * Ordering is the reason. For two listeners on the same element the capture
	 * flag is ignored and registration order decides, so binding to the form
	 * would leave it to chance whether this or the editor's own handler runs
	 * first. A capture listener on an ancestor is reached before either of
	 * them, every time.
	 */
	document.addEventListener(
		'submit',
		function ( event ) {
			if ( event.target !== form ) {
				return;
			}

			if ( cleared ) {
				cleared = false;
				return; // Already checked; this is the resubmit.
			}

			event.preventDefault();
			event.stopImmediatePropagation();

			var button = form.querySelector( '#submit' );
			var label  = button ? button.value : '';
			var code   = currentCode();

			if ( button ) {
				button.disabled = true;
				button.value = settings.i18n.checking;
			}

			function restore() {
				if ( button ) {
					button.disabled = false;
					button.value = label;
				}
			}

			ask( settings.action, code )
				.then( function ( verdict ) {
					restore();

					if ( ! verdict.ok ) {
						showFailure( verdict, settings.i18n.blocked );
						return;
					}

					// Nothing certain enough to stop the save, but something
					// worth reading before it happens.
					if ( verdict.warnings && verdict.warnings.length ) {
						showRisky( verdict, code );
						return;
					}

					removeNotice();
					watchForRevert( code );
					proceed();
				} )
				.catch( function () {
					/*
					 * The checker is an extra gate, not a gatekeeper. If it
					 * cannot answer, the save goes ahead exactly as it would
					 * without this file — WordPress still reverts the change if
					 * the site stops answering afterwards. Failing closed here
					 * would mean one unreachable admin-ajax.php makes the
					 * editor permanently unusable, which is a worse failure
					 * than the one being guarded against.
					 */
					restore();
					showWarning( settings.i18n.offline );
					watchForRevert( code );
					proceed();
				} );
		},
		true
	);
}() );

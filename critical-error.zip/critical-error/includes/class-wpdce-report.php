<?php
/**
 * Token-gated recovery report.
 *
 * The awkward property of a critical error is that the tool for diagnosing it
 * lives behind the thing that is broken. If wp-admin fatals, you cannot log in
 * to read why wp-admin fatals.
 *
 * So the report is also reachable without logging in:
 *
 *     https://example.com/?wpdce-report=TOKEN
 *
 * That is an unauthenticated endpoint printing file paths and source code, so
 * it is treated as hostile ground:
 *
 *   - the token is 64 hex characters from random_bytes()
 *   - comparison uses hash_equals(), so there is no timing oracle
 *   - failures are counted per IP in a FILE, because the database may be the
 *     very thing that has failed, and cut off after a handful
 *   - every attempt, successful or not, is recorded
 *   - the page is noindex/no-store, and anyone without the token gets a plain
 *     404 that does not admit the endpoint exists
 *
 * Strongest option: put the token in wp-config.php, where no SQL injection or
 * option dump can reach it, and where it works even with the database down.
 *
 *     define( 'WPDCE_RECOVERY_KEY', '…' );
 *
 * @package WPD_Critical_Error
 */

defined( 'ABSPATH' ) || exit;

class WPDCE_Report {

	const QUERY_VAR    = 'wpdce-report';
	const OPTION       = 'wpdce_report_token';
	const ATTEMPT_FILE = 'attempts.json';
	const MAX_ATTEMPTS = 8;
	const ATTEMPT_TTL  = 3600;

	/**
	 * Called as early as the plugin loads. Cheap when the parameter is absent,
	 * which is every request but one.
	 *
	 * Only the token is accepted here, and that is a matter of what exists yet
	 * rather than of policy: this runs before `pluggable.php`, so there is no
	 * `wp_validate_auth_cookie()` to ask who is knocking. The token path has to
	 * live at this point because it is the path that must work when the site is
	 * too broken to reach any later one.
	 */
	public static function maybe_render() {
		if ( ! self::requested() ) {
			return;
		}

		$ip = self::ip();

		// Checked before anything else, so a guessing attempt costs as little
		// as possible on this side of it.
		if ( self::locked_out( $ip ) ) {
			self::refuse();
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$candidate = (string) $_GET[ self::QUERY_VAR ];
		$candidate = function_exists( 'wp_unslash' ) ? wp_unslash( $candidate ) : stripslashes( $candidate );

		if ( ! self::verify( $candidate ) ) {
			/*
			 * Not refused — deferred. A wrong token and no token look the same
			 * from here, and the second of those is how somebody who is still
			 * logged in asks for this page. The refusal happens at
			 * maybe_render_for_admin(), by which point that question can
			 * actually be answered.
			 */
			return;
		}

		self::clear_failures( $ip );
		self::handle( false );
	}

	/**
	 * The other way in: you are still logged in.
	 *
	 * The recovery token answers "the dashboard is gone and I have nothing" —
	 * but it has an awkward property, which is that you get it from the
	 * dashboard. If the site broke before you thought to save it, and you have
	 * no FTP and no database client, the token is behind the very door it was
	 * meant to open.
	 *
	 * Your login cookie is not. It is already in the browser you are holding.
	 * So an administrator who is still signed in can open the report with no
	 * token at all:
	 *
	 *     https://example.com/?wpdce-report=1
	 *
	 * This runs on `plugins_loaded`, which is after WordPress has loaded
	 * `pluggable.php` and long before it loads the theme's `functions.php` —
	 * the file the theme editor writes, and therefore the file most likely to
	 * be the one that is crashing. The cookie is validated directly rather than
	 * through `wp_get_current_user()`, because that fires filters this early in
	 * the request that plugins have not yet had the chance to register.
	 */
	public static function maybe_render_for_admin() {
		if ( ! self::requested() ) {
			return;
		}

		$ip = self::ip();

		// A valid token already rendered and exited during plugin load, so
		// arriving here means whatever was supplied did not verify.
		if ( ! self::locked_out( $ip ) && self::viewer_may_recover() ) {
			self::clear_failures( $ip );
			self::handle( true );
		}

		self::count_failure( $ip );
		self::refuse();
	}

	/**
	 * Is the visitor an administrator of this site, according to their cookie?
	 *
	 * @return bool
	 */
	private static function viewer_may_recover() {
		if ( ! function_exists( 'wp_validate_auth_cookie' ) || ! function_exists( 'user_can' ) ) {
			return false;
		}

		$user = wp_validate_auth_cookie( '', 'logged_in' );

		if ( ! $user ) {
			return false;
		}

		// The same capability the dashboard screen requires. Nothing is
		// readable here that Tools → Critical Errors would not show.
		return user_can( (int) $user, 'manage_options' );
	}

	/**
	 * @return bool Whether this request is asking for the report at all.
	 */
	private static function requested() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return ! empty( $_GET[ self::QUERY_VAR ] );
	}

	/**
	 * @return string
	 */
	private static function ip() {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash
		return isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '';
	}

	/**
	 * Serve the report to a visitor who has proved they may see it.
	 *
	 * @param bool $authenticated True when they got in with a login cookie
	 *                            rather than with the token.
	 */
	private static function handle( $authenticated ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( isset( $_POST['wpdce_clear'] ) && self::may_clear( $authenticated ) ) {
			WPDCE_Log::clear();
		}

		self::render( $authenticated );
	}

	/**
	 * The token is itself the credential, so a token request needs nothing
	 * more. A cookie request does: without a nonce, any page on the internet
	 * could make a signed-in administrator's browser wipe the log.
	 *
	 * @param bool $authenticated Cookie rather than token.
	 * @return bool
	 */
	private static function may_clear( $authenticated ) {
		if ( ! $authenticated ) {
			return true;
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$nonce = isset( $_POST['wpdce_nonce'] ) ? (string) wp_unslash( $_POST['wpdce_nonce'] ) : '';

		return '' !== $nonce && function_exists( 'wp_verify_nonce' ) && (bool) wp_verify_nonce( $nonce, 'wpdce_clear' );
	}

	/**
	 * @param string $candidate Supplied token.
	 * @return bool
	 */
	public static function verify( $candidate ) {
		$candidate = trim( $candidate );

		if ( strlen( $candidate ) < 20 ) {
			return false;
		}

		foreach ( self::valid_tokens() as $token ) {
			if ( '' !== $token && hash_equals( $token, $candidate ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * @return string[]
	 */
	private static function valid_tokens() {
		$tokens = array();

		// Constant first: it needs no database, which is the case that matters.
		if ( defined( 'WPDCE_RECOVERY_KEY' ) && is_string( WPDCE_RECOVERY_KEY ) ) {
			$tokens[] = (string) WPDCE_RECOVERY_KEY;
		}

		if ( function_exists( 'get_option' ) ) {
			$stored = get_option( self::OPTION, '' );
			if ( is_string( $stored ) && '' !== $stored ) {
				$tokens[] = $stored;
			}
		}

		return $tokens;
	}

	/**
	 * The token shown in the dashboard, created on first read.
	 *
	 * Stored in plain text, and that is a considered trade rather than an
	 * oversight. Hashing it would mean it could only ever be displayed once —
	 * and the moment you need it is precisely the moment you cannot reach the
	 * screen that would generate a new one. Anyone who can read this option
	 * already has database access, at which point the source excerpts it
	 * protects are the least of your problems. Use WPDCE_RECOVERY_KEY if that
	 * trade is wrong for your site.
	 *
	 * @return string
	 */
	public static function token() {
		if ( defined( 'WPDCE_RECOVERY_KEY' ) && is_string( WPDCE_RECOVERY_KEY ) && '' !== WPDCE_RECOVERY_KEY ) {
			return (string) WPDCE_RECOVERY_KEY;
		}

		$stored = get_option( self::OPTION, '' );

		if ( is_string( $stored ) && strlen( $stored ) >= 20 ) {
			return $stored;
		}

		return self::regenerate();
	}

	/**
	 * @return string New token.
	 */
	public static function regenerate() {
		try {
			$token = bin2hex( random_bytes( 32 ) );
		} catch ( Exception $e ) {
			// random_bytes only throws when no CSPRNG is available at all.
			$token = hash( 'sha256', uniqid( (string) mt_rand(), true ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.rand_mt_rand
		}

		update_option( self::OPTION, $token, false );

		return $token;
	}

	/**
	 * @return string Full URL to the report.
	 */
	public static function url() {
		return add_query_arg( self::QUERY_VAR, self::token(), home_url( '/' ) );
	}

	/* ------------------------------------------------------------------ *
	 * Throttling. File-backed, because the database may be the casualty.
	 * ------------------------------------------------------------------ */

	/**
	 * @return string
	 */
	private static function attempt_path() {
		$dir = WPDCE_Log::dir();

		return '' === $dir ? '' : $dir . self::ATTEMPT_FILE;
	}

	/**
	 * @return array
	 */
	private static function attempts() {
		$path = self::attempt_path();

		if ( '' === $path || ! is_readable( $path ) ) {
			return array();
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents, WordPress.PHP.NoSilencedErrors.Discouraged
		$decoded = json_decode( (string) @file_get_contents( $path ), true );

		return is_array( $decoded ) ? $decoded : array();
	}

	/**
	 * @param array $attempts Data.
	 */
	private static function save_attempts( array $attempts ) {
		$path = self::attempt_path();

		if ( '' === $path ) {
			return;
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents, WordPress.PHP.NoSilencedErrors.Discouraged
		@file_put_contents( $path, json_encode( $attempts ), LOCK_EX ); // phpcs:ignore WordPress.WP.AlternativeFunctions.json_encode_json_encode
	}

	/**
	 * @param string $ip IP.
	 * @return bool
	 */
	public static function locked_out( $ip ) {
		$attempts = self::attempts();
		$key      = md5( (string) $ip );

		if ( ! isset( $attempts[ $key ] ) ) {
			return false;
		}

		if ( ( time() - (int) $attempts[ $key ]['first'] ) > self::ATTEMPT_TTL ) {
			return false;
		}

		return (int) $attempts[ $key ]['count'] >= self::MAX_ATTEMPTS;
	}

	/**
	 * @param string $ip IP.
	 */
	private static function count_failure( $ip ) {
		$attempts = self::attempts();
		$key      = md5( (string) $ip );
		$now      = time();

		if ( ! isset( $attempts[ $key ] ) || ( $now - (int) $attempts[ $key ]['first'] ) > self::ATTEMPT_TTL ) {
			$attempts[ $key ] = array( 'count' => 0, 'first' => $now );
		}

		$attempts[ $key ]['count'] = (int) $attempts[ $key ]['count'] + 1;

		// Keep the file bounded under a distributed guessing attempt.
		if ( count( $attempts ) > 200 ) {
			$attempts = array_slice( $attempts, -100, null, true );
		}

		self::save_attempts( $attempts );
	}

	/**
	 * @param string $ip IP.
	 */
	private static function clear_failures( $ip ) {
		$attempts = self::attempts();
		$key      = md5( (string) $ip );

		if ( isset( $attempts[ $key ] ) ) {
			unset( $attempts[ $key ] );
			self::save_attempts( $attempts );
		}
	}

	/**
	 * Refuse without confirming that the endpoint exists at all.
	 */
	private static function refuse() {
		if ( ! headers_sent() ) {
			header( 'HTTP/1.1 404 Not Found' );
			header( 'X-Robots-Tag: noindex, nofollow' );
			header( 'Cache-Control: no-store' );
		}

		exit;
	}

	/**
	 * @param bool $authenticated Reached with a login cookie rather than a token.
	 */
	private static function render( $authenticated = false ) {
		if ( ! headers_sent() ) {
			header( 'Content-Type: text/html; charset=utf-8' );
			header( 'X-Robots-Tag: noindex, nofollow, noarchive' );
			header( 'Cache-Control: no-store, no-cache, must-revalidate' );
		}

		$errors = WPDCE_Log::recent();

		// Read by the view, which needs a nonce on its clear form when there is
		// no token doing that job.
		$wpdce_authenticated = (bool) $authenticated;

		require WPDCE_DIR . 'views/report.php';

		exit;
	}

	/**
	 * The recovery URL for somebody who is signed in — no token in it, so it is
	 * safe to print in the dashboard, in an email, or in a support ticket.
	 *
	 * @return string
	 */
	public static function login_url() {
		return add_query_arg( self::QUERY_VAR, '1', home_url( '/' ) );
	}

	/**
	 * The stored token, or '' — without creating one.
	 *
	 * token() will generate and save a token if none exists, which is right on
	 * a dashboard screen and wrong during a crash: a request that is already
	 * failing should not be asked to write to the database on its way out.
	 *
	 * @return string
	 */
	public static function token_if_any() {
		if ( defined( 'WPDCE_RECOVERY_KEY' ) && is_string( WPDCE_RECOVERY_KEY ) && '' !== WPDCE_RECOVERY_KEY ) {
			return (string) WPDCE_RECOVERY_KEY;
		}

		if ( ! function_exists( 'get_option' ) ) {
			return '';
		}

		$stored = get_option( self::OPTION, '' );

		return ( is_string( $stored ) && strlen( $stored ) >= 20 ) ? $stored : '';
	}

	/**
	 * Put the recovery links into the email WordPress already sends.
	 *
	 * When a site fatals, core emails the administrator a recovery-mode link.
	 * That email is the one piece of this that reaches you when the dashboard
	 * is blank, the front end is blank, and you have no file access — so it is
	 * the right place for the links, and it costs nothing: no mail of our own,
	 * no delivery to arrange, and nothing extra attempted inside a request that
	 * is already crashing.
	 *
	 * Everything here is written so that a failure is silent. A crash handler
	 * that throws while explaining a crash helps nobody.
	 */
	public static function hook() {
		add_filter( 'recovery_mode_email', array( __CLASS__, 'add_links_to_email' ), 10, 1 );
	}

	/**
	 * @param array $email to/subject/message/headers, as core assembled it.
	 * @return array
	 */
	public static function add_links_to_email( $email ) {
		if ( ! is_array( $email ) || ! isset( $email['message'] ) ) {
			return $email;
		}

		try {
			$lines = array( '', str_repeat( '-', 60 ), '' );

			$lines[] = __( 'From the critical error reporter on this site:', 'wpd-critical-error' );
			$lines[] = '';
			$lines[] = __( 'The full report — which file, which line, which plugin, and the code itself:', 'wpd-critical-error' );

			$token = self::token_if_any();

			if ( '' !== $token ) {
				$lines[] = '';
				$lines[] = add_query_arg( self::QUERY_VAR, $token, home_url( '/' ) );
				$lines[] = '';
				$lines[] = __( 'That link needs no login and works while the site is down. Treat it as a password, and generate a new one from Tools → Critical Errors once the site is back.', 'wpd-critical-error' );
			}

			$lines[] = '';
			$lines[] = __( 'Or, if you are still signed in as an administrator in your browser, no token is needed:', 'wpd-critical-error' );
			$lines[] = '';
			$lines[] = self::login_url();

			$email['message'] .= implode( "\n", $lines ) . "\n";
		} catch ( Throwable $e ) {
			return $email; // Say less rather than fail while a site is down.
		}

		return $email;
	}
}

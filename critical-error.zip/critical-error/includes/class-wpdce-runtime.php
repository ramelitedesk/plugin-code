<?php
/**
 * The fatal a parser cannot see: code that is perfectly valid and still kills
 * the site the moment it runs.
 *
 *     function test_custom_plugin_fatal_error() {
 *         undefined_test_function();
 *     }
 *     add_action( 'init', 'test_custom_plugin_fatal_error' );
 *
 * There is nothing wrong with that syntactically. `token_get_all()` accepts it,
 * `php -l` accepts it, and every page of the site goes white on the next
 * request. WordPress only finds out afterwards, from its loopback — and on the
 * installs where the loopback cannot run, nobody finds out at all until the
 * dashboard is already blank.
 *
 * So this resolves names instead of grammar. It runs inside a fully booted
 * WordPress, which means `function_exists()` here gives the same answer PHP
 * will give when the file loads: every core function, every function of every
 * active plugin, every function of the theme. A name that does not resolve now
 * will not resolve then.
 *
 * WHAT IT REFUSES TO GUESS
 *
 * A false positive here is worse than a miss. Being told "this will crash" when
 * it will not is how people learn to click past the warning, and then the real
 * one goes past too. So every construct whose resolution cannot be settled by
 * reading the file alone — a variable function, a `use` import, an include that
 * may define the missing name, a namespace, a conditional declaration — either
 * drops the finding to a warning or drops it entirely.
 *
 * SEVERITY
 *
 *   fatal   The call is reached on load, or from a function registered by name
 *           as a callback. This one is going to run. The save is stopped.
 *   warning The name is missing, but whether that code ever runs depends on
 *           something not in this file. Shown, with the lines, and the save is
 *           still allowed.
 *
 * @package WPD_Critical_Error
 */

defined( 'ABSPATH' ) || exit;

class WPDCE_Runtime {

	/**
	 * Names that look like function calls to a tokeniser and are not.
	 *
	 * `array(...)`, `isset(...)`, `list(...)` and friends are language
	 * constructs: they emit their own token types in some PHP versions and a
	 * plain T_STRING in others. Checking function_exists() on them would report
	 * `isset` as an undefined function on half the PHP versions in the wild.
	 */
	const CONSTRUCTS = array(
		'array', 'isset', 'unset', 'empty', 'list', 'echo', 'print', 'exit', 'die',
		'include', 'include_once', 'require', 'require_once', 'eval', 'match', 'fn',
		'function', 'return', 'throw', 'yield', 'clone', 'new', 'if', 'elseif',
		'else', 'while', 'for', 'foreach', 'switch', 'case', 'catch', 'declare',
		'use', 'static', 'self', 'parent', 'and', 'or', 'xor', 'as', 'do', 'try',
		'finally', 'global', 'class', 'interface', 'trait', 'enum', 'namespace',
		'default', 'break', 'continue', 'endif', 'endwhile', 'endfor', 'endforeach',
		'endswitch', 'instanceof', 'insteadof', 'abstract', 'final', 'public',
		'private', 'protected', 'const', 'var', 'extends', 'implements', 'true',
		'false', 'null', 'int', 'float', 'string', 'bool', 'object', 'mixed',
		'void', 'never', 'iterable', 'callable',
	);

	/**
	 * Functions whose string arguments are callbacks.
	 *
	 * A function named in one of these is reached from somewhere this file
	 * cannot see, so "nothing in this file calls it" says nothing about whether
	 * it runs. It does run.
	 */
	const CALLBACK_REGISTRARS = array(
		'add_action', 'add_filter', 'register_activation_hook',
		'register_deactivation_hook', 'register_uninstall_hook', 'add_shortcode',
		'call_user_func', 'call_user_func_array', 'register_rest_route',
		'wp_schedule_event', 'wp_schedule_single_event', 'usort', 'uasort',
		'uksort', 'array_map', 'array_filter', 'array_walk', 'add_meta_box',
		'register_setting', 'add_submenu_page', 'add_menu_page', 'add_options_page',
	);

	/**
	 * Everything in this file that will not resolve when PHP loads it.
	 *
	 * @param string $code      Submitted source.
	 * @param string $real_file Absolute path being edited, or ''.
	 * @return array<int,array> Findings, most severe first.
	 */
	public static function scan( $code, $real_file = '' ) {
		// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		$tokens = @token_get_all( (string) $code );

		if ( ! is_array( $tokens ) || ! $tokens ) {
			return array();
		}

		$map = self::walk( $tokens );

		/*
		 * Includes have to be followed rather than surrendered to.
		 *
		 * The tempting shortcut is "this file includes something, so anything
		 * missing might be defined in there — warn, do not block". It is even
		 * true. It is also useless, because the file this check exists for is
		 * a theme's functions.php, and essentially every functions.php in the
		 * world ends with a run of `require get_template_directory() . '/inc/…'`
		 * lines. That shortcut disarms the check precisely where it is needed.
		 *
		 * So the includes are resolved and read, and what they declare is added
		 * to what this file declares. Only an include that cannot be resolved —
		 * a variable path, a computed name — falls back to the shortcut.
		 */
		$followed = self::follow_includes( $map['includes'], $real_file, $map['file_guards'] );

		$map['declared'] += $followed['declared'];

		/*
		 * What is left that turns certainty into a guess:
		 *
		 *   - an include whose path could not be worked out, which may define
		 *     anything at all;
		 *   - a `use` import, which rewrites what a bare name means;
		 *   - a namespace, where an unqualified class name resolves to the
		 *     namespace and not to the global table this check consults.
		 *
		 * None of them are reasons to say nothing. They are reasons not to
		 * block the save over what is now an educated guess.
		 */
		$map['unresolved'] = $followed['unresolved'];

		$uncertain = $followed['unresolved'] || $map['imports'] || '' !== $map['namespace'];

		$loading = self::loading( $real_file );

		$findings = array();

		foreach ( $map['refs'] as $ref ) {
			$finding = self::judge( $ref, $map, $uncertain, $code, $loading );

			if ( $finding ) {
				$findings[] = $finding;
			}
		}

		foreach ( $map['returns'] as $bad ) {
			if ( isset( $bad['parameter'] ) ) {
				continue; // Judged at the call sites, not here.
			}

			$findings[] = self::judge_return( $bad, $map, $code, $loading );
		}

		foreach ( $map['accesses'] as $access ) {
			$finding = self::judge_access( $access, $map, $code, $loading );

			if ( $finding ) {
				$findings[] = $finding;
			}
		}

		foreach ( $followed['missing'] as $missing ) {
			$findings[] = self::judge_missing_include( $missing, $map, $code, $loading );
		}

		foreach ( $map['unbound'] as $unbound ) {
			$reached = isset( $map['reachable'][ $unbound['key'] ] );

			$findings[] = array(
				'severity' => ( $reached && 'entry' === $loading ) ? 'fatal' : 'warning',
				'kind'     => 'unbound',
				'name'     => $unbound['name'],
				'line'     => $unbound['line'],
				'label'    => __( 'Undefined variable', 'wpd-critical-error' ),
				'message'  => sprintf(
					/* translators: %s: method name. */
					__( 'Uncaught Error: Call to a member function %s() on null', 'wpd-critical-error' ),
					$unbound['member']
				),
				'excerpt'  => WPDCE_Editor::excerpt( $code, $unbound['line'] ),
				'hint'     => sprintf(
					/* translators: 1: variable name, 2: variable name again. */
					__( 'A function has its own scope, and nothing in this one gives %1$s a value — so it is null, and calling a method on null is fatal. If it is one of WordPress\'s globals, the line it needs is global %2$s; at the top of the function. A closure needs use ( %2$s ) instead.', 'wpd-critical-error' ),
					$unbound['name'],
					$unbound['name']
				),
			);
		}

		// One finding per name. Ten calls to the same missing function is one
		// mistake, and listing it ten times reads as ten.
		$findings = self::unique_by_name( $findings );

		usort(
			$findings,
			static function ( $a, $b ) {
				if ( $a['severity'] === $b['severity'] ) {
					return $a['line'] - $b['line'];
				}
				return 'fatal' === $a['severity'] ? -1 : 1;
			}
		);

		return $findings;
	}

	/* ------------------------------------------------------------------ *
	 * Reading the file
	 * ------------------------------------------------------------------ */

	/**
	 * One pass over the tokens, collecting everything the judgement needs.
	 *
	 * @param array $tokens From token_get_all().
	 * @return array{refs:array,declared:array,strings:array,guarded:array,imports:bool,includes:bool,namespace:string}
	 */
	private static function walk( array $tokens ) {
		$total = count( $tokens );

		$refs      = array();
		$declared  = array();  // Lowercased "kind:name" of everything this file declares.
		$strings   = array();  // Lowercased string literals — how callbacks are named.
		$guarded   = array();  // Names the file itself tests with *_exists().
		$imports   = false;
		$includes  = array();  // One token slice per include expression.
		$namespace = '';

		/*
		 * Who calls whom. '' is the file itself — code at the top level, which
		 * runs the moment the file is included. Everything reachable from there
		 * runs too, and that is the difference between code that will crash the
		 * site and code that merely could.
		 */
		$calls   = array();
		$hooked  = array();   // Keys seeded as reachable from outside the file.
		$vars    = array();   // Top-level $variable => the class it was given.
		$types   = array();   // Key => declared return type.
		$returns = array();   // Literal returns that cannot satisfy that type.
		$strict  = false;

		/*
		 * What each class this file declares actually has, and every use of a
		 * member on an object whose class is one of them. Judged together at
		 * the end, because a class may be declared below the code that uses it.
		 */
		$classes  = array();
		$accesses = array();

		// Paths the file itself tests for before requiring them.
		$file_guards = array();

		// Open `if ( … ) :` blocks, which have no brace to count.
		$alternate = 0;

		// How many return statements each function body has.
		$return_count = array();

		/*
		 * Which variables each function body binds, and which it only ever
		 * calls a method on. A function has its own scope, so a `$wpdb` that
		 * nobody declared `global` inside it is null — and calling a method on
		 * null is a fatal error, not a notice.
		 */
		$scopes = array();

		// One entry per open brace, so the scanner always knows whether it is
		// inside a function body and, if so, whose.
		$stack   = array();
		$pending = null;

		for ( $i = 0; $i < $total; $i++ ) {
			$token = $tokens[ $i ];

			if ( ! is_array( $token ) ) {
				if ( '{' === $token ) {
					$stack[] = null === $pending ? array( 'kind' => 'block', 'name' => '' ) : $pending;
					$pending = null;
				} elseif ( '}' === $token ) {
					array_pop( $stack );
				} elseif ( ';' === $token ) {
					/*
					 * A declaration with no body — `abstract function f();` in
					 * an abstract class, or any method of an interface. Without
					 * this the pending frame would sit there waiting, and the
					 * next unrelated brace in the file would be labelled as
					 * that function's body.
					 */
					$pending = null;
				}
				continue;
			}

			switch ( $token[0] ) {
				case T_CURLY_OPEN:
				case T_DOLLAR_OPEN_CURLY_BRACES:
					// "{$var}" inside a string. Its closer is a real '}', so it
					// has to be balanced or every depth after it is wrong.
					$stack[] = array( 'kind' => 'block', 'name' => '' );
					break;

				case T_NAMESPACE:
					$namespace = 'set';
					break;

				case T_USE:
					// `use Foo\Bar;` at the top level imports a name. Inside a
					// class body it is a trait, and after a closure signature
					// it captures variables.
					if ( ! $stack ) {
						$imports = true;
						break;
					}

					$holder = end( $stack );

					// A trait brings in members this file may not be able to
					// see, so the class can no longer be judged on what it
					// declares for itself.
					if ( $holder && 'class' === $holder['kind'] && isset( $classes[ strtolower( $holder['name'] ) ] ) ) {
						$classes[ strtolower( $holder['name'] ) ]['opaque'] = true;
					}
					break;

				case T_INCLUDE:
				case T_INCLUDE_ONCE:
				case T_REQUIRE:
				case T_REQUIRE_ONCE:
					$includes[] = array(
						'tokens'   => self::expression_after( $tokens, $i ),
						'required' => T_REQUIRE === $token[0] || T_REQUIRE_ONCE === $token[0],
						'line'     => (int) $token[2],
						'key'      => self::owner_key( $stack ),
						'context'  => self::context( $stack ),

						/*
						 * Unconditional means exactly that: not inside a brace
						 * of any kind, and not inside an `if ( … ) : … endif;`
						 * either. Anything else has a condition on it, and the
						 * author put it there because the file is not always
						 * meant to be present — WordPress loads db.php,
						 * sunrise.php and object-cache.php this way, and
						 * blocking a save over one would be flatly wrong.
						 */
						'certain'  => ! $stack && 0 === $alternate,
					);
					break;

				case T_IF:
				case T_FOR:
				case T_FOREACH:
				case T_WHILE:
				case T_SWITCH:
					if ( WPDCE_Editor::opens_alternative_block( $tokens, $i ) ) {
						$alternate++;
					}
					break;

				case T_ENDIF:
				case T_ENDFOR:
				case T_ENDFOREACH:
				case T_ENDWHILE:
				case T_ENDSWITCH:
					$alternate = max( 0, $alternate - 1 );
					break;

				case T_CONSTANT_ENCAPSED_STRING:
					$value = trim( $token[1], "'\"" );

					if ( '' !== $value ) {
						$strings[ strtolower( $value ) ] = true;
					}
					break;

				case T_DECLARE:
					// declare( strict_types=1 ) changes what a return value is
					// allowed to be, so it has to be known before judging one.
					$strict = $strict || self::declares_strict_types( $tokens, $i );
					break;

				case T_FUNCTION:
					$name  = self::name_after( $tokens, $i );
					$owner = self::owner_key( $stack );

					// Declared directly inside a class body: a method, which is
					// reached through its class rather than by its bare name.
					$holder = end( $stack );
					$inside = ( $holder && 'class' === $holder['kind'] ) ? $holder['name'] : '';

					if ( '' !== $name && '' !== $inside ) {
						$key     = 'method:' . strtolower( $inside ) . '::' . strtolower( $name );
						$pending = array( 'kind' => 'function', 'name' => $name, 'hook' => false, 'key' => $key, 'class' => $inside, 'signature' => self::signature( $tokens, $i ) );

						$holder_key = strtolower( $inside );

						if ( isset( $classes[ $holder_key ] ) ) {
							$classes[ $holder_key ]['methods'][ strtolower( $name ) ] = array(
								'name'   => $name,
								'static' => self::modified_static( $tokens, $i ),
							);

							// __call and friends answer for members that were
							// never written down, so a class with any of them
							// cannot be judged on what it declares.
							if ( 0 === strpos( strtolower( $name ), '__' ) ) {
								$classes[ $holder_key ]['magic'][ strtolower( $name ) ] = true;
							}
						}
					} elseif ( '' !== $name ) {
						$key = 'function:' . strtolower( $name );

						$declared[ $key ] = true;

						$pending = array( 'kind' => 'function', 'name' => $name, 'hook' => false, 'key' => $key, 'class' => '', 'signature' => self::signature( $tokens, $i ) );
					} else {
						// An anonymous function is still a body, and code in it
						// must not be attributed to the function enclosing it.
						$key  = 'closure:' . (int) $token[2];
						$hook = self::inside_registrar( $tokens, $i );

						if ( $hook ) {
							// Handed straight to add_action(). It runs.
							$hooked[ $key ] = true;
						}

						$pending = array( 'kind' => 'function', 'name' => '', 'hook' => $hook, 'key' => $key, 'class' => self::enclosing_class( $stack ), 'signature' => self::signature( $tokens, $i ) );

						/*
						 * A closure written inline runs wherever the code
						 * around it runs — `$x = function () {…}; $x();` is not
						 * modelled, but `array_map( function () {…}, … )` is
						 * reached exactly when its own line is.
						 */
						$calls[ $owner ][] = $key;
					}

					$type = self::return_type( $tokens, $i );

					if ( $type ) {
						$types[ $key ] = $type;
					}

					/*
					 * Parameters and `use ( … )` variables are written before
					 * the body's brace, so by the time the walk is inside the
					 * body they are long past. They are bound here instead, or
					 * every parameter would look undefined.
					 */
					foreach ( self::signature_variables( $tokens, $i ) as $bound ) {
						$scopes[ $key ]['bound'][ $bound ] = true;
					}
					break;

				case T_CLASS:
				case T_INTERFACE:
				case T_TRAIT:
					if ( self::preceded_by_double_colon( $tokens, $i ) ) {
						break; // Foo::class
					}

					$name = self::name_after( $tokens, $i );

					if ( '' !== $name ) {
						$declared[ 'class:' . strtolower( $name ) ] = true;

						// The member table this class will be judged against.
						// A class that turns out to inherit from somewhere this
						// file cannot see is disqualified below.
						$classes[ strtolower( $name ) ] = array(
							'name'    => $name,
							'methods' => array(),
							'props'   => array(),
							'magic'   => array(),
							'opaque'  => T_CLASS !== $token[0] || self::has_unknown_parent( $tokens, $i ),
						);
					}

					$pending = array( 'kind' => 'class', 'name' => $name, 'hook' => false, 'key' => '', 'class' => $name, 'signature' => array() );
					break;

				case T_RETURN:
					/*
					 * Counted for every return, wherever it sits. A function
					 * with two of them may leave by either, and the pass-through
					 * reasoning below only holds when there is exactly one way
					 * out — otherwise `if ( $v ) { return 'x'; } return $v;`
					 * would be reported for a branch it may never take.
					 */
					$counted = self::owner_key( $stack );

					if ( '' !== $counted ) {
						$return_count[ $counted ] = isset( $return_count[ $counted ] ) ? $return_count[ $counted ] + 1 : 1;
					}

					$bad = self::bad_return( $tokens, $i, $stack, $types, $strict );

					if ( $bad ) {
						$returns[] = $bad;
					}
					break;

				case T_VARIABLE:
					$holder = end( $stack );

					// Directly inside a class body, a variable is a property
					// declaration rather than a use of one.
					if ( $holder && 'class' === $holder['kind'] && isset( $classes[ strtolower( $holder['name'] ) ] ) ) {
						$property = self::property_declaration( $tokens, $i );

						if ( $property ) {
							$classes[ strtolower( $holder['name'] ) ]['props'][ strtolower( ltrim( $token[1], '$' ) ) ] = $property;
						}

						break;
					}

					self::variable_use( $tokens, $i, $stack, $declared, $vars, $calls, $accesses );
					self::note_scope_variable( $tokens, $i, $stack, $scopes );
					break;

				case T_STRING:
					/*
					 * `if ( file_exists( … ) ) { require …; }` is the way every
					 * optional drop-in in WordPress is loaded — db.php,
					 * object-cache.php, maintenance.php. The require is real
					 * and the file is genuinely absent, and it is completely
					 * correct code. The author said so; take their word for it.
					 */
					if ( in_array( strtolower( $token[1] ), array( 'file_exists', 'is_file', 'is_readable', 'stream_resolve_include_path' ), true ) ) {
						$open = self::next_index( $tokens, $i, '(' );

						if ( -1 !== $open ) {
							$file_guards[] = self::expression_after( $tokens, $open );
						}
					}

					$ref = self::reference( $tokens, $i, $stack );

					if ( $ref ) {
						if ( 'guard' === $ref['kind'] ) {
							$guarded[ $ref['name'] ] = true;
							break;
						}

						self::record_call( $tokens, $i, $ref, $stack, $calls, $accesses );

						$refs[] = $ref;
					}
					break;

				case T_NEW:
					$ref = self::instantiation( $tokens, $i, $stack );

					if ( $ref ) {
						// Constructing a class runs its constructor.
						$calls[ self::owner_key( $stack ) ][] = 'method:' . strtolower( self::bare( $ref['name'] ) ) . '::__construct';

						$refs[] = $ref;
					}
					break;

				case T_EXTENDS:
				case T_IMPLEMENTS:
					foreach ( self::names_after( $tokens, $i ) as $entry ) {
						$refs[] = array(
							'kind'    => 'class',
							'name'    => $entry['name'],
							'line'    => $entry['line'],
							'context' => 'top', // A missing parent is fatal at load.
							'owner'   => '',
							'hook'    => false,
							'key'     => '',
							'why'     => T_EXTENDS === $token[0] ? 'extends' : 'implements',
						);
					}
					break;

				default:
					// PHP 8 gives namespaced names their own token types, which
					// do not exist as constants on PHP 7 and so cannot appear
					// as case labels above.
					if ( in_array( $token[0], self::name_tokens(), true ) ) {
						$ref = self::reference( $tokens, $i, $stack );

						if ( $ref && 'guard' !== $ref['kind'] ) {
							self::record_call( $tokens, $i, $ref, $stack, $calls, $accesses );

							$refs[] = $ref;
						}
					}
					break;
			}
		}

		// A function named as a string anywhere in the file is registered as a
		// callback somewhere this file cannot see. It runs.
		foreach ( $declared as $key => $unused ) {
			if ( 0 === strpos( $key, 'function:' ) && isset( $strings[ substr( $key, 9 ) ] ) ) {
				$hooked[ $key ] = true;
			}
		}

		return array(
			'refs'      => $refs,
			'declared'  => $declared,
			'strings'   => $strings,
			'guarded'   => $guarded,
			'imports'   => $imports,
			'includes'  => $includes,
			'file_guards' => $file_guards,
			'namespace' => $namespace,
			'reachable' => self::reachable( $calls, $hooked ),
			'returns'   => $returns,
			'classes'   => $classes,
			'accesses'  => $accesses,
			'unbound'   => self::unbound( $scopes ),
			'strict'    => $strict,
			'passthrough' => self::passthrough( $returns, $return_count ),
		);
	}

	/* ------------------------------------------------------------------ *
	 * Class members
	 * ------------------------------------------------------------------ */

	/**
	 * Does this class inherit from somewhere this file cannot read?
	 *
	 * A class extending something declared elsewhere has members that are not
	 * written down here, and "the method is not in this file" then says nothing
	 * about whether it exists. The same goes for implementing an interface,
	 * which brings constants along with it.
	 *
	 * @param array $tokens Tokens.
	 * @param int   $i      Index of T_CLASS.
	 * @return bool
	 */
	private static function has_unknown_parent( array $tokens, $i ) {
		$total = count( $tokens );

		for ( $j = $i + 1; $j < $total; $j++ ) {
			$token = $tokens[ $j ];

			if ( is_string( $token ) ) {
				if ( '{' === $token ) {
					return false;
				}
				continue;
			}

			if ( T_EXTENDS === $token[0] || T_IMPLEMENTS === $token[0] ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Was this function declared `static`?
	 *
	 * @param array $tokens Tokens.
	 * @param int   $i      Index of T_FUNCTION.
	 * @return bool
	 */
	private static function modified_static( array $tokens, $i ) {
		for ( $j = $i - 1; $j >= 0; $j-- ) {
			$token = $tokens[ $j ];

			if ( is_string( $token ) ) {
				return false; // '{', '}' or ';' — the previous member ended.
			}

			if ( T_STATIC === $token[0] ) {
				return true;
			}

			$modifiers = array( T_WHITESPACE, T_COMMENT, T_DOC_COMMENT, T_PUBLIC, T_PRIVATE, T_PROTECTED, T_ABSTRACT, T_FINAL, T_VAR );

			if ( defined( 'T_READONLY' ) ) {
				$modifiers[] = T_READONLY;
			}

			if ( ! in_array( $token[0], $modifiers, true ) ) {
				return false;
			}
		}

		return false;
	}

	/**
	 * A typed property declaration, read backwards from its variable.
	 *
	 * Only declarations with a type are of interest. An untyped property
	 * accepts anything, and a property that was never declared at all is a
	 * dynamic one — deprecated since PHP 8.2, and not an error.
	 *
	 * @param array $tokens Tokens.
	 * @param int   $i      Index of the T_VARIABLE.
	 * @return array{type:string,nullable:bool}|null
	 */
	private static function property_declaration( array $tokens, $i ) {
		$type      = '';
		$nullable  = false;
		$declared  = false;
		$modifiers = array( T_PUBLIC, T_PRIVATE, T_PROTECTED, T_VAR );

		if ( defined( 'T_READONLY' ) ) {
			$modifiers[] = T_READONLY;
		}

		for ( $j = $i - 1; $j >= 0; $j-- ) {
			$token = $tokens[ $j ];

			if ( is_string( $token ) ) {
				if ( '?' === $token ) {
					$nullable = true;
					continue;
				}

				break; // '{', '}' or ';' — the start of this declaration.
			}

			if ( in_array( $token[0], array( T_WHITESPACE, T_COMMENT, T_DOC_COMMENT ), true ) ) {
				continue;
			}

			if ( in_array( $token[0], $modifiers, true ) ) {
				$declared = true;
				continue;
			}

			if ( T_STATIC === $token[0] || T_FINAL === $token[0] ) {
				continue;
			}

			if ( T_STRING === $token[0] || T_ARRAY === $token[0] ) {
				if ( '' !== $type ) {
					return null; // A union, read right to left.
				}

				$type = strtolower( $token[1] );
				continue;
			}

			return null; // Anything else: not a plain typed property.
		}

		if ( ! $declared ) {
			return null;
		}

		$known = array( 'int', 'float', 'string', 'bool', 'array' );

		return in_array( $type, $known, true ) ? array( 'type' => $type, 'nullable' => $nullable ) : null;
	}

	/* ------------------------------------------------------------------ *
	 * What actually runs
	 * ------------------------------------------------------------------ */

	/**
	 * Everything that runs when this file is loaded.
	 *
	 * The old rule for "does this code run?" was a single heuristic: is the
	 * enclosing function's name written as a string somewhere, the way a hook
	 * callback is registered. That catches `add_action( 'init', 'my_function' )`
	 * and misses the plainest case there is —
	 *
	 *     function test_fatal_error() {
	 *         undefined_function_for_testing();
	 *     }
	 *
	 *     test_fatal_error();
	 *
	 * — where nothing is registered and nothing is a string, and the site is
	 * gone all the same, because the last line calls it.
	 *
	 * So calls are followed instead. The top level of the file runs by
	 * definition; whatever it calls runs; whatever that calls runs. The same
	 * walk covers methods, reached through `new` and through a variable holding
	 * an instance, which is how the third case people hit gets caught:
	 *
	 *     $test = new TestCriticalError();
	 *     $test->run();
	 *
	 * @param array $calls  Caller key => callee keys. '' is the top level.
	 * @param array $hooked Keys reached from outside the file.
	 * @return array<string,bool> Reachable keys.
	 */
	private static function reachable( array $calls, array $hooked ) {
		$reachable = array();
		$queue     = array_keys( $hooked );

		// The top level runs on include, so everything it calls runs.
		if ( isset( $calls[''] ) ) {
			$queue = array_merge( $queue, $calls[''] );
		}

		$guard = 0;

		while ( $queue ) {
			$key = array_pop( $queue );

			// A cycle, or a diamond. Either way it has been dealt with.
			if ( isset( $reachable[ $key ] ) || ++$guard > 5000 ) {
				continue;
			}

			$reachable[ $key ] = true;

			if ( isset( $calls[ $key ] ) ) {
				$queue = array_merge( $queue, $calls[ $key ] );
			}
		}

		return $reachable;
	}

	/**
	 * Record the edge from whatever encloses this reference to what it calls.
	 *
	 * @param array $tokens Tokens.
	 * @param int   $i      Index of the name.
	 * @param array $ref    The reference reference() produced.
	 * @param array $stack  Open blocks.
	 * @param array $calls  Accumulator.
	 */
	private static function record_call( array $tokens, $i, array $ref, array $stack, array &$calls, array &$accesses ) {
		$owner = self::owner_key( $stack );
		$bare  = strtolower( self::bare( $ref['name'] ) );

		if ( 'function' === $ref['kind'] ) {
			$calls[ $owner ][] = 'function:' . $bare;

			$literals = self::literal_arguments( $tokens, $i );

			if ( $literals ) {
				$accesses[] = array(
					'kind'      => 'argument',
					'class'     => '',
					'member'    => $ref['name'],
					'callee'    => 'function:' . $bare,
					'literals'  => $literals,
					'line'      => (int) $tokens[ $i ][2],
					'key'       => $owner,
					'context'   => self::context( $stack ),
					'inside'    => '',
				);
			}

			return;
		}

		// Foo::bar() — the class was the reference; the method is the call.
		if ( 'static' !== $ref['why'] ) {
			return;
		}

		$member = self::member_ref( $tokens, $i );

		if ( null === $member || ! $member['call'] ) {
			return;
		}

		$calls[ $owner ][] = 'method:' . $bare . '::' . strtolower( $member['name'] );

		$accesses[] = array(
			'kind'    => 'static',
			'class'   => $bare,
			'member'  => $member['name'],
			'line'    => $member['line'],
			'key'     => $owner,
			'context' => self::context( $stack ),
			'inside'  => strtolower( self::enclosing_class( $stack ) ),
		);
	}

	/**
	 * Functions whose declared return type is really their caller's problem.
	 *
	 * Only where there is exactly one such return. Two of them and the
	 * function's behaviour depends on which one is reached, which is a branch
	 * this does not reason about.
	 *
	 * @param array $returns Everything bad_return() collected.
	 * @return array<string,array> Callee key => the pass-through it performs.
	 */
	private static function passthrough( array $returns, array $return_count = array() ) {
		$out     = array();
		$refused = array();

		foreach ( $returns as $bad ) {
			if ( ! isset( $bad['parameter'] ) ) {
				continue;
			}

			// One way out, or none of this holds.
			if ( ! isset( $return_count[ $bad['key'] ] ) || 1 !== $return_count[ $bad['key'] ] ) {
				$refused[ $bad['key'] ] = true;
				continue;
			}

			if ( isset( $out[ $bad['key'] ] ) ) {
				$refused[ $bad['key'] ] = true;
				continue;
			}

			$out[ $bad['key'] ] = array(
				'parameter' => $bad['parameter'],
				'type'      => $bad['type'],
				'nullable'  => $bad['nullable'],
				'line'      => $bad['line'],
			);
		}

		foreach ( array_keys( $refused ) as $key ) {
			unset( $out[ $key ] );
		}

		return $out;
	}

	/**
	 * Method calls on variables their scope never gives a value to.
	 *
	 * @param array $scopes Per-scope bindings and method calls.
	 * @return array<int,array>
	 */
	private static function unbound( array $scopes ) {
		$out = array();

		foreach ( $scopes as $key => $scope ) {
			if ( empty( $scope['calls'] ) ) {
				continue;
			}

			$bound = isset( $scope['bound'] ) ? $scope['bound'] : array();
			$seen  = array();

			foreach ( $scope['calls'] as $call ) {
				$name = strtolower( $call['name'] );

				if ( isset( $bound[ $name ] ) || isset( $seen[ $name ] ) ) {
					continue;
				}

				$seen[ $name ] = true;

				$out[] = array(
					'key'    => $key,
					'name'   => $call['name'],
					'member' => $call['member'],
					'line'   => $call['line'],
				);
			}
		}

		return $out;
	}

	/**
	 * Superglobals, which are in scope everywhere and bound by nobody.
	 */
	const SUPERGLOBALS = array(
		'$globals', '$_get', '$_post', '$_server', '$_files', '$_cookie',
		'$_session', '$_request', '$_env', '$this', '$http_response_header',
		'$argc', '$argv', '$php_errormsg',
	);

	/**
	 * Note whether this occurrence binds the variable or merely uses it.
	 *
	 * The rule is deliberately blunt: a variable counts as bound if it appears
	 * anywhere in its scope in any position other than `$var->something`. That
	 * covers assignment, parameters, `global`, `static`, `use`, `foreach as`,
	 * `catch`, list destructuring, `$var[…]`, and being passed to a function
	 * that takes its argument by reference — which is the one that would
	 * otherwise cause false positives, because there is no way to know from
	 * here that `preg_match( $re, $s, $matches )` defines `$matches`.
	 *
	 * What is left is a variable that appears in its scope *only* as the object
	 * of a method call and is never given a value anywhere. That is null, and
	 * calling a method on null is fatal.
	 *
	 * @param array $tokens Tokens.
	 * @param int   $i      Index of the T_VARIABLE.
	 * @param array $stack  Open blocks.
	 * @param array $scopes Accumulator.
	 */
	private static function note_scope_variable( array $tokens, $i, array $stack, array &$scopes ) {
		$key = self::owner_key( $stack );

		/*
		 * Only inside a function body. At the top level of a theme's
		 * functions.php, `$wpdb` and friends really are in scope — that is the
		 * global scope, and this check would be wrong there.
		 */
		if ( '' === $key ) {
			return;
		}

		$name = strtolower( $tokens[ $i ][1] );

		if ( in_array( $name, self::SUPERGLOBALS, true ) ) {
			return;
		}

		$member = self::member_ref( $tokens, $i );

		if ( null === $member || ! $member['call'] ) {
			$scopes[ $key ]['bound'][ $name ] = true;
			return;
		}

		$scopes[ $key ]['calls'][] = array(
			'name'   => $tokens[ $i ][1],
			'member' => $member['name'],
			'line'   => $member['line'],
		);
	}

	/**
	 * Every variable written between `function` and the body's opening brace:
	 * the parameters, and a closure's `use ( … )` list.
	 *
	 * @param array $tokens Tokens.
	 * @param int   $i      Index of T_FUNCTION.
	 * @return array<int,string> Lowercased names.
	 */
	private static function signature_variables( array $tokens, $i ) {
		$total = count( $tokens );
		$names = array();

		for ( $j = $i + 1; $j < $total; $j++ ) {
			$token = $tokens[ $j ];

			if ( is_string( $token ) ) {
				if ( '{' === $token || ';' === $token ) {
					break;
				}
				continue;
			}

			if ( T_VARIABLE === $token[0] ) {
				$names[] = strtolower( $token[1] );
			}
		}

		return $names;
	}

	/**
	 * The literal arguments of a call, by position.
	 *
	 * Positions holding anything other than a literal are simply absent from
	 * the result — there is nothing to say about them.
	 *
	 * @param array $tokens Tokens.
	 * @param int   $i      Index of the function name.
	 * @return array<int,string> Position => literal kind.
	 */
	private static function literal_arguments( array $tokens, $i ) {
		$open = self::next_index( $tokens, $i, '(' );

		if ( -1 === $open ) {
			return array();
		}

		$close = self::matching( $tokens, $open, '(', ')' );

		if ( -1 === $close ) {
			return array();
		}

		$out      = array();
		$position = 0;
		$start    = $open;

		for ( $j = $open + 1; $j <= $close; $j++ ) {
			$token = $tokens[ $j ];

			$boundary = is_string( $token ) && ( ( ',' === $token && self::depth_between( $tokens, $open, $j ) === 1 ) || $j === $close );

			if ( ! $boundary ) {
				continue;
			}

			// literal_after() reads from just past its index up to a
			// terminator, which is exactly the shape of one argument.
			$literal = self::literal_after( array_merge( array_slice( $tokens, $start, $j - $start ), array( ';' ) ), 0 );

			if ( null !== $literal ) {
				$out[ $position ] = $literal;
			}

			$position++;
			$start = $j;
		}

		return $out;
	}

	/**
	 * Parenthesis depth at $j, counting from the opening paren at $open.
	 *
	 * @param array $tokens Tokens.
	 * @param int   $open   Index of the opening parenthesis.
	 * @param int   $j      Index to measure at.
	 * @return int
	 */
	private static function depth_between( array $tokens, $open, $j ) {
		$depth = 0;

		for ( $k = $open; $k < $j; $k++ ) {
			if ( ! is_string( $tokens[ $k ] ) ) {
				continue;
			}

			if ( '(' === $tokens[ $k ] || '[' === $tokens[ $k ] ) {
				$depth++;
			} elseif ( ')' === $tokens[ $k ] || ']' === $tokens[ $k ] ) {
				$depth--;
			}
		}

		return $depth;
	}

	/**
	 * `$this->run()`, `$object->run()`, and `$object = new Thing()`.
	 *
	 * Only single, unambiguous top-level assignments are tracked. A variable
	 * given two different classes, or given anything that is not a plain `new`,
	 * is marked unknown and no call is attributed to it — the point of this is
	 * to raise a warning to a refusal, and a refusal must not rest on a guess.
	 *
	 * @param array $tokens   Tokens.
	 * @param int   $i        Index of the variable.
	 * @param array $stack    Open blocks.
	 * @param array $declared What this file declares.
	 * @param array $vars     Accumulator: variable => class.
	 * @param array $calls    Accumulator.
	 */
	private static function variable_use( array $tokens, $i, array $stack, array $declared, array &$vars, array &$calls, array &$accesses ) {
		$name  = $tokens[ $i ][1];
		$owner = self::owner_key( $stack );
		$after = self::significant( $tokens, $i, 1 );

		// $var = new Thing( … )
		if ( '=' === $after ) {
			$value = self::significant( $tokens, self::next_index( $tokens, $i, '=' ), 1 );

			if ( is_array( $value ) && T_NEW === $value[0] ) {
				$class = self::significant( $tokens, self::next_index_of_token( $tokens, $i, T_NEW ), 1 );
				$class = ( is_array( $class ) && in_array( $class[0], self::name_tokens(), true ) )
					? strtolower( self::bare( $class[1] ) )
					: '?';
			} else {
				$class = '?';
			}

			// Assigned twice, differently: from here on it could be either.
			if ( isset( $vars[ $name ] ) && $vars[ $name ] !== $class ) {
				$vars[ $name ] = '?';
			} else {
				$vars[ $name ] = $class;
			}

			return;
		}

		if ( ! is_array( $after ) || T_OBJECT_OPERATOR !== $after[0] ) {
			return;
		}

		$member = self::member_ref( $tokens, $i );

		if ( null === $member ) {
			return;
		}

		// $this-> resolves without any guessing at all; anything else needs the
		// variable to have been given a class, once, in plain sight.
		if ( '$this' === strtolower( $name ) ) {
			$class = strtolower( self::enclosing_class( $stack ) );
		} else {
			$class = isset( $vars[ $name ] ) ? $vars[ $name ] : '?';
		}

		if ( '?' === $class || '' === $class || ! isset( $declared[ 'class:' . $class ] ) ) {
			return;
		}

		if ( $member['call'] ) {
			$calls[ $owner ][] = 'method:' . $class . '::' . strtolower( $member['name'] );

			/*
			 * `$this->read()` is NOT checked for existence, and the reason is
			 * the whole of WordPress's own pomo/streams.php: a base class calls
			 * `$this->read()` and the subclasses supply it. `$this` is whatever
			 * the object turned out to be, which may be a class in another file
			 * that has not been written yet. Sweeping core produced 128 of
			 * these and every one was correct code.
			 *
			 * A variable given `new Thing()` on a line above is a different
			 * matter: the object is exactly that class, and if the class is
			 * declared here and inherits nothing, its methods are all visible.
			 */
			if ( '$this' !== strtolower( $name ) ) {
				$accesses[] = array(
					'kind'    => 'method',
					'class'   => $class,
					'member'  => $member['name'],
					'line'    => $member['line'],
					'key'     => $owner,
					'context' => self::context( $stack ),
					'inside'  => strtolower( self::enclosing_class( $stack ) ),
				);
			}

			return;
		}

		// $object->property = <literal>
		$equals = self::significant( $tokens, $member['index'], 1 );

		if ( '=' !== $equals ) {
			return;
		}

		$literal = self::literal_after( $tokens, self::next_index( $tokens, $member['index'], '=' ) );

		if ( null === $literal ) {
			return;
		}

		$accesses[] = array(
			'kind'    => 'property',
			'class'   => $class,
			'member'  => $member['name'],
			'line'    => $member['line'],
			'key'     => $owner,
			'context' => self::context( $stack ),
			'inside'  => strtolower( self::enclosing_class( $stack ) ),
			'literal' => $literal,
		);
	}

	/**
	 * The name after `->` or `::`, when it is a method call.
	 *
	 * @param array $tokens Tokens.
	 * @param int   $i      Index of the variable or class name.
	 * @return string
	 */
	private static function member_after( array $tokens, $i ) {
		$member = self::member_ref( $tokens, $i );

		return ( $member && $member['call'] ) ? $member['name'] : '';
	}

	/**
	 * The member after `->` or `::`, whether it is called, and where it is.
	 *
	 * @param array $tokens Tokens.
	 * @param int   $i      Index of the variable or class name.
	 * @return array{name:string,call:bool,line:int,index:int}|null
	 */
	private static function member_ref( array $tokens, $i ) {
		$total = count( $tokens );
		$seen  = false;

		for ( $j = $i + 1; $j < $total; $j++ ) {
			$token = $tokens[ $j ];

			if ( is_array( $token ) ) {
				if ( in_array( $token[0], array( T_WHITESPACE, T_COMMENT, T_DOC_COMMENT ), true ) ) {
					continue;
				}

				if ( ! $seen ) {
					$operators = array( T_OBJECT_OPERATOR, T_DOUBLE_COLON );

					if ( defined( 'T_NULLSAFE_OBJECT_OPERATOR' ) ) {
						$operators[] = T_NULLSAFE_OBJECT_OPERATOR;
					}

					if ( ! in_array( $token[0], $operators, true ) ) {
						return null;
					}

					$seen = true;
					continue;
				}

				// `$obj->$name` and `Foo::$bar` are dynamic or static-property
				// access, neither of which can be checked by reading.
				if ( T_STRING !== $token[0] ) {
					return null;
				}

				return array(
					'name'  => $token[1],
					'call'  => '(' === self::significant( $tokens, $j, 1 ),
					'line'  => (int) $token[2],
					'index' => $j,
				);
			}

			return null;
		}

		return null;
	}

	/**
	 * @param array $stack Open blocks.
	 * @return string The key of the innermost function-like body, or '' at the
	 *                top level of the file.
	 */
	private static function owner_key( array $stack ) {
		for ( $i = count( $stack ) - 1; $i >= 0; $i-- ) {
			if ( 'function' === $stack[ $i ]['kind'] ) {
				return isset( $stack[ $i ]['key'] ) ? $stack[ $i ]['key'] : '';
			}
		}

		return '';
	}

	/**
	 * @param array $stack Open blocks.
	 * @return string The innermost class body's name, or ''.
	 */
	private static function enclosing_class( array $stack ) {
		for ( $i = count( $stack ) - 1; $i >= 0; $i-- ) {
			if ( 'class' === $stack[ $i ]['kind'] ) {
				return $stack[ $i ]['name'];
			}

			if ( isset( $stack[ $i ]['class'] ) && '' !== $stack[ $i ]['class'] ) {
				return $stack[ $i ]['class'];
			}
		}

		return '';
	}

	/**
	 * @param array $tokens Tokens.
	 * @param int   $i      Start index.
	 * @param int   $id     Token id to find.
	 * @return int
	 */
	private static function next_index_of_token( array $tokens, $i, $id ) {
		$total = count( $tokens );

		for ( $j = $i + 1; $j < $total; $j++ ) {
			if ( is_array( $tokens[ $j ] ) && $id === $tokens[ $j ][0] ) {
				return $j;
			}
		}

		return $i;
	}

	/* ------------------------------------------------------------------ *
	 * Return types
	 * ------------------------------------------------------------------ */

	/**
	 * The declared return type of the function starting at $i.
	 *
	 * @param array $tokens Tokens.
	 * @param int   $i      Index of T_FUNCTION.
	 * @return array{type:string,nullable:bool}|null Null when there is none, or
	 *                                               when it is not a type this
	 *                                               check reasons about.
	 */
	private static function return_type( array $tokens, $i ) {
		$total = count( $tokens );
		$depth = 0;
		$colon = -1;

		// Step over the parameter list, which may itself contain colons in
		// default values and types.
		for ( $j = $i + 1; $j < $total; $j++ ) {
			$token = $tokens[ $j ];

			if ( ! is_string( $token ) ) {
				continue;
			}

			if ( '(' === $token ) {
				$depth++;
			} elseif ( ')' === $token ) {
				$depth--;

				if ( 0 === $depth ) {
					$colon = $j;
					break;
				}
			}
		}

		if ( -1 === $colon ) {
			return null;
		}

		$next = self::significant( $tokens, $colon, 1 );

		if ( ':' !== $next ) {
			return null; // No declared return type.
		}

		$nullable = false;
		$type     = '';

		for ( $j = self::next_index( $tokens, $colon, ':' ) + 1; $j < $total; $j++ ) {
			$token = $tokens[ $j ];

			if ( is_string( $token ) ) {
				if ( '?' === $token ) {
					$nullable = true;
					continue;
				}

				// The body, or an abstract declaration: the type ended, and it
				// was a single name.
				if ( '{' === $token || ';' === $token ) {
					break;
				}

				// A union, an intersection, or a parenthesised combination of
				// them. Each has its own coercion rules and none of them are
				// worth being half-right about.
				return null;
			}

			if ( in_array( $token[0], array( T_WHITESPACE, T_COMMENT, T_DOC_COMMENT ), true ) ) {
				continue;
			}

			if ( T_STRING === $token[0] || T_ARRAY === $token[0] ) {
				if ( '' !== $type ) {
					return null; // Two names: a union or an intersection.
				}

				$type = strtolower( $token[1] );
				continue;
			}

			break;
		}

		// Only the types whose coercion rules are simple enough to be certain
		// about. A class name, a union, `iterable`, `mixed`, `self`: skipped.
		$known = array( 'int', 'float', 'string', 'bool', 'array', 'void', 'never' );

		if ( ! in_array( $type, $known, true ) ) {
			return null;
		}

		// `?void` is not a thing, and a nullable type accepts null by
		// definition, so both are recorded and judged below.
		return array( 'type' => $type, 'nullable' => $nullable );
	}

	/**
	 * A `return <literal>;` that the declared return type will not accept.
	 *
	 * PHP is not strict by default, and that is the whole difficulty. This is
	 * fine, and returns int(5):
	 *
	 *     function f(): int { return "5"; }
	 *
	 * and so is `function f(): string { return 5; }`. A check that simply
	 * compared type names would refuse both, which is the sort of false
	 * positive that gets a feature switched off. So what is modelled is
	 * coercion, not equality — and only for literal returns written directly in
	 * the function's body, never for an expression whose type is not knowable
	 * by reading, and never for a return nested inside a condition, which may
	 * be a branch that is never taken.
	 *
	 * @param array $tokens Tokens.
	 * @param int   $i      Index of T_RETURN.
	 * @param array $stack  Open blocks.
	 * @param array $types  Key => declared return type.
	 * @param bool  $strict Whether the file declares strict_types.
	 * @return array|null
	 */
	private static function bad_return( array $tokens, $i, array $stack, array $types, $strict ) {
		$frame = end( $stack );

		// Directly in a function's body: the innermost open brace is the
		// function's own. Anything deeper is inside an if, a loop or a switch,
		// and may be a branch that never runs.
		if ( ! $frame || 'function' !== $frame['kind'] || empty( $frame['key'] ) ) {
			return null;
		}

		$key = $frame['key'];

		if ( ! isset( $types[ $key ] ) ) {
			return null;
		}

		$declared = $types[ $key ];
		$literal  = self::literal_after( $tokens, $i );

		if ( null === $literal ) {
			/*
			 * `return $value;` where $value is an untyped parameter. The
			 * function's return type then depends on what each caller passes,
			 * which is one hop away and worth following:
			 *
			 *     function wp_test_function( $value ): string {
			 *         return $value;
			 *     }
			 *
			 *     wp_test_function( [] );   // TypeError, array returned
			 */
			$parameter = self::returned_parameter( $tokens, $i, $frame );

			if ( null !== $parameter ) {
				return array(
					'key'       => $key,
					'name'      => $frame['name'],
					'line'      => (int) $tokens[ $i ][2],
					'type'      => $declared['type'],
					'nullable'  => $declared['nullable'],
					'parameter' => $parameter,
				);
			}

			return null; // Not a literal, so not knowable by reading.
		}

		$problem = self::return_mismatch( $declared, $literal, $strict );

		if ( '' === $problem ) {
			return null;
		}

		return array(
			'key'     => $key,
			'name'    => $frame['name'],
			'line'    => (int) $tokens[ $i ][2],
			'type'    => $declared['type'],
			'given'   => $literal,
			'problem' => $problem,
		);
	}

	/**
	 * `return $param;` — which parameter, if that is all the return does.
	 *
	 * Strictly one hop and no cleverness: the return must hand back a bare
	 * parameter, and that parameter must have no type of its own. A typed
	 * parameter is PHP's problem to enforce at the call, and an expression is
	 * not knowable by reading.
	 *
	 * @param array $tokens Tokens.
	 * @param int   $i      Index of T_RETURN.
	 * @param array $frame  The function's stack frame.
	 * @return int|null Zero-based parameter position.
	 */
	private static function returned_parameter( array $tokens, $i, array $frame ) {
		if ( empty( $frame['signature'] ) ) {
			return null;
		}

		$total    = count( $tokens );
		$variable = '';

		for ( $j = $i + 1; $j < $total; $j++ ) {
			$token = $tokens[ $j ];

			if ( is_string( $token ) ) {
				if ( ';' === $token ) {
					break;
				}

				return null; // An expression, not a bare variable.
			}

			if ( in_array( $token[0], array( T_WHITESPACE, T_COMMENT, T_DOC_COMMENT ), true ) ) {
				continue;
			}

			if ( T_VARIABLE === $token[0] && '' === $variable ) {
				$variable = strtolower( $token[1] );
				continue;
			}

			return null;
		}

		if ( '' === $variable ) {
			return null;
		}

		foreach ( $frame['signature'] as $position => $parameter ) {
			if ( $parameter['name'] === $variable ) {
				// A typed parameter cannot hold the wrong thing in the first
				// place; PHP refuses it at the call, not at the return.
				return $parameter['typed'] ? null : $position;
			}
		}

		return null;
	}

	/**
	 * The parameters of the function starting at $i, in order.
	 *
	 * Only the parameter list — a closure's `use ( … )` variables come after
	 * the closing parenthesis and are not parameters.
	 *
	 * @param array $tokens Tokens.
	 * @param int   $i      Index of T_FUNCTION.
	 * @return array<int,array{name:string,typed:bool}>
	 */
	private static function signature( array $tokens, $i ) {
		$total  = count( $tokens );
		$depth  = 0;
		$out    = array();
		$typed  = false;
		$opened = false;

		for ( $j = $i + 1; $j < $total; $j++ ) {
			$token = $tokens[ $j ];

			if ( is_string( $token ) ) {
				if ( '(' === $token ) {
					$depth++;
					$opened = true;
				} elseif ( ')' === $token ) {
					$depth--;

					if ( 0 === $depth ) {
						break;
					}
				} elseif ( ',' === $token && 1 === $depth ) {
					$typed = false;
				} elseif ( '?' === $token && 1 === $depth ) {
					$typed = true;
				}

				continue;
			}

			if ( ! $opened || 1 !== $depth ) {
				continue;
			}

			if ( T_VARIABLE === $token[0] ) {
				$out[] = array( 'name' => strtolower( $token[1] ), 'typed' => $typed );
				$typed = false;
				continue;
			}

			if ( in_array( $token[0], array( T_WHITESPACE, T_COMMENT, T_DOC_COMMENT ), true ) ) {
				continue;
			}

			// Anything else before the variable is a type, a modifier for a
			// promoted property, or a by-reference ampersand. Only a type
			// matters, and treating the others as one costs nothing but a
			// finding this check would rather not make.
			$typed = true;
		}

		return $out;
	}

	/**
	 * The kind of the literal a `return` hands back, if it is one.
	 *
	 * @param array $tokens Tokens.
	 * @param int   $i      Index of T_RETURN.
	 * @return string|null int|float|string|bool|null|array, or null if the
	 *                     value is anything else at all.
	 */
	private static function literal_after( array $tokens, $i ) {
		$total = count( $tokens );
		$found = null;

		for ( $j = $i + 1; $j < $total; $j++ ) {
			$token = $tokens[ $j ];

			if ( is_string( $token ) ) {
				if ( ';' === $token ) {
					return $found;
				}

				// A negative number is two tokens; anything else means the
				// value is an expression rather than a literal.
				if ( '-' === $token || '+' === $token ) {
					if ( null !== $found ) {
						return null;
					}
					continue;
				}

				if ( '[' === $token && null === $found ) {
					$found = 'array';

					// Skip the array's contents; only its type matters.
					$j = self::matching( $tokens, $j, '[', ']' );

					if ( -1 === $j ) {
						return null;
					}

					continue;
				}

				return null;
			}

			if ( in_array( $token[0], array( T_WHITESPACE, T_COMMENT, T_DOC_COMMENT ), true ) ) {
				continue;
			}

			if ( null !== $found ) {
				return null; // Two values: an expression, not a literal.
			}

			switch ( $token[0] ) {
				case T_LNUMBER:
					$found = 'int';
					break;

				case T_DNUMBER:
					$found = 'float';
					break;

				case T_CONSTANT_ENCAPSED_STRING:
					// The literal's own text is kept, because "5" and "five"
					// behave completely differently.
					$found = 'string:' . substr( $token[1], 1, -1 );
					break;

				case T_ARRAY:
					$found = 'array';
					$open  = self::next_index( $tokens, $j, '(' );
					$j     = -1 === $open ? $j : self::matching( $tokens, $open, '(', ')' );

					if ( -1 === $j ) {
						return null;
					}
					break;

				case T_STRING:
					$word = strtolower( $token[1] );

					if ( 'true' === $word || 'false' === $word ) {
						$found = 'bool';
						break;
					}

					if ( 'null' === $word ) {
						$found = 'null';
						break;
					}

					return null;

				default:
					return null;
			}
		}

		return null;
	}

	/**
	 * Will PHP accept this literal from a function declared to return that type?
	 *
	 * @param array  $declared type/nullable.
	 * @param string $literal  From literal_after().
	 * @param bool   $strict   strict_types is on.
	 * @return string The mismatch, named as PHP names it, or '' when it is fine.
	 */
	private static function return_mismatch( array $declared, $literal, $strict ) {
		$type  = $declared['type'];
		$given = 0 === strpos( $literal, 'string:' ) ? 'string' : $literal;
		$text  = 'string' === $given ? substr( $literal, 7 ) : '';

		// A void function returning a value is refused at compile time, before
		// a single line of the file has run.
		if ( 'void' === $type ) {
			return 'void';
		}

		if ( 'never' === $type ) {
			return 'never';
		}

		if ( 'null' === $given ) {
			return $declared['nullable'] ? '' : 'null';
		}

		if ( $given === $type ) {
			return '';
		}

		// int is accepted where float is declared, in both modes.
		if ( 'float' === $type && 'int' === $given ) {
			return '';
		}

		if ( $strict ) {
			return $given;
		}

		// Coercive mode. An array is never a scalar and a scalar is never an
		// array; everything else among the scalars converts.
		if ( 'array' === $type || 'array' === $given ) {
			return $given;
		}

		if ( 'int' === $type || 'float' === $type ) {
			/*
			 * "5" becomes 5. "5 apples" becomes 5 with a deprecation, which is
			 * noisy but not fatal. "invalid integer" is a TypeError. Only the
			 * last of those is reported, and a string that begins with a
			 * number is left alone rather than guessed about.
			 */
			if ( 'string' === $given && ! preg_match( '/^\s*[+-]?(\d|\.\d)/', $text ) ) {
				return $given;
			}

			return '';
		}

		// string and bool take any other scalar.
		return '';
	}

	/**
	 * @param array  $tokens Tokens.
	 * @param int    $i      Index of the opening punctuation.
	 * @param string $open   Opening character.
	 * @param string $close  Closing character.
	 * @return int Index of the match, or -1.
	 */
	private static function matching( array $tokens, $i, $open, $close ) {
		$total = count( $tokens );
		$depth = 0;

		for ( $j = $i; $j < $total; $j++ ) {
			if ( ! is_string( $tokens[ $j ] ) ) {
				continue;
			}

			if ( $open === $tokens[ $j ] ) {
				$depth++;
			} elseif ( $close === $tokens[ $j ] ) {
				$depth--;

				if ( 0 === $depth ) {
					return $j;
				}
			}
		}

		return -1;
	}

	/**
	 * @param array $tokens Tokens.
	 * @param int   $i      Index of T_DECLARE.
	 * @return bool
	 */
	private static function declares_strict_types( array $tokens, $i ) {
		$total = min( count( $tokens ), $i + 12 );
		$seen  = false;

		for ( $j = $i + 1; $j < $total; $j++ ) {
			$token = $tokens[ $j ];

			if ( is_array( $token ) && T_STRING === $token[0] && 'strict_types' === strtolower( $token[1] ) ) {
				$seen = true;
				continue;
			}

			if ( $seen && is_array( $token ) && T_LNUMBER === $token[0] ) {
				return '1' === $token[1];
			}
		}

		return false;
	}

	/* ------------------------------------------------------------------ *
	 * Following the includes
	 * ------------------------------------------------------------------ */

	/** Enough to read a theme or a plugin, and not enough to read a tree. */
	const MAX_INCLUDE_FILES = 60;
	const MAX_INCLUDE_DEPTH = 2;

	/**
	 * Work out what the file's own includes bring with them.
	 *
	 * @param array  $expressions One token slice per include statement.
	 * @param string $real_file   The file being edited.
	 * @return array{declared:array,unresolved:bool}
	 */
	private static function follow_includes( array $expressions, $real_file, array $file_guards = array() ) {
		$declared   = array();
		$missing    = array();
		$unresolved = false;
		$guarded    = array();

		foreach ( $file_guards as $guard ) {
			$literal = '';
			self::resolve_path( $guard, $real_file, $literal );

			if ( '' !== $literal ) {
				$guarded[ wp_normalize_path( $literal ) ] = true;
			}
		}

		if ( ! $expressions ) {
			return array( 'declared' => $declared, 'unresolved' => false, 'missing' => $missing );
		}

		$seen  = array();
		$count = 0;

		foreach ( $expressions as $expression ) {
			$literal = '';
			$path    = self::resolve_path( $expression['tokens'], $real_file, $literal );

			if ( '' !== $path ) {
				$declared += self::declared_by_file( $path, 0, $seen, $count );
				continue;
			}

			/*
			 * A path that could not be worked out at all is a shrug: it may
			 * define anything, so everything downstream softens to a warning.
			 *
			 * A path that WAS worked out and points at nothing is the opposite
			 * of a shrug. `require` on a missing file is a fatal error, and one
			 * of the easiest to cause — a snippet copied from a plugin that
			 * expects a file the site does not have.
			 */
			if ( '' === $literal || file_exists( $literal ) ) {
				$unresolved = true;
				continue;
			}

			// The file checks for it before requiring it. That is the whole
			// optional-drop-in pattern, and it is correct code.
			if ( isset( $guarded[ wp_normalize_path( $literal ) ] ) ) {
				continue;
			}

			$missing[] = array(
				'path'     => $literal,
				'required' => $expression['required'],
				'certain'  => ! empty( $expression['certain'] ),
				'line'     => $expression['line'],
				'key'      => $expression['key'],
				'context'  => $expression['context'],
			);
		}

		return array( 'declared' => $declared, 'unresolved' => $unresolved, 'missing' => $missing );
	}

	/**
	 * Turn `get_template_directory() . '/inc/template-tags.php'` into a path.
	 *
	 * Only the shapes that people actually write are understood — literals,
	 * concatenation, the magic constants, defined constants, and a short list
	 * of WordPress's own directory functions. Anything with a variable in it,
	 * or anything else at all, returns '' and is reported as unresolved rather
	 * than guessed at. Nothing here is executed: the functions on the list are
	 * called, and they are on the list because they take no arguments and only
	 * return a path.
	 *
	 * @param array  $tokens    The expression's tokens.
	 * @param string $real_file The file the expression was written in.
	 * @return string Absolute path, or ''.
	 */
	private static function resolve_path( array $tokens, $real_file, &$literal = null ) {
		$literal = '';

		if ( ! $tokens || '' === $real_file ) {
			return '';
		}

		$directory = dirname( $real_file );
		$out       = '';
		$total     = count( $tokens );

		for ( $i = 0; $i < $total; $i++ ) {
			$token = $tokens[ $i ];

			if ( is_string( $token ) ) {
				// Concatenation and grouping are the only punctuation a path
				// expression may contain.
				if ( '.' === $token || '(' === $token || ')' === $token ) {
					continue;
				}

				return '';
			}

			if ( in_array( $token[0], array( T_WHITESPACE, T_COMMENT, T_DOC_COMMENT ), true ) ) {
				continue;
			}

			switch ( $token[0] ) {
				case T_CONSTANT_ENCAPSED_STRING:
					// Single-quoted only: a double-quoted path may interpolate,
					// and then it is not a literal at all.
					if ( '"' === substr( $token[1], 0, 1 ) && false !== strpos( $token[1], '$' ) ) {
						return '';
					}
					$out .= substr( $token[1], 1, -1 );
					break;

				case T_DIR:
					$out .= $directory;
					break;

				case T_FILE:
					$out .= $real_file;
					break;

				case T_STRING:
					$piece = self::resolve_name( $tokens, $i, $real_file, $directory );

					if ( null === $piece ) {
						return '';
					}

					$out .= $piece;
					break;

				default:
					return '';
			}
		}

		if ( '' === $out ) {
			return '';
		}

		// Worked out in full. Whether anything is there is the next question,
		// and a different one.
		$literal = $out;

		$real = realpath( $out );

		if ( ! $real || ! is_file( $real ) ) {
			return '';
		}

		$real = wp_normalize_path( $real );

		/*
		 * Only files belonging to this installation are read. The expression
		 * came from a text box, and "it only reads it" is not a reason to let
		 * a text box name any file on the disk.
		 */
		if ( defined( 'ABSPATH' ) && 0 !== strpos( $real, wp_normalize_path( ABSPATH ) ) ) {
			return '';
		}

		return 'php' === strtolower( (string) pathinfo( $real, PATHINFO_EXTENSION ) ) ? $real : '';
	}

	/**
	 * A bare name inside a path expression: a constant, or one of a short list
	 * of path functions.
	 *
	 * @param array  $tokens    Expression tokens.
	 * @param int    $i         Index of the name, advanced past its arguments.
	 * @param string $real_file File being edited.
	 * @param string $directory Its directory.
	 * @return string|null Null when it cannot be resolved.
	 */
	private static function resolve_name( array $tokens, &$i, $real_file, $directory ) {
		$name  = strtolower( $tokens[ $i ][1] );
		$total = count( $tokens );

		// `dirname( __FILE__ )` and `plugin_dir_path( __FILE__ )` are the two
		// pre-__DIR__ spellings of "this directory", and both are still
		// everywhere. Anything else taking arguments is not resolved.
		if ( in_array( $name, array( 'dirname', 'plugin_dir_path' ), true ) ) {
			$argument = '';

			for ( $j = $i + 1; $j < $total; $j++ ) {
				$token = $tokens[ $j ];

				if ( is_string( $token ) ) {
					if ( '(' === $token ) {
						continue;
					}
					if ( ')' === $token ) {
						$i = $j;
						return 'dirname' === $name ? $argument : $argument . '/';
					}
					return null;
				}

				if ( in_array( $token[0], array( T_WHITESPACE, T_COMMENT, T_DOC_COMMENT ), true ) ) {
					continue;
				}

				if ( T_FILE === $token[0] ) {
					$argument = $directory; // dirname( __FILE__ )
					continue;
				}

				if ( T_DIR === $token[0] ) {
					$argument = 'dirname' === $name ? dirname( $directory ) : $directory;
					continue;
				}

				return null;
			}

			return null;
		}

		// Zero-argument calls that return a directory, and nothing else. The
		// two spellings that take __FILE__ were handled above.
		$directories = array(
			'get_template_directory',
			'get_stylesheet_directory',
			'get_theme_root',
		);

		if ( in_array( $name, $directories, true ) && function_exists( $name ) ) {
			// Followed by '()' and nothing else, or it is not the no-argument
			// call this list is about.
			$next  = self::significant( $tokens, $i, 1 );
			$after = null;

			for ( $j = $i + 1; $j < $total; $j++ ) {
				if ( is_string( $tokens[ $j ] ) && ')' === $tokens[ $j ] ) {
					$after = $j;
					break;
				}
			}

			if ( '(' !== $next || null === $after || $after !== self::next_index( $tokens, $i, '(' ) + 1 ) {
				return null;
			}

			$i = $after;

			return (string) call_user_func( $name );
		}

		// A defined constant is a literal by another name.
		if ( defined( $tokens[ $i ][1] ) ) {
			$value = constant( $tokens[ $i ][1] );

			return is_string( $value ) ? $value : null;
		}

		return null;
	}

	/**
	 * @param array  $tokens Tokens.
	 * @param int    $i      Start.
	 * @param string $char   Punctuation to find.
	 * @return int Index, or -1.
	 */
	private static function next_index( array $tokens, $i, $char ) {
		$total = count( $tokens );

		for ( $j = $i + 1; $j < $total; $j++ ) {
			if ( is_string( $tokens[ $j ] ) && $char === $tokens[ $j ] ) {
				return $j;
			}
		}

		return -1;
	}

	/**
	 * Everything a file declares, and everything the files it includes declare.
	 *
	 * Declarations at any depth count here, conditional ones included. This
	 * list is only ever used to *suppress* a finding, so erring towards "yes,
	 * that name exists" is erring towards saying less.
	 *
	 * @param string $path  Absolute path.
	 * @param int    $depth Current recursion depth.
	 * @param array  $seen  Paths already read.
	 * @param int    $count Files read so far.
	 * @return array<string,bool> "kind:lowercased name" keys.
	 */
	private static function declared_by_file( $path, $depth, array &$seen, &$count ) {
		if ( isset( $seen[ $path ] ) || $depth > self::MAX_INCLUDE_DEPTH || $count >= self::MAX_INCLUDE_FILES ) {
			return array();
		}

		$seen[ $path ] = true;
		$count++;

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents, WordPress.PHP.NoSilencedErrors.Discouraged
		$code = @file_get_contents( $path );

		if ( false === $code ) {
			return array();
		}

		// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		$tokens = @token_get_all( $code );

		if ( ! is_array( $tokens ) ) {
			return array();
		}

		$declared = array();
		$total    = count( $tokens );

		for ( $i = 0; $i < $total; $i++ ) {
			$token = $tokens[ $i ];

			if ( ! is_array( $token ) ) {
				continue;
			}

			switch ( $token[0] ) {
				case T_FUNCTION:
					$name = self::name_after( $tokens, $i );

					if ( '' !== $name ) {
						$declared[ 'function:' . strtolower( $name ) ] = true;
					}
					break;

				case T_CLASS:
				case T_INTERFACE:
				case T_TRAIT:
					if ( self::preceded_by_double_colon( $tokens, $i ) ) {
						break;
					}

					$name = self::name_after( $tokens, $i );

					if ( '' !== $name ) {
						$declared[ 'class:' . strtolower( $name ) ] = true;
					}
					break;

				case T_INCLUDE:
				case T_INCLUDE_ONCE:
				case T_REQUIRE:
				case T_REQUIRE_ONCE:
					$nested = self::resolve_path( self::expression_after( $tokens, $i ), $path );

					if ( '' !== $nested ) {
						$declared += self::declared_by_file( $nested, $depth + 1, $seen, $count );
					}
					break;
			}
		}

		return $declared;
	}

	/**
	 * The tokens of the expression that follows a keyword, up to its
	 * terminating semicolon.
	 *
	 * @param array $tokens Tokens.
	 * @param int   $i      Index of the keyword.
	 * @return array
	 */
	private static function expression_after( array $tokens, $i ) {
		$total = count( $tokens );
		$out   = array();
		$depth = 0;

		for ( $j = $i + 1; $j < $total; $j++ ) {
			$token = $tokens[ $j ];

			if ( is_string( $token ) ) {
				if ( '(' === $token ) {
					$depth++;
				} elseif ( ')' === $token ) {
					if ( 0 === $depth ) {
						break; // The closing paren of an enclosing call.
					}
					$depth--;
				} elseif ( ';' === $token && 0 === $depth ) {
					break;
				} elseif ( ',' === $token && 0 === $depth ) {
					break;
				}
			} elseif ( T_CLOSE_TAG === $token[0] ) {
				break;
			}

			$out[] = $token;
		}

		return $out;
	}

	/**
	 * Is this name a call, a static reference, or an existence check?
	 *
	 * @param array $tokens Tokens.
	 * @param int   $i      Index.
	 * @param array $stack  Open blocks.
	 * @return array|null
	 */
	private static function reference( array $tokens, $i, array $stack ) {
		$name = $tokens[ $i ][1];
		$line = (int) $tokens[ $i ][2];

		/*
		 * `$obj->foo()`, `Foo::foo()`, `function foo`, `new Foo`, `class Foo`,
		 * `const FOO`, `#[Attribute]`: the token before decides what this is,
		 * and in none of those cases is it a global function call.
		 */
		$before = self::significant( $tokens, $i, -1 );

		if ( is_array( $before ) ) {
			$blockers = array( T_OBJECT_OPERATOR, T_DOUBLE_COLON, T_FUNCTION, T_NEW, T_CLASS, T_INTERFACE, T_TRAIT, T_CONST, T_GOTO );

			foreach ( array( 'T_NULLSAFE_OBJECT_OPERATOR', 'T_ATTRIBUTE' ) as $constant ) {
				if ( defined( $constant ) ) {
					$blockers[] = constant( $constant );
				}
			}

			if ( in_array( $before[0], $blockers, true ) ) {
				return null;
			}
		}

		$after = self::significant( $tokens, $i, 1 );

		// `Foo::bar()` — the class is the thing that has to exist.
		if ( is_array( $after ) && T_DOUBLE_COLON === $after[0] ) {
			return self::class_ref( $name, $line, $stack );
		}

		if ( '(' !== $after ) {
			return null; // A constant, a type hint, a bare word. Not a call.
		}

		$bare = self::bare( $name );

		if ( in_array( strtolower( $bare ), self::CONSTRUCTS, true ) ) {
			return null;
		}

		// `function_exists( 'x' )` is the author saying "I know this may not be
		// here". Record the name; never report it.
		if ( in_array( strtolower( $bare ), array( 'function_exists', 'class_exists', 'method_exists', 'interface_exists', 'trait_exists', 'enum_exists', 'is_callable', 'defined' ), true ) ) {
			$argument = self::first_string_argument( $tokens, $i );

			if ( '' !== $argument ) {
				return array( 'kind' => 'guard', 'name' => strtolower( self::bare( $argument ) ) );
			}

			return null;
		}

		$owner = self::owner( $stack );

		return array(
			'kind'    => 'function',
			'name'    => $name,
			'line'    => $line,
			'context' => self::context( $stack ),
			'owner'   => $owner['name'],
			'hook'    => $owner['hook'],
			'key'     => self::owner_key( $stack ),
			'why'     => 'call',
		);
	}

	/**
	 * `new Foo`.
	 *
	 * @param array $tokens Tokens.
	 * @param int   $i      Index of T_NEW.
	 * @param array $stack  Open blocks.
	 * @return array|null
	 */
	private static function instantiation( array $tokens, $i, array $stack ) {
		$after = self::significant( $tokens, $i, 1 );

		if ( ! is_array( $after ) || ! in_array( $after[0], self::name_tokens(), true ) ) {
			return null; // new $class, new class {…}, new (expr).
		}

		return self::class_ref( $after[1], (int) $after[2], $stack, 'new' );
	}

	/**
	 * @param string $name  Class name as written.
	 * @param int    $line  Line.
	 * @param array  $stack Open blocks.
	 * @param string $why   How it was referenced.
	 * @return array|null
	 */
	private static function class_ref( $name, $line, array $stack, $why = 'static' ) {
		$bare = self::bare( $name );

		if ( in_array( strtolower( $bare ), array( 'self', 'static', 'parent', 'class' ), true ) ) {
			return null;
		}

		$owner = self::owner( $stack );

		return array(
			'kind'    => 'class',
			'name'    => $name,
			'line'    => $line,
			'context' => self::context( $stack ),
			'owner'   => $owner['name'],
			'hook'    => $owner['hook'],
			'key'     => self::owner_key( $stack ),
			'why'     => $why,
		);
	}

	/**
	 * Where in the file this reference sits.
	 *
	 * 'top' means it is not inside any function body, so including the file
	 * runs it. That is the difference between "this may crash the site" and
	 * "this crashes the site".
	 *
	 * @param array $stack Open blocks.
	 * @return string top|function|class
	 */
	private static function context( array $stack ) {
		foreach ( $stack as $frame ) {
			if ( 'function' === $frame['kind'] ) {
				return 'function';
			}
		}

		foreach ( $stack as $frame ) {
			if ( 'class' === $frame['kind'] ) {
				return 'class';
			}
		}

		return 'top';
	}

	/**
	 * The outermost function this reference is inside — the one that would be
	 * named in an add_action() call.
	 *
	 * @param array $stack Open blocks.
	 * @return array{name:string,hook:bool}
	 */
	private static function owner( array $stack ) {
		foreach ( $stack as $frame ) {
			if ( 'function' === $frame['kind'] ) {
				return array(
					'name' => $frame['name'],
					'hook' => ! empty( $frame['hook'] ),
				);
			}
		}

		return array( 'name' => '', 'hook' => false );
	}

	/* ------------------------------------------------------------------ *
	 * Judgement
	 * ------------------------------------------------------------------ */

	/**
	 * Does this reference resolve, and if not, how badly?
	 *
	 * @param array  $ref       One reference.
	 * @param array  $map       Everything walk() found.
	 * @param bool   $uncertain Namespace/import/include present.
	 * @param string $code      Source, for the excerpt.
	 * @param string $loading   entry|included|dormant — see loading().
	 * @return array|null
	 */
	private static function judge( array $ref, array $map, $uncertain, $code, $loading = 'entry' ) {
		$bare  = self::bare( $ref['name'] );
		$lower = strtolower( $bare );

		if ( '' === $bare ) {
			return null;
		}

		// Declared in this very file — including inside an
		// if ( ! function_exists() ) guard, which is a declaration wherever it
		// sits, and including below the line that calls it.
		if ( isset( $map['declared'][ $ref['kind'] . ':' . $lower ] ) ) {
			return null;
		}

		// The file tests for it before using it. That is correct code.
		if ( isset( $map['guarded'][ $lower ] ) ) {
			return null;
		}

		if ( self::resolves( $ref['kind'], $ref['name'], $bare ) ) {
			return null;
		}

		$severity = self::severity( $ref, $map );

		/*
		 * Class names are the weaker signal of the two. Autoloaders register
		 * classes lazily, `use` rewrites bare names, and a namespaced file
		 * resolves them against its own namespace rather than the global table
		 * consulted here. A missing function is a fact; a missing class in one
		 * of those files is a suspicion, and suspicions do not block saves.
		 */
		if ( 'class' === $ref['kind'] && $uncertain ) {
			$severity = 'warning';
		}

		// An include whose path could not be worked out may define anything.
		if ( 'function' === $ref['kind'] && ! empty( $map['unresolved'] ) ) {
			$severity = 'warning';
		}

		// `use function foo;` makes a bare name mean something else entirely.
		if ( 'function' === $ref['kind'] && $map['imports'] && false === strpos( $ref['name'], '\\' ) ) {
			$severity = 'warning';
		}

		/*
		 * Everything above decided whether the code runs. This decides whether
		 * the answer can be trusted, and only one kind of file gives a
		 * trustworthy one: the file WordPress loads by itself, every request —
		 * a theme's functions.php, an active plugin's main file. There, the
		 * function table consulted a moment ago is the table the code will meet.
		 *
		 * Any other file is included by something, somewhere, on some
		 * requests. A plugin's front-end-only partial, checked from inside
		 * wp-admin, refers to a class that is genuinely not loaded right now
		 * and will be perfectly present when the file is used. Blocking that
		 * save would be wrong, and wrong in the way that gets a feature turned
		 * off. It is still worth saying; it is not worth refusing over.
		 */
		if ( 'entry' !== $loading ) {
			$severity = 'warning';
		}

		return array(
			'severity' => $severity,
			'kind'     => $ref['kind'],
			'name'     => $bare,
			'line'     => $ref['line'],
			'label'    => 'function' === $ref['kind']
				? __( 'Undefined function', 'wpd-critical-error' )
				: __( 'Undefined class', 'wpd-critical-error' ),
			'message'  => self::message( $ref, $bare ),
			'excerpt'  => WPDCE_Editor::excerpt( $code, $ref['line'] ),
			'hint'     => self::hint( $ref, $bare, $severity, $loading ),
		);
	}

	/**
	 * How does this file come to be loaded, if it does?
	 *
	 *   entry     WordPress loads it itself, on every request: a theme's
	 *             functions.php, an active plugin's main file. What resolves
	 *             now is what will resolve then, so a finding here is a fact.
	 *
	 *   included  It is loaded, if at all, because something includes it —
	 *             conditionally, on some requests, in some contexts. A missing
	 *             name here may simply be one that this request has no reason
	 *             to have loaded.
	 *
	 *   dormant   It belongs to a deactivated plugin or an unused theme.
	 *             Nothing in it is declared, so almost everything it says looks
	 *             undefined — and none of it is running, so none of it can take
	 *             the site down until someone activates it.
	 *
	 * Anything it cannot place is 'included': the middle answer, which reports
	 * without refusing.
	 *
	 * @param string $real_file Absolute path being edited, or ''.
	 * @return string entry|included|dormant
	 */
	private static function loading( $real_file ) {
		if ( '' === $real_file || ! function_exists( 'wp_normalize_path' ) ) {
			return 'included';
		}

		$path = wp_normalize_path( $real_file );

		if ( defined( 'WP_PLUGIN_DIR' ) && function_exists( 'get_option' ) ) {
			$plugins = wp_normalize_path( WP_PLUGIN_DIR ) . '/';

			if ( 0 === strpos( $path, $plugins ) ) {
				$relative = substr( $path, strlen( $plugins ) );
				$folder   = strtok( $relative, '/' );
				$active   = (array) get_option( 'active_plugins', array() );

				if ( function_exists( 'is_multisite' ) && is_multisite() && function_exists( 'get_site_option' ) ) {
					$active = array_merge( $active, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
				}

				$dormant = true;

				foreach ( $active as $entry ) {
					$entry = (string) $entry;

					// The plugin's own main file: this is what WordPress
					// includes, and it includes it every single request.
					if ( $entry === $relative ) {
						return 'entry';
					}

					if ( '' !== $folder && 0 === strpos( $entry, $folder . '/' ) ) {
						$dormant = false; // Active plugin, but not its main file.
					}
				}

				return $dormant ? 'dormant' : 'included';
			}
		}

		if ( function_exists( 'get_stylesheet_directory' ) && function_exists( 'get_template_directory' ) ) {
			$live = false;

			foreach ( array( get_stylesheet_directory(), get_template_directory() ) as $directory ) {
				$directory = wp_normalize_path( $directory );

				// Both the child's functions.php and the parent's are loaded by
				// WordPress on their own, before anything else in the theme.
				if ( $path === $directory . '/functions.php' ) {
					return 'entry';
				}

				if ( 0 === strpos( $path, $directory . '/' ) ) {
					$live = true;
				}
			}

			if ( $live ) {
				return 'included';
			}

			// Under wp-content/themes and belonging to neither the active theme
			// nor its parent: installed, not in use.
			if ( defined( 'WP_CONTENT_DIR' ) && 0 === strpos( $path, wp_normalize_path( WP_CONTENT_DIR ) . '/themes/' ) ) {
				return 'dormant';
			}
		}

		return 'included';
	}

	/**
	 * A return value the declared type will not accept.
	 *
	 * @param array  $bad     From bad_return().
	 * @param array  $map     Everything walk() found.
	 * @param string $code    Source, for the excerpt.
	 * @param string $loading entry|included|dormant.
	 * @return array
	 */
	private static function judge_return( array $bad, array $map, $code, $loading ) {
		/*
		 * Returning a value from a void function is refused when the file is
		 * compiled, before any of it runs — so it does not matter in the least
		 * whether anything calls the function. Every other mismatch is a
		 * TypeError thrown at the moment of the return, which makes it exactly
		 * as reachable as the function holding it.
		 */
		$compile_time = in_array( $bad['problem'], array( 'void', 'never' ), true );

		if ( $compile_time ) {
			$severity = 'fatal';
			$message  = 'void' === $bad['problem']
				? __( 'Fatal error: A void function must not return a value', 'wpd-critical-error' )
				: __( 'Fatal error: A never-returning function must not return', 'wpd-critical-error' );
			$hint     = __( 'PHP refuses this when it compiles the file, so it does not matter whether anything calls the function — every page of the site would have gone blank on the next request. Either drop the return value or change the declared return type.', 'wpd-critical-error' );
		} else {
			$reached  = isset( $map['reachable'][ $bad['key'] ] );
			$severity = $reached ? 'fatal' : 'warning';

			$message = sprintf(
				/* translators: 1: function name, 2: declared type, 3: type actually returned. */
				__( 'Uncaught TypeError: %1$s(): Return value must be of type %2$s, %3$s returned', 'wpd-critical-error' ),
				$bad['name'],
				$bad['type'],
				'null' === $bad['problem'] ? 'null' : $bad['problem']
			);

			$hint = $reached
				? __( 'This file calls that function, so the error happens on the next request and takes the site down with it. PHP converts between scalar types where it can — "5" is an acceptable int — but this value cannot be converted, so it is a fatal error rather than a quiet coercion.', 'wpd-critical-error' )
				: __( 'Nothing in this file appears to call that function, so the site keeps working until something does — and it is a fatal error the moment something does.', 'wpd-critical-error' );

			if ( 'null' === $bad['problem'] ) {
				$hint = __( 'A declared return type does not accept null unless it is written as nullable. Change the type to ?', 'wpd-critical-error' ) . $bad['type'] . __( ', or return a value of that type.', 'wpd-critical-error' );
			}
		}

		if ( ! $compile_time && 'entry' !== $loading ) {
			$severity = 'warning';
		}

		return array(
			'severity' => $severity,
			'kind'     => 'return',
			'name'     => $bad['name'] . '():' . $bad['line'],
			'line'     => $bad['line'],
			'label'    => __( 'Return type', 'wpd-critical-error' ),
			'message'  => $message,
			'excerpt'  => WPDCE_Editor::excerpt( $code, $bad['line'] ),
			'hint'     => $hint,
		);
	}

	/**
	 * A `require` of a file that is not there.
	 *
	 * The path was worked out in full — no variables, no guessing — and nothing
	 * is at the end of it. `require` and `require_once` stop the request dead;
	 * `include` and `include_once` only warn and carry on, which is a warning
	 * here for the same reason.
	 *
	 * @param array  $missing From follow_includes().
	 * @param array  $map     Everything walk() found.
	 * @param string $code    Source, for the excerpt.
	 * @param string $loading entry|included|dormant.
	 * @return array
	 */
	private static function judge_missing_include( array $missing, array $map, $code, $loading ) {
		$reached = 'top' === $missing['context'] || ( '' !== $missing['key'] && isset( $map['reachable'][ $missing['key'] ] ) );

		$severity = ( $missing['required'] && $missing['certain'] && $reached && 'entry' === $loading ) ? 'fatal' : 'warning';

		return array(
			'severity' => $severity,
			'kind'     => 'include',
			'name'     => basename( $missing['path'] ),
			'line'     => $missing['line'],
			'label'    => $missing['required']
				? __( 'Missing file', 'wpd-critical-error' )
				: __( 'Missing include', 'wpd-critical-error' ),
			'message'  => $missing['required']
				? sprintf(
					/* translators: %s: file path. */
					__( 'Uncaught Error: Failed opening required \'%s\'', 'wpd-critical-error' ),
					self::shorten_path( $missing['path'] )
				)
				: sprintf(
					/* translators: %s: file path. */
					__( 'include(%s): Failed to open stream: No such file or directory', 'wpd-critical-error' ),
					self::shorten_path( $missing['path'] )
				),
			'excerpt'  => WPDCE_Editor::excerpt( $code, $missing['line'] ),
			'hint'     => $missing['required']
				? __( 'The path is worked out in full and there is no file at the end of it. require stops the request where it stands, so this would take the site down. Check the filename, or use include if the file is genuinely optional.', 'wpd-critical-error' )
				: __( 'There is no file at that path. include only warns and carries on, so the site will keep working — but whatever that file was meant to provide will not be there.', 'wpd-critical-error' ),
		);
	}

	/**
	 * @param string $path Absolute path.
	 * @return string Relative to the installation, where that is shorter.
	 */
	private static function shorten_path( $path ) {
		$path = wp_normalize_path( $path );

		if ( defined( 'ABSPATH' ) ) {
			$root = wp_normalize_path( ABSPATH );

			if ( 0 === strpos( $path, $root ) ) {
				return substr( $path, strlen( $root ) );
			}
		}

		return $path;
	}

	/**
	 * A member used on a class this file declares, and can therefore vouch for.
	 *
	 * Being able to vouch for it is the whole condition. The class must be
	 * declared here, must not extend or implement anything from outside, must
	 * not pull in a trait, and must not have the magic methods that answer for
	 * members nobody wrote down. Miss any of those and this says nothing at
	 * all — an inherited method is not a missing one.
	 *
	 * @param array  $access  One recorded use.
	 * @param array  $map     Everything walk() found.
	 * @param string $code    Source, for the excerpt.
	 * @param string $loading entry|included|dormant.
	 * @return array|null
	 */
	private static function judge_access( array $access, array $map, $code, $loading ) {
		if ( 'argument' === $access['kind'] ) {
			return self::judge_argument( $access, $map, $code, $loading );
		}

		if ( ! isset( $map['classes'][ $access['class'] ] ) ) {
			return null;
		}

		$class = $map['classes'][ $access['class'] ];

		if ( ! empty( $class['opaque'] ) ) {
			return null;
		}

		$member = strtolower( $access['member'] );

		if ( 'property' === $access['kind'] ) {
			$problem = self::property_problem( $class, $member, $access['literal'] );
		} else {
			$problem = self::method_problem( $class, $member, $access );
		}

		if ( ! $problem ) {
			return null;
		}

		// The same reachability that governs everything else: at the top level
		// it runs on load, inside something the file reaches it runs on the
		// next request, and otherwise it is a warning.
		$reached = 'top' === $access['context'] || ( '' !== $access['key'] && isset( $map['reachable'][ $access['key'] ] ) );

		$severity = ( $reached && 'entry' === $loading ) ? 'fatal' : 'warning';

		return array(
			'severity' => $severity,
			'kind'     => 'member',
			'name'     => $class['name'] . '::' . $access['member'],
			'line'     => $access['line'],
			'label'    => $problem['label'],
			'message'  => $problem['message'],
			'excerpt'  => WPDCE_Editor::excerpt( $code, $access['line'] ),
			'hint'     => $problem['hint'] . ' ' . (
				$reached
					? __( 'This file reaches that line, so it is a fatal error on the next request.', 'wpd-critical-error' )
					: __( 'Nothing in this file appears to reach that line, so the site keeps working until something does.', 'wpd-critical-error' )
			),
		);
	}

	/**
	 * A literal handed to a function that returns it under a declared type.
	 *
	 * The one-hop case:
	 *
	 *     function wp_test_function( $value ): string {
	 *         return $value;
	 *     }
	 *
	 *     wp_test_function( [] );
	 *
	 * Nothing about the function alone is wrong, and nothing about the call
	 * alone is wrong. Put together they are a TypeError, and the two halves are
	 * usually nowhere near each other on the screen.
	 *
	 * @param array  $access  The recorded call.
	 * @param array  $map     Everything walk() found.
	 * @param string $code    Source, for the excerpt.
	 * @param string $loading entry|included|dormant.
	 * @return array|null
	 */
	private static function judge_argument( array $access, array $map, $code, $loading ) {
		if ( ! isset( $map['passthrough'][ $access['callee'] ] ) ) {
			return null;
		}

		$through  = $map['passthrough'][ $access['callee'] ];
		$position = $through['parameter'];

		if ( ! isset( $access['literals'][ $position ] ) ) {
			return null;
		}

		$problem = self::return_mismatch(
			array( 'type' => $through['type'], 'nullable' => $through['nullable'] ),
			$access['literals'][ $position ],
			$map['strict']
		);

		if ( '' === $problem ) {
			return null;
		}

		$reached = 'top' === $access['context'] || ( '' !== $access['key'] && isset( $map['reachable'][ $access['key'] ] ) );

		return array(
			'severity' => ( $reached && 'entry' === $loading ) ? 'fatal' : 'warning',
			'kind'     => 'argument',
			'name'     => $access['member'] . '()@' . $access['line'],
			'line'     => $access['line'],
			'label'    => __( 'Return type', 'wpd-critical-error' ),
			'message'  => sprintf(
				/* translators: 1: function name, 2: declared type, 3: type actually returned. */
				__( 'Uncaught TypeError: %1$s(): Return value must be of type %2$s, %3$s returned', 'wpd-critical-error' ),
				$access['member'],
				$through['type'],
				'null' === $problem ? 'null' : $problem
			),
			'excerpt'  => WPDCE_Editor::excerpt( $code, $access['line'] ),
			'hint'     => sprintf(
				/* translators: 1: function name, 2: declared type, 3: line number of the return. */
				__( '%1$s() hands its argument straight back, and it is declared to return %2$s (line %3$d). What is passed here cannot be converted to that, so the error is thrown on the way out of the function rather than on the way in.', 'wpd-critical-error' ),
				$access['member'],
				$through['type'],
				$through['line']
			),
		);
	}

	/**
	 * `$object->method()` and `Class::method()`.
	 *
	 * @param array $class  The class's member table.
	 * @param array $member Lowercased member name.
	 * @param array $access The recorded use.
	 * @return array|null
	 */
	private static function method_problem( array $class, $member, array $access ) {
		$magic = 'static' === $access['kind'] ? '__callstatic' : '__call';

		if ( isset( $class['magic'][ $magic ] ) ) {
			return null; // The class answers for methods it never declared.
		}

		if ( ! isset( $class['methods'][ $member ] ) ) {
			return array(
				'label'   => __( 'Undefined method', 'wpd-critical-error' ),
				'message' => sprintf(
					/* translators: 1: class name, 2: method name. */
					__( 'Uncaught Error: Call to undefined method %1$s::%2$s()', 'wpd-critical-error' ),
					$class['name'],
					$access['member']
				),
				'hint'    => self::method_suggestion( $class, $access['member'] ),
			);
		}

		if ( 'static' !== $access['kind'] ) {
			// Calling a static method through an instance is allowed.
			return null;
		}

		if ( $class['methods'][ $member ]['static'] ) {
			return null;
		}

		/*
		 * Inside a class body, `Foo::bar()` may be a perfectly ordinary call to
		 * an inherited or sibling method with $this carried along. Outside one
		 * there is no $this to carry, and PHP 8 makes it an Error rather than
		 * the notice it used to be.
		 */
		if ( '' !== $access['inside'] ) {
			return null;
		}

		return array(
			'label'   => __( 'Static call', 'wpd-critical-error' ),
			'message' => sprintf(
				/* translators: 1: class name, 2: method name. */
				__( 'Uncaught Error: Non-static method %1$s::%2$s() cannot be called statically', 'wpd-critical-error' ),
				$class['name'],
				$class['methods'][ $member ]['name']
			),
			'hint'    => sprintf(
				/* translators: 1: class name, 2: method name. */
				__( 'The method is not declared static, so it needs an instance: $object = new %1$s(); $object->%2$s(); — or declare the method static, if it does not use $this. PHP 8 made this an error; older versions only warned, which is why code like it still circulates.', 'wpd-critical-error' ),
				$class['name'],
				$class['methods'][ $member ]['name']
			),
		);
	}

	/**
	 * The methods a class does have, and the nearest one to what was typed.
	 *
	 * @param array  $class  The class's member table.
	 * @param string $member The name that was not found.
	 * @return string
	 */
	private static function method_suggestion( array $class, $member ) {
		$hint = __( 'That class is declared in this same file, and has no such method.', 'wpd-critical-error' );

		if ( ! $class['methods'] ) {
			return $hint;
		}

		$best     = '';
		$distance = PHP_INT_MAX;

		if ( strlen( $member ) <= 60 ) {
			foreach ( $class['methods'] as $candidate ) {
				if ( strlen( $candidate['name'] ) > 60 ) {
					continue;
				}

				$d = levenshtein( strtolower( $member ), strtolower( $candidate['name'] ) );

				if ( $d > 0 && $d < $distance ) {
					$distance = $d;
					$best     = $candidate['name'];
				}
			}
		}

		if ( '' !== $best && $distance <= max( 2, (int) floor( strlen( $member ) / 3 ) ) ) {
			return $hint . ' ' . sprintf(
				/* translators: %s: a similarly spelled method that does exist. */
				__( 'Did you mean %s()?', 'wpd-critical-error' ),
				$best
			);
		}

		$names = array();

		foreach ( $class['methods'] as $candidate ) {
			$names[] = $candidate['name'] . '()';
		}

		return $hint . ' ' . sprintf(
			/* translators: %s: comma-separated list of method names. */
			__( 'It has: %s', 'wpd-critical-error' ),
			implode( ', ', array_slice( $names, 0, 12 ) )
		);
	}

	/**
	 * `$object->property = <literal>` against a declared property type.
	 *
	 * @param array  $class   The class's member table.
	 * @param string $member  Lowercased property name.
	 * @param string $literal From literal_after().
	 * @return array|null
	 */
	private static function property_problem( array $class, $member, $literal ) {
		if ( isset( $class['magic']['__set'] ) ) {
			return null;
		}

		/*
		 * A property that was never declared is a dynamic one. PHP 8.2
		 * deprecates those loudly, but it does not refuse them, and a check
		 * that stops a save over a deprecation is a check in the way.
		 */
		if ( ! isset( $class['props'][ $member ] ) ) {
			return null;
		}

		$declared = $class['props'][ $member ];

		// Typed properties coerce exactly as return values do, so the same
		// reasoning decides both — "5" is an acceptable int, "invalid" is not.
		$problem = self::return_mismatch( $declared, $literal, false );

		if ( '' === $problem ) {
			return null;
		}

		return array(
			'label'   => __( 'Property type', 'wpd-critical-error' ),
			'message' => sprintf(
				/* translators: 1: type being assigned, 2: class name, 3: property name, 4: declared type. */
				__( 'Uncaught TypeError: Cannot assign %1$s to property %2$s::$%3$s of type %4$s', 'wpd-critical-error' ),
				'null' === $problem ? 'null' : $problem,
				$class['name'],
				$member,
				( $declared['nullable'] ? '?' : '' ) . $declared['type']
			),
			'hint'    => __( 'PHP converts between scalar types where it can, so "5" would be an acceptable int — this value cannot be converted, which makes it a fatal error rather than a quiet coercion.', 'wpd-critical-error' ),
		);
	}

	/**
	 * Will this code actually run?
	 *
	 * @param array $ref One reference.
	 * @param array $map Everything walk() found.
	 * @return string fatal|warning
	 */
	private static function severity( array $ref, array $map ) {
		// Not inside a function: including the file executes it.
		if ( 'top' === $ref['context'] ) {
			return 'fatal';
		}

		// A closure passed straight to add_action().
		if ( ! empty( $ref['hook'] ) ) {
			return 'fatal';
		}

		/*
		 * Inside something this file reaches: a function it calls, a function
		 * it registers as a callback by name, a method on an object it makes.
		 * Not dead code — scheduled code.
		 */
		if ( ! empty( $ref['key'] ) && isset( $map['reachable'][ $ref['key'] ] ) ) {
			return 'fatal';
		}

		return 'warning';
	}

	/**
	 * Does the name exist in the running site?
	 *
	 * @param string $kind function|class.
	 * @param string $name As written.
	 * @param string $bare Without its namespace.
	 * @return bool
	 */
	private static function resolves( $kind, $name, $bare ) {
		$candidates = array_unique( array( ltrim( (string) $name, '\\' ), $bare ) );

		foreach ( $candidates as $candidate ) {
			if ( '' === $candidate ) {
				continue;
			}

			if ( 'function' === $kind ) {
				if ( function_exists( $candidate ) ) {
					return true;
				}
				continue;
			}

			// Autoloading left on: a class an autoloader can produce is a class
			// that will be there when the code runs.
			if ( class_exists( $candidate ) || interface_exists( $candidate ) || trait_exists( $candidate ) ) {
				return true;
			}

			if ( function_exists( 'enum_exists' ) && enum_exists( $candidate ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * @param array  $ref  Reference.
	 * @param string $bare Name.
	 * @return string
	 */
	private static function message( array $ref, $bare ) {
		if ( 'function' === $ref['kind'] ) {
			return sprintf(
				/* translators: %s: function name. */
				__( 'Uncaught Error: Call to undefined function %s()', 'wpd-critical-error' ),
				$bare
			);
		}

		return sprintf(
			/* translators: %s: class name. */
			__( 'Uncaught Error: Class "%s" not found', 'wpd-critical-error' ),
			$bare
		);
	}

	/**
	 * What to do about it, in the terms of the specific mistake.
	 *
	 * @param array  $ref      Reference.
	 * @param string $bare     Name.
	 * @param string $severity fatal|warning.
	 * @param string $loading  entry|included|dormant.
	 * @return string
	 */
	private static function hint( array $ref, $bare, $severity, $loading = 'entry' ) {
		if ( 'dormant' === $loading ) {
			$where = __( 'This file belongs to a plugin or theme that is not active, so nothing here is running and the site is in no danger right now. It becomes a fatal error the moment it is activated.', 'wpd-critical-error' );
		} elseif ( 'included' === $loading ) {
			$where = __( 'WordPress does not load this file on its own — something has to include it — so this check cannot say for certain when, or whether, that line runs. When it does run, it is a fatal error.', 'wpd-critical-error' );
		} elseif ( 'fatal' === $severity && 'top' === $ref['context'] ) {
			$where = __( 'This line runs the moment the file is loaded, so every page of the site — the dashboard included — would have gone blank on the next request.', 'wpd-critical-error' );
		} elseif ( 'fatal' === $severity && '' !== $ref['owner'] ) {
			$where = sprintf(
				/* translators: %s: function name. */
				__( 'It is inside %s(), which this file registers as a callback by name — so it is not unused code. It runs on the next request and takes the site down with it.', 'wpd-critical-error' ),
				$ref['owner']
			);
		} elseif ( 'fatal' === $severity ) {
			$where = __( 'It is inside a closure passed straight to a hook, so it runs on the next request.', 'wpd-critical-error' );
		} else {
			$where = __( 'Nothing in this file appears to reach that line, so the site keeps working until something does — and it is a fatal error the moment something does.', 'wpd-critical-error' );
		}

		$suggestion = self::did_you_mean( $ref['kind'], $bare );

		$fix = 'function' === $ref['kind']
			? __( 'Check the spelling, or which plugin provides it — if it comes from a plugin that may be deactivated, wrap the call in if ( function_exists( … ) ).', 'wpd-critical-error' )
			: __( 'Check the spelling and the namespace, and whether the plugin that declares it is active.', 'wpd-critical-error' );

		return trim( $where . ' ' . $suggestion . ' ' . $fix );
	}

	/**
	 * A close match among the names that do exist.
	 *
	 * Most of these are typos, and a typo has a neighbour. Saying which one
	 * turns "that does not exist" into an answer.
	 *
	 * @param string $kind function|class.
	 * @param string $bare Name.
	 * @return string
	 */
	private static function did_you_mean( $kind, $bare ) {
		$length = strlen( $bare );

		if ( $length > 60 || $length < 4 ) {
			return ''; // levenshtein() refuses long strings; short ones match noise.
		}

		if ( 'function' === $kind ) {
			$defined = get_defined_functions();
			$pool    = array_merge( $defined['internal'], $defined['user'] );
		} else {
			$pool = array_merge( get_declared_classes(), get_declared_interfaces() );
		}

		$best     = '';
		$distance = PHP_INT_MAX;
		$limit    = max( 1, (int) floor( $length / 5 ) );

		foreach ( $pool as $candidate ) {
			$candidate = self::bare( $candidate );

			if ( strlen( $candidate ) > 60 || abs( strlen( $candidate ) - $length ) > $limit ) {
				continue;
			}

			$d = levenshtein( strtolower( $bare ), strtolower( $candidate ) );

			if ( $d > 0 && $d < $distance ) {
				$distance = $d;
				$best     = $candidate;

				if ( 1 === $distance ) {
					break;
				}
			}
		}

		if ( '' === $best || $distance > $limit ) {
			return '';
		}

		return sprintf(
			/* translators: %s: a similarly spelled name that does exist. */
			__( 'Did you mean %s?', 'wpd-critical-error' ),
			$best . ( 'function' === $kind ? '()' : '' )
		);
	}

	/* ------------------------------------------------------------------ *
	 * Token helpers
	 * ------------------------------------------------------------------ */

	/**
	 * Token ids that carry a namespaced name.
	 *
	 * PHP 8 emits `Foo\Bar` as one token; PHP 7 splits it. The constants only
	 * exist on 8, so they are looked up rather than written literally.
	 *
	 * @return array
	 */
	private static function name_tokens() {
		static $ids = null;

		if ( null !== $ids ) {
			return $ids;
		}

		$ids = array();

		foreach ( array( 'T_NAME_QUALIFIED', 'T_NAME_FULLY_QUALIFIED', 'T_NAME_RELATIVE' ) as $constant ) {
			if ( defined( $constant ) ) {
				$ids[] = constant( $constant );
			}
		}

		$ids[] = T_STRING;

		return $ids;
	}

	/**
	 * The next or previous token that is not whitespace or a comment.
	 *
	 * @param array $tokens    Tokens.
	 * @param int   $i         Index to start from.
	 * @param int   $direction 1 or -1.
	 * @return array|string|null
	 */
	private static function significant( array $tokens, $i, $direction ) {
		$total = count( $tokens );

		for ( $j = $i + $direction; $j >= 0 && $j < $total; $j += $direction ) {
			$token = $tokens[ $j ];

			if ( is_array( $token ) && in_array( $token[0], array( T_WHITESPACE, T_COMMENT, T_DOC_COMMENT ), true ) ) {
				continue;
			}

			return $token;
		}

		return null;
	}

	/**
	 * The name in `function foo(` / `class Foo`.
	 *
	 * @param array $tokens Tokens.
	 * @param int   $i      Index of the keyword.
	 * @return string
	 */
	private static function name_after( array $tokens, $i ) {
		$total = count( $tokens );

		for ( $j = $i + 1; $j < $total; $j++ ) {
			$token = $tokens[ $j ];

			if ( is_array( $token ) ) {
				if ( in_array( $token[0], array( T_WHITESPACE, T_COMMENT, T_DOC_COMMENT ), true ) ) {
					continue;
				}

				return T_STRING === $token[0] ? $token[1] : '';
			}

			if ( '&' === $token ) {
				continue; // function &foo()
			}

			return ''; // '(' — a closure, or anything that is not a name.
		}

		return '';
	}

	/**
	 * The comma-separated names after `extends` / `implements`.
	 *
	 * @param array $tokens Tokens.
	 * @param int   $i      Index of the keyword.
	 * @return array<int,array{name:string,line:int}>
	 */
	private static function names_after( array $tokens, $i ) {
		$total = count( $tokens );
		$names = array();
		$ids   = self::name_tokens();

		for ( $j = $i + 1; $j < $total; $j++ ) {
			$token = $tokens[ $j ];

			if ( is_array( $token ) ) {
				if ( in_array( $token[0], array( T_WHITESPACE, T_COMMENT, T_DOC_COMMENT, T_NS_SEPARATOR ), true ) ) {
					continue;
				}

				if ( in_array( $token[0], $ids, true ) ) {
					$names[] = array( 'name' => $token[1], 'line' => (int) $token[2] );
					continue;
				}

				if ( T_IMPLEMENTS === $token[0] ) {
					continue; // class A extends B implements C
				}

				break;
			}

			if ( ',' === $token ) {
				continue;
			}

			break; // '{'
		}

		return $names;
	}

	/**
	 * @param array $tokens Tokens.
	 * @param int   $i      Index.
	 * @return bool
	 */
	private static function preceded_by_double_colon( array $tokens, $i ) {
		$before = self::significant( $tokens, $i, -1 );

		return is_array( $before ) && T_DOUBLE_COLON === $before[0];
	}

	/**
	 * The first literal string argument of the call starting at $i.
	 *
	 * @param array $tokens Tokens.
	 * @param int   $i      Index of the function name.
	 * @return string
	 */
	private static function first_string_argument( array $tokens, $i ) {
		$total = min( count( $tokens ), $i + 12 );

		for ( $j = $i + 1; $j < $total; $j++ ) {
			$token = $tokens[ $j ];

			if ( is_array( $token ) && T_CONSTANT_ENCAPSED_STRING === $token[0] ) {
				return trim( $token[1], "'\"" );
			}

			if ( is_string( $token ) && ( ')' === $token || ';' === $token ) ) {
				break;
			}
		}

		return '';
	}

	/**
	 * Was this closure written as an argument to add_action() and friends?
	 *
	 * Walks back to the unclosed '(' that encloses it and looks at whose call
	 * it is. Stops at a statement boundary, so a closure two statements later
	 * is not attributed to an add_action() above it.
	 *
	 * @param array $tokens Tokens.
	 * @param int   $i      Index of T_FUNCTION.
	 * @return bool
	 */
	private static function inside_registrar( array $tokens, $i ) {
		$depth = 0;
		$floor = max( 0, $i - 200 );

		for ( $j = $i - 1; $j >= $floor; $j-- ) {
			$token = $tokens[ $j ];

			if ( ! is_string( $token ) ) {
				continue;
			}

			if ( ')' === $token ) {
				$depth++;
			} elseif ( '(' === $token ) {
				if ( 0 === $depth ) {
					$name = self::significant( $tokens, $j, -1 );

					return is_array( $name )
						&& T_STRING === $name[0]
						&& in_array( strtolower( $name[1] ), self::CALLBACK_REGISTRARS, true );
				}

				$depth--;
			} elseif ( ( ';' === $token || '}' === $token ) && 0 === $depth ) {
				return false;
			}
		}

		return false;
	}

	/**
	 * @param string $name Possibly namespaced.
	 * @return string
	 */
	private static function bare( $name ) {
		$name = ltrim( (string) $name, '\\' );
		$at   = strrpos( $name, '\\' );

		return false === $at ? $name : substr( $name, $at + 1 );
	}

	/**
	 * @param array $findings Findings.
	 * @return array
	 */
	private static function unique_by_name( array $findings ) {
		$seen = array();
		$out  = array();

		foreach ( $findings as $finding ) {
			$key = $finding['kind'] . ':' . strtolower( $finding['name'] );

			// Keep the worse of two reports for the same name.
			if ( isset( $seen[ $key ] ) ) {
				if ( 'fatal' === $finding['severity'] && 'warning' === $out[ $seen[ $key ] ]['severity'] ) {
					$out[ $seen[ $key ] ] = $finding;
				}
				continue;
			}

			$seen[ $key ] = count( $out );
			$out[]        = $finding;
		}

		return $out;
	}
}

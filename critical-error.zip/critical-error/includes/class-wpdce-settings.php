<?php
/**
 * Settings.
 *
 * Read through a guard on every access, because the handler that reads them
 * runs during shutdown — sometimes a shutdown caused by the database being
 * unreachable, when get_option() cannot answer. Defaults have to be usable on
 * their own.
 *
 * @package WPD_Critical_Error
 */

defined( 'ABSPATH' ) || exit;

class WPDCE_Settings {

	const OPTION = 'wpdce_settings';

	/** @var array|null */
	private static $cache = null;

	/**
	 * @return array
	 */
	public static function defaults() {
		return array(
			// On by default: the cost is one registered handler, and the
			// benefit is knowing which plugin broke the site instead of
			// bisecting forty of them by hand.
			'capture'         => 1,

			// Off by default. Notices and deprecations are constant background
			// noise on most sites and would bury the fatal you came to find.
			'capture_notices' => 0,

			// On by default. It only ever *prevents* a save that would have
			// taken the site down, and it falls back to WordPress's own
			// behaviour whenever it cannot run — so the worst case is the
			// status quo.
			'editor_guard'    => 1,

			// On by default, and the reason the guard catches anything at all
			// beyond typos: resolving every name in the file against the
			// running site is what turns "valid PHP" into "valid PHP that
			// calls a function nobody has defined". It never blocks unless the
			// call is one that is certain to run.
			'editor_runtime'  => 1,
		);
	}

	/**
	 * @return array
	 */
	public static function all() {
		if ( null !== self::$cache ) {
			return self::$cache;
		}

		if ( ! function_exists( 'get_option' ) ) {
			return self::defaults();
		}

		$saved = get_option( self::OPTION, array() );

		self::$cache = array_merge( self::defaults(), is_array( $saved ) ? $saved : array() );

		return self::$cache;
	}

	/**
	 * @param string $key Key.
	 * @return bool
	 */
	public static function enabled( $key ) {
		$all = self::all();

		return ! empty( $all[ $key ] );
	}

	/**
	 * @param array $values Values.
	 */
	public static function update( array $values ) {
		$clean = array();

		foreach ( self::defaults() as $key => $default ) {
			$clean[ $key ] = empty( $values[ $key ] ) ? 0 : 1;
		}

		update_option( self::OPTION, $clean, false );

		self::$cache = null;
	}
}

<?php
/**
 * Admin screen: Tools → Critical Errors.
 *
 * @package WPD_Critical_Error
 */

defined( 'ABSPATH' ) || exit;

class WPDCE_Admin {

	const PAGE  = 'wpd-critical-error';
	const NONCE = 'wpdce_action';

	/** @var WPDCE_Admin|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_post_wpdce_action', array( $this, 'handle_action' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
		add_action( 'admin_notices', array( $this, 'fatal_notice' ) );
	}

	public function add_menu() {
		$fatals = WPDCE_Log::fatal_count();

		add_management_page(
			__( 'Critical Errors', 'wpd-critical-error' ),
			$fatals
				? sprintf(
					/* translators: %s: bubble markup. */
					__( 'Critical Errors %s', 'wpd-critical-error' ),
					'<span class="update-plugins count-' . (int) $fatals . '"><span class="update-count">' . (int) $fatals . '</span></span>'
				)
				: __( 'Critical Errors', 'wpd-critical-error' ),
			'manage_options',
			self::PAGE,
			array( $this, 'render' )
		);
	}

	/**
	 * @param string $hook Current screen.
	 */
	public function enqueue( $hook ) {
		if ( false === strpos( (string) $hook, self::PAGE ) ) {
			return;
		}

		wp_enqueue_style( 'wpdce-admin', WPDCE_URL . 'assets/admin.css', array(), WPDCE_VERSION );
	}

	/**
	 * A fatal error is not something to leave sitting quietly on a settings
	 * page — if the site crashed, say so where the person actually is.
	 */
	public function fatal_notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$screen = get_current_screen();

		if ( $screen && false !== strpos( (string) $screen->id, self::PAGE ) ) {
			return;
		}

		$fatals = WPDCE_Log::recent( true );

		if ( ! $fatals ) {
			return;
		}

		$first = reset( $fatals );

		printf(
			'<div class="notice notice-error"><p><strong>%s</strong> %s <a href="%s">%s</a></p></div>',
			esc_html__( 'Critical error recorded:', 'wpd-critical-error' ),
			esc_html(
				sprintf(
					/* translators: 1: component type, 2: component name. */
					__( 'most recently in %1$s "%2$s".', 'wpd-critical-error' ),
					$first['blame']['type'],
					$first['blame']['name'] ? $first['blame']['name'] : __( 'an unknown location', 'wpd-critical-error' )
				)
			),
			esc_url( admin_url( 'tools.php?page=' . self::PAGE ) ),
			esc_html__( 'See what failed', 'wpd-critical-error' )
		);
	}

	public function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'wpd-critical-error' ) );
		}

		$errors   = WPDCE_Log::recent();
		$fatals   = WPDCE_Log::fatal_count();
		$settings = WPDCE_Settings::all();
		$is_mu    = defined( 'WPMU_PLUGIN_DIR' ) && file_exists( WPMU_PLUGIN_DIR . '/wpd-critical-error-loader.php' );

		require WPDCE_DIR . 'views/admin.php';
	}

	/**
	 * Clear the log, regenerate the token, save settings.
	 */
	public function handle_action() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'wpd-critical-error' ) );
		}

		check_admin_referer( self::NONCE );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked above.
		$do  = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
		$msg = '';

		switch ( $do ) {
			case 'clear':
				WPDCE_Log::clear();
				$msg = 'cleared';
				break;

			case 'new_token':
				WPDCE_Report::regenerate();
				$msg = 'token';
				break;

			case 'selftest':
				$result = WPDCE_Handler::self_test();

				set_transient( 'wpdce_selftest_result', $result, 60 );

				$msg = 'selftest';
				break;

			case 'save':
				WPDCE_Settings::update(
					array(
						// phpcs:ignore WordPress.Security.NonceVerification.Missing
						'capture'         => isset( $_POST['capture'] ),
						// phpcs:ignore WordPress.Security.NonceVerification.Missing
						'capture_notices' => isset( $_POST['capture_notices'] ),
						// phpcs:ignore WordPress.Security.NonceVerification.Missing
						'editor_guard'    => isset( $_POST['editor_guard'] ),
						// phpcs:ignore WordPress.Security.NonceVerification.Missing
						'editor_runtime'  => isset( $_POST['editor_runtime'] ),
					)
				);
				$msg = 'saved';
				break;
		}

		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE, 'done' => $msg ), admin_url( 'tools.php' ) ) );
		exit;
	}

	/**
	 * A single action button.
	 *
	 * @param string $do      Action key.
	 * @param string $label   Button text.
	 * @param string $classes Extra classes.
	 * @param string $confirm Confirmation prompt, or ''.
	 */
	public static function button( $do, $label, $classes = 'button', $confirm = '' ) {
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
			<input type="hidden" name="action" value="wpdce_action" />
			<input type="hidden" name="do" value="<?php echo esc_attr( $do ); ?>" />
			<?php wp_nonce_field( self::NONCE ); ?>
			<button
				type="submit"
				class="<?php echo esc_attr( $classes ); ?>"
				<?php if ( '' !== $confirm ) : ?>
					onclick="return confirm(<?php echo esc_attr( wp_json_encode( $confirm ) ); ?>)"
				<?php endif; ?>
			><?php echo esc_html( $label ); ?></button>
		</form>
		<?php
	}
}

<?php
/**
 * A check on the theme and plugin file editors, before the file is written.
 *
 * WordPress is not defenceless here. Since 4.9 the editor writes the file, makes
 * a loopback request to see whether the site still answers, and puts the old
 * content back if it does not. That is a good design and this does not replace
 * it.
 *
 * It has two gaps, and both of them are the reason people still lose an
 * afternoon to this screen:
 *
 *   1. It tells you a line number and a message, and nothing else. You are then
 *      counting lines in a textarea to find the code it is talking about. The
 *      one thing you actually want to see — the code that broke — is the one
 *      thing it does not show you.
 *
 *   2. The loopback fails constantly. Local installs, staging behind basic auth,
 *      hosts that block outbound requests to themselves, anything behind a VPN.
 *      When it fails, core reverts the change and says "Unable to communicate
 *      back with site" — which diagnoses nothing, and the change is gone anyway.
 *
 * So this checks the code *before* anything is written, in the browser, with no
 * loopback involved: a real PHP parse, plus the declaration conflicts that a
 * parse cannot see. If it fails, the save never happens, nothing on disk is
 * touched, your code stays exactly where you typed it, and the notice shows the
 * offending lines with the failing one marked.
 *
 * WHAT IT CANNOT SEE, stated up front: a parse check catches syntax, not
 * behaviour. `undefined_function()` called at the top level of functions.php is
 * a fatal at runtime and perfectly valid syntax, so it passes this and is caught
 * by core's loopback instead. That case is not left bare either — when core
 * reverts, this fills in what core leaves out and shows the code around the
 * failing line.
 *
 * @package WPD_Critical_Error
 */

defined( 'ABSPATH' ) || exit;

class WPDCE_Editor {

	/** @var WPDCE_Editor|null */
	private static $instance = null;

	const NONCE  = 'wpdce_check_code';
	const ACTION = 'wpdce_check_code';

	/** Asked after a save that WordPress reverted, to explain why. */
	const ACTION_AFTER = 'wpdce_after_save';

	/** Screens this runs on. */
	const SCREENS = array( 'theme-editor.php', 'plugin-editor.php' );

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		/*
		 * First, and before anything reads $_POST. `admin_init` fires inside
		 * wp-admin/admin.php, which theme-editor.php and admin-ajax.php both
		 * include before they do any work — so this runs while the file on disk
		 * is still untouched.
		 */
		add_action( 'admin_init', array( $this, 'refuse_save' ), 1 );

		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
		add_action( 'admin_notices', array( $this, 'explain_failed_save' ) );
		add_action( 'wp_ajax_' . self::ACTION, array( $this, 'ajax_check' ) );
		add_action( 'wp_ajax_' . self::ACTION_AFTER, array( $this, 'ajax_aftermath' ) );
	}

	/* ------------------------------------------------------------------ *
	 * The gate that cannot be walked around
	 * ------------------------------------------------------------------ */

	/**
	 * Refuse the save on the server, before the file is written.
	 *
	 * The browser-side check is the one that gives a good answer — it runs
	 * while you type, it never loses your work, and it can put your cursor on
	 * the failing line. What it cannot do is be relied upon. JavaScript may be
	 * off, `admin-ajax.php` may be unreachable, a request may be made by
	 * something that is not the editor at all, and in every one of those cases
	 * the browser gate is simply absent.
	 *
	 * So the same verdict is taken again here, where it is not optional. This
	 * one has no fallback and no fail-open: if the code would certainly crash
	 * the site, `wp_edit_theme_plugin_file()` is never reached and nothing is
	 * written. Warnings still do not block — a check that refuses on a guess is
	 * a check people turn off, and the whole gate would go with it.
	 */
	public function refuse_save() {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		if ( ! isset( $_SERVER['REQUEST_METHOD'] ) || 'POST' !== strtoupper( (string) wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$posted = wp_unslash( (array) $_POST );
		$page   = isset( $GLOBALS['pagenow'] ) ? (string) $GLOBALS['pagenow'] : '';

		$verdict = self::verdict_for_save( $posted, $page );

		if ( null === $verdict ) {
			return;
		}

		if ( self::is_editor_ajax( $posted ) ) {
			wp_send_json_error( array( 'message' => self::plain_text( $verdict ) ) );
		}

		self::die_with( $verdict, (string) $posted['newcontent'] );
	}

	/**
	 * Should this request be refused, and why?
	 *
	 * Separated from the refusing so that the decision can be tested without a
	 * browser, a database, or a way to catch `exit`.
	 *
	 * @param array  $posted Unslashed request data.
	 * @param string $page   The `pagenow` global.
	 * @return array|null The blocking verdict, or null to let the save proceed.
	 */
	public static function verdict_for_save( array $posted, $page ) {
		if ( ! WPDCE_Settings::enabled( 'editor_guard' ) ) {
			return null;
		}

		if ( ! isset( $posted['newcontent'] ) ) {
			return null;
		}

		// Either the editor's own Ajax save, or its no-JavaScript form post.
		// Anything else that happens to carry a `newcontent` field is not ours.
		if ( ! self::is_editor_ajax( $posted ) && ! in_array( $page, self::SCREENS, true ) ) {
			return null;
		}

		$file = self::resolve( $posted );

		/*
		 * No resolvable path means either no capability or no such file, and
		 * core is about to refuse the request on those grounds a moment from
		 * now. There is nothing useful to add to that.
		 */
		if ( '' === $file ) {
			return null;
		}

		$verdict = self::inspect( (string) $posted['newcontent'], $file );

		// Warnings deliberately do not block. The browser gate offers them with
		// a Save anyway button; refusing them here would make that button a lie
		// and would refuse saves on what is, by construction, a guess.
		return empty( $verdict['ok'] ) ? $verdict : null;
	}

	/**
	 * @param array $posted Request data.
	 * @return bool
	 */
	private static function is_editor_ajax( array $posted ) {
		return isset( $posted['action'] ) && 'edit-theme-plugin-file' === (string) $posted['action'];
	}

	/**
	 * The verdict as one line, for places that cannot take markup.
	 *
	 * @param array $verdict From inspect().
	 * @return string
	 */
	private static function plain_text( array $verdict ) {
		return sprintf(
			/* translators: 1: error label, 2: line number, 3: message, 4: what to do. */
			__( 'Not saved — this would have crashed the site. %1$s on line %2$d: %3$s %4$s', 'wpd-critical-error' ),
			$verdict['label'],
			(int) $verdict['line'],
			$verdict['message'],
			$verdict['hint']
		);
	}

	/**
	 * Stop the request with the diagnosis, and with the code still in reach.
	 *
	 * This is the path taken when JavaScript never ran, which means the only
	 * copy of what was typed is in this request. Going back restores it in
	 * every current browser — the editor screen was fetched with GET, so there
	 * is no resubmission prompt — but "in every current browser" is not a
	 * promise worth making about somebody's afternoon, so the submitted code is
	 * also printed here, selected on click, ready to be copied out.
	 *
	 * @param array  $verdict   From inspect().
	 * @param string $submitted The code that was refused.
	 */
	private static function die_with( array $verdict, $submitted ) {
		ob_start();
		?>
		<div class="wpdce-editor-notice">
			<p class="wpdce-editor-notice__head">
				<strong><?php esc_html_e( 'Not saved — this would have crashed the site.', 'wpd-critical-error' ); ?></strong>
			</p>
			<?php self::render_verdict( $verdict ); ?>

			<p class="description">
				<?php esc_html_e( 'Nothing was written. The file on disk is exactly as it was.', 'wpd-critical-error' ); ?>
			</p>

			<p>
				<label for="wpdce-returned">
					<strong><?php esc_html_e( 'Your code, so that it is not lost:', 'wpd-critical-error' ); ?></strong>
				</label>
			</p>
			<textarea
				id="wpdce-returned"
				rows="12"
				readonly
				onclick="this.select()"
				style="width:100%;font-family:monospace;font-size:12px;"
			><?php echo esc_textarea( $submitted ); ?></textarea>
			<p class="description">
				<?php esc_html_e( 'Going back to the editor restores what you typed. This copy is here in case it does not.', 'wpd-critical-error' ); ?>
			</p>
		</div>

		<style>
			<?php
			// wp_die() renders its own minimal page with none of the admin
			// stylesheets, so the few rules the diagnosis needs come with it.
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents, WordPress.PHP.NoSilencedErrors.Discouraged
			$css = @file_get_contents( WPDCE_DIR . 'assets/admin.css' );
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents, WordPress.PHP.NoSilencedErrors.Discouraged
			$css .= @file_get_contents( WPDCE_DIR . 'assets/editor.css' );

			echo wp_strip_all_tags( (string) $css ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			?>
		</style>
		<?php
		$html = (string) ob_get_clean();

		wp_die(
			$html, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			__( 'Not saved — this would have crashed the site', 'wpd-critical-error' ),
			array(
				'response'  => 200,
				'back_link' => true,
			)
		);
	}

	/* ------------------------------------------------------------------ *
	 * The check
	 * ------------------------------------------------------------------ */

	/**
	 * Would this code kill the site if it were saved?
	 *
	 * @param string $code      The submitted source.
	 * @param string $real_file Absolute path of the file being edited, or ''.
	 * @return array{ok:bool,label:string,message:string,line:int,excerpt:array,hint:string,warnings:array}
	 */
	public static function inspect( $code, $real_file = '' ) {
		$code = (string) $code;

		// Only PHP is worth parsing. A stylesheet is not going to fatal, and
		// running a PHP parser over CSS would report every rule as an error.
		if ( '' !== $real_file && 'php' !== strtolower( (string) pathinfo( $real_file, PATHINFO_EXTENSION ) ) ) {
			return self::pass();
		}

		/*
		 * Every verdict carries a `warnings` list, empty or not, so that a
		 * caller never has to ask whether the key is there. The union operator
		 * fills it in for the checks that predate it and have nothing to add.
		 */
		$empty = array( 'warnings' => array() );

		$parse = self::parse_failure( $code );

		if ( $parse ) {
			return $parse + $empty;
		}

		$clash = self::declaration_clash( $code, $real_file );

		if ( $clash ) {
			return $clash + $empty;
		}

		return self::runtime_risk( $code, $real_file );
	}

	/**
	 * The fatal that is valid PHP: a call to something that does not exist.
	 *
	 * Everything above this point reads grammar. This one resolves names
	 * against the running site, which is the only way to catch the case that
	 * costs people their afternoon — `undefined_function()` inside a function
	 * hooked to `init`, which parses perfectly and blanks the dashboard on the
	 * very next request.
	 *
	 * Findings come back in two strengths and are treated differently on
	 * purpose. A call that is definitely reached stops the save. A call whose
	 * reachability depends on something outside this file is shown, with the
	 * lines, and the save is still the author's to make — because a check that
	 * blocks on guesses is a check people learn to work around.
	 *
	 * @param string $code      Source.
	 * @param string $real_file Absolute path being edited.
	 * @return array
	 */
	private static function runtime_risk( $code, $real_file ) {
		if ( ! WPDCE_Settings::enabled( 'editor_runtime' ) || ! class_exists( 'WPDCE_Runtime' ) ) {
			return self::pass();
		}

		$findings = WPDCE_Runtime::scan( $code, $real_file );

		if ( ! $findings ) {
			return self::pass();
		}

		// scan() sorts fatals first, so the first finding decides the verdict
		// and the rest are listed underneath it.
		$first = array_shift( $findings );

		if ( 'fatal' !== $first['severity'] ) {
			$verdict             = self::pass();
			$verdict['warnings'] = array_merge( array( $first ), $findings );

			return $verdict;
		}

		return array(
			'ok'       => false,
			'label'    => $first['label'],
			'message'  => $first['message'],
			'line'     => $first['line'],
			'excerpt'  => $first['excerpt'],
			'hint'     => $first['hint'],
			'warnings' => $findings,
		);
	}

	/**
	 * Syntax, checked without running a line of the code.
	 *
	 * TOKEN_PARSE makes the tokeniser apply PHP's real grammar and throw on
	 * invalid source. That distinction matters: `include`-ing the file to find
	 * out whether it parses would also execute whatever is in it, on a live
	 * site, which is a spectacular way to turn a typo into an outage.
	 *
	 * @param string $code Source.
	 * @return array|null
	 */
	private static function parse_failure( $code ) {
		if ( ! defined( 'TOKEN_PARSE' ) ) {
			return null; // Nothing to check with; do not pretend otherwise.
		}

		try {
			// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			@token_get_all( $code, TOKEN_PARSE );
		} catch ( ParseError $e ) {
			return array(
				'ok'      => false,
				'label'   => __( 'Parse error', 'wpd-critical-error' ),
				'message' => $e->getMessage(),
				'line'    => (int) $e->getLine(),
				'excerpt' => self::excerpt( $code, (int) $e->getLine() ),
				'hint'    => __( 'PHP could not read this file at all, so every page on the site would have gone white. The cause is usually a few lines above the one marked — an unclosed brace, a missing semicolon, or a stray <?php tag left in a pasted snippet.', 'wpd-critical-error' ),
			);
		} catch ( Throwable $e ) {
			return array(
				'ok'      => false,
				'label'   => __( 'Compile error', 'wpd-critical-error' ),
				'message' => $e->getMessage(),
				'line'    => (int) $e->getLine(),
				'excerpt' => self::excerpt( $code, (int) $e->getLine() ),
				'hint'    => __( 'PHP refused to compile this file.', 'wpd-critical-error' ),
			);
		}

		return null;
	}

	/**
	 * Declaring something that already exists.
	 *
	 * This is the fatal a syntax check cannot see and the one people actually
	 * hit: a snippet from a blog post gets pasted into functions.php, then
	 * pasted again a month later, and PHP dies with "Cannot redeclare".
	 *
	 * The check is accurate rather than heuristic because it runs inside a fully
	 * loaded WordPress — `function_exists()` here is the same answer PHP would
	 * give when the file loads. Reflection then says *where* the existing one
	 * lives, so re-saving a file that declares its own functions is not mistaken
	 * for a conflict.
	 *
	 * @param string $code      Source.
	 * @param string $real_file Absolute path being edited.
	 * @return array|null
	 */
	private static function declaration_clash( $code, $real_file ) {
		$found = self::declarations( $code );

		// Declared twice inside the submitted code itself. This one does not
		// need to know anything about the site, and it is the commonest of the
		// lot — the same snippet pasted in twice.
		foreach ( $found['duplicates'] as $duplicate ) {
			return array(
				'ok'      => false,
				'label'   => __( 'Duplicate declaration', 'wpd-critical-error' ),
				'message' => sprintf(
					/* translators: 1: function or class, 2: name, 3: line number. */
					__( 'Cannot redeclare %1$s %2$s() — it is already declared on line %3$d of this same file.', 'wpd-critical-error' ),
					$duplicate['kind'],
					$duplicate['name'],
					$duplicate['first']
				),
				'line'    => $duplicate['line'],
				'excerpt' => self::excerpt( $code, $duplicate['line'] ),
				'hint'    => __( 'The same snippet appears twice. Delete one of the two copies.', 'wpd-critical-error' ),
			);
		}

		/*
		 * Without a resolved path there is no way to tell "this file already
		 * declares this function, and you are re-saving it" from a real
		 * conflict — and reporting the former would flag every ordinary save.
		 * So when the path is unknown, this check does not run.
		 */
		if ( '' === $real_file ) {
			return null;
		}

		foreach ( $found['declarations'] as $entry ) {
			$exists = 'function' === $entry['kind']
				? function_exists( $entry['qualified'] )
				: class_exists( $entry['qualified'], false ) || interface_exists( $entry['qualified'], false ) || trait_exists( $entry['qualified'], false );

			if ( ! $exists ) {
				continue;
			}

			$owner = self::declared_in( $entry['kind'], $entry['qualified'] );

			// Declared by this very file: that is just the current version of
			// it, loaded. Re-saving the file is not a redeclaration.
			if ( '' !== $owner && self::same_file( $owner, $real_file ) ) {
				continue;
			}

			return array(
				'ok'      => false,
				'label'   => __( 'Duplicate declaration', 'wpd-critical-error' ),
				'message' => sprintf(
					/* translators: 1: function or class, 2: name, 3: where it already exists. */
					__( 'Cannot redeclare %1$s %2$s() — it already exists in %3$s.', 'wpd-critical-error' ),
					$entry['kind'],
					$entry['name'],
					'' === $owner ? __( 'PHP itself', 'wpd-critical-error' ) : WPDCE_Handler::relative( $owner )
				),
				'line'    => $entry['line'],
				'excerpt' => self::excerpt( $code, $entry['line'] ),
				'hint'    => __( 'Rename yours to something unlikely to collide, or wrap it in if ( ! function_exists( … ) ) so it only declares when nothing else has.', 'wpd-critical-error' ),
			);
		}

		return null;
	}

	/**
	 * Top-level function and class declarations, with their line numbers.
	 *
	 * Only depth zero counts. A declaration inside braces is inside an `if`, a
	 * class body or another function, and the classic
	 * `if ( ! function_exists( 'x' ) ) { function x() {} }` guard is precisely
	 * the code that must NOT be reported — it is the correct way to write this,
	 * and flagging it would train people to ignore the warning.
	 *
	 * @param string $code Source.
	 * @return array{declarations:array,duplicates:array}
	 */
	private static function declarations( $code ) {
		// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		$tokens = @token_get_all( $code );

		if ( ! is_array( $tokens ) ) {
			return array( 'declarations' => array(), 'duplicates' => array() );
		}

		$depth      = 0;
		$alternate  = 0;
		$namespace  = '';
		$found      = array();
		$duplicates = array();
		$seen       = array();
		$total      = count( $tokens );

		for ( $i = 0; $i < $total; $i++ ) {
			$token = $tokens[ $i ];

			if ( ! is_array( $token ) ) {
				if ( '{' === $token ) {
					$depth++;
				} elseif ( '}' === $token ) {
					$depth--;
				}
				continue;
			}

			switch ( $token[0] ) {
				// Interpolation braces inside strings and heredocs. Their
				// closing brace is an ordinary '}' token, so they have to be
				// counted or the depth drifts negative and every later
				// declaration looks top-level when it is not.
				case T_CURLY_OPEN:
				case T_DOLLAR_OPEN_CURLY_BRACES:
					$depth++;
					break;

				/*
				 * Alternative syntax — if ( … ) : … endif; — opens a block
				 * without opening a brace. The idiom this matters for is the
				 * one every starter theme ships:
				 *
				 *     if ( ! function_exists( "wp_body_open" ) ) :
				 *         function wp_body_open() { … }
				 *     endif;
				 *
				 * Counting only braces leaves that function looking top-level,
				 * and it is then reported as redeclaring the core function it
				 * exists to stand in for — refusing to save a file that is not
				 * merely valid but correct.
				 */
				case T_IF:
				case T_FOR:
				case T_FOREACH:
				case T_WHILE:
				case T_SWITCH:
					if ( self::opens_alternative_block( $tokens, $i ) ) {
						$alternate++;
					}
					break;

				case T_ENDIF:
				case T_ENDFOR:
				case T_ENDFOREACH:
				case T_ENDWHILE:
				case T_ENDSWITCH:
					$alternate = max( 0, $alternate - 1 );
					break;

				case T_NAMESPACE:
					if ( 0 === $depth ) {
						$namespace = self::read_namespace( $tokens, $i );
					}
					break;

				case T_FUNCTION:
					if ( 0 !== $depth || 0 !== $alternate ) {
						break;
					}
					$name = self::read_name( $tokens, $i );
					if ( '' !== $name ) {
						self::collect( 'function', $name, $namespace, (int) $token[2], $found, $seen, $duplicates );
					}
					break;

				case T_CLASS:
				case T_INTERFACE:
				case T_TRAIT:
					if ( 0 !== $depth || 0 !== $alternate ) {
						break;
					}
					// `Foo::class` is a T_CLASS token too, and `new class {}` is
					// anonymous. Both are excluded by requiring a name.
					if ( self::follows_double_colon( $tokens, $i ) ) {
						break;
					}
					$name = self::read_name( $tokens, $i );
					if ( '' !== $name ) {
						self::collect( 'class', $name, $namespace, (int) $token[2], $found, $seen, $duplicates );
					}
					break;
			}
		}

		return array( 'declarations' => $found, 'duplicates' => $duplicates );
	}

	/**
	 * @param string $kind       function|class.
	 * @param string $name       Bare name.
	 * @param string $namespace  Current namespace.
	 * @param int    $line       Line.
	 * @param array  $found      Accumulator.
	 * @param array  $seen       name => first line.
	 * @param array  $duplicates Accumulator.
	 */
	private static function collect( $kind, $name, $namespace, $line, array &$found, array &$seen, array &$duplicates ) {
		$qualified = '' === $namespace ? $name : $namespace . '\\' . $name;
		$key       = $kind . ':' . strtolower( $qualified );

		if ( isset( $seen[ $key ] ) ) {
			$duplicates[] = array( 'kind' => $kind, 'name' => $name, 'line' => $line, 'first' => $seen[ $key ] );
			return;
		}

		$seen[ $key ] = $line;

		$found[] = array(
			'kind'      => $kind,
			'name'      => $name,
			'qualified' => $qualified,
			'line'      => $line,
		);
	}

	/**
	 * The name in `function foo(` / `class Foo`, skipping whitespace and the
	 * by-reference ampersand.
	 *
	 * @param array $tokens Tokens.
	 * @param int   $i      Index of the keyword.
	 * @return string
	 */
	private static function read_name( array $tokens, $i ) {
		$total = count( $tokens );

		for ( $j = $i + 1; $j < $total; $j++ ) {
			$token = $tokens[ $j ];

			if ( is_array( $token ) ) {
				if ( T_WHITESPACE === $token[0] || T_COMMENT === $token[0] || T_DOC_COMMENT === $token[0] ) {
					continue;
				}
				return T_STRING === $token[0] ? $token[1] : '';
			}

			if ( '&' === $token ) {
				continue; // function &foo()
			}

			return ''; // '(' — a closure, or anything else that is not a name.
		}

		return '';
	}

	/**
	 * @param array $tokens Tokens.
	 * @param int   $i      Index of T_NAMESPACE.
	 * @return string
	 */
	private static function read_namespace( array $tokens, $i ) {
		$total = count( $tokens );
		$name  = '';

		for ( $j = $i + 1; $j < $total; $j++ ) {
			$token = $tokens[ $j ];

			if ( is_array( $token ) ) {
				if ( T_WHITESPACE === $token[0] ) {
					continue;
				}
				// PHP 8 emits the whole dotted name as one token; PHP 7 emits
				// T_STRING and T_NS_SEPARATOR separately.
				if ( T_STRING === $token[0] || defined( 'T_NAME_QUALIFIED' ) && T_NAME_QUALIFIED === $token[0] ) {
					$name .= $token[1];
					continue;
				}
				if ( T_NS_SEPARATOR === $token[0] ) {
					$name .= '\\';
					continue;
				}
				break;
			}

			break; // ';' or '{'
		}

		return trim( $name, '\\' );
	}

	/**
	 * Does this control structure use the colon form rather than braces?
	 *
	 * `if ( … ) :` and `if ( … ) {` are the same block; only one of them is
	 * visible to a brace counter. Told apart by stepping over the condition's
	 * parentheses and looking at what comes next — which is also why `else :`
	 * and `elseif ( … ) :` are not counted here: they continue a block that has
	 * already been counted, and only one `endif` closes the lot.
	 *
	 * @param array $tokens Tokens.
	 * @param int   $i      Index of the control keyword.
	 * @return bool
	 */
	public static function opens_alternative_block( array $tokens, $i ) {
		$total = count( $tokens );
		$depth = 0;

		for ( $j = $i + 1; $j < $total; $j++ ) {
			$token = $tokens[ $j ];

			if ( is_array( $token ) ) {
				if ( in_array( $token[0], array( T_WHITESPACE, T_COMMENT, T_DOC_COMMENT ), true ) ) {
					continue;
				}

				if ( 0 === $depth ) {
					return false; // Something other than a condition. Not ours.
				}

				continue;
			}

			if ( '(' === $token ) {
				$depth++;
				continue;
			}

			if ( ')' === $token ) {
				$depth--;

				if ( 0 === $depth ) {
					// The token after the closing parenthesis decides it.
					for ( $k = $j + 1; $k < $total; $k++ ) {
						$next = $tokens[ $k ];

						if ( is_array( $next ) && in_array( $next[0], array( T_WHITESPACE, T_COMMENT, T_DOC_COMMENT ), true ) ) {
							continue;
						}

						return ':' === $next;
					}

					return false;
				}

				continue;
			}

			if ( 0 === $depth ) {
				return false;
			}
		}

		return false;
	}

	/**
	 * @param array $tokens Tokens.
	 * @param int   $i      Index.
	 * @return bool
	 */
	private static function follows_double_colon( array $tokens, $i ) {
		for ( $j = $i - 1; $j >= 0; $j-- ) {
			$token = $tokens[ $j ];

			if ( is_array( $token ) && T_WHITESPACE === $token[0] ) {
				continue;
			}

			return is_array( $token ) && T_DOUBLE_COLON === $token[0];
		}

		return false;
	}

	/**
	 * Which file declared this, according to PHP itself.
	 *
	 * @param string $kind function|class.
	 * @param string $name Qualified name.
	 * @return string Normalised path, or '' for an internal (built-in) symbol.
	 */
	private static function declared_in( $kind, $name ) {
		try {
			$reflection = 'function' === $kind ? new ReflectionFunction( $name ) : new ReflectionClass( $name );
			$file       = $reflection->getFileName();
		} catch ( Throwable $e ) {
			return '';
		}

		return $file ? wp_normalize_path( $file ) : '';
	}

	/**
	 * @param string $a Path.
	 * @param string $b Path.
	 * @return bool
	 */
	private static function same_file( $a, $b ) {
		$a = realpath( $a );
		$b = realpath( $b );

		return $a && $b && wp_normalize_path( $a ) === wp_normalize_path( $b );
	}

	/**
	 * Lines around the failing one, keyed by line number.
	 *
	 * @param string $code   Source.
	 * @param int    $line   Failing line.
	 * @param int    $radius Lines either side.
	 * @return array<int,string>
	 */
	public static function excerpt( $code, $line, $radius = 8 ) {
		$lines = preg_split( '/\r\n|\r|\n/', (string) $code );

		if ( ! is_array( $lines ) ) {
			return array();
		}

		$total = count( $lines );
		$line  = max( 1, min( $total, (int) $line ) );
		$start = max( 1, $line - $radius );
		$end   = min( $total, $line + $radius );
		$out   = array();

		for ( $i = $start; $i <= $end; $i++ ) {
			$source = (string) $lines[ $i - 1 ];

			// One 8,000-character minified line would push the marked line off
			// the side of the screen, which defeats the purpose of showing it.
			$out[ $i ] = strlen( $source ) > 400 ? substr( $source, 0, 400 ) . ' …' : $source;
		}

		return $out;
	}

	/**
	 * @return array
	 */
	private static function pass() {
		return array( 'ok' => true, 'label' => '', 'message' => '', 'line' => 0, 'excerpt' => array(), 'hint' => '', 'warnings' => array() );
	}

	/* ------------------------------------------------------------------ *
	 * Wiring
	 * ------------------------------------------------------------------ */

	/**
	 * @param string $hook Current screen.
	 */
	public function enqueue( $hook ) {
		if ( ! in_array( $hook, self::SCREENS, true ) || ! WPDCE_Settings::enabled( 'editor_guard' ) ) {
			return;
		}

		wp_enqueue_style( 'wpdce-admin', WPDCE_URL . 'assets/admin.css', array(), WPDCE_VERSION );
		wp_enqueue_style( 'wpdce-editor', WPDCE_URL . 'assets/editor.css', array( 'wpdce-admin' ), WPDCE_VERSION );

		wp_enqueue_script( 'wpdce-editor', WPDCE_URL . 'assets/editor.js', array(), WPDCE_VERSION, true );

		wp_localize_script(
			'wpdce-editor',
			'wpdceEditor',
			array(
				'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
				'action'      => self::ACTION,
				'afterAction' => self::ACTION_AFTER,
				'nonce'       => wp_create_nonce( self::NONCE ),
				'i18n'        => array(
					'checking'    => __( 'Checking for fatal errors…', 'wpd-critical-error' ),
					'blocked'     => __( 'Not saved — this would have crashed the site.', 'wpd-critical-error' ),
					'reverted'    => __( 'WordPress put the file back. Here is what crashed.', 'wpd-critical-error' ),
					'lineLabel'   => __( 'Line %d', 'wpd-critical-error' ),
					'offline'     => __( 'The check could not run, so the file was saved without it. WordPress will still revert the change if the site stops answering.', 'wpd-critical-error' ),
					'warned'      => __( 'Not saved yet — this code refers to something that does not exist on this site.', 'wpd-critical-error' ),
					'also'        => __( 'Also found in this file:', 'wpd-critical-error' ),
					'saveAnyway'  => __( 'Save anyway', 'wpd-critical-error' ),
					'saveAnyway2' => __( 'I have read the warning above and want to write this file.', 'wpd-critical-error' ),
					'cancel'      => __( 'Go back and fix it', 'wpd-critical-error' ),
				),
			)
		);
	}

	/**
	 * The pre-flight endpoint the editor calls before it submits.
	 */
	public function ajax_check() {
		check_ajax_referer( self::NONCE, 'nonce' );

		if ( ! current_user_can( 'edit_themes' ) && ! current_user_can( 'edit_plugins' ) ) {
			wp_send_json_error( array( 'message' => __( 'You are not allowed to edit files.', 'wpd-critical-error' ) ), 403 );
		}

		/*
		 * Deliberately not sanitised. This is PHP source on its way to a parser
		 * and straight back out again — sanitising it would change the very
		 * thing being checked, and the result would describe code the user
		 * never wrote. It is never executed, never written to disk, and is
		 * escaped at every point it reaches the page.
		 */
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing
		$code = isset( $_POST['code'] ) ? (string) wp_unslash( $_POST['code'] ) : '';

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$file = self::resolve( wp_unslash( (array) $_POST ) );

		wp_send_json_success( self::inspect( $code, $file ) );
	}

	/**
	 * Why did WordPress revert that save?
	 *
	 * Asked once, after a save that got past the pre-flight and came back an
	 * error anyway. That means core's loopback request crashed — and this
	 * plugin's handler was registered inside that request, so the file, line
	 * and message are already on disk. All that is left is to line the recorded
	 * line number up against the code the editor still has on screen.
	 */
	public function ajax_aftermath() {
		check_ajax_referer( self::NONCE, 'nonce' );

		if ( ! current_user_can( 'edit_themes' ) && ! current_user_can( 'edit_plugins' ) ) {
			wp_send_json_error( array( 'message' => __( 'You are not allowed to edit files.', 'wpd-critical-error' ) ), 403 );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$file = self::resolve( wp_unslash( (array) $_POST ) );

		$recorded = '' === $file ? null : self::recorded_fatal( $file );

		if ( ! $recorded ) {
			wp_send_json_success( array( 'found' => false ) );
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing
		$code = isset( $_POST['code'] ) ? (string) wp_unslash( $_POST['code'] ) : '';

		wp_send_json_success(
			array(
				'found'   => true,
				'label'   => $recorded['label'],
				'message' => $recorded['message'],
				'line'    => (int) $recorded['line'],
				'excerpt' => self::excerpt( $code, (int) $recorded['line'] ),
				'hint'    => __( 'This is valid PHP — it only fails when it runs, which is why the check before the save passed it. Your code is still in the editor; WordPress has put the previous version back on disk.', 'wpd-critical-error' ),
			)
		);
	}

	/**
	 * Absolute path of the file the editor is pointed at.
	 *
	 * Used only to read — never to write — but validated as though it were a
	 * write, because "it is only a read" is how directory traversal ships.
	 *
	 * @param array $args Request data.
	 * @return string Normalised path, or ''.
	 */
	private static function resolve( array $args ) {
		$file = isset( $args['file'] ) ? (string) $args['file'] : '';

		if ( '' === $file || 0 !== validate_file( $file ) ) {
			return '';
		}

		if ( ! empty( $args['plugin'] ) ) {
			if ( ! current_user_can( 'edit_plugins' ) || 0 !== validate_file( (string) $args['plugin'] ) ) {
				return '';
			}
			$path = WP_PLUGIN_DIR . '/' . $file;
		} elseif ( ! empty( $args['theme'] ) ) {
			if ( ! current_user_can( 'edit_themes' ) || 0 !== validate_file( (string) $args['theme'] ) ) {
				return '';
			}

			$theme = wp_get_theme( (string) $args['theme'] );

			if ( ! $theme->exists() ) {
				return '';
			}

			$path = $theme->get_stylesheet_directory() . '/' . $file;
		} else {
			return '';
		}

		$real = realpath( $path );

		return ( $real && is_file( $real ) ) ? wp_normalize_path( $real ) : '';
	}

	/* ------------------------------------------------------------------ *
	 * After core has reverted a save
	 * ------------------------------------------------------------------ */

	/**
	 * Say what core does not: which code caused it.
	 *
	 * This fires when a save reached the server and came back reverted — either
	 * because JavaScript was unavailable and the pre-flight never ran, or
	 * because the fatal was a runtime one that no parser could have predicted.
	 * Core prints a message and a line number. This prints the lines.
	 */
	public function explain_failed_save() {
		if ( ! WPDCE_Settings::enabled( 'editor_guard' ) ) {
			return;
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		if ( ! $screen || ! in_array( $screen->base, array( 'theme-editor', 'plugin-editor' ), true ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		if ( ! isset( $_SERVER['REQUEST_METHOD'] ) || 'POST' !== strtoupper( (string) wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( ! isset( $_POST['newcontent'] ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_themes' ) && ! current_user_can( 'edit_plugins' ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$posted = wp_unslash( (array) $_POST );
		$file   = self::resolve( $posted );

		if ( '' === $file || 'php' !== strtolower( (string) pathinfo( $file, PATHINFO_EXTENSION ) ) ) {
			return;
		}

		$submitted = (string) $posted['newcontent'];

		/*
		 * The plainest possible test for "did core keep this?": compare what
		 * was submitted with what is on disk now. Core reverts by writing the
		 * previous content back, so a mismatch means the save was undone. This
		 * avoids reaching into theme-editor.php's local $edit_error, which a
		 * hook cannot see anyway.
		 */
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents, WordPress.PHP.NoSilencedErrors.Discouraged
		$on_disk = @file_get_contents( $file );

		if ( false === $on_disk || 0 === strcmp( $on_disk, $submitted ) ) {
			return; // Saved. Nothing to explain.
		}

		$verdict = self::inspect( $submitted, $file );

		if ( empty( $verdict['ok'] ) ) {
			self::render_notice( $verdict );
			return;
		}

		// Syntactically fine, so the fatal happened at runtime. The loopback
		// request that core made is the one that crashed — and this plugin's
		// handler was running inside it, so the details are already recorded.
		$recorded = self::recorded_fatal( $file );

		if ( $recorded ) {
			self::render_notice(
				array(
					'ok'      => false,
					'label'   => $recorded['label'],
					'message' => $recorded['message'],
					'line'    => (int) $recorded['line'],
					'excerpt' => self::excerpt( $submitted, (int) $recorded['line'] ),
					'hint'    => __( 'This one is valid PHP — it only fails when it runs, which is why the parse check passed it. Your code is still in the editor below; WordPress has put the previous version back on disk.', 'wpd-critical-error' ),
				)
			);
		}
	}

	/**
	 * The fatal this plugin captured during core's loopback, if it captured one.
	 *
	 * @param string $file Absolute path being edited.
	 * @return array|null
	 */
	private static function recorded_fatal( $file ) {
		if ( ! class_exists( 'WPDCE_Log' ) ) {
			return null;
		}

		WPDCE_Log::flush_cache(); // The loopback was a different PHP process.

		foreach ( WPDCE_Log::recent( true ) as $entry ) {
			if ( empty( $entry['file'] ) || time() - (int) $entry['last_seen'] > 180 ) {
				continue;
			}

			if ( self::same_file( (string) $entry['file'], $file ) ) {
				return $entry;
			}
		}

		return null;
	}

	/**
	 * @param array $verdict From inspect().
	 */
	private static function render_notice( array $verdict ) {
		?>
		<div class="notice notice-error wpdce-editor-notice">
			<p class="wpdce-editor-notice__head">
				<strong><?php esc_html_e( 'Your change was not saved — it would have crashed the site.', 'wpd-critical-error' ); ?></strong>
			</p>
			<?php self::render_verdict( $verdict ); ?>
		</div>
		<?php
	}

	/**
	 * The body of a diagnosis: what failed, where, and the code around it.
	 *
	 * @param array $verdict From inspect().
	 */
	public static function render_verdict( array $verdict ) {
		?>
		<p class="wpdce-editor-notice__what">
			<span class="wpdce-badge wpdce-badge--fatal"><?php echo esc_html( $verdict['label'] ); ?></span>
			<?php if ( ! empty( $verdict['line'] ) ) : ?>
				<span class="wpdce-editor-notice__line">
					<?php
					printf(
						/* translators: %d: line number. */
						esc_html__( 'line %d', 'wpd-critical-error' ),
						(int) $verdict['line']
					);
					?>
				</span>
			<?php endif; ?>
			<code><?php echo esc_html( $verdict['message'] ); ?></code>
		</p>

		<?php if ( ! empty( $verdict['excerpt'] ) ) : ?>
			<pre class="wpdce-src"><?php
			foreach ( $verdict['excerpt'] as $number => $source ) {
				printf(
					'<span class="%s"><span class="n">%5d</span> %s</span>' . "\n",
					(int) $number === (int) $verdict['line'] ? 'bad' : '',
					(int) $number,
					esc_html( $source )
				);
			}
			?></pre>
		<?php endif; ?>

		<?php if ( ! empty( $verdict['hint'] ) ) : ?>
			<p class="description"><?php echo esc_html( $verdict['hint'] ); ?></p>
		<?php endif; ?>

		<?php if ( ! empty( $verdict['warnings'] ) ) : ?>
			<p class="wpdce-editor-notice__also"><strong><?php esc_html_e( 'Also found in this file:', 'wpd-critical-error' ); ?></strong></p>
			<ul class="wpdce-editor-notice__list">
				<?php foreach ( $verdict['warnings'] as $extra ) : ?>
					<li>
						<span class="wpdce-badge <?php echo 'fatal' === $extra['severity'] ? 'wpdce-badge--fatal' : 'wpdce-badge--warn'; ?>"><?php echo esc_html( $extra['label'] ); ?></span>
						<?php
						printf(
							/* translators: %d: line number. */
							esc_html__( 'line %d', 'wpd-critical-error' ),
							(int) $extra['line']
						);
						?>
						<code><?php echo esc_html( $extra['message'] ); ?></code>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
		<?php
	}
}

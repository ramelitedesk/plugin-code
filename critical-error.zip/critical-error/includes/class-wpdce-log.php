<?php
/**
 * Storage for captured PHP errors.
 *
 * File-backed rather than option-backed, and that is the whole design decision.
 * The errors most worth capturing are the ones that take a site down, and a
 * site that is down is often down *because* the database is unreachable — at
 * which point update_option() cannot record the very failure you need to read
 * afterwards. A JSON file on disk survives that.
 *
 * @package WPD_Critical_Error
 */

defined( 'ABSPATH' ) || exit;

class WPDCE_Log {

	const FILE        = 'errors.json';
	const MAX_ENTRIES = 100;

	/** @var array|null Memoised read. */
	private static $cache = null;

	/**
	 * Where the log lives.
	 *
	 * Degrades deliberately: a fatal can happen so early that the uploads API
	 * does not exist yet, so each fallback needs fewer parts of WordPress than
	 * the one before it.
	 *
	 * @return string Directory with a trailing slash, or '' if none is usable.
	 */
	public static function dir() {
		$dir = '';

		if ( function_exists( 'wp_get_upload_dir' ) ) {
			$uploads = wp_get_upload_dir();
			if ( ! empty( $uploads['basedir'] ) ) {
				$dir = rtrim( $uploads['basedir'], '/\\' ) . '/wpd-critical-error';
			}
		}

		if ( '' === $dir && defined( 'WP_CONTENT_DIR' ) ) {
			$dir = rtrim( WP_CONTENT_DIR, '/\\' ) . '/wpd-critical-error';
		}

		if ( '' === $dir ) {
			return '';
		}

		// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		if ( ! is_dir( $dir ) && ! @mkdir( $dir, 0755, true ) && ! is_dir( $dir ) ) {
			return '';
		}

		self::protect( $dir );

		return $dir . '/';
	}

	/**
	 * This directory holds file paths and quoted source code. Deny it at the
	 * directory level and leave nothing browsable.
	 *
	 * On Nginx the .htaccess is ignored — the filename is not guessable and the
	 * report itself is token-gated, but if you are on Nginx, add a deny rule for
	 * this path to your server config.
	 *
	 * @param string $dir Directory.
	 */
	private static function protect( $dir ) {
		$files = array(
			'/.htaccess' => "Require all denied\n<IfModule !mod_authz_core.c>\n\tDeny from all\n</IfModule>\n",
			'/index.php' => "<?php\n// Silence is golden.\n",
		);

		foreach ( $files as $name => $contents ) {
			if ( ! file_exists( $dir . $name ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents, WordPress.PHP.NoSilencedErrors.Discouraged
				@file_put_contents( $dir . $name, $contents );
			}
		}
	}

	/**
	 * @return string Absolute path to the log file, or ''.
	 */
	public static function path() {
		$dir = self::dir();

		return '' === $dir ? '' : $dir . self::FILE;
	}

	/**
	 * Record one error.
	 *
	 * Repeats are folded together. A warning inside a loop can fire ten thousand
	 * times in one request, and ten thousand identical rows are strictly less
	 * informative than one row carrying a count.
	 *
	 * @param array $entry Error data.
	 * @return bool Whether it was written.
	 */
	public static function record( array $entry ) {
		$path = self::path();

		if ( '' === $path ) {
			return false;
		}

		$entries   = self::all();
		$signature = self::signature( $entry );
		$now       = time();

		if ( isset( $entries[ $signature ] ) ) {
			$entries[ $signature ]['count']     = (int) $entries[ $signature ]['count'] + 1;
			$entries[ $signature ]['last_seen'] = $now;
			// Keep the newest context: the first occurrence's request is rarely
			// the one still being investigated.
			$entries[ $signature ]['request'] = $entry['request'];
		} else {
			$entry['count']        = 1;
			$entry['first_seen']   = $now;
			$entry['last_seen']    = $now;
			$entries[ $signature ] = $entry;
		}

		if ( count( $entries ) > self::MAX_ENTRIES ) {
			$entries = self::sorted( $entries );
			$entries = array_slice( $entries, 0, self::MAX_ENTRIES, true );
		}

		self::$cache = $entries;

		$json = function_exists( 'wp_json_encode' ) ? wp_json_encode( $entries ) : json_encode( $entries ); // phpcs:ignore WordPress.WP.AlternativeFunctions.json_encode_json_encode

		if ( ! $json ) {
			return false;
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents, WordPress.PHP.NoSilencedErrors.Discouraged
		return false !== @file_put_contents( $path, $json, LOCK_EX );
	}

	/**
	 * Same file, same line, same message, same level = the same problem.
	 *
	 * @param array $entry Error.
	 * @return string
	 */
	private static function signature( array $entry ) {
		return md5( $entry['type'] . '|' . $entry['file'] . '|' . $entry['line'] . '|' . $entry['message'] );
	}

	/**
	 * @param array $entries Entries.
	 * @return array Newest sighting first.
	 */
	private static function sorted( array $entries ) {
		uasort(
			$entries,
			static function ( $a, $b ) {
				return (int) $b['last_seen'] <=> (int) $a['last_seen'];
			}
		);

		return $entries;
	}

	/**
	 * Drop the memoised copy so the next read comes from disk.
	 *
	 * Needed when another process has written to the file — the self-test's
	 * loopback request is a different PHP process entirely, so this one has no
	 * idea its cache is stale.
	 */
	public static function flush_cache() {
		self::$cache = null;
	}

	/**
	 * @return array Keyed by signature.
	 */
	public static function all() {
		if ( null !== self::$cache ) {
			return self::$cache;
		}

		$path = self::path();

		if ( '' === $path || ! is_readable( $path ) ) {
			self::$cache = array();
			return self::$cache;
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents, WordPress.PHP.NoSilencedErrors.Discouraged
		$decoded = json_decode( (string) @file_get_contents( $path ), true );

		self::$cache = is_array( $decoded ) ? $decoded : array();

		return self::$cache;
	}

	/**
	 * @param bool $fatal_only Only errors that ended the request.
	 * @return array Newest first.
	 */
	public static function recent( $fatal_only = false ) {
		$entries = self::all();

		if ( $fatal_only ) {
			$entries = array_filter(
				$entries,
				static function ( $entry ) {
					return ! empty( $entry['fatal'] );
				}
			);
		}

		return self::sorted( $entries );
	}

	/**
	 * @return int
	 */
	public static function fatal_count() {
		return count( self::recent( true ) );
	}

	/**
	 * @return int
	 */
	public static function total_count() {
		return count( self::all() );
	}

	/**
	 * Remove everything.
	 *
	 * @return bool
	 */
	public static function clear() {
		self::$cache = array();

		$path = self::path();

		if ( '' === $path || ! file_exists( $path ) ) {
			return true;
		}

		// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		return (bool) @unlink( $path );
	}
}

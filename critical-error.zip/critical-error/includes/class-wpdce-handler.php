<?php
/**
 * Error capture and attribution.
 *
 * WordPress's white screen tells you that a critical error happened and nothing
 * about which of your forty plugins caused it. The information exists — PHP
 * knows the exact file and line — it simply is not shown, because printing raw
 * paths and source to visitors would be a disclosure problem.
 *
 * So this captures it, attributes it to a plugin or theme by name, keeps the
 * source around the failing line, and makes it readable somewhere safe.
 *
 * ONE LIMIT, STATED UP FRONT: this can only catch what happens after it is
 * registered. WordPress loads plugins in alphabetical order, so a fatal inside
 * `akismet` happens before a plugin named `critical-error` exists. Installing
 * via config/mu-loader.php fixes that — must-use plugins load before every
 * regular plugin — and the admin screen says so when it is not installed.
 *
 * @package WPD_Critical_Error
 */

defined( 'ABSPATH' ) || exit;

class WPDCE_Handler {

	/** @var WPDCE_Handler|null */
	private static $instance = null;

	/** @var bool Guard against double registration. */
	private static $registered = false;

	/** @var int Non-fatal errors recorded this request. */
	private $recorded = 0;

	/** @var int Beyond this, stop recording non-fatals for this request. */
	const PER_REQUEST_CAP = 25;

	/** @var array Real stack trace, kept by the exception handler for shutdown. */
	private $last_trace = array();

	/** @var callable|null Whatever error handler was in place before ours. */
	private $previous_error_handler = null;

	/** @var callable|null Whatever exception handler was in place before ours. */
	private $previous_exception_handler = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	/**
	 * Errors that end the request.
	 *
	 * E_ERROR and friends cannot be seen by a normal error handler at all —
	 * only error_get_last() during shutdown catches them, which is the entire
	 * reason the shutdown hook exists.
	 *
	 * @return int[]
	 */
	public static function fatal_types() {
		return array( E_ERROR, E_PARSE, E_CORE_ERROR, E_CORE_WARNING, E_COMPILE_ERROR, E_COMPILE_WARNING, E_USER_ERROR );
	}

	public function register() {
		if ( self::$registered ) {
			return;
		}
		self::$registered = true;

		// Both previous handlers are kept and chained to. Replacing another
		// tool's handler outright is how a plugin silently breaks everyone
		// else's debugging.
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.prevent_path_disclosure_set_error_handler
		$this->previous_error_handler     = set_error_handler( array( $this, 'handle_error' ) );
		$this->previous_exception_handler = set_exception_handler( array( $this, 'handle_exception' ) );

		register_shutdown_function( array( $this, 'handle_shutdown' ) );
	}

	/**
	 * Non-fatal errors: warnings, notices, deprecations.
	 *
	 * Returns false deliberately. That hands the error back to PHP's normal
	 * handling, so WP_DEBUG_LOG, Query Monitor and the host's error log all
	 * still receive it. A plugin that swallows every error is a plugin that
	 * silently breaks everyone else's debugging.
	 *
	 * @param int    $type    Level.
	 * @param string $message Message.
	 * @param string $file    File.
	 * @param int    $line    Line.
	 * @return bool
	 */
	public function handle_error( $type, $message, $file = '', $line = 0 ) {
		// Respect the @ operator and the configured error_reporting level.
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.prevent_path_disclosure_error_reporting
		if ( ! ( error_reporting() & $type ) ) {
			return false;
		}

		if ( $this->recorded < self::PER_REQUEST_CAP && $this->should_capture( $type ) ) {
			$this->recorded++;

			try {
				WPDCE_Log::record( $this->build( $type, $message, $file, $line, false ) );
			} catch ( Throwable $e ) {
				// A logger that throws while logging is worse than one that misses.
				$this->recorded = self::PER_REQUEST_CAP;
			}
		}

		// Hand the error onward: to whichever handler we displaced, or — when
		// there was none — to PHP itself, so WP_DEBUG_LOG and the host's error
		// log still receive it. This plugin adds a record, it never removes one.
		if ( is_callable( $this->previous_error_handler ) ) {
			return (bool) call_user_func( $this->previous_error_handler, $type, $message, $file, $line );
		}

		return false;
	}

	/**
	 * @param int $type Level.
	 * @return bool
	 */
	private function should_capture( $type ) {
		if ( ! WPDCE_Settings::enabled( 'capture' ) ) {
			return false;
		}

		$noisy = array( E_NOTICE, E_USER_NOTICE, E_DEPRECATED, E_USER_DEPRECATED );

		if ( defined( 'E_STRICT' ) ) {
			$noisy[] = E_STRICT;
		}

		if ( in_array( $type, $noisy, true ) && ! WPDCE_Settings::enabled( 'capture_notices' ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Uncaught exceptions.
	 *
	 * PHP turns these into a fatal immediately afterwards, but this is the only
	 * moment the real stack trace still exists — by shutdown it is gone.
	 *
	 * @param Throwable $e Exception.
	 */
	public function handle_exception( $e ) {
		$this->last_trace = $this->format_trace( $e->getTrace() );

		try {
			WPDCE_Log::record(
				$this->build(
					E_ERROR,
					sprintf( 'Uncaught %s: %s', get_class( $e ), $e->getMessage() ),
					$e->getFile(),
					$e->getLine(),
					true
				)
			);
		} catch ( Throwable $inner ) {
			// Recording failed; PHP's normal outcome below still has to happen.
			$inner = null;
		}

		/*
		 * Restore what PHP would have done.
		 *
		 * Installing an exception handler makes PHP consider the exception
		 * handled, and the process then exits 0 — a crashed script reporting
		 * success. WP-CLI, cron jobs and deploy scripts read that status, so a
		 * crash reporter that swallows it turns a loud failure into a silent
		 * one. (This was a real bug here, caught by the end-to-end test.)
		 */
		if ( is_callable( $this->previous_exception_handler ) ) {
			call_user_func( $this->previous_exception_handler, $e );
			return;
		}

		// Match PHP's own wording so log parsers still recognise it.
		error_log( // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			sprintf(
				'PHP Fatal error:  Uncaught %s: %s in %s:%d',
				get_class( $e ),
				$e->getMessage(),
				$e->getFile(),
				$e->getLine()
			)
		);

		// exit() still runs registered shutdown functions, so WordPress's own
		// fatal-error screen and recovery email are unaffected.
		exit( 255 );
	}

	/**
	 * The only place a true fatal can be observed.
	 */
	public function handle_shutdown() {
		$error = error_get_last();

		if ( ! $error || ! in_array( $error['type'], self::fatal_types(), true ) ) {
			return;
		}

		try {
			WPDCE_Log::record( $this->build( $error['type'], $error['message'], $error['file'], $error['line'], true ) );
		} catch ( Throwable $e ) {
			return;
		}
	}

	/**
	 * Assemble one record.
	 *
	 * @param int    $type    Level.
	 * @param string $message Message.
	 * @param string $file    File.
	 * @param int    $line    Line.
	 * @param bool   $fatal   Did it end the request.
	 * @return array
	 */
	private function build( $type, $message, $file, $line, $fatal ) {
		$file = (string) $file;
		$line = (int) $line;

		return array(
			'type'     => (int) $type,
			'label'    => self::type_label( $type ),
			'fatal'    => (bool) $fatal,
			'message'  => self::shorten( (string) $message, 1000 ),
			'file'     => $file,
			'relative' => self::relative( $file ),
			'line'     => $line,
			'blame'    => self::blame( $file ),
			'excerpt'  => self::excerpt( $file, $line ),
			'trace'    => $this->last_trace,
			'request'  => $this->request_context(),
			'php'      => PHP_VERSION,
		);
	}

	/**
	 * Which component owns this file?
	 *
	 * The single most useful field in the record. "A plugin crashed" is not
	 * actionable; "the plugin in the folder named X crashed" is — you can rename
	 * that folder over FTP and have the site back in thirty seconds.
	 *
	 * @param string $file Absolute path.
	 * @return array{type:string,name:string,slug:string}
	 */
	public static function blame( $file ) {
		$path = str_replace( '\\', '/', (string) $file );

		if ( defined( 'WPDCE_DIR' ) && 0 === strpos( $path, str_replace( '\\', '/', WPDCE_DIR ) ) ) {
			return array( 'type' => 'self', 'name' => 'WPD Critical Error Reporter', 'slug' => '' );
		}
		if ( preg_match( '#/wp-content/mu-plugins/([^/]+)#', $path, $m ) ) {
			return array( 'type' => 'must-use plugin', 'name' => $m[1], 'slug' => $m[1] );
		}
		if ( preg_match( '#/wp-content/plugins/([^/]+)#', $path, $m ) ) {
			return array( 'type' => 'plugin', 'name' => self::plugin_name( $m[1] ), 'slug' => $m[1] );
		}
		if ( preg_match( '#/wp-content/themes/([^/]+)#', $path, $m ) ) {
			return array( 'type' => 'theme', 'name' => $m[1], 'slug' => $m[1] );
		}
		if ( preg_match( '#/(wp-admin|wp-includes)/#', $path ) ) {
			return array( 'type' => 'WordPress core', 'name' => 'WordPress core', 'slug' => '' );
		}

		return array( 'type' => 'unknown', 'name' => '', 'slug' => '' );
	}

	/**
	 * Turn a folder slug into the plugin's real name where possible.
	 *
	 * Wrapped in a guard because this runs during shutdown, when the plugin API
	 * may not be loaded.
	 *
	 * @param string $slug Folder name.
	 * @return string
	 */
	private static function plugin_name( $slug ) {
		if ( ! function_exists( 'get_plugins' ) || ! function_exists( 'is_admin' ) || ! is_admin() ) {
			return $slug;
		}

		try {
			foreach ( get_plugins() as $file => $data ) {
				if ( 0 === strpos( $file, $slug . '/' ) && ! empty( $data['Name'] ) ) {
					return $data['Name'] . ' (' . $slug . ')';
				}
			}
		} catch ( Throwable $e ) {
			return $slug;
		}

		return $slug;
	}

	/**
	 * Source around the failing line.
	 *
	 * @param string $file   Path.
	 * @param int    $line   Failing line.
	 * @param int    $radius Lines either side.
	 * @return array<int,string> Line number => source.
	 */
	public static function excerpt( $file, $line, $radius = 8 ) {
		if ( '' === $file || ! is_file( $file ) || ! is_readable( $file ) ) {
			return array();
		}

		// A 40 MB minified vendor bundle has no readable excerpt, and reading it
		// would burn memory during a shutdown that is already going badly.
		if ( filesize( $file ) > 2 * 1024 * 1024 ) {
			return array();
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file, WordPress.PHP.NoSilencedErrors.Discouraged
		$lines = @file( $file, FILE_IGNORE_NEW_LINES );

		if ( ! is_array( $lines ) ) {
			return array();
		}

		$start = max( 0, $line - $radius - 1 );
		$end   = min( count( $lines ) - 1, $line + $radius - 1 );
		$out   = array();

		for ( $i = $start; $i <= $end; $i++ ) {
			// Long minified lines are truncated rather than dropped: knowing the
			// line exists matters even when its content is unreadable.
			$out[ $i + 1 ] = self::shorten( (string) $lines[ $i ], 400 );
		}

		return $out;
	}

	/**
	 * @param array $trace Raw backtrace.
	 * @return array
	 */
	private function format_trace( array $trace ) {
		$out = array();

		foreach ( array_slice( $trace, 0, 15 ) as $frame ) {
			$out[] = array(
				'file'     => isset( $frame['file'] ) ? self::relative( $frame['file'] ) : '',
				'line'     => isset( $frame['line'] ) ? (int) $frame['line'] : 0,
				'function' => ( isset( $frame['class'] ) ? $frame['class'] . $frame['type'] : '' ) . ( isset( $frame['function'] ) ? $frame['function'] : '' ),
			);
		}

		return $out;
	}

	/**
	 * @return array
	 */
	private function request_context() {
		// phpcs:disable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		return array(
			'time'   => time(),
			'uri'    => isset( $_SERVER['REQUEST_URI'] ) ? self::shorten( (string) $_SERVER['REQUEST_URI'], 300 ) : '',
			'method' => isset( $_SERVER['REQUEST_METHOD'] ) ? substr( (string) $_SERVER['REQUEST_METHOD'], 0, 10 ) : '',
			'admin'  => function_exists( 'is_admin' ) ? (bool) is_admin() : false,
			'user'   => function_exists( 'get_current_user_id' ) ? (int) get_current_user_id() : 0,
			'ip'     => isset( $_SERVER['REMOTE_ADDR'] ) ? substr( (string) $_SERVER['REMOTE_ADDR'], 0, 45 ) : '',
		);
		// phpcs:enable
	}

	/**
	 * Path relative to the WordPress root, for display.
	 *
	 * @param string $file Absolute path.
	 * @return string
	 */
	public static function relative( $file ) {
		$file = str_replace( '\\', '/', (string) $file );

		if ( defined( 'ABSPATH' ) ) {
			$root = str_replace( '\\', '/', ABSPATH );
			if ( 0 === strpos( $file, $root ) ) {
				return substr( $file, strlen( $root ) );
			}
		}

		return $file;
	}

	/**
	 * @param string $value Value.
	 * @param int    $max   Length.
	 * @return string
	 */
	private static function shorten( $value, $max ) {
		return strlen( $value ) > $max ? substr( $value, 0, $max ) . '…' : $value;
	}

	/**
	 * Prove the whole chain works, rather than asking anyone to take it on faith.
	 *
	 * An empty error log has two possible meanings — "your site is healthy" and
	 * "this plugin is not actually running" — and they look identical. This
	 * makes them distinguishable.
	 *
	 * Two stages, because they test different code paths:
	 *
	 *   1. A local warning, which goes through set_error_handler().
	 *   2. A loopback request to a URL that deliberately fatals, which is the
	 *      only way to exercise the shutdown handler — the one that catches
	 *      real critical errors. It crashes that one internal request; the page
	 *      you are looking at is unaffected.
	 *
	 * @return array{warning:bool,fatal:bool,fatal_note:string}
	 */
	public static function self_test() {
		$result = array( 'warning' => false, 'fatal' => false, 'fatal_note' => '' );

		$before = WPDCE_Log::total_count();

		// --- Stage 1: a real warning through the real handler. -------------
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_trigger_error
		trigger_error( 'WPD Critical Error self-test: this warning is expected and can be cleared.', E_USER_WARNING );

		WPDCE_Log::flush_cache();
		$result['warning'] = WPDCE_Log::total_count() > $before;

		// --- Stage 2: a real fatal, in a request of its own. ---------------
		$token = bin2hex( random_bytes( 16 ) );
		set_transient( 'wpdce_selftest', $token, 5 * MINUTE_IN_SECONDS );

		$response = wp_remote_get(
			add_query_arg( 'wpdce-selftest', $token, home_url( '/' ) ),
			array( 'timeout' => 15, 'sslverify' => false, 'blocking' => true )
		);

		delete_transient( 'wpdce_selftest' );

		WPDCE_Log::flush_cache();

		foreach ( WPDCE_Log::recent( true ) as $entry ) {
			if ( false !== strpos( $entry['message'], 'wpdce_deliberate_selftest_crash' ) ) {
				$result['fatal'] = true;
				break;
			}
		}

		if ( ! $result['fatal'] ) {
			// A failed loopback is not the same as a failed handler, and saying
			// so matters: plenty of local and firewalled setups cannot call
			// themselves over HTTP.
			$result['fatal_note'] = is_wp_error( $response )
				? $response->get_error_message()
				: __( 'The loopback request completed but no fatal was recorded.', 'wpd-critical-error' );
		}

		return $result;
	}

	/**
	 * The endpoint stage 2 calls. Crashes on purpose, once, for a caller that
	 * already holds a one-time token generated seconds earlier in wp-admin.
	 */
	public static function maybe_self_destruct() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( empty( $_GET['wpdce-selftest'] ) || ! function_exists( 'get_transient' ) ) {
			return;
		}

		$expected = get_transient( 'wpdce_selftest' );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		if ( ! is_string( $expected ) || '' === $expected || ! hash_equals( $expected, (string) $_GET['wpdce-selftest'] ) ) {
			return;
		}

		delete_transient( 'wpdce_selftest' );

		// The most common cause of a real WordPress critical error, on purpose.
		wpdce_deliberate_selftest_crash();
	}

	/**
	 * @param int $type Level.
	 * @return string
	 */
	public static function type_label( $type ) {
		$map = array(
			E_ERROR             => 'Fatal error',
			E_WARNING           => 'Warning',
			E_PARSE             => 'Parse error',
			E_NOTICE            => 'Notice',
			E_CORE_ERROR        => 'Core error',
			E_CORE_WARNING      => 'Core warning',
			E_COMPILE_ERROR     => 'Compile error',
			E_COMPILE_WARNING   => 'Compile warning',
			E_USER_ERROR        => 'Fatal error (triggered)',
			E_USER_WARNING      => 'Warning (triggered)',
			E_USER_NOTICE       => 'Notice (triggered)',
			E_RECOVERABLE_ERROR => 'Recoverable error',
			E_DEPRECATED        => 'Deprecated',
			E_USER_DEPRECATED   => 'Deprecated (triggered)',
		);

		if ( defined( 'E_STRICT' ) ) {
			$map[ E_STRICT ] = 'Strict standards';
		}

		return isset( $map[ $type ] ) ? $map[ $type ] : 'Error';
	}
}

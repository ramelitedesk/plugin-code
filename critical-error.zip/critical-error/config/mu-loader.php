<?php
/**
 * Plugin Name: WPD Critical Error Reporter (loader)
 * Description: Loads the critical error reporter ahead of every regular plugin, so a fatal in one of them is still recorded.
 *
 * COPY THIS FILE TO: wp-content/mu-plugins/wpd-critical-error-loader.php
 *
 * Why this exists
 * ---------------
 * WordPress loads regular plugins in alphabetical order. A crash reporter can
 * only report crashes that happen after it is loaded, so as a regular plugin it
 * is blind to a fatal in anything alphabetically before it — which, for a plugin
 * whose folder starts with "c", is most of them.
 *
 * Must-use plugins load before all of that. Installed here, the handler is in
 * place before the first regular plugin is touched.
 *
 * Leave the plugin itself deactivated on the Plugins screen when you use this,
 * or it will be loaded twice. (Loading twice is harmless — registration is
 * guarded — but the Plugins screen will be misleading about what is running.)
 *
 * @package WPD_Critical_Error
 */

defined( 'ABSPATH' ) || exit;

/*
 * The plugin folder is usually called `critical-error`, but people rename
 * folders, and a loader that silently does nothing when it cannot find its
 * target is the worst possible failure for a crash reporter: everything looks
 * installed, and nothing is running.
 *
 * So: try the likely names, and if none of them exist, say so out loud.
 */
$wpdce_candidates = array(
	'critical-error',
	'wpd-critical-error',
	'critical-error-reporter',
);

/**
 * Override the folder name if yours differs from all of the above.
 * Define this in wp-config.php, above this loader's first use.
 */
if ( defined( 'WPDCE_PLUGIN_DIRNAME' ) ) {
	array_unshift( $wpdce_candidates, WPDCE_PLUGIN_DIRNAME );
}

$wpdce_loaded = false;

foreach ( $wpdce_candidates as $wpdce_dirname ) {
	$wpdce_main = WP_PLUGIN_DIR . '/' . $wpdce_dirname . '/wpd-critical-error.php';

	if ( is_readable( $wpdce_main ) ) {
		require_once $wpdce_main;
		$wpdce_loaded = true;
		break;
	}
}

if ( ! $wpdce_loaded ) {
	add_action(
		'admin_notices',
		static function () use ( $wpdce_candidates ) {
			if ( ! current_user_can( 'manage_options' ) ) {
				return;
			}

			printf(
				'<div class="notice notice-error"><p><strong>%s</strong> %s<br><code>%s</code></p></div>',
				esc_html__( 'WPD Critical Error loader: plugin not found.', 'wpd-critical-error' ),
				esc_html__( 'The must-use loader is installed but cannot locate the plugin. It looked inside the plugins directory for:', 'wpd-critical-error' ),
				esc_html( implode( '/wpd-critical-error.php, ', $wpdce_candidates ) . '/wpd-critical-error.php' )
			);
		}
	);
}

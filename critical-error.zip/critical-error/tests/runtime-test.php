<?php
/**
 * The undefined-name check.
 *
 * This is the check that resolves names against the running site rather than
 * reading grammar, and it is the one with the most room to be wrong. The two
 * ways it can be wrong are not equal:
 *
 *   A MISS costs nothing that was not already lost — WordPress's loopback is
 *   still behind it, and the plugin still explains the crash afterwards.
 *
 *   A FALSE POSITIVE that BLOCKS is unforgivable. It refuses to save code that
 *   was fine, cannot be argued with from the editor, and teaches people to
 *   switch the feature off. Every "this must still save" case below is worth
 *   more than the catches.
 *
 * So the cases are grouped by that: what must be stopped, what must be allowed
 * through with a warning, and what must not be mentioned at all.
 *
 * @package WPD_Critical_Error
 */

if ( 'cli' !== PHP_SAPI ) {
	http_response_code( 404 );
	exit;
}

require __DIR__ . '/bootstrap.php';
require_once dirname( __DIR__ ) . '/includes/class-wpdce-runtime.php';

$pass = 0;
$fail = 0;

/**
 * @param string $label  Assertion.
 * @param bool   $ok     Result.
 * @param string $detail Shown on failure.
 */
function check( $label, $ok, $detail = '' ) {
	global $pass, $fail;

	if ( $ok ) {
		$pass++;
		printf( "  ok    %s\n", $label );
		return;
	}

	$fail++;
	printf( "  FAIL  %s%s\n", $label, '' !== $detail ? ' :: ' . $detail : '' );
}

/**
 * @param array $findings From scan().
 * @return string
 */
function summarise( array $findings ) {
	if ( ! $findings ) {
		return 'nothing reported';
	}

	$parts = array();

	foreach ( $findings as $finding ) {
		$parts[] = sprintf( '%s %s @ %d', $finding['severity'], $finding['name'], $finding['line'] );
	}

	return implode( ', ', $parts );
}

/**
 * @param array $verdict From WPDCE_Editor::inspect().
 * @return string
 */
function summarise_verdict( array $verdict ) {
	return sprintf(
		'%s%s, %d warning(s)',
		empty( $verdict['ok'] ) ? 'blocked: ' : 'saves',
		empty( $verdict['ok'] ) ? $verdict['label'] . ' @ ' . $verdict['line'] : '',
		isset( $verdict['warnings'] ) ? count( $verdict['warnings'] ) : 0
	);
}

/**
 * The first finding for a given name, if there is one.
 *
 * @param array  $findings From scan().
 * @param string $name     Name.
 * @return array|null
 */
function finding_for( array $findings, $name ) {
	foreach ( $findings as $finding ) {
		if ( strtolower( $finding['name'] ) === strtolower( $name ) ) {
			return $finding;
		}
	}

	return null;
}

/**
 * @param string $code Source.
 * @return array
 */
function scan( $code ) {
	return WPDCE_Runtime::scan( $code, '/var/www/wp-content/themes/x/functions.php' );
}

/*
 * A handful of functions that exist in this process, standing in for "every
 * function of core and of every active plugin" on a real site.
 */
function wpdce_fixture_helper() {
	return true;
}

class WPDCE_Fixture_Thing {
	public static function go() {
		return true;
	}
}

/*
 * Enough of a site layout for the "is this file even loaded?" question to have
 * an answer: an active theme at themes/x, one other theme installed, and one
 * active plugin among two.
 */
define( 'WP_CONTENT_DIR', '/var/www/wp-content' );
define( 'WP_PLUGIN_DIR', '/var/www/wp-content/plugins' );

function get_stylesheet_directory() {
	// A test may point the active theme at a real directory, so that the
	// includes in a functions.php can be resolved and read the way they are on
	// an actual site.
	return '' === $GLOBALS['wpdce_state']['theme_dir']
		? '/var/www/wp-content/themes/x'
		: $GLOBALS['wpdce_state']['theme_dir'];
}

function get_template_directory() {
	return get_stylesheet_directory();
}

$GLOBALS['wpdce_state']['options']['active_plugins'] = array( 'live-plugin/live-plugin.php' );

echo "\n=== The case this exists for ===\n";

$hooked = <<<'PHP'
<?php
function test_custom_plugin_fatal_error() {
    // Deliberate fatal error for testing.
    undefined_test_function();
}

add_action('init', 'test_custom_plugin_fatal_error');
PHP;

$findings = scan( $hooked );
$first    = finding_for( $findings, 'undefined_test_function' );

check( 'the hooked undefined call is found', null !== $first, summarise( $findings ) );
check( 'and it blocks the save', $first && 'fatal' === $first['severity'], summarise( $findings ) );
check( 'on the line that calls it', $first && 4 === $first['line'], $first ? 'line ' . $first['line'] : '' );
check(
	'the message reads like the fatal it would have been',
	$first && false !== strpos( $first['message'], 'Call to undefined function undefined_test_function()' ),
	$first ? $first['message'] : ''
);
check(
	'the excerpt carries the offending line',
	$first && isset( $first['excerpt'][4] ) && false !== strpos( $first['excerpt'][4], 'undefined_test_function' ),
	$first ? implode( ' / ', $first['excerpt'] ) : ''
);
check(
	'the hint names the function that will run it',
	$first && false !== strpos( $first['hint'], 'test_custom_plugin_fatal_error()' ),
	$first ? $first['hint'] : ''
);

echo "\n=== Certain to run: the save is stopped ===\n";

$findings = scan( '<?php undefined_thing_at_top();' );
check( 'a top-level call is fatal', 'fatal' === $findings[0]['severity'], summarise( $findings ) );
check(
	'and the hint says the whole site goes down',
	false !== strpos( $findings[0]['hint'], 'every page of the site' ),
	$findings[0]['hint']
);

$findings = scan( "<?php\nif ( is_admin() ) {\n\tundefined_thing_at_top();\n}" );
check( 'inside a top-level if is still top-level', $findings && 'fatal' === $findings[0]['severity'], summarise( $findings ) );

$closure = <<<'PHP'
<?php
add_action( 'init', function () {
	undefined_in_closure();
} );
PHP;
check( 'a closure handed to add_action is fatal', 'fatal' === scan( $closure )[0]['severity'], summarise( scan( $closure ) ) );

$findings = scan( '<?php $thing = new Undefined_Fixture_Class();' );
check( 'instantiating a class nobody declares is fatal', $findings && 'fatal' === $findings[0]['severity'], summarise( $findings ) );
check( 'and it is reported as a class', $findings && 'class' === $findings[0]['kind'], summarise( $findings ) );

$findings = scan( '<?php Undefined_Fixture_Class::go();' );
check( 'a static call on a missing class is fatal', $findings && 'fatal' === $findings[0]['severity'], summarise( $findings ) );

$findings = scan( '<?php class Mine extends Undefined_Fixture_Parent {}' );
check( 'extending a class that does not exist is fatal', $findings && 'fatal' === $findings[0]['severity'], summarise( $findings ) );

echo "\n=== Reached by being called, not by being registered ===\n";

/*
 * The first rule for "does this run?" was a single heuristic: is the enclosing
 * function's name written as a string somewhere, the way a hook callback is
 * registered. It caught add_action( 'init', 'my_function' ) and missed the
 * plainest case there is — a function called on the line below itself.
 *
 * These are the shapes people actually write when they set out to break a site
 * on purpose, which makes them the shapes that must be caught.
 */
$called_below = <<<'PHP'
<?php
function test_fatal_error() {
    undefined_function_for_testing();
}

test_fatal_error();
PHP;
$findings = scan( $called_below );
check( 'a function called at the top of the file is reached', $findings && 'fatal' === $findings[0]['severity'], summarise( $findings ) );

$never_called = <<<'PHP'
<?php
function test_fatal_error() {
    undefined_function_for_testing();
}
PHP;
$findings = scan( $never_called );
check( 'and the same function, uncalled, is only a warning', $findings && 'warning' === $findings[0]['severity'], summarise( $findings ) );

$transitive = <<<'PHP'
<?php
function outer() {
	inner();
}

function inner() {
	undefined_two_steps_away();
}

outer();
PHP;
$findings = scan( $transitive );
check( 'reachability is followed through a second call', $findings && 'fatal' === $findings[0]['severity'], summarise( $findings ) );

$broken_chain = <<<'PHP'
<?php
function outer() {
	inner();
}

function inner() {
	undefined_two_steps_away();
}
PHP;
$findings = scan( $broken_chain );
check( 'but only when something starts the chain', $findings && 'warning' === $findings[0]['severity'], summarise( $findings ) );

$instance = <<<'PHP'
<?php
class TestCriticalError {
    public function run() {
        return new ClassThatDoesNotExist();
    }
}

$test = new TestCriticalError();
$test->run();
PHP;
$findings = scan( $instance );
check( 'a method called on an object made at the top level is reached', $findings && 'fatal' === $findings[0]['severity'], summarise( $findings ) );

$unused_method = <<<'PHP'
<?php
class TestCriticalError {
    public function run() {
        return new ClassThatDoesNotExist();
    }
}

$test = new TestCriticalError();
PHP;
$findings = scan( $unused_method );
check( 'a method nobody calls is only a warning', $findings && 'warning' === $findings[0]['severity'], summarise( $findings ) );

$constructor = <<<'PHP'
<?php
class Booter {
	public function __construct() {
		undefined_in_a_constructor();
	}
}

new Booter();
PHP;
$findings = scan( $constructor );
check( 'constructing a class runs its constructor', $findings && 'fatal' === $findings[0]['severity'], summarise( $findings ) );

$through_this = <<<'PHP'
<?php
class Booter {
	public function __construct() {
		$this->boot();
	}

	private function boot() {
		undefined_behind_this();
	}
}

new Booter();
PHP;
$findings = scan( $through_this );
check( '$this->method() is followed as well', $findings && 'fatal' === $findings[0]['severity'], summarise( $findings ) );

$static = <<<'PHP'
<?php
class Booter {
	public static function go() {
		undefined_in_a_static();
	}
}

Booter::go();
PHP;
$findings = scan( $static );
check( 'and a static call at the top level', $findings && 'fatal' === $findings[0]['severity'], summarise( $findings ) );

/*
 * The tracking must give up rather than guess. A variable that has held two
 * different classes could be either by the time the method is called, and a
 * refusal that rests on a guess is the thing this whole design avoids.
 */
$ambiguous = <<<'PHP'
<?php
class One {
	public function run() {
		undefined_in_one();
	}
}

class Two {
	public function run() {
		return 1;
	}
}

$thing = new One();
$thing = new Two();
$thing->run();
PHP;
$findings = scan( $ambiguous );
check( 'a variable given two classes is not resolved', $findings && 'warning' === $findings[0]['severity'], summarise( $findings ) );

echo "\n=== Might never run: warn, and let it save ===\n";

$dormant = <<<'PHP'
<?php
function nothing_calls_this() {
	undefined_but_dormant();
}
PHP;
$findings = scan( $dormant );
check( 'an unreferenced function only warns', $findings && 'warning' === $findings[0]['severity'], summarise( $findings ) );
check(
	'and says so plainly',
	$findings && false !== strpos( $findings[0]['hint'], 'keeps working until something does' ),
	$findings ? $findings[0]['hint'] : ''
);

$method = <<<'PHP'
<?php
class Mine {
	public function run() {
		undefined_in_method();
	}
}
PHP;
$findings = scan( $method );
check( 'a method body only warns', $findings && 'warning' === $findings[0]['severity'], summarise( $findings ) );

$included = <<<'PHP'
<?php
require_once dirname( $base ) . '/helpers.php';
maybe_defined_over_there();
PHP;
$findings = scan( $included );
check( 'an include that cannot be resolved downgrades to a warning', $findings && 'warning' === $findings[0]['severity'], summarise( $findings ) );

$variable_include = <<<'PHP'
<?php
require_once $path . '/helpers.php';
maybe_defined_over_there();
PHP;
$findings = scan( $variable_include );
check( 'and so does a path built from a variable', $findings && 'warning' === $findings[0]['severity'], summarise( $findings ) );

echo "\n=== Includes are followed, not surrendered to ===\n";

/*
 * The rule this replaced said "there is an include, so anything might be
 * defined — warn". True, and useless: every functions.php on the internet ends
 * with a run of require lines, so that rule disarmed the check on the one file
 * it exists for. These read the included files instead.
 */
// Inside ABSPATH, because the resolver deliberately refuses to read anything
// outside the installation.
$inc_dir = __DIR__ . '/sandbox-includes-' . getmypid();

if ( ! is_dir( $inc_dir . '/inc' ) ) {
	mkdir( $inc_dir . '/inc', 0777, true );
}

file_put_contents(
	$inc_dir . '/inc/template-tags.php',
	"<?php\nfunction wpdce_declared_in_an_include() {\n\treturn 1;\n}\n"
);

// A second level, to prove the walk does not stop at the first file.
file_put_contents(
	$inc_dir . '/inc/deeper.php',
	"<?php\nfunction wpdce_declared_two_levels_down() {\n\treturn 1;\n}\n"
);

file_put_contents(
	$inc_dir . '/inc/loader.php',
	"<?php\nrequire_once __DIR__ . '/deeper.php';\n"
);

$editing = $inc_dir . '/functions.php';

$GLOBALS['wpdce_state']['theme_dir'] = $inc_dir;

$with_include = "<?php\nrequire get_template_directory() . '/inc/template-tags.php';\n\nwpdce_declared_in_an_include();\n";
$findings     = WPDCE_Runtime::scan( $with_include, $editing );
check( 'a function the include declares is not reported', array() === $findings, summarise( $findings ) );

$still_missing = "<?php\nrequire get_template_directory() . '/inc/template-tags.php';\n\nwpdce_not_declared_anywhere();\n";
$findings      = WPDCE_Runtime::scan( $still_missing, $editing );
check(
	'but one it does not declare is still a certain fatal',
	$findings && 'fatal' === $findings[0]['severity'],
	summarise( $findings )
);

$two_levels = "<?php\nrequire __DIR__ . '/inc/loader.php';\n\nwpdce_declared_two_levels_down();\n";
$findings   = WPDCE_Runtime::scan( $two_levels, $editing );
check( 'an include of an include is followed too', array() === $findings, summarise( $findings ) );

$old_spelling = "<?php\nrequire dirname( __FILE__ ) . '/inc/template-tags.php';\n\nwpdce_declared_in_an_include();\n";
$findings     = WPDCE_Runtime::scan( $old_spelling, $editing );
check( 'dirname( __FILE__ ) resolves as well as __DIR__', array() === $findings, summarise( $findings ) );

/*
 * The include expression comes out of a text box. "It is only read" is not a
 * reason to let a text box name any file on the disk, so anything outside the
 * installation is refused — and refusing to read it leaves the name unresolved,
 * which is a warning rather than silence.
 */
$stray = sys_get_temp_dir() . '/wpdce-outside-' . getmypid() . '.php';
file_put_contents( $stray, "<?php\nfunction wpdce_not_declared_anywhere() { return 1; }\n" );

$outside  = "<?php\nrequire '" . $stray . "';\n\nwpdce_not_declared_anywhere();\n";
$findings = WPDCE_Runtime::scan( $outside, $editing );
check(
	'an include pointing outside the install is not read',
	$findings && 'warning' === $findings[0]['severity'],
	summarise( $findings )
);

unlink( $stray );
array_map( 'unlink', glob( $inc_dir . '/inc/*' ) ?: array() );
rmdir( $inc_dir . '/inc' );
rmdir( $inc_dir );

$GLOBALS['wpdce_state']['theme_dir'] = '';

$namespaced = <<<'PHP'
<?php
namespace Acme\Theme;
$thing = new Widget();
PHP;
$findings = scan( $namespaced );
check( 'a namespaced class name only warns', $findings && 'warning' === $findings[0]['severity'], summarise( $findings ) );

$imported = <<<'PHP'
<?php
use Acme\Helpers;
undefined_maybe_imported();
PHP;
$findings = scan( $imported );
check( 'a use import downgrades to a warning', $findings && 'warning' === $findings[0]['severity'], summarise( $findings ) );

echo "\n=== Files that are not loaded right now ===\n";

/*
 * A deactivated plugin's own functions are not declared, so its files call
 * names that genuinely do not resolve. Blocking those saves would make the
 * plugin editor unusable for exactly the plugin someone is trying to repair.
 */
$dormant_code = "<?php\nmy_inactive_plugin_boot();\n";

$deactivated = WPDCE_Runtime::scan( $dormant_code, '/var/www/wp-content/plugins/sleeping-plugin/sleeping-plugin.php' );
check( 'a deactivated plugin only warns', $deactivated && 'warning' === $deactivated[0]['severity'], summarise( $deactivated ) );
check(
	'and says why the site is not on fire',
	$deactivated && false !== strpos( $deactivated[0]['hint'], 'not active' ),
	$deactivated ? $deactivated[0]['hint'] : ''
);

$live = WPDCE_Runtime::scan( $dormant_code, '/var/www/wp-content/plugins/live-plugin/live-plugin.php' );
check( 'an active plugin\'s main file still blocks', $live && 'fatal' === $live[0]['severity'], summarise( $live ) );

/*
 * A file WordPress does not load by itself. It is included by something, on
 * some requests — a front-end partial checked from inside wp-admin refers to
 * classes this request had no reason to load, and refusing that save would be
 * a false positive of the worst kind.
 */
$partial = WPDCE_Runtime::scan( $dormant_code, '/var/www/wp-content/plugins/live-plugin/inc/front-end.php' );
check( 'but an included file inside it only warns', $partial && 'warning' === $partial[0]['severity'], summarise( $partial ) );
check(
	'and says the loading is what it cannot see',
	$partial && false !== strpos( $partial[0]['hint'], 'does not load this file on its own' ),
	$partial ? $partial[0]['hint'] : ''
);

$theme_partial = WPDCE_Runtime::scan( $dormant_code, '/var/www/wp-content/themes/x/inc/template-tags.php' );
check( 'the same for a theme include', $theme_partial && 'warning' === $theme_partial[0]['severity'], summarise( $theme_partial ) );

$unknown = WPDCE_Runtime::scan( $dormant_code, '' );
check( 'a path it cannot place never blocks', $unknown && 'warning' === $unknown[0]['severity'], summarise( $unknown ) );

$unused_theme = WPDCE_Runtime::scan( $dormant_code, '/var/www/wp-content/themes/other/functions.php' );
check( 'a theme that is not in use only warns', $unused_theme && 'warning' === $unused_theme[0]['severity'], summarise( $unused_theme ) );

$active_theme = WPDCE_Runtime::scan( $dormant_code, '/var/www/wp-content/themes/x/functions.php' );
check( 'the active theme still blocks', $active_theme && 'fatal' === $active_theme[0]['severity'], summarise( $active_theme ) );

echo "\n=== A variable its scope never gives a value to ===\n";

/*
 * A function has its own scope, so the WordPress globals are not in it. The
 * missing `global $wpdb;` is one of the commonest fatals there is, and the
 * error PHP gives — "on null" — names the method rather than the variable,
 * which sends people looking in the wrong place.
 */
$unbound = <<<'PHP'
<?php
add_action('init', function () {
    $wpdb->nonexistent_method_for_testing();
});
PHP;
$findings = scan( $unbound );
check( 'a method called on an unbound variable', $findings && 'fatal' === $findings[0]['severity'], summarise( $findings ) );
check(
	'reads the way PHP reports it',
	$findings && false !== strpos( $findings[0]['message'], 'Call to a member function nonexistent_method_for_testing() on null' ),
	$findings ? $findings[0]['message'] : ''
);
check(
	'and names the line that would fix it',
	$findings && false !== strpos( $findings[0]['hint'], 'global $wpdb;' ),
	$findings ? $findings[0]['hint'] : ''
);

check( 'global makes it fine',   array() === scan( "<?php\nadd_action('init', function () {\n\tglobal \$wpdb;\n\t\$wpdb->query( 'x' );\n});\n" ), 'flagged a global' );
check( 'use ( … ) makes it fine', array() === scan( "<?php\n\$wpdb = null;\nadd_action('init', function () use ( \$wpdb ) {\n\t\$wpdb->query( 'x' );\n});\n" ), 'flagged a use clause' );
check( 'a parameter makes it fine', array() === scan( "<?php\nfunction f( \$thing ) {\n\t\$thing->run();\n}\nf( null );\n" ), 'flagged a parameter' );
$assigned = "<?php\nfunction f() {\n\t\$thing = wpdce_fixture_helper();\n\t\$thing->run();\n}\nf();\n";
check( 'an assignment makes it fine', array() === scan( $assigned ), summarise( scan( $assigned ) ) );
check( 'a foreach binding makes it fine', array() === scan( "<?php\nfunction f( \$list ) {\n\tforeach ( \$list as \$item ) {\n\t\t\$item->run();\n\t}\n}\nf( array() );\n" ), 'flagged a foreach variable' );
check( '$this is never reported', array() === scan( "<?php\nclass C {\n\tpublic function a() {\n\t\t\$this->b();\n\t}\n\tpublic function b() {}\n}\n" ), 'flagged $this' );

/*
 * The reason the rule is "bound if it appears anywhere except as $var->…":
 * there is no way to know from here that preg_match() defines its third
 * argument, and a check that did not allow for that would fire constantly.
 */
$by_reference = "<?php\nfunction f( \$text ) {\n\tpreg_match( '/x/', \$text, \$matches );\n\t\$matches->whatever();\n}\nf( '' );\n";
check( 'a by-reference argument counts as binding it', array() === scan( $by_reference ), summarise( scan( $by_reference ) ) );

$top_level = "<?php\n\$wpdb->get_results( 'SELECT 1' );\n";
check( 'the top level of the file is the global scope', array() === scan( $top_level ), summarise( scan( $top_level ) ) );

$property_read = "<?php\nfunction f() {\n\treturn \$undefined->property;\n}\nf();\n";
check( 'reading a property on null is only a warning in PHP, so it is not reported', array() === scan( $property_read ), summarise( scan( $property_read ) ) );

echo "\n=== A parameter handed straight back under a declared type ===\n";

$passthrough = <<<'PHP'
<?php
function wp_test_function($value): string {
    return $value;
}

add_action('init', function () {
    wp_test_function([]);
});
PHP;
$findings = scan( $passthrough );
check( 'an array through a function declared to return string', $findings && 'fatal' === $findings[0]['severity'], summarise( $findings ) );
check(
	'reported at the call, which is where the mistake is',
	$findings && 7 === $findings[0]['line'],
	$findings ? 'line ' . $findings[0]['line'] : ''
);

check( 'a value that does convert is fine',  array() === scan( "<?php\nfunction f( \$v ): string { return \$v; }\nf( 5 );\n" ), summarise( scan( "<?php\nfunction f( \$v ): string { return \$v; }\nf( 5 );\n" ) ) );
check( 'a typed parameter is PHP\'s own business', array() === scan( "<?php\nfunction f( int \$v ): string { return \$v; }\nf( 5 );\n" ), summarise( scan( "<?php\nfunction f( int \$v ): string { return \$v; }\nf( 5 );\n" ) ) );
check( 'a non-literal argument is not guessed at', array() === scan( "<?php\nfunction f( \$v ): string { return \$v; }\nf( \$anything );\n" ), summarise( scan( "<?php\nfunction f( \$v ): string { return \$v; }\nf( \$anything );\n" ) ) );

$two_returns = "<?php\nfunction f( \$v ): string {\n\tif ( \$v ) {\n\t\treturn 'x';\n\t}\n\treturn \$v;\n}\nf( array() );\n";
check( 'a function with more than one return is left alone', array() === scan( $two_returns ), summarise( scan( $two_returns ) ) );

echo "\n=== A require of a file that is not there ===\n";

// A directory that really exists, standing in for the active theme, so that
// __DIR__ resolves and the file being edited is one WordPress loads by itself.
$req_dir = __DIR__ . '/sandbox-require-' . getmypid();

if ( ! is_dir( $req_dir . '/inc' ) ) {
	mkdir( $req_dir . '/inc', 0777, true );
}

file_put_contents( $req_dir . '/inc/template-tags.php', "<?php\n// A file that is really there.\n" );

$GLOBALS['wpdce_state']['theme_dir'] = $req_dir;

$editing = $req_dir . '/functions.php';

$missing_require = "<?php\nrequire_once __DIR__ . '/file-that-does-not-exist.php';\n";
$findings        = WPDCE_Runtime::scan( $missing_require, $editing );
check( 'an unconditional require of a missing file', $findings && 'fatal' === $findings[0]['severity'], summarise( $findings ) );
check(
	'reads the way PHP reports it',
	$findings && false !== strpos( $findings[0]['message'], 'Failed opening required' ),
	$findings ? $findings[0]['message'] : ''
);

$missing_include = "<?php\ninclude __DIR__ . '/file-that-does-not-exist.php';\n";
$findings        = WPDCE_Runtime::scan( $missing_include, $editing );
check( 'include only warns, because that is all PHP does', $findings && 'warning' === $findings[0]['severity'], summarise( $findings ) );

/*
 * Every optional drop-in in WordPress is loaded this way — db.php,
 * object-cache.php, maintenance.php, sunrise.php. Sweeping the installation
 * turned up thirteen of them before these two rules existed, and every one was
 * correct code.
 */
$guarded_require = "<?php\nif ( file_exists( __DIR__ . '/optional.php' ) ) {\n\trequire_once __DIR__ . '/optional.php';\n}\n";
$findings        = WPDCE_Runtime::scan( $guarded_require, $editing );
check( 'a require the file tests for first is not reported', array() === $findings, summarise( $findings ) );

$conditional_require = "<?php\nif ( defined( 'SOMETHING' ) ) {\n\trequire_once __DIR__ . '/file-that-does-not-exist.php';\n}\n";
$findings            = WPDCE_Runtime::scan( $conditional_require, $editing );
check( 'a require under any condition at all only warns', $findings && 'warning' === $findings[0]['severity'], summarise( $findings ) );

$alt_syntax = "<?php\nif ( defined( 'SOMETHING' ) ) :\n\trequire_once __DIR__ . '/file-that-does-not-exist.php';\nendif;\n";
$findings   = WPDCE_Runtime::scan( $alt_syntax, $editing );
check( 'including one written with endif;', $findings && 'warning' === $findings[0]['severity'], summarise( $findings ) );

$present = "<?php\nrequire_once __DIR__ . '/inc/template-tags.php';\n";
$findings = WPDCE_Runtime::scan( $present, $editing );
check( 'a require of a file that is there is silent', array() === $findings, summarise( $findings ) );

unlink( $req_dir . '/inc/template-tags.php' );
rmdir( $req_dir . '/inc' );
rmdir( $req_dir );

$GLOBALS['wpdce_state']['theme_dir'] = '';

echo "\n=== Members of a class this file can vouch for ===\n";

$missing_method = <<<'PHP'
<?php
class TestClass {
    public function run() {
        return "OK";
    }
}

$test = new TestClass();
$test->missingMethod();
PHP;
$findings = scan( $missing_method );
check( 'a method the class does not have', $findings && 'fatal' === $findings[0]['severity'], summarise( $findings ) );
check(
	'reads the way PHP reports it',
	$findings && false !== strpos( $findings[0]['message'], 'Call to undefined method TestClass::missingMethod()' ),
	$findings ? $findings[0]['message'] : ''
);
check(
	'and says what the class does have',
	$findings && false !== strpos( $findings[0]['hint'], 'run()' ),
	$findings ? $findings[0]['hint'] : ''
);

$typo_method = <<<'PHP'
<?php
class TestClass {
    public function process() {
        return "OK";
    }
}

$test = new TestClass();
$test->proccess();
PHP;
$findings = scan( $typo_method );
check(
	'a near-miss is offered as a correction',
	$findings && false !== strpos( $findings[0]['hint'], 'Did you mean process()?' ),
	$findings ? $findings[0]['hint'] : ''
);

$static_misuse = <<<'PHP'
<?php
class TestClass {
    public function run() {
        return "OK";
    }
}

TestClass::run();
PHP;
$findings = scan( $static_misuse );
check( 'calling an instance method statically', $findings && 'fatal' === $findings[0]['severity'], summarise( $findings ) );
check(
	'named as PHP names it',
	$findings && false !== strpos( $findings[0]['message'], 'Non-static method TestClass::run() cannot be called statically' ),
	$findings ? $findings[0]['message'] : ''
);

$property_type = <<<'PHP'
<?php
class TestClass {
    public int $value;
}

$test = new TestClass();
$test->value = "invalid";
PHP;
$findings = scan( $property_type );
check( 'a value a typed property cannot hold', $findings && 'fatal' === $findings[0]['severity'], summarise( $findings ) );
check(
	'named as PHP names it',
	$findings && false !== strpos( $findings[0]['message'], 'Cannot assign string to property TestClass::$value of type int' ),
	$findings ? $findings[0]['message'] : ''
);

$static_ok = "<?php\nclass T { public static function go() { return 1; } }\n\nT::go();\n";
check( 'a static method called statically is fine', array() === scan( $static_ok ), summarise( scan( $static_ok ) ) );

$instance_static = "<?php\nclass T { public static function go() { return 1; } }\n\n\$t = new T();\n\$t->go();\n";
check( 'a static method called on an instance is fine', array() === scan( $instance_static ), summarise( scan( $instance_static ) ) );

$coerced = "<?php\nclass T { public int \$value; }\n\n\$t = new T();\n\$t->value = \"5\";\n";
check( 'a numeric string into an int property is fine', array() === scan( $coerced ), summarise( scan( $coerced ) ) );

$dynamic = "<?php\nclass T { public function run() { return 1; } }\n\n\$t = new T();\n\$t->whatever = \"anything\";\n";
check( 'a property that was never declared is not an error', array() === scan( $dynamic ), summarise( scan( $dynamic ) ) );

$untyped = "<?php\nclass T { public \$value; }\n\n\$t = new T();\n\$t->value = \"anything\";\n";
check( 'an untyped property takes anything', array() === scan( $untyped ), summarise( scan( $untyped ) ) );

$nullable_prop = "<?php\nclass T { public ?int \$value; }\n\n\$t = new T();\n\$t->value = null;\n";
check( 'null into a nullable property is fine', array() === scan( $nullable_prop ), summarise( scan( $nullable_prop ) ) );

echo "\n=== Classes it must not vouch for ===\n";

/*
 * This is the group that matters. Sweeping WordPress core produced 128 findings
 * of exactly this shape before they were understood, and every one of them was
 * correct code — a base class calling a method its subclasses supply. If the
 * full set of a class's members cannot be read from this file, nothing about
 * its members can be claimed.
 */
$subclass_supplies = <<<'PHP'
<?php
class Reader {
	public function readint32() {
		return $this->read( 4 );
	}
}

class FileReader extends Reader {
	public function read( $bytes ) {
		return $bytes;
	}
}

$r = new FileReader();
$r->readint32();
PHP;
check( '$this->method() is never checked — it may be a subclass', array() === scan( $subclass_supplies ), summarise( scan( $subclass_supplies ) ) );

$inherits = <<<'PHP'
<?php
class Mine extends WPDCE_Fixture_Thing {
	public function run() {
		return 1;
	}
}

$m = new Mine();
$m->inherited_from_the_parent();
PHP;
check( 'a class that extends anything is left alone', array() === scan( $inherits ), summarise( scan( $inherits ) ) );

$implements = "<?php\ninterface I { public function a(); }\nclass C implements I { public function a() { return 1; } }\n\n\$c = new C();\n\$c->b();\n";
check( 'so is one that implements an interface', array() === scan( $implements ), summarise( scan( $implements ) ) );

$trait = "<?php\ntrait Helper { public function help() { return 1; } }\nclass C { use Helper; public function a() { return 1; } }\n\n\$c = new C();\n\$c->help();\n";
check( 'and one that uses a trait', array() === scan( $trait ), summarise( scan( $trait ) ) );

$magic_call = "<?php\nclass C {\n\tpublic function __call( \$name, \$args ) { return 1; }\n}\n\n\$c = new C();\n\$c->anything_at_all();\n";
check( '__call answers for methods nobody declared', array() === scan( $magic_call ), summarise( scan( $magic_call ) ) );

$magic_static = "<?php\nclass C {\n\tpublic static function __callStatic( \$name, \$args ) { return 1; }\n}\n\nC::anything_at_all();\n";
check( '__callStatic does the same for static calls', array() === scan( $magic_static ), summarise( scan( $magic_static ) ) );

$magic_set = "<?php\nclass C {\n\tpublic int \$value;\n\tpublic function __set( \$name, \$v ) {}\n}\n\n\$c = new C();\n\$c->value = \"invalid\";\n";
check( '__set does the same for properties', array() === scan( $magic_set ), summarise( scan( $magic_set ) ) );

$unknown_class = "<?php\n\$thing = new WPDCE_Fixture_Thing();\n\$thing->not_a_real_method();\n";
check( 'a class declared elsewhere is not judged', array() === scan( $unknown_class ), summarise( scan( $unknown_class ) ) );

$inside_class = <<<'PHP'
<?php
class Base {
	public function run() {
		return 1;
	}
}

class Child extends Base {
	public function go() {
		return Base::run();
	}
}
PHP;
check( 'Class::method() written inside a class is left alone', array() === scan( $inside_class ), summarise( scan( $inside_class ) ) );

$abstract_declared = "<?php\nabstract class A {\n\tabstract public function later();\n\tpublic function now() { return 1; }\n}\n";
$findings = scan( $abstract_declared );
check( 'an abstract declaration does not swallow the next brace', array() === $findings, summarise( $findings ) );

echo "\n=== Return types, where PHP is not strict and that is the difficulty ===\n";

/*
 * PHP coerces between scalars by default, so comparing type names would be
 * wrong far more often than it was right:
 *
 *     function f(): int { return "5"; }        // returns int(5). Fine.
 *     function f(): string { return 5; }       // returns "5". Fine.
 *     function f(): int { return "five"; }     // TypeError. Site down.
 *
 * Every "must still save" case below is a real coercion PHP performs, checked
 * against the real interpreter before it was written down.
 */
$type_error = <<<'PHP'
<?php
function test_type_error(): int {
    return "invalid integer";
}

test_type_error();
PHP;
$findings = scan( $type_error );
check( 'a string that cannot become an int is caught', $findings && 'fatal' === $findings[0]['severity'], summarise( $findings ) );
check(
	'and reads the way PHP reports it',
	$findings && false !== strpos( $findings[0]['message'], 'test_type_error(): Return value must be of type int, string returned' ),
	$findings ? $findings[0]['message'] : ''
);
check( 'pointing at the return, not the declaration', $findings && 3 === $findings[0]['line'], $findings ? 'line ' . $findings[0]['line'] : '' );

$uncalled_type_error = "<?php\nfunction test_type_error(): int {\n\treturn \"invalid integer\";\n}\n";
$findings            = scan( $uncalled_type_error );
check( 'uncalled, it is only a warning', $findings && 'warning' === $findings[0]['severity'], summarise( $findings ) );

check( 'a numeric string is a valid int',      array() === scan( '<?php function f(): int { return "5"; } f();' ), summarise( scan( '<?php function f(): int { return "5"; } f();' ) ) );
check( 'an int is a valid string',             array() === scan( '<?php function f(): string { return 5; } f();' ), summarise( scan( '<?php function f(): string { return 5; } f();' ) ) );
check( 'an int is a valid float',              array() === scan( '<?php function f(): float { return 1; } f();' ), summarise( scan( '<?php function f(): float { return 1; } f();' ) ) );
check( 'an int is a valid bool',               array() === scan( '<?php function f(): bool { return 1; } f();' ), summarise( scan( '<?php function f(): bool { return 1; } f();' ) ) );
check( 'a float is a valid string',            array() === scan( '<?php function f(): string { return 1.5; } f();' ), summarise( scan( '<?php function f(): string { return 1.5; } f();' ) ) );
check( 'null from a nullable type',            array() === scan( '<?php function f(): ?int { return null; } f();' ), summarise( scan( '<?php function f(): ?int { return null; } f();' ) ) );
check( 'a leading-numeric string is not fatal', array() === scan( '<?php function f(): int { return "5 apples"; } f();' ), summarise( scan( '<?php function f(): int { return "5 apples"; } f();' ) ) );
check( 'the type it actually declares',        array() === scan( '<?php function f(): int { return 5; } f();' ), summarise( scan( '<?php function f(): int { return 5; } f();' ) ) );

$findings = scan( '<?php function f(): int { return null; } f();' );
check( 'null from a type that is not nullable is caught', $findings && 'return' === $findings[0]['kind'], summarise( $findings ) );

$findings = scan( '<?php function f(): array { return "x"; } f();' );
check( 'a string is never an array', $findings && 'fatal' === $findings[0]['severity'], summarise( $findings ) );

$findings = scan( '<?php function f(): int { return array( 1 ); } f();' );
check( 'and an array is never an int', $findings && 'fatal' === $findings[0]['severity'], summarise( $findings ) );

$findings = scan( '<?php function f(): int { return [ 1, 2 ]; } f();' );
check( 'in either spelling', $findings && 'fatal' === $findings[0]['severity'], summarise( $findings ) );

$void = '<?php function f(): void { return 5; }';
$findings = scan( $void );
check( 'returning a value from void is fatal even uncalled', $findings && 'fatal' === $findings[0]['severity'], summarise( $findings ) );
check(
	'because PHP refuses it at compile time',
	$findings && false !== strpos( $findings[0]['hint'], 'compiles the file' ),
	$findings ? $findings[0]['hint'] : ''
);

$strict = "<?php\ndeclare(strict_types=1);\n\nfunction f(): int {\n\treturn \"5\";\n}\n\nf();\n";
$findings = scan( $strict );
check( 'strict_types makes the numeric string an error again', $findings && 'fatal' === $findings[0]['severity'], summarise( $findings ) );

$method_type = <<<'PHP'
<?php
class Thing {
	public function count(): int {
		return "not a number";
	}
}

$thing = new Thing();
$thing->count();
PHP;
$findings = scan( $method_type );
check( 'a method is checked the same way', $findings && 'fatal' === $findings[0]['severity'], summarise( $findings ) );

echo "\n=== Return types it must not guess about ===\n";

check( 'a union type is left alone',      array() === scan( '<?php function f(): int|string { return "x"; } f();' ), summarise( scan( '<?php function f(): int|string { return "x"; } f();' ) ) );
check( 'a class return type is left alone', array() === scan( '<?php function f(): WPDCE_Fixture_Thing { return null; } f();' ), summarise( scan( '<?php function f(): WPDCE_Fixture_Thing { return null; } f();' ) ) );
check( 'mixed is left alone',             array() === scan( '<?php function f(): mixed { return "x"; } f();' ), summarise( scan( '<?php function f(): mixed { return "x"; } f();' ) ) );
check( 'no declared type, nothing to check', array() === scan( '<?php function f() { return "x"; } f();' ), summarise( scan( '<?php function f() { return "x"; } f();' ) ) );

$expression = '<?php function f(): int { return $count + 1; } f();';
check( 'a value that is not a literal is not guessed at', array() === scan( $expression ), summarise( scan( $expression ) ) );

$call = '<?php function f(): int { return strlen( "abc" ); } f();';
check( 'nor is the result of a call', array() === scan( $call ), summarise( scan( $call ) ) );

/*
 * A return inside a condition may be a branch that is never taken, and the
 * check does not reason about branches. Skipping them entirely is the
 * conservative choice, and conservative is the right direction here.
 */
$branch = <<<'PHP'
<?php
function f(): int {
	if ( something() ) {
		return "not a number";
	}

	return 1;
}

f();
PHP;
check( 'a return inside a branch is not judged', null === finding_for( scan( $branch ), 'f():4' ), summarise( scan( $branch ) ) );

echo "\n=== Must not be mentioned at all ===\n";

check( 'a function that exists', array() === scan( '<?php wpdce_fixture_helper();' ), summarise( scan( '<?php wpdce_fixture_helper();' ) ) );
check( 'a built-in function', array() === scan( '<?php echo strtoupper( "x" );' ), summarise( scan( '<?php echo strtoupper( "x" );' ) ) );
check( 'a class that exists', array() === scan( '<?php WPDCE_Fixture_Thing::go();' ), summarise( scan( '<?php WPDCE_Fixture_Thing::go();' ) ) );
check( 'new on a class that exists', array() === scan( '<?php $t = new WPDCE_Fixture_Thing();' ), summarise( scan( '<?php $t = new WPDCE_Fixture_Thing();' ) ) );

$self_declared = <<<'PHP'
<?php
my_own_function();

function my_own_function() {
	return 1;
}
PHP;
check( 'a function declared lower down in the same file', array() === scan( $self_declared ), summarise( scan( $self_declared ) ) );

$guarded = <<<'PHP'
<?php
if ( function_exists( 'acf_add_options_page' ) ) {
	acf_add_options_page();
}
PHP;
check( 'a call the author guarded with function_exists', array() === scan( $guarded ), summarise( scan( $guarded ) ) );

$guarded_class = <<<'PHP'
<?php
if ( class_exists( 'WooCommerce' ) ) {
	$shop = new WooCommerce();
}
PHP;
check( 'a class the author guarded with class_exists', array() === scan( $guarded_class ), summarise( scan( $guarded_class ) ) );

$conditional = <<<'PHP'
<?php
if ( ! function_exists( 'my_theme_setup' ) ) {
	function my_theme_setup() {
		my_theme_setup_helper();
	}
}

function my_theme_setup_helper() {
	return 1;
}
PHP;
check( 'the function_exists declaration idiom', array() === scan( $conditional ), summarise( scan( $conditional ) ) );

$constructs = <<<'PHP'
<?php
$a = array( 1, 2 );
if ( isset( $a[0] ) && ! empty( $a ) ) {
	list( $x, $y ) = $a;
	unset( $a );
	print( $x );
}
PHP;
check( 'language constructs are not function calls', array() === scan( $constructs ), summarise( scan( $constructs ) ) );

$methods = <<<'PHP'
<?php
$thing = new WPDCE_Fixture_Thing();
$thing->whatever_method();
$thing->chained()->deeper();
PHP;
check( 'method calls are never resolved as functions', array() === scan( $methods ), summarise( scan( $methods ) ) );

$dynamic = <<<'PHP'
<?php
$callback = 'something_or_other';
$callback();
$class = 'Some_Class';
$made = new $class();
PHP;
check( 'variable functions and classes are left alone', array() === scan( $dynamic ), summarise( scan( $dynamic ) ) );

$strings = <<<'PHP'
<?php
$sql = "SELECT * FROM t WHERE a = {$x} AND b = 1";
$note = 'undefined_function_name_in_a_string()';
PHP;
check( 'names inside strings are not calls', array() === scan( $strings ), summarise( scan( $strings ) ) );

$self = <<<'PHP'
<?php
class Mine extends WPDCE_Fixture_Thing {
	const NAME = 'x';

	public function run() {
		return self::NAME . static::class . parent::go();
	}
}
PHP;
check( 'self, static and parent are not classes to look up', array() === scan( $self ), summarise( scan( $self ) ) );

$template = <<<'PHP'
<?php
/* Template Name: Thing */
get_header();
?>
<div class="wrap">
	<?php echo esc_html( 'hello' ); ?>
</div>
<?php
get_footer();
PHP;
$findings = scan( $template );
check(
	'a template calling core functions that exist here is quiet',
	null === finding_for( $findings, 'esc_html' ),
	summarise( $findings )
);

echo "\n=== Reporting ===\n";

$repeated = <<<'PHP'
<?php
undefined_repeated();
undefined_repeated();
undefined_repeated();
PHP;
check( 'the same missing name is reported once', 1 === count( scan( $repeated ) ), summarise( scan( $repeated ) ) );

$both = <<<'PHP'
<?php
function dormant_one() {
	undefined_dormant();
}

undefined_at_top();
PHP;
$findings = scan( $both );
check( 'fatals sort above warnings', 'fatal' === $findings[0]['severity'], summarise( $findings ) );
check( 'and both are kept', 2 === count( $findings ), summarise( $findings ) );

$typo = scan( '<?php wpdce_fixture_helpr();' );
check(
	'a near-miss suggests the real name',
	$typo && false !== strpos( $typo[0]['hint'], 'Did you mean' ),
	$typo ? $typo[0]['hint'] : 'nothing reported'
);

echo "\n=== Through the editor's own verdict ===\n";

/*
 * The scan is only worth what the guard does with it, and the guard has three
 * possible answers where it used to have two. These check the wiring rather
 * than the analysis: that a fatal reaches the browser as a refusal, that a
 * warning reaches it as a warning with the save still available, and that the
 * checks that came before this one still take precedence — a file that does not
 * parse must be reported as a parse error, not as a pile of missing names.
 */
require_once dirname( __DIR__ ) . '/includes/class-wpdce-editor.php';

$path = '/var/www/wp-content/themes/x/functions.php';

$verdict = WPDCE_Editor::inspect( $hooked, $path );
check( 'a certain fatal comes back as a refusal', empty( $verdict['ok'] ), summarise_verdict( $verdict ) );
check( 'carrying the code that caused it', ! empty( $verdict['excerpt'] ), summarise_verdict( $verdict ) );

$verdict = WPDCE_Editor::inspect( $dormant, $path );
check( 'a maybe is not a refusal', ! empty( $verdict['ok'] ), summarise_verdict( $verdict ) );
check( 'but it is still reported', 1 === count( $verdict['warnings'] ), summarise_verdict( $verdict ) );
check( 'with the lines attached', ! empty( $verdict['warnings'][0]['excerpt'] ), summarise_verdict( $verdict ) );

$verdict = WPDCE_Editor::inspect( "<?php\nfunction broken( {\n", $path );
check(
	'a file that does not parse is still a parse error first',
	empty( $verdict['ok'] ) && false !== strpos( $verdict['label'], 'Parse' ),
	summarise_verdict( $verdict )
);

$verdict = WPDCE_Editor::inspect( 'body { color: undefined_thing(); }', '/var/www/wp-content/themes/x/style.css' );
check( 'a stylesheet is never scanned', ! empty( $verdict['ok'] ) && ! $verdict['warnings'], summarise_verdict( $verdict ) );

$GLOBALS['wpdce_state']['options']['wpdce_settings'] = array( 'editor_runtime' => 0 );
WPDCE_Settings::update( array( 'capture' => 1, 'editor_guard' => 1, 'editor_runtime' => 0 ) );

$verdict = WPDCE_Editor::inspect( $hooked, $path );
check( 'and the whole check can be switched off', ! empty( $verdict['ok'] ), summarise_verdict( $verdict ) );

WPDCE_Settings::update( array( 'capture' => 1, 'editor_guard' => 1, 'editor_runtime' => 1 ) );

echo "\n=== Files it should not slow down ===\n";

$big   = "<?php\n" . str_repeat( "\$x = strlen( 'abc' );\n", 4000 );
$start = microtime( true );
scan( $big );
$took = microtime( true ) - $start;

check( 'a 4,000-line file is checked in well under a second', $took < 1.0, sprintf( '%.3fs', $took ) );

printf( "\n----\npassed: %d   failed: %d\n", $pass, $fail );

exit( $fail > 0 ? 1 : 0 );

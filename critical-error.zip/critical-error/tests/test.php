<?php
/**
 * Tests.
 *
 * The two things that must be right: attribution (naming the wrong plugin sends
 * someone deleting innocent code) and the token gate (this endpoint prints
 * source code to unauthenticated visitors).
 *
 * @package WPD_Critical_Error
 */

if ( 'cli' !== PHP_SAPI ) {
	http_response_code( 404 );
	exit;
}

require __DIR__ . '/bootstrap.php';

$pass = 0;
$fail = 0;

/**
 * @param string   $label Name.
 * @param callable $fn    Test.
 */
function it( $label, callable $fn ) {
	global $pass, $fail;

	try {
		$fn();
		$pass++;
		printf( "  ok    %s\n", $label );
	} catch ( Throwable $e ) {
		$fail++;
		printf( "  FAIL  %s :: %s @ %s:%d\n", $label, $e->getMessage(), basename( $e->getFile() ), $e->getLine() );
	}
}

/**
 * @param bool   $condition Assertion.
 * @param string $message   Failure text.
 */
function ok( $condition, $message ) {
	if ( ! $condition ) {
		throw new RuntimeException( $message );
	}
}

wpdce_test_reset();

echo "\n=== Attribution ===\n";

it( 'names the plugin folder responsible', function () {
	$blame = WPDCE_Handler::blame( '/var/www/html/wp-content/plugins/woocommerce/includes/class-wc-cart.php' );
	ok( 'plugin' === $blame['type'], 'expected a plugin, got ' . $blame['type'] );
	ok( 'woocommerce' === $blame['slug'], 'wrong slug: ' . $blame['slug'] );
} );

it( 'names the theme responsible', function () {
	$blame = WPDCE_Handler::blame( '/var/www/html/wp-content/themes/benefitshealth/functions.php' );
	ok( 'theme' === $blame['type'], 'expected a theme, got ' . $blame['type'] );
	ok( 'benefitshealth' === $blame['name'], 'wrong theme: ' . $blame['name'] );
} );

it( 'distinguishes core from a plugin', function () {
	$blame = WPDCE_Handler::blame( '/var/www/html/wp-includes/post.php' );
	ok( 'WordPress core' === $blame['type'], 'core file misattributed to ' . $blame['type'] );
} );

it( 'recognises must-use plugins', function () {
	$blame = WPDCE_Handler::blame( '/var/www/html/wp-content/mu-plugins/loader/boot.php' );
	ok( 'must-use plugin' === $blame['type'], 'got ' . $blame['type'] );
} );

it( 'does not blame a plugin for an unrelated path', function () {
	$blame = WPDCE_Handler::blame( '/usr/share/php/something.php' );
	ok( 'unknown' === $blame['type'], 'invented an owner: ' . $blame['type'] );
} );

it( 'blames itself rather than a neighbour', function () {
	$blame = WPDCE_Handler::blame( WPDCE_DIR . 'includes/class-wpdce-log.php' );
	ok( 'self' === $blame['type'], 'got ' . $blame['type'] );
} );

echo "\n=== Source excerpt ===\n";

it( 'quotes the failing line and its neighbours', function () {
	$file = sys_get_temp_dir() . '/wpdce-excerpt.php';
	file_put_contents( $file, implode( "\n", array_map( static function ( $n ) {
		return "line $n";
	}, range( 1, 40 ) ) ) );

	$excerpt = WPDCE_Handler::excerpt( $file, 20, 3 );
	unlink( $file );

	ok( isset( $excerpt[20] ), 'the failing line itself is missing' );
	ok( 'line 20' === $excerpt[20], 'wrong content: ' . $excerpt[20] );
	ok( isset( $excerpt[17] ) && isset( $excerpt[23] ), 'context lines missing' );
	ok( ! isset( $excerpt[16] ), 'radius not respected' );
} );

it( 'returns nothing for a file it cannot read', function () {
	ok( array() === WPDCE_Handler::excerpt( '/nope/missing.php', 10 ), 'invented an excerpt' );
} );

echo "\n=== Storage ===\n";

it( 'records an error and reads it back', function () {
	wpdce_test_reset();

	WPDCE_Log::record( array(
		'type' => E_ERROR, 'label' => 'Fatal error', 'fatal' => true,
		'message' => 'Call to undefined function foo()',
		'file' => '/var/www/wp-content/plugins/x/y.php', 'relative' => 'wp-content/plugins/x/y.php',
		'line' => 12, 'blame' => array( 'type' => 'plugin', 'name' => 'x', 'slug' => 'x' ),
		'excerpt' => array(), 'trace' => array(), 'request' => array( 'uri' => '/', 'method' => 'GET' ),
		'php' => PHP_VERSION,
	) );

	ok( 1 === WPDCE_Log::total_count(), 'nothing stored' );
	ok( 1 === WPDCE_Log::fatal_count(), 'not counted as fatal' );
} );

it( 'folds repeats into a count instead of flooding', function () {
	wpdce_test_reset();

	$entry = array(
		'type' => E_WARNING, 'label' => 'Warning', 'fatal' => false,
		'message' => 'Undefined array key "id"',
		'file' => '/var/www/wp-content/plugins/x/y.php', 'relative' => 'x/y.php',
		'line' => 44, 'blame' => array( 'type' => 'plugin', 'name' => 'x', 'slug' => 'x' ),
		'excerpt' => array(), 'trace' => array(), 'request' => array( 'uri' => '/a', 'method' => 'GET' ),
		'php' => PHP_VERSION,
	);

	for ( $i = 0; $i < 50; $i++ ) {
		WPDCE_Log::record( $entry );
	}

	ok( 1 === WPDCE_Log::total_count(), 'repeats were stored separately: ' . WPDCE_Log::total_count() );

	$all = WPDCE_Log::all();
	$row = reset( $all );

	ok( 50 === (int) $row['count'], 'count wrong: ' . $row['count'] );
} );

it( 'keeps different errors apart', function () {
	wpdce_test_reset();

	foreach ( array( 10, 20, 30 ) as $line ) {
		WPDCE_Log::record( array(
			'type' => E_WARNING, 'label' => 'Warning', 'fatal' => false, 'message' => 'msg',
			'file' => '/f.php', 'relative' => 'f.php', 'line' => $line,
			'blame' => array( 'type' => 'plugin', 'name' => 'x', 'slug' => 'x' ),
			'excerpt' => array(), 'trace' => array(), 'request' => array( 'uri' => '/', 'method' => 'GET' ),
			'php' => PHP_VERSION,
		) );
	}

	ok( 3 === WPDCE_Log::total_count(), 'distinct errors merged: ' . WPDCE_Log::total_count() );
} );

it( 'clear() empties the log', function () {
	WPDCE_Log::clear();
	ok( 0 === WPDCE_Log::total_count(), 'log survived clear()' );
} );

it( 'protects its own storage directory', function () {
	$dir = WPDCE_Log::dir();
	ok( '' !== $dir, 'no storage directory' );
	ok( file_exists( $dir . '.htaccess' ), 'no deny rule written' );
	ok( file_exists( $dir . 'index.php' ), 'directory is browsable' );
} );

echo "\n=== Recovery token ===\n";

it( 'generates a long random token', function () {
	wpdce_test_reset();

	$a = WPDCE_Report::regenerate();
	$b = WPDCE_Report::regenerate();

	ok( 64 === strlen( $a ), 'token too short: ' . strlen( $a ) );
	ok( ctype_xdigit( $a ), 'token is not hex' );
	ok( $a !== $b, 'regenerate returned the same token twice' );
} );

it( 'accepts the right token and refuses everything else', function () {
	wpdce_test_reset();

	$token = WPDCE_Report::regenerate();

	ok( WPDCE_Report::verify( $token ), 'the correct token was refused' );
	ok( ! WPDCE_Report::verify( '' ), 'empty token accepted' );
	ok( ! WPDCE_Report::verify( 'short' ), 'short token accepted' );
	ok( ! WPDCE_Report::verify( str_repeat( 'a', 64 ) ), 'wrong token accepted' );
	ok( ! WPDCE_Report::verify( substr( $token, 0, 63 ) ), 'truncated token accepted' );
	ok( ! WPDCE_Report::verify( $token . 'x' ), 'extended token accepted' );
} );

it( 'regenerating invalidates the previous link', function () {
	wpdce_test_reset();

	$old = WPDCE_Report::regenerate();
	WPDCE_Report::regenerate();

	ok( ! WPDCE_Report::verify( $old ), 'the old token still works' );
} );

/*
 * The token has a chicken-and-egg problem that is worth stating plainly: you
 * get it from the dashboard, and the dashboard is what a critical error takes
 * away. These cover the two ways out of that — a link that needs no token
 * because it checks your login cookie instead, and both links being put into
 * the email WordPress already sends when a site goes down.
 */
echo "\n=== Getting back in when nothing was saved in advance ===\n";

it( 'the token-free link carries no token', function () {
	wpdce_test_reset();

	$url = WPDCE_Report::login_url();

	ok( false !== strpos( $url, 'wpdce-report=1' ), 'the query var is missing: ' . $url );
	ok( false === strpos( $url, WPDCE_Report::regenerate() ), 'the token leaked into the token-free link' );
} );

it( 'reading the token never creates one', function () {
	wpdce_test_reset();

	// This is read during a crash. A request that is already failing must not
	// be asked to write to the database on its way out.
	ok( '' === WPDCE_Report::token_if_any(), 'reported a token where there was none' );
	ok( '' === get_option( 'wpdce_report_token', '' ), 'reading the token created one' );

	$token = WPDCE_Report::regenerate();

	ok( WPDCE_Report::token_if_any() === $token, 'did not return the stored token' );
} );

it( 'the links go into the email WordPress already sends', function () {
	wpdce_test_reset();

	$token = WPDCE_Report::regenerate();
	$email = WPDCE_Report::add_links_to_email( array( 'message' => 'Core says the site is broken.' ) );

	ok( false !== strpos( $email['message'], 'Core says the site is broken.' ), 'core\'s own text was lost' );
	ok( false !== strpos( $email['message'], $token ), 'the recovery link is missing' );
	ok( false !== strpos( $email['message'], 'wpdce-report=1' ), 'the token-free link is missing' );
} );

it( 'and the email is left alone when there is nothing to add to', function () {
	wpdce_test_reset();

	// Whatever else happens, a crash handler must not break the message that
	// tells somebody their site has crashed.
	ok( array() === WPDCE_Report::add_links_to_email( array() ), 'invented a message' );
	ok( 'not an array' === WPDCE_Report::add_links_to_email( 'not an array' ), 'mangled an unexpected value' );

	$email = WPDCE_Report::add_links_to_email( array( 'message' => 'x' ) );

	ok( false !== strpos( $email['message'], 'wpdce-report=1' ), 'the token-free link should not need a token' );
} );

it( 'a wp-config constant is accepted without the database', function () {
	define( 'WPDCE_RECOVERY_KEY', str_repeat( 'k', 40 ) );

	ok( WPDCE_Report::verify( str_repeat( 'k', 40 ) ), 'the constant token was refused' );
	ok( WPDCE_Report::token() === str_repeat( 'k', 40 ), 'the constant should win over the option' );
} );

echo "\n=== Self-test endpoint ===\n";

it( 'the crash endpoint ignores a request with no token', function () {
	wpdce_test_reset();
	$_GET = array();

	// If this were unguarded it would call an undefined function and kill the
	// test run, so simply reaching the next line is the assertion.
	WPDCE_Handler::instance()->maybe_self_destruct();

	ok( true, 'unreachable' );
} );

it( 'the crash endpoint ignores a wrong token', function () {
	wpdce_test_reset();

	set_transient( 'wpdce_selftest', str_repeat( 'a', 32 ) );
	$_GET = array( 'wpdce-selftest' => str_repeat( 'b', 32 ) );

	WPDCE_Handler::instance()->maybe_self_destruct();

	ok( false !== get_transient( 'wpdce_selftest' ), 'a wrong guess consumed the real token' );

	$_GET = array();
} );

it( 'the crash endpoint ignores a token when none was issued', function () {
	wpdce_test_reset();

	delete_transient( 'wpdce_selftest' );
	$_GET = array( 'wpdce-selftest' => str_repeat( 'c', 32 ) );

	WPDCE_Handler::instance()->maybe_self_destruct();

	ok( true, 'unreachable' );

	$_GET = array();
} );

echo "\n=== Settings ===\n";

it( 'captures fatals by default and notices only on request', function () {
	wpdce_test_reset();

	ok( WPDCE_Settings::enabled( 'capture' ), 'capture should default to on' );
	ok( ! WPDCE_Settings::enabled( 'capture_notices' ), 'notices should default to off' );
} );

it( 'settings survive a round trip', function () {
	wpdce_test_reset();

	WPDCE_Settings::update( array( 'capture' => 1, 'capture_notices' => 1 ) );
	ok( WPDCE_Settings::enabled( 'capture_notices' ), 'notices did not turn on' );

	WPDCE_Settings::update( array( 'capture' => 0, 'capture_notices' => 0 ) );
	ok( ! WPDCE_Settings::enabled( 'capture' ), 'capture did not turn off' );
} );

echo "\n";
printf( "%d passed, %d failed\n", $pass, $fail );

wpdce_test_reset();

exit( $fail > 0 ? 1 : 0 );

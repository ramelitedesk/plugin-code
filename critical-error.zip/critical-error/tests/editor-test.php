<?php
/**
 * The file-editor guard.
 *
 * Two ways for this feature to be worse than useless, and the cases below are
 * weighted towards both:
 *
 *   1. A false negative lets a fatal through — but WordPress's own loopback
 *      check is still behind it, so the cost is that this added nothing.
 *   2. A FALSE POSITIVE refuses to save code that was perfectly fine. That is
 *      the one that matters. It cannot be worked around from the editor, it
 *      makes the screen useless, and the natural response is to switch the
 *      whole plugin off. So every "this must still save" case here is as
 *      important as the ones that catch a crash.
 *
 * @package WPD_Critical_Error
 */

if ( 'cli' !== PHP_SAPI ) {
	http_response_code( 404 );
	exit;
}

require __DIR__ . '/bootstrap.php';

$pass = 0;
$fail = 0;

/**
 * @param string $label  Assertion.
 * @param bool   $ok     Result.
 * @param string $detail Shown on failure.
 */
function check( $label, $ok, $detail = '' ) {
	global $pass, $fail;

	if ( $ok ) {
		$pass++;
		printf( "  ok    %s\n", $label );
		return;
	}

	$fail++;
	printf( "  FAIL  %s%s\n", $label, '' !== $detail ? ' :: ' . $detail : '' );
}

/**
 * @param array $verdict From inspect().
 * @return string
 */
function summarise( array $verdict ) {
	return $verdict['ok'] ? 'saved' : $verdict['label'] . ' @ line ' . $verdict['line'] . ' — ' . $verdict['message'];
}

$sandbox = sys_get_temp_dir() . '/wpdce-editor-test-' . getmypid();

if ( ! is_dir( $sandbox ) ) {
	mkdir( $sandbox, 0777, true );
}

$GLOBALS['wpdce_state']['theme_dir'] = $sandbox;

/*
 * The sandbox stands in for the active theme, so that a file inside it is one
 * WordPress would load by itself — which is what makes a missing name there a
 * certainty rather than a suspicion. realpath(), because the checks compare
 * against a resolved path and Windows hands out more than one spelling of the
 * same directory.
 */
function get_stylesheet_directory() {
	return realpath( $GLOBALS['wpdce_state']['theme_dir'] );
}

function get_template_directory() {
	return get_stylesheet_directory();
}

/**
 * A save request as the editors actually make it.
 *
 * @param string $code   Submitted content.
 * @param array  $extra  Fields to add or override.
 * @return array
 */
function save_request( $code, array $extra = array() ) {
	return array_merge(
		array(
			'theme'      => 'sandbox',
			'file'       => 'functions.php',
			'newcontent' => $code,
			'action'     => 'update',
			'nonce'      => 'irrelevant-here',
		),
		$extra
	);
}

/* ================================================================ *
 * Code that must be refused
 * ================================================================ */

echo "\n=== Syntax that would white-screen the site ===\n";

$missing_semicolon = "<?php\nadd_action( 'init', 'x' );\n\$a = 1\n\$b = 2;\n";
$verdict           = WPDCE_Editor::inspect( $missing_semicolon, $sandbox . '/functions.php' );

check( 'missing semicolon is caught', ! $verdict['ok'], summarise( $verdict ) );
check( 'and points at the right line', 4 === $verdict['line'], 'line ' . $verdict['line'] );
check( 'and hands back the code to show', ! empty( $verdict['excerpt'] ) );
check( 'the marked line is in the excerpt', isset( $verdict['excerpt'][4] ) && false !== strpos( $verdict['excerpt'][4], '$b = 2;' ) );

$unclosed = "<?php\nfunction thing() {\n\techo 'hello';\n";
$verdict  = WPDCE_Editor::inspect( $unclosed, $sandbox . '/functions.php' );
check( 'an unclosed brace is caught', ! $verdict['ok'], summarise( $verdict ) );

// Pasting a snippet that includes its own opening tag into an existing file.
// This is the single commonest way the theme editor kills a site.
$stray_tag = "<?php\nadd_filter( 'the_content', 'x' );\n\n<?php\nfunction y() { return 1; }\n";
$verdict   = WPDCE_Editor::inspect( $stray_tag, $sandbox . '/functions.php' );
check( 'a stray <?php from a pasted snippet is caught', ! $verdict['ok'], summarise( $verdict ) );

$bad_string = "<?php\n\$x = 'unterminated;\n\$y = 2;\n";
$verdict    = WPDCE_Editor::inspect( $bad_string, $sandbox . '/functions.php' );
check( 'an unterminated string is caught', ! $verdict['ok'], summarise( $verdict ) );

echo "\n=== Redeclaring something that already exists ===\n";

$twice   = "<?php\nfunction wpdce_demo_helper() {\n\treturn 1;\n}\n\nfunction wpdce_demo_helper() {\n\treturn 2;\n}\n";
$verdict = WPDCE_Editor::inspect( $twice, $sandbox . '/functions.php' );

check( 'the same snippet pasted twice is caught', ! $verdict['ok'], summarise( $verdict ) );
check( 'and points at the second copy', 6 === $verdict['line'], 'line ' . $verdict['line'] );
check( 'and names the first', false !== strpos( $verdict['message'], 'line 2' ), $verdict['message'] );

$class_twice = "<?php\nclass WPDCE_Demo_Thing {}\nclass WPDCE_Demo_Thing {}\n";
$verdict     = WPDCE_Editor::inspect( $class_twice, $sandbox . '/functions.php' );
check( 'a class declared twice is caught', ! $verdict['ok'], summarise( $verdict ) );

// A function that genuinely exists elsewhere in this process.
$owner = $sandbox . '/owner.php';
file_put_contents( $owner, "<?php\nfunction wpdce_owned_by_another_file() { return 1; }\n" );
require $owner;

$editing_elsewhere = "<?php\nfunction wpdce_owned_by_another_file() {\n\treturn 2;\n}\n";
$verdict           = WPDCE_Editor::inspect( $editing_elsewhere, $sandbox . '/functions.php' );

check( 'redeclaring a function owned by another file is caught', ! $verdict['ok'], summarise( $verdict ) );
check( 'and says where the original lives', false !== strpos( $verdict['message'], 'owner.php' ), $verdict['message'] );

$redeclare_builtin = "<?php\nfunction str_repeat( \$a, \$b ) {\n\treturn '';\n}\n";
$verdict           = WPDCE_Editor::inspect( $redeclare_builtin, $sandbox . '/functions.php' );
check( 'redeclaring a PHP built-in is caught', ! $verdict['ok'], summarise( $verdict ) );

/* ================================================================ *
 * Code that must still save
 * ================================================================ */

echo "\n=== Perfectly good code that must NOT be blocked ===\n";

$fine    = "<?php\n/**\n * Theme functions.\n */\nfunction wpdce_unique_setup_fn() {\n\tadd_theme_support( 'title-tag' );\n}\nadd_action( 'after_setup_theme', 'wpdce_unique_setup_fn' );\n";
$verdict = WPDCE_Editor::inspect( $fine, $sandbox . '/functions.php' );
check( 'ordinary theme code saves', $verdict['ok'], summarise( $verdict ) );

// Re-saving the file that already declares the function. If this were flagged,
// every second save of functions.php would be refused.
$verdict = WPDCE_Editor::inspect( "<?php\nfunction wpdce_owned_by_another_file() { return 1; }\n", $owner );
check( 'a file re-saving its own function is not flagged', $verdict['ok'], summarise( $verdict ) );

// The correct way to write a redeclarable helper. Flagging this would be the
// worst false positive available, because it is the recommended pattern.
$guarded  = "<?php\nif ( ! function_exists( 'wpdce_owned_by_another_file' ) ) {\n";
$guarded .= "\tfunction wpdce_owned_by_another_file() { return 2; }\n}\n";
$verdict  = WPDCE_Editor::inspect( $guarded, $sandbox . '/functions.php' );
check( 'a function_exists() guard is not flagged', $verdict['ok'], summarise( $verdict ) );

$closures = "<?php\n\$a = function () { return 1; };\n\$b = function () { return 2; };\n\$c = fn( \$x ) => \$x;\n";
$verdict  = WPDCE_Editor::inspect( $closures, $sandbox . '/functions.php' );
check( 'anonymous functions are not declarations', $verdict['ok'], summarise( $verdict ) );

$anon_class = "<?php\n\$a = new class {};\n\$b = new class {};\n";
$verdict    = WPDCE_Editor::inspect( $anon_class, $sandbox . '/functions.php' );
check( 'anonymous classes are not declarations', $verdict['ok'], summarise( $verdict ) );

$class_constant = "<?php\n\$a = WPDCE_Demo_Thing::class;\n\$b = WPDCE_Demo_Thing::class;\n";
$verdict        = WPDCE_Editor::inspect( $class_constant, $sandbox . '/functions.php' );
check( '::class is not a class declaration', $verdict['ok'], summarise( $verdict ) );

$methods = "<?php\nclass WPDCE_Unique_Holder {\n\tpublic function run() {}\n\tpublic function stop() {}\n}\n";
$verdict = WPDCE_Editor::inspect( $methods, $sandbox . '/functions.php' );
check( 'methods are not top-level functions', $verdict['ok'], summarise( $verdict ) );

/*
 * Braces inside strings and heredocs. If the depth counter were fooled by these
 * the tracker would drift and later declarations would be misjudged in both
 * directions — this is the case that makes a regex approach unworkable.
 */
$braces  = "<?php\n\$name = 'x';\n\$a = \"a {\$name} brace\";\n\$b = '{ unbalanced';\n";
$braces .= "\$c = <<<TXT\n  { \$name } and } here\nTXT;\n";
$braces .= "// a comment with } in it\n";
$braces .= "function wpdce_after_the_braces() { return 1; }\n";
$verdict = WPDCE_Editor::inspect( $braces, $sandbox . '/functions.php' );
check( 'braces in strings, heredocs and comments do not confuse it', $verdict['ok'], summarise( $verdict ) );

$conditional = "<?php\nif ( is_admin() ) {\n\tfunction wpdce_owned_by_another_file() { return 3; }\n}\n";
$verdict     = WPDCE_Editor::inspect( $conditional, $sandbox . '/functions.php' );
check( 'a conditionally declared function is not flagged', $verdict['ok'], summarise( $verdict ) );

/*
 * The same guard written with a colon instead of a brace. Every starter theme
 * derived from _s ships template-tags.php full of these, so a brace-only depth
 * counter refuses to save one of the commonest files on the internet — and
 * refuses it with "you are redeclaring wp_body_open", about the very shim that
 * exists to avoid redeclaring it.
 */
$alternative  = "<?php\nif ( ! function_exists( 'wpdce_shimmed' ) ) :\n";
$alternative .= "\tfunction wpdce_shimmed() { return 1; }\n";
$alternative .= "endif;\n";
$verdict      = WPDCE_Editor::inspect( $alternative, $sandbox . '/functions.php' );
check( 'the if ( … ) : … endif; guard is not flagged', $verdict['ok'], summarise( $verdict ) );

$alt_real = "<?php\nif ( ! function_exists( 'wpdce_owned_by_another_file' ) ) :\n\tfunction wpdce_demo_helper() { return 1; }\nendif;\n";
$verdict  = WPDCE_Editor::inspect( $alt_real, $sandbox . '/functions.php' );
check( 'even when the function really does already exist', $verdict['ok'], summarise( $verdict ) );

// And the counter has to come back down, or every declaration after an
// endif; would be treated as conditional and the check would go silent.
$after_endif  = "<?php\nif ( is_admin() ) :\n\techo 'x';\nendif;\n";
$after_endif .= "function wpdce_owned_by_another_file() { return 2; }\n";
$verdict      = WPDCE_Editor::inspect( $after_endif, $sandbox . '/functions.php' );
check( 'a real redeclaration after an endif; is still caught', ! $verdict['ok'], summarise( $verdict ) );

$foreach_alt  = "<?php\nforeach ( array( 1, 2 ) as \$n ) :\n\techo \$n;\nendforeach;\n";
$foreach_alt .= "switch ( 1 ) :\n\tcase 1:\n\t\tbreak;\nendswitch;\n";
$foreach_alt .= "function wpdce_owned_by_another_file() { return 3; }\n";
$verdict      = WPDCE_Editor::inspect( $foreach_alt, $sandbox . '/functions.php' );
check( 'endforeach and endswitch balance too', ! $verdict['ok'], summarise( $verdict ) );

$ternary = "<?php\n\$a = is_admin() ? 1 : 2;\nfunction wpdce_owned_by_another_file() { return 4; }\n";
$verdict = WPDCE_Editor::inspect( $ternary, $sandbox . '/functions.php' );
check( 'a ternary colon does not open a block', ! $verdict['ok'], summarise( $verdict ) );

$template = "<?php get_header(); ?>\n<main>\n\t<h1>Hello</h1>\n</main>\n<?php get_footer(); ?>\n";
$verdict  = WPDCE_Editor::inspect( $template, $sandbox . '/page.php' );
check( 'a mixed PHP/HTML template saves', $verdict['ok'], summarise( $verdict ) );

$empty   = '';
$verdict = WPDCE_Editor::inspect( $empty, $sandbox . '/functions.php' );
check( 'an empty file saves', $verdict['ok'], summarise( $verdict ) );

echo "\n=== Files that are not PHP ===\n";

$css     = "body {\n\tcolor: red;\n}\n";
$verdict = WPDCE_Editor::inspect( $css, $sandbox . '/style.css' );
check( 'a stylesheet is never parsed as PHP', $verdict['ok'], summarise( $verdict ) );

$js      = "function a() { return 1; }\nfunction a() { return 2; }\n";
$verdict = WPDCE_Editor::inspect( $js, $sandbox . '/theme.js' );
check( 'JavaScript is never parsed as PHP', $verdict['ok'], summarise( $verdict ) );

echo "\n=== Without a resolved path ===\n";

/*
 * The declaration check needs to know which file is being edited, or it cannot
 * tell "you are re-saving this file" from a real conflict. With no path it must
 * skip that check rather than guess — but the parse check still runs, because
 * it needs nothing but the code.
 */
$verdict = WPDCE_Editor::inspect( "<?php\nfunction wpdce_owned_by_another_file() { return 9; }\n", '' );
check( 'the declaration check is skipped rather than guessed at', $verdict['ok'], summarise( $verdict ) );

$verdict = WPDCE_Editor::inspect( "<?php\n\$a = 1\n\$b = 2;\n", '' );
check( 'the parse check still runs without a path', ! $verdict['ok'], summarise( $verdict ) );

echo "\n=== The excerpt ===\n";

$long = "<?php\n";
for ( $i = 2; $i <= 40; $i++ ) {
	$long .= '// line ' . $i . "\n";
}
$long   .= "\$broken = ;\n"; // line 41
$verdict = WPDCE_Editor::inspect( $long, $sandbox . '/functions.php' );

check( 'a long file is caught', ! $verdict['ok'], summarise( $verdict ) );
check( 'the excerpt is a window, not the whole file', count( $verdict['excerpt'] ) <= 17, count( $verdict['excerpt'] ) . ' lines' );
check( 'the window is centred on the failure', isset( $verdict['excerpt'][ $verdict['line'] ] ) );
check( 'line numbers are the real ones', array_key_first( $verdict['excerpt'] ) > 1 );

$wide    = "<?php\n\$x = '" . str_repeat( 'y', 5000 ) . "'\n\$z = 1;\n";
$verdict = WPDCE_Editor::inspect( $wide, $sandbox . '/functions.php' );
$widest  = 0;

foreach ( $verdict['excerpt'] as $source ) {
	$widest = max( $widest, strlen( $source ) );
}

check( 'a very long line is truncated for display', $widest <= 410, $widest . ' chars' );

/* ================================================================ *
 * The gate that does not depend on JavaScript
 * ================================================================ */

/*
 * The browser check is the one that gives a good answer. This is the one that
 * cannot be walked around: it runs on `admin_init`, before theme-editor.php or
 * admin-ajax.php has read a byte of $_POST, and it is the only reason the
 * feature can be described as *preventing* a save rather than discouraging one.
 *
 * The refusal itself ends the request, so what is asserted here is the
 * decision — whether this request would be refused, and why.
 */
echo "\n=== Refused on the server, before anything is written ===\n";

file_put_contents( $sandbox . '/functions.php', "<?php\n// The file as it stands on disk.\n" );

$broken = "<?php\nfunction wpdce_gate_demo() {\n\techo 'x';\n";

$verdict = WPDCE_Editor::verdict_for_save( save_request( $broken ), 'theme-editor.php' );
check( 'the no-JavaScript form post is refused', null !== $verdict, 'not refused' );
check( 'and carries the code to show', $verdict && ! empty( $verdict['excerpt'] ), 'no excerpt' );

$ajax    = save_request( $broken, array( 'action' => 'edit-theme-plugin-file' ) );
$verdict = WPDCE_Editor::verdict_for_save( $ajax, 'admin-ajax.php' );
check( 'the editor\'s own Ajax save is refused too', null !== $verdict, 'not refused' );

$verdict = WPDCE_Editor::verdict_for_save( save_request( "<?php\n// nothing wrong with this\n" ), 'theme-editor.php' );
check( 'a good file is left alone', null === $verdict, 'refused a valid file' );

/*
 * The line the whole design rests on. A warning is a guess about whether code
 * runs, and refusing a save over a guess is what makes people switch a gate
 * off — so the server never blocks on one. The browser offers Save anyway, and
 * this must not make that button a lie.
 */
require_once dirname( __DIR__ ) . '/includes/class-wpdce-runtime.php';

$dormant = "<?php\nfunction wpdce_gate_dormant() {\n\twpdce_no_such_function_anywhere();\n}\n";
$verdict = WPDCE_Editor::verdict_for_save( save_request( $dormant ), 'theme-editor.php' );
check( 'a warning never blocks the save', null === $verdict, 'a warning blocked the save' );

$certain = "<?php\nwpdce_no_such_function_anywhere();\n";
$verdict = WPDCE_Editor::verdict_for_save( save_request( $certain ), 'theme-editor.php' );
check( 'a certain fatal does block it', null !== $verdict, 'let a certain fatal through' );

echo "\n=== And is not a gate on anything else ===\n";

$verdict = WPDCE_Editor::verdict_for_save( save_request( $broken ), 'options-general.php' );
check( 'another screen posting a newcontent field is ignored', null === $verdict, 'blocked an unrelated form' );

$verdict = WPDCE_Editor::verdict_for_save( array( 'theme' => 'sandbox', 'file' => 'functions.php' ), 'theme-editor.php' );
check( 'a request with no content is ignored', null === $verdict, 'blocked a request with nothing in it' );

$verdict = WPDCE_Editor::verdict_for_save( save_request( $broken, array( 'file' => '../../../wp-config.php' ) ), 'theme-editor.php' );
check( 'a traversal attempt resolves to nothing and is left to core', null === $verdict, 'engaged with a traversal path' );

$GLOBALS['wpdce_state']['can'] = false;
$verdict                       = WPDCE_Editor::verdict_for_save( save_request( $broken ), 'theme-editor.php' );
check( 'without the capability it does not answer at all', null === $verdict, 'answered without a capability' );
$GLOBALS['wpdce_state']['can'] = true;

$verdict = WPDCE_Editor::verdict_for_save( save_request( 'body { color: red }', array( 'file' => 'style.css' ) ), 'theme-editor.php' );
check( 'a stylesheet is never refused', null === $verdict, 'refused a stylesheet' );

WPDCE_Settings::update( array( 'capture' => 1, 'editor_guard' => 0, 'editor_runtime' => 1 ) );
$verdict = WPDCE_Editor::verdict_for_save( save_request( $broken ), 'theme-editor.php' );
check( 'and the whole gate can be switched off', null === $verdict, 'blocked while switched off' );
WPDCE_Settings::update( array( 'capture' => 1, 'editor_guard' => 1, 'editor_runtime' => 1 ) );

/* ------------------------------------------------------------------ */

array_map( 'unlink', glob( $sandbox . '/*' ) ?: array() );
rmdir( $sandbox );

printf( "\n----\npassed: %d   failed: %d\n", $pass, $fail );

exit( $fail > 0 ? 1 : 0 );

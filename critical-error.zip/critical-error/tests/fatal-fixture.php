<?php
/**
 * Deliberately crashes, in a subprocess, so the handler can be proved to
 * capture a real fatal rather than a simulated one.
 *
 * Run by end-to-end.php — not part of the normal suite.
 *
 * @package WPD_Critical_Error
 */

if ( 'cli' !== PHP_SAPI ) {
	http_response_code( 404 );
	exit;
}

require __DIR__ . '/bootstrap.php';

WPDCE_Handler::instance()->register();

// A warning first, to prove non-fatals are captured too and that recording one
// does not interfere with catching the fatal that follows.
$undefined = array();
// phpcs:ignore
echo $undefined['missing_key'] ?? '';
trigger_error( 'a deliberate warning', E_USER_WARNING ); // phpcs:ignore

// Now the real thing: an undefined function is the single most common cause of
// a WordPress critical error, usually after a plugin update removes an API.
wpdce_function_that_does_not_exist();

echo "UNREACHABLE\n";

<?php
/**
 * Minimal WordPress stand-in so the plugin can be exercised without a site.
 *
 * @package WPD_Critical_Error
 */

/*
 * Command line only. This file ships inside the plugin and therefore sits under
 * a web root, where it would otherwise be requestable.
 */
if ( 'cli' !== PHP_SAPI ) {
	http_response_code( 404 );
	exit;
}

define( 'ABSPATH', dirname( __DIR__ ) . '/' );

$GLOBALS['wpdce_state'] = array( 'options' => array(), 'transients' => array() );

function get_option( $key, $default = false ) {
	return array_key_exists( $key, $GLOBALS['wpdce_state']['options'] )
		? $GLOBALS['wpdce_state']['options'][ $key ]
		: $default;
}

function update_option( $key, $value, $autoload = null ) {
	$GLOBALS['wpdce_state']['options'][ $key ] = $value;
	return true;
}

function wp_json_encode( $data ) {
	return json_encode( $data );
}

function wp_unslash( $value ) {
	return is_string( $value ) ? stripslashes( $value ) : $value;
}

function home_url( $path = '/' ) {
	return 'https://example.test' . $path;
}

function add_query_arg( $key, $value, $url ) {
	return $url . ( false === strpos( $url, '?' ) ? '?' : '&' ) . rawurlencode( $key ) . '=' . rawurlencode( $value );
}

function wp_get_upload_dir() {
	$dir = sys_get_temp_dir() . '/wpdce-test-uploads';
	if ( ! is_dir( $dir ) ) {
		mkdir( $dir, 0777, true );
	}
	return array( 'basedir' => $dir );
}

function get_transient( $key ) {
	return isset( $GLOBALS['wpdce_state']['transients'][ $key ] )
		? $GLOBALS['wpdce_state']['transients'][ $key ]
		: false;
}

function set_transient( $key, $value, $ttl = 0 ) {
	$GLOBALS['wpdce_state']['transients'][ $key ] = $value;
	return true;
}

function delete_transient( $key ) {
	unset( $GLOBALS['wpdce_state']['transients'][ $key ] );
	return true;
}

function esc_html( $value ) {
	return htmlspecialchars( (string) $value, ENT_QUOTES, 'UTF-8' );
}

function human_time_diff( $from, $to = 0 ) {
	return '2 minutes';
}

function __( $text, $domain = '' ) {
	return $text;
}

function wp_normalize_path( $path ) {
	return str_replace( '\\', '/', (string) $path );
}

function add_action( $hook, $callback, $priority = 10, $args = 1 ) {
	return true;
}

/*
 * Enough of the file editors' surroundings to exercise the server-side gate:
 * the capability check it leans on, the path validation, and a theme whose
 * directory the test controls. Everything here is deliberately simple — these
 * stand in for WordPress, they are not a model of it.
 */
// WP_PLUGIN_DIR and the theme directories are deliberately NOT defined here.
// Each test file lays out the site it needs, and a layout baked in at this
// level would silently win over the one a test declares.
$GLOBALS['wpdce_state']['can']       = true;
$GLOBALS['wpdce_state']['theme_dir'] = '';

function current_user_can( $capability ) {
	return (bool) $GLOBALS['wpdce_state']['can'];
}

function validate_file( $file, $allowed = array() ) {
	$file = (string) $file;

	// The two rules that matter here: no traversal, no absolute paths.
	if ( false !== strpos( $file, '..' ) ) {
		return 1;
	}

	if ( ':' === substr( $file, 1, 1 ) ) {
		return 2;
	}

	return 0;
}

class WPDCE_Test_Theme {

	public function exists() {
		return '' !== $GLOBALS['wpdce_state']['theme_dir'];
	}

	public function get_stylesheet_directory() {
		return $GLOBALS['wpdce_state']['theme_dir'];
	}
}

function wp_get_theme( $slug = '' ) {
	return new WPDCE_Test_Theme();
}

require_once dirname( __DIR__ ) . '/includes/class-wpdce-settings.php';
require_once dirname( __DIR__ ) . '/includes/class-wpdce-log.php';
require_once dirname( __DIR__ ) . '/includes/class-wpdce-handler.php';
require_once dirname( __DIR__ ) . '/includes/class-wpdce-report.php';
require_once dirname( __DIR__ ) . '/includes/class-wpdce-editor.php';

define( 'WPDCE_DIR', dirname( __DIR__ ) . '/' );

/**
 * Start from nothing.
 */
function wpdce_test_reset() {
	$GLOBALS['wpdce_state']['options'] = array();

	WPDCE_Log::clear();

	$dir = WPDCE_Log::dir();

	foreach ( array( 'attempts.json' ) as $file ) {
		if ( $dir && file_exists( $dir . $file ) ) {
			unlink( $dir . $file );
		}
	}

	// Reset the memoised settings cache.
	$ref = new ReflectionProperty( 'WPDCE_Settings', 'cache' );
	$ref->setAccessible( true );
	$ref->setValue( null );
}

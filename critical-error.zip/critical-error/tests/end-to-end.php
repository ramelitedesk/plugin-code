<?php
/**
 * End-to-end proof.
 *
 * Every other test exercises the pieces. This one crashes a real PHP process
 * and checks that the crash was recorded — which is the only claim that
 * actually matters, and the one a unit test cannot make.
 *
 * @package WPD_Critical_Error
 */

if ( 'cli' !== PHP_SAPI ) {
	http_response_code( 404 );
	exit;
}

require __DIR__ . '/bootstrap.php';

$pass = 0;
$fail = 0;

/**
 * @param string $label   Name.
 * @param bool   $ok      Result.
 * @param string $detail  Shown on failure.
 */
function check( $label, $ok, $detail = '' ) {
	global $pass, $fail;

	if ( $ok ) {
		$pass++;
		printf( "  ok    %s\n", $label );
	} else {
		$fail++;
		printf( "  FAIL  %s%s\n", $label, $detail ? " :: $detail" : '' );
	}
}

wpdce_test_reset();

echo "\n=== A real fatal, in a real process ===\n";

$fixture = __DIR__ . '/fatal-fixture.php';
$output  = array();
$status  = 0;

exec( escapeshellarg( PHP_BINARY ) . ' ' . escapeshellarg( $fixture ) . ' 2>&1', $output, $status );

check( 'the fixture process died as intended', 0 !== $status, "exit status was $status" );
check( 'execution stopped at the fatal', false === strpos( implode( "\n", $output ), 'UNREACHABLE' ) );

// The subprocess wrote the log; read it fresh.
$ref = new ReflectionProperty( 'WPDCE_Log', 'cache' );
$ref->setAccessible( true );
$ref->setValue( null );

$entries = WPDCE_Log::all();
$fatals  = WPDCE_Log::recent( true );

check( 'something was recorded', ! empty( $entries ), 'the log is empty' );
check( 'the fatal was recorded', ! empty( $fatals ), 'no fatal in the log' );

if ( $fatals ) {
	$fatal = reset( $fatals );

	check(
		'it names the undefined function',
		false !== stripos( $fatal['message'], 'wpdce_function_that_does_not_exist' ),
		$fatal['message']
	);
	check(
		'it names the file that crashed',
		false !== stripos( $fatal['file'], 'fatal-fixture.php' ),
		$fatal['file']
	);
	check(
		'it records a plausible line number',
		$fatal['line'] > 0,
		'line ' . $fatal['line']
	);
	check(
		'it quotes the failing line of source',
		isset( $fatal['excerpt'][ $fatal['line'] ] )
			&& false !== stripos( $fatal['excerpt'][ $fatal['line'] ], 'wpdce_function_that_does_not_exist' ),
		'excerpt did not contain the failing call'
	);
	check( 'it is flagged as fatal', ! empty( $fatal['fatal'] ) );
}

$warnings = array_filter(
	$entries,
	static function ( $e ) {
		return empty( $e['fatal'] );
	}
);

check( 'the earlier warning was captured too', ! empty( $warnings ), 'no non-fatal entries' );

echo "\n";
printf( "%d passed, %d failed\n", $pass, $fail );

wpdce_test_reset();

exit( $fail > 0 ? 1 : 0 );

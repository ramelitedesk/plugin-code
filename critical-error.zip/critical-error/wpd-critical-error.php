<?php
/**
 * Plugin Name:       WPD Critical Error Reporter
 * Plugin URI:        https://webart.technology/
 * Description:       Finds out which file and which plugin caused a WordPress critical error, and shows it to you — in the dashboard when the dashboard works, and over a token-protected URL when it does not.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Webart Technology
 * License:           GPL-2.0-or-later
 * Text Domain:       wpd-critical-error
 *
 * @package WPD_Critical_Error
 */

defined( 'ABSPATH' ) || exit;

define( 'WPDCE_VERSION', '1.0.0' );
define( 'WPDCE_FILE', __FILE__ );
define( 'WPDCE_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPDCE_URL', plugin_dir_url( __FILE__ ) );

require_once WPDCE_DIR . 'includes/class-wpdce-settings.php';
require_once WPDCE_DIR . 'includes/class-wpdce-log.php';
require_once WPDCE_DIR . 'includes/class-wpdce-handler.php';
require_once WPDCE_DIR . 'includes/class-wpdce-report.php';

/**
 * There is almost nothing to this bootstrap on purpose.
 *
 * A crash reporter is only worth what it captures, and it can only capture what
 * happens after it is registered. Every line of setup executed before the
 * handler is installed is a window in which a fatal goes unrecorded — so the
 * handler goes on first, and everything else waits for `plugins_loaded`.
 */
WPDCE_Handler::instance()->register();

/**
 * The recovery report is checked here, before the rest of WordPress has had a
 * chance to fail. If the token matches, this call renders the report and exits;
 * on every other request it is a single isset() and returns.
 */
WPDCE_Report::maybe_render();

/**
 * The other half of the recovery report, and the answer to the awkward
 * question the token raises: you get the token from the dashboard, so what use
 * is it when the dashboard is the thing that is gone and you have no file
 * access either?
 *
 * An administrator who is still signed in can open the report with no token,
 * from `?wpdce-report=1`. That needs `wp_validate_auth_cookie()`, which does
 * not exist yet at the line above — but it does by `plugins_loaded`, which is
 * still well before WordPress loads the theme's functions.php.
 *
 * And the links go into the email core already sends when a site fatals, which
 * is the one thing that reaches you when there is nothing left to log in to.
 */
add_action( 'plugins_loaded', array( 'WPDCE_Report', 'maybe_render_for_admin' ), -PHP_INT_MAX );
WPDCE_Report::hook();

/**
 * The self-test's crash endpoint. Runs on `init` rather than here, because it
 * needs the transient API, and it does nothing at all without a one-time token
 * generated in wp-admin moments earlier.
 */
add_action( 'init', array( WPDCE_Handler::instance(), 'maybe_self_destruct' ), 1 );

add_action(
	'plugins_loaded',
	static function () {
		if ( ! is_admin() ) {
			return;
		}

		require_once WPDCE_DIR . 'includes/class-wpdce-admin.php';
		WPDCE_Admin::instance();

		/*
		 * The file-editor guard belongs to the same idea as the rest of this
		 * plugin — say which code broke the site — moved one step earlier, to
		 * before the code has broken anything.
		 */
		require_once WPDCE_DIR . 'includes/class-wpdce-runtime.php';
		require_once WPDCE_DIR . 'includes/class-wpdce-editor.php';
		WPDCE_Editor::instance();
	},
	20
);

register_activation_hook(
	WPDCE_FILE,
	static function () {
		// Create the storage directory and its deny rules now, while we know a
		// human is present, rather than during a shutdown that is going badly.
		WPDCE_Log::dir();
		WPDCE_Report::token();
	}
);

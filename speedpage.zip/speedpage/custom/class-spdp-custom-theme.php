<?php
/**
 * Custom / hand-coded theme support.
 *
 * Builder sites get their markup contract from the builder. Hand-coded themes
 * often miss the small things Lighthouse grades: title-tag support, a viewport
 * meta, responsive embeds, a lang attribute, alt text, tap-target-friendly
 * defaults. This module fills those gaps and does nothing on a page a builder
 * rendered.
 *
 * @package SpeedPage
 */

defined( 'ABSPATH' ) || exit;

class SPDP_Custom_Theme {

	/** @var SPDP_Custom_Theme|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'after_setup_theme', array( $this, 'add_theme_supports' ), 20 );
		add_action( 'wp_head', array( $this, 'ensure_viewport' ), 0 );
		add_filter( 'speedpage_html', array( $this, 'repair_markup' ), 30 );
	}

	/**
	 * Only relevant on themes that did not opt in themselves.
	 */
	public function add_theme_supports() {
		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'responsive-embeds' );
		add_theme_support(
			'html5',
			array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' )
		);
	}

	/**
	 * A missing/incorrect viewport is an automatic Lighthouse failure and kills
	 * the mobile-friendly signal.
	 */
	public function ensure_viewport() {
		if ( ! spdp_should_optimize() ) {
			return;
		}
		if ( ! apply_filters( 'speedpage_print_viewport', true ) ) {
			return;
		}
		// Printed early; the duplicate check below removes a theme's own copy.
		echo '<meta name="viewport" content="width=device-width, initial-scale=1" />' . "\n";
	}

	/**
	 * Whole-document repairs that only make sense once the page is assembled.
	 *
	 * @param string $html Page HTML.
	 * @return string
	 */
	public function repair_markup( $html ) {
		$html = (string) $html;

		/*
		 * Stash script/style bodies first. Without this, an inline script
		 * containing the string target="_blank" (analytics link trackers do
		 * exactly that) gets rewritten as if it were markup, and the JS breaks.
		 */
		$stash   = array();
		$stashed = preg_replace_callback(
			'#<(script|style)\b[^>]*>.*?</\1>#is',
			function ( $m ) use ( &$stash ) {
				$key           = '<!--spdp-keep-repair-' . count( $stash ) . '-->';
				$stash[ $key ] = $m[0];
				return $key;
			},
			$html
		);

		if ( null === $stashed || PREG_NO_ERROR !== preg_last_error() ) {
			return $html;
		}
		$html = $stashed;

		// Remove a second viewport tag if the theme printed one too.
		$count = preg_match_all( '/<meta[^>]+name=["\']viewport["\'][^>]*>/i', $html, $matches );
		if ( $count > 1 ) {
			$first = true;
			$result = preg_replace_callback(
				'/<meta[^>]+name=["\']viewport["\'][^>]*>/i',
				function ( $m ) use ( &$first ) {
					if ( $first ) {
						$first = false;
						return $m[0];
					}
					return '';
				},
				$html
			);
			if ( null !== $result ) {
				$html = $result;
			}
		}

		// <html> without lang fails the "document has a lang attribute" audit.
		if ( preg_match( '/<html\b(?![^>]*\blang=)[^>]*>/i', $html, $m ) ) {
			$lang = get_bloginfo( 'language' );
			$html = str_replace( $m[0], rtrim( $m[0], '>' ) . ' lang="' . esc_attr( $lang ) . '">', $html );
		}

		// Links opening in a new tab need rel=noopener (best-practices audit).
		$result = preg_replace_callback(
			'/<a\s[^>]*target=["\']_blank["\'][^>]*>/i',
			function ( $m ) {
				$tag = $m[0];
				if ( preg_match( '/\srel=["\'][^"\']*noopener/i', $tag ) ) {
					return $tag;
				}
				if ( preg_match( '/\srel=["\']([^"\']*)["\']/i', $tag, $rel ) ) {
					return str_replace( $rel[0], ' rel="' . trim( $rel[1] . ' noopener noreferrer' ) . '"', $tag );
				}
				return rtrim( $tag, '>' ) . ' rel="noopener noreferrer">';
			},
			$html
		);
		if ( null !== $result ) {
			$html = $result;
		}

		foreach ( $stash as $key => $snippet ) {
			$html = str_replace( $key, $snippet, $html );
		}

		return $html;
	}


}

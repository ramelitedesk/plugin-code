<?php
/**
 * Diagnostics.
 *
 * Prints a report as an HTML comment at the end of the page: which modules
 * loaded, whether the optimisation gate opened, and — for every script, style
 * and image — what the plugin decided and why.
 *
 * Two ways to switch it on:
 *
 *   1. wp-config.php:  define( 'SPEEDPAGE_DEBUG', true );
 *   2. A URL token:    https://example.com/?speedpage-debug=TOKEN
 *      The token is shown on the settings screen. Use this to inspect a live
 *      site while logged out, without editing any files.
 *
 * The report names your active plugins, so keep the constant off in production
 * and treat the token as a password.
 *
 * @package SpeedPage
 */

defined( 'ABSPATH' ) || exit;

class SPDP_Debug {

	/** @var SPDP_Debug|null */
	private static $instance = null;

	/** @var bool|null Memoised enabled state. */
	private static $enabled = null;

	/**
	 * Decisions recorded by the other modules.
	 *
	 * @var array<string, array<int, string>>
	 */
	private static $log = array(
		'script' => array(),
		'style'  => array(),
		'image'  => array(),
		'asset'  => array(),
		'note'   => array(),
	);

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * @return bool
	 */
	public static function is_enabled() {
		if ( null !== self::$enabled ) {
			return self::$enabled;
		}

		$on = defined( 'SPEEDPAGE_DEBUG' ) && SPEEDPAGE_DEBUG;

		if ( ! $on ) {
			$token = (string) SPDP_Options::get( 'debug_token', '' );
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only, token-compared.
			$given = isset( $_GET['speedpage-debug'] ) ? sanitize_text_field( wp_unslash( $_GET['speedpage-debug'] ) ) : '';
			if ( '' !== $token && '' !== $given && hash_equals( $token, $given ) ) {
				$on = true;
			}
		}

		self::$enabled = (bool) apply_filters( 'speedpage_debug', $on );
		return self::$enabled;
	}

	/**
	 * Record a decision. A no-op unless debugging is on, so callers do not need
	 * to guard it themselves.
	 *
	 * @param string $bucket script|style|image|asset|note.
	 * @param string $item   What the decision was about.
	 * @param string $note   What happened, and why.
	 */
	public static function log( $bucket, $item, $note = '' ) {
		if ( ! self::is_enabled() || ! isset( self::$log[ $bucket ] ) ) {
			return;
		}
		self::$log[ $bucket ][] = '' !== $note ? $item . '  →  ' . $note : $item;
	}

	private function __construct() {
		add_filter( 'style_loader_tag', array( $this, 'inspect_style' ), 9999, 4 );
		add_action( 'wp_footer', array( $this, 'report' ), 99999 );
	}

	/**
	 * @param string $tag    Link tag.
	 * @param string $handle Handle.
	 * @param string $href   URL.
	 * @param string $media  Media attribute.
	 * @return string
	 */
	public function inspect_style( $tag, $handle, $href, $media ) {
		$blocking = ( false === strpos( $tag, "media='print'" ) && false === strpos( $tag, 'media="print"' ) );
		self::log(
			'style',
			$handle,
			$blocking ? 'RENDER-BLOCKING (media=' . $media . ')' : 'async'
		);
		return $tag;
	}

	/**
	 * The single most useful line in the report: why the gate is shut.
	 *
	 * @return string
	 */
	private function gate_reason() {
		if ( is_admin() ) {
			return 'is_admin()';
		}
		if ( wp_doing_ajax() ) {
			return 'wp_doing_ajax()';
		}
		if ( wp_doing_cron() ) {
			return 'wp_doing_cron()';
		}
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return 'REST_REQUEST';
		}
		if ( is_customize_preview() ) {
			return 'is_customize_preview()';
		}
		if ( spdp_is_builder_editor() ) {
			return 'builder editor detected — see "editor query args" below';
		}
		if ( is_user_logged_in() && ! apply_filters( 'speedpage_optimize_logged_in', false ) ) {
			return 'is_user_logged_in() as "' . wp_get_current_user()->user_login . '" — use a private window';
		}
		if ( is_feed() ) {
			return 'is_feed()';
		}
		if ( is_embed() ) {
			return 'is_embed()';
		}
		if ( is_preview() ) {
			return 'is_preview()';
		}
		if ( ! apply_filters( 'speedpage_should_optimize', true ) ) {
			return 'a speedpage_should_optimize filter returned false';
		}
		return 'open';
	}

	/**
	 * @return string
	 */
	private function editor_query_args() {
		$hits = array();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only diagnostics.
		foreach ( array_keys( (array) $_GET ) as $key ) {
			if ( preg_match( '/(builder|_edit|preview|_fb|editor)/i', (string) $key ) ) {
				$hits[] = sanitize_key( $key );
			}
		}
		return $hits ? implode( ', ', $hits ) : 'none';
	}

	/**
	 * Modules that should be running but are not.
	 *
	 * @param string[] $active Active module keys.
	 * @return string
	 */
	private function missing_modules( array $active ) {
		$expected = array( 'context', 'perf', 'assets', 'images', 'fonts', 'html', 'headers', 'custom' );
		if ( class_exists( 'SPDP_Woo' ) && SPDP_Woo::is_active() ) {
			$expected[] = 'woo';
		}
		$missing = array_diff( $expected, $active );
		return $missing ? implode( ', ', $missing ) : 'none';
	}

	/**
	 * @param string   $title Section heading.
	 * @param string[] $rows  Lines.
	 * @param int      $limit Max rows printed.
	 * @return string[]
	 */
	private function section( $title, array $rows, $limit = 40 ) {
		$out = array( '', $title . ' (' . count( $rows ) . ')', str_repeat( '-', 60 ) );
		if ( ! $rows ) {
			$out[] = '  (nothing recorded)';
			return $out;
		}
		foreach ( array_slice( $rows, 0, $limit ) as $row ) {
			$out[] = '  ' . $row;
		}
		if ( count( $rows ) > $limit ) {
			$out[] = '  … ' . ( count( $rows ) - $limit ) . ' more';
		}
		return $out;
	}

	public function report() {
		$suite   = class_exists( 'SpeedPage' ) ? SpeedPage::instance() : null;
		$active  = ( $suite && method_exists( $suite, 'active_modules' ) ) ? $suite->active_modules() : array();
		$detect  = class_exists( 'SPDP_Builder_Detect' ) ? SPDP_Builder_Detect::instance() : null;
		$reason  = $this->gate_reason();
		$open    = ( 'open' === $reason );
		$builder = $detect ? $detect->builder_for() : null;

		$scripts  = self::$log['script'];
		$deferred = count( array_filter( $scripts, static function ( $row ) {
			return false !== strpos( $row, 'DEFERRED' );
		} ) );
		$delayed = count( array_filter( $scripts, static function ( $row ) {
			return false !== strpos( $row, 'DELAYED' );
		} ) );

		$styles   = self::$log['style'];
		$blocking = count( array_filter( $styles, static function ( $row ) {
			return false !== strpos( $row, 'RENDER-BLOCKING' );
		} ) );

		$lines = array(
			'',
			'  SPEEDPAGE DEBUG ' . SPDP_VERSION . '  —  ' . gmdate( 'Y-m-d H:i:s' ) . ' UTC',
			'  ' . home_url( add_query_arg( array() ) ),
			str_repeat( '=', 60 ),
			'',
			'STATUS',
			str_repeat( '-', 60 ),
			'  optimisation gate  : ' . ( $open ? 'OPEN — running' : '*** CLOSED ***' ),
			'  reason             : ' . $reason,
			'  modules active     : ' . ( $active ? implode( ', ', $active ) : '*** NONE ***' ),
			'  modules missing    : ' . $this->missing_modules( $active ),
			'',
			'ENVIRONMENT',
			str_repeat( '-', 60 ),
			'  page type          : ' . ( class_exists( 'SPDP_Context' ) ? SPDP_Context::instance()->type() : 'n/a' ),
			'  builders installed : ' . ( $detect ? $detect->summary() : 'n/a' ),
			'  builder for page   : ' . ( $builder ? $builder->label() : 'none' ),
			'  editor query args  : ' . $this->editor_query_args(),
			'  logged in          : ' . ( is_user_logged_in() ? 'YES (' . wp_get_current_user()->user_login . ')' : 'no' ),
			'  theme              : ' . wp_get_theme()->get( 'Name' ) . ' ' . wp_get_theme()->get( 'Version' ),
			'  WP / PHP           : ' . get_bloginfo( 'version' ) . ' / ' . PHP_VERSION,
			'  queries / time     : ' . get_num_queries() . ' queries in ' . timer_stop( 0, 3 ) . 's',
			'  peak memory        : ' . size_format( memory_get_peak_usage( true ) ),
			'',
			'SETTINGS THAT AFFECT RENDERING',
			str_repeat( '-', 60 ),
			'  defer_js           : ' . $this->flag( 'defer_js' ),
			'  delay_js_until_input: ' . $this->flag( 'delay_js_until_input' ),
			'  minify_html        : ' . $this->flag( 'minify_html' ),
			'  lazy_images        : ' . $this->flag( 'lazy_images' ),
			'  lcp_priority       : ' . $this->flag( 'lcp_priority' ),
			'  add_dimensions     : ' . $this->flag( 'add_dimensions' ),
			'  cache_headers      : ' . $this->flag( 'cache_headers' ),
			'  critical CSS       : ' . ( '' !== trim( (string) SPDP_Options::get( 'critical_css', '' ) ) ? strlen( (string) SPDP_Options::get( 'critical_css', '' ) ) . ' bytes inlined' : '*** EMPTY — CSS stays render-blocking ***' ),
			'  preload fonts      : ' . ( SPDP_Options::lines( 'preload_fonts' ) ? count( SPDP_Options::lines( 'preload_fonts' ) ) . ' file(s)' : 'none' ),
			'',
			'SUMMARY',
			str_repeat( '-', 60 ),
			'  scripts seen       : ' . count( $scripts ),
			'    deferred         : ' . $deferred,
			'    delayed          : ' . $delayed,
			'    untouched        : ' . ( count( $scripts ) - $deferred - $delayed ),
			'  stylesheets seen   : ' . count( $styles ),
			'    render-blocking  : ' . $blocking,
			'  LCP image id       : ' . ( class_exists( 'SPDP_Context' ) ? ( SPDP_Context::instance()->image_id() ?: '0 — nothing to preload' ) : 'n/a' ),
		);

		$lines = array_merge( $lines, $this->section( 'SCRIPTS', $scripts ) );
		$lines = array_merge( $lines, $this->section( 'STYLESHEETS', $styles ) );
		$lines = array_merge( $lines, $this->section( 'IMAGES', self::$log['image'], 25 ) );
		$lines = array_merge( $lines, $this->section( 'DEQUEUED / CLEANED', self::$log['asset'] ) );
		$lines = array_merge( $lines, $this->section( 'NOTES', self::$log['note'] ) );

		$hints = $this->hints( $open, $active, $scripts, $deferred );
		if ( $hints ) {
			$lines = array_merge( $lines, array( '', 'WHAT TO LOOK AT FIRST', str_repeat( '-', 60 ) ), $hints );
		}

		$lines[] = '';
		$lines[] = str_repeat( '=', 60 );

		echo "\n<!--\n" . esc_html( implode( "\n", $lines ) ) . "\n-->\n";
	}

	/**
	 * @param string $key Setting key.
	 * @return string
	 */
	private function flag( $key ) {
		return SPDP_Options::enabled( $key ) ? 'on' : 'off';
	}

	/**
	 * Turn the raw numbers into the next thing to check.
	 *
	 * @param bool     $open     Gate state.
	 * @param string[] $active   Active modules.
	 * @param array    $scripts  Script log.
	 * @param int      $deferred Deferred count.
	 * @return string[]
	 */
	private function hints( $open, array $active, array $scripts, $deferred ) {
		$hints = array();

		if ( ! $open ) {
			$hints[] = '  * The gate is CLOSED, so nothing below was optimised. Fix the';
			$hints[] = '    "reason" line first — everything else is downstream of it.';
			return $hints;
		}

		$missing = $this->missing_modules( $active );
		if ( 'none' !== $missing ) {
			$hints[] = '  * Modules are missing: ' . $missing;
			$hints[] = '    Either a speedpage_module_{key} filter disabled them, or the';
			$hints[] = '    setting is off. Re-save the settings screen.';
		}

		if ( ! in_array( 'assets', $active, true ) ) {
			$hints[] = '  * The assets module is not running, so no script was deferred.';
		} elseif ( $scripts && 0 === $deferred ) {
			$hints[] = '  * Scripts were found but none deferred. Check the SCRIPTS list';
			$hints[] = '    above — each line says why. "hardcoded" means the theme';
			$hints[] = '    prints <script> in the template instead of enqueueing it,';
			$hints[] = '    which no plugin can defer.';
		}

		if ( '' === trim( (string) SPDP_Options::get( 'critical_css', '' ) ) ) {
			$hints[] = '  * Critical CSS is empty, so stylesheets stay render-blocking.';
			$hints[] = '    This is the remaining half of "eliminate render-blocking".';
		}

		if ( class_exists( 'SPDP_Context' ) && ! SPDP_Context::instance()->image_id() ) {
			$hints[] = '  * No LCP image found for this view. Set a featured image, or';
			$hints[] = '    override it with the speedpage_image_id filter.';
		}

		if ( ! defined( 'WP_CACHE' ) || ! WP_CACHE ) {
			$hints[] = '  * No page cache detected (WP_CACHE is off). TTFB will stay high';
			$hints[] = '    regardless of anything this plugin does.';
		}

		return $hints;
	}
}

<?php
/**
 * What kind of page is this, and what is its most important image.
 *
 * Trimmed to what an optimisation layer actually needs. The version this was
 * split out of also computed canonical URLs, indexability and description
 * sources — all of which belong to SEO, none of which decides how fast a page
 * loads.
 *
 * What is left matters because of one thing: the LCP element. Getting the hero
 * image loaded eagerly with a high fetch priority, while everything below the
 * fold loads lazily, is most of the Largest Contentful Paint score. That needs
 * an answer to "which image is the hero", and this is where it comes from.
 *
 * @package SpeedPage
 */

defined( 'ABSPATH' ) || exit;

class SPDP_Context {

	/** @var SPDP_Context|null */
	private static $instance = null;

	/** @var array Memoised per request. */
	private $cache = array();

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp', array( $this, 'reset' ), 1 );
	}

	public function reset() {
		$this->cache = array();
	}

	/**
	 * One of: front_page, home, singular, category, tag, tax, author, date,
	 * post_type_archive, search, 404, archive.
	 *
	 * @return string
	 */
	public function type() {
		if ( isset( $this->cache['type'] ) ) {
			return $this->cache['type'];
		}

		$type = 'archive';

		if ( is_front_page() ) {
			$type = 'front_page';
		} elseif ( is_home() ) {
			$type = 'home';
		} elseif ( is_singular() ) {
			$type = 'singular';
		} elseif ( is_search() ) {
			$type = 'search';
		} elseif ( is_404() ) {
			$type = '404';
		} elseif ( is_category() ) {
			$type = 'category';
		} elseif ( is_tag() ) {
			$type = 'tag';
		} elseif ( is_tax() ) {
			$type = 'tax';
		} elseif ( is_author() ) {
			$type = 'author';
		} elseif ( is_date() ) {
			$type = 'date';
		} elseif ( is_post_type_archive() ) {
			$type = 'post_type_archive';
		}

		$this->cache['type'] = $type;

		return $type;
	}

	/**
	 * @return int Queried post ID, or 0 on non-singular views.
	 */
	public function post_id() {
		return is_singular() ? (int) get_queried_object_id() : 0;
	}

	/**
	 * @return SPDP_Builder_Base|null
	 */
	public function builder() {
		if ( ! array_key_exists( 'builder', $this->cache ) ) {
			$this->cache['builder'] = class_exists( 'SPDP_Builder_Detect' )
				? SPDP_Builder_Detect::instance()->builder_for( $this->post_id() )
				: null;
		}

		return $this->cache['builder'];
	}

	/**
	 * The image most likely to be the Largest Contentful Paint element.
	 *
	 * Asked of the builder first, because a builder-rendered hero is rarely the
	 * featured image and often is not in the post content at all — it is in the
	 * layout JSON, which only the builder adapter can read.
	 *
	 * @return int Attachment ID, or 0.
	 */
	public function image_id() {
		if ( isset( $this->cache['image'] ) ) {
			return $this->cache['image'];
		}

		$id = 0;

		if ( $this->post_id() && class_exists( 'SPDP_Builder_Detect' ) ) {
			$id = SPDP_Builder_Detect::instance()->hero_image_for( $this->post_id() );
		}

		if ( ! $id && $this->post_id() ) {
			$id = has_post_thumbnail( $this->post_id() ) ? (int) get_post_thumbnail_id( $this->post_id() ) : 0;
		}

		/**
		 * Override the hero image for the current view.
		 *
		 * @param int          $id      Attachment ID.
		 * @param SPDP_Context $context Context object.
		 */
		$this->cache['image'] = (int) apply_filters( 'speedpage_image_id', $id, $this );

		return $this->cache['image'];
	}
}

<?php
/**
 * Shared helpers. Deliberately procedural and prefixed so theme authors can
 * call them from templates without touching the class layer.
 *
 * @package SpeedPage
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'speedpage' ) ) {
	/**
	 * @return SpeedPage
	 */
	function speedpage() {
		return SpeedPage::instance();
	}
}

if ( ! function_exists( 'spdp_is_builder_editor' ) ) {
	/**
	 * True while a page builder editor or preview iframe is rendering.
	 *
	 * Every optimisation must bail here. Deferring scripts inside Elementor's
	 * editor, or minifying the HTML it round-trips, is how an optimisation
	 * plugin earns its reputation for breaking sites — and the person it breaks
	 * things for is the one building the site, who will simply uninstall it.
	 *
	 * @return bool
	 */
	function spdp_is_builder_editor() {
		return class_exists( 'SPDP_Builder_Detect' ) && SPDP_Builder_Detect::instance()->is_editing();
	}
}

if ( ! function_exists( 'spdp_should_optimize' ) ) {
	/**
	 * The single gate every front-end optimisation passes through.
	 *
	 * @return bool
	 */
	function spdp_should_optimize() {
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
			return false;
		}
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return false;
		}
		if ( is_customize_preview() || spdp_is_builder_editor() ) {
			return false;
		}

		/*
		 * Logged-in users see the unoptimised page by default. They are the
		 * ones editing the site, and an admin bar that stopped working because
		 * its script was delayed is a support ticket, not a score.
		 */
		if ( is_user_logged_in() && ! apply_filters( 'speedpage_optimize_logged_in', false ) ) {
			return false;
		}
		if ( is_feed() || is_embed() || is_preview() ) {
			return false;
		}

		/**
		 * @param bool $optimize Whether to optimise this request.
		 */
		return apply_filters( 'speedpage_should_optimize', true );
	}
}

if ( ! function_exists( 'spdp_preg_replace' ) ) {
	/**
	 * preg_replace() that can never destroy the subject.
	 *
	 * PCRE returns null on failure — invalid UTF-8 with the /u modifier, or a
	 * blown backtrack limit on a large page. Assigning that null back to the
	 * page HTML is how an optimisation plugin serves a blank screen. This
	 * wrapper keeps the original string whenever the replace did not succeed.
	 *
	 * @param string $pattern     Regex.
	 * @param string $replacement Replacement.
	 * @param string $subject     Subject.
	 * @param int    $limit       Max replacements.
	 * @return string
	 */
	function spdp_preg_replace( $pattern, $replacement, $subject, $limit = -1 ) {
		$subject = (string) $subject;
		$result  = preg_replace( $pattern, $replacement, $subject, $limit );

		if ( null === $result || PREG_NO_ERROR !== preg_last_error() ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG && function_exists( 'error_log' ) ) {
				error_log( 'SpeedPage: regex failed (' . preg_last_error_msg() . '), original output kept.' ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			}
			return $subject;
		}

		return $result;
	}
}

if ( ! function_exists( 'preg_last_error_msg' ) ) {
	/**
	 * Polyfill for PHP < 8.0.
	 *
	 * @return string
	 */
	function preg_last_error_msg() {
		return 'preg error ' . preg_last_error();
	}
}

if ( ! function_exists( 'spdp_absolute_url' ) ) {
	/**
	 * Normalise a possibly protocol-relative or root-relative URL to absolute.
	 *
	 * @param string $url URL.
	 * @return string
	 */
	function spdp_absolute_url( $url ) {
		$url = trim( (string) $url );

		if ( '' === $url ) {
			return '';
		}
		if ( 0 === strpos( $url, '//' ) ) {
			return ( is_ssl() ? 'https:' : 'http:' ) . $url;
		}
		if ( 0 === strpos( $url, '/' ) ) {
			return home_url( $url );
		}

		return $url;
	}
}

if ( ! function_exists( 'spdp_is_local_asset' ) ) {
	/**
	 * @param string $url Asset URL.
	 * @return bool
	 */
	function spdp_is_local_asset( $url ) {
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		$test = wp_parse_url( spdp_absolute_url( $url ), PHP_URL_HOST );

		return ! $test || $test === $host;
	}
}

if ( ! function_exists( 'spdp_current_url' ) ) {
	/**
	 * @return string The current request URL.
	 */
	function spdp_current_url() {
		global $wp;

		$url = home_url( add_query_arg( array(), $wp ? $wp->request : '' ) );

		return user_trailingslashit( $url );
	}
}

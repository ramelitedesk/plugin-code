<?php
/**
 * Settings and defaults.
 *
 * @package SpeedPage
 */

defined( 'ABSPATH' ) || exit;

class SPDP_Options {

	const OPTION = 'speedpage_settings';

	/** Bump when stored settings need repairing. See maybe_upgrade(). */
	const SCHEMA_VERSION = 1;

	/**
	 * Module switches with no checkbox on the settings screen. They are
	 * code-level only, via the speedpage_module_{key} filter, so the save
	 * handler must never infer "off" from their absence in $_POST.
	 *
	 * This list exists because of a real bug in the plugin this was split out
	 * of: saving the settings form switched off every module key the form did
	 * not render, which silently disabled the entire optimisation layer while
	 * the screen went on reporting success.
	 */
	const INTERNAL_KEYS = array(
		'context',
		'perf',
		'assets',
		'images',
		'fonts',
		'html',
		'headers',
		'custom',
		'woo',
	);

	/** @var array|null */
	private static $cache = null;

	/**
	 * @return array
	 */
	public static function defaults() {
		return apply_filters(
			'speedpage_default_settings',
			array(
				'_schema'                    => self::SCHEMA_VERSION,

				// Modules.
				'context'                    => 1,
				'perf'                       => 1,
				'assets'                     => 1,
				'images'                     => 1,
				'fonts'                      => 1,
				'html'                       => 1,
				'headers'                    => 1,
				'custom'                     => 1,
				'woo'                        => 1,

				// Scripts.
				'defer_js'                   => 1,
				// Off by default. Holding every script until the first tap is
				// the single biggest score win available and also the single
				// most likely thing to break a slider, a sticky header or an
				// analytics beacon. It is opt-in for that reason.
				'delay_js_until_input'       => 0,
				'remove_emojis'              => 1,
				'remove_embeds'              => 1,
				'remove_block_css'           => 0,
				'disable_dashicons'          => 1,
				'jquery_migrate'             => 1,
				'heartbeat_throttle'         => 1,

				// Images.
				'lazy_images'                => 1,
				'lcp_priority'               => 1,
				'add_dimensions'             => 1,

				// Fonts.
				'preload_fonts'              => '',
				'font_display_swap'          => 1,
				'preconnect'                 => 'https://fonts.gstatic.com',

				// HTML and headers.
				'minify_html'                => 1,
				'critical_css'               => '',
				'cache_headers'              => 1,

				// WooCommerce.
				'woo_conditional_assets'     => 1,
				'woo_disable_cart_fragments' => 1,

				// Diagnostics. Generated on first admin load.
				'debug_token'                => '',
			)
		);
	}

	/**
	 * @return array
	 */
	public static function all() {
		if ( null === self::$cache ) {
			$saved       = get_option( self::OPTION, array() );
			self::$cache = wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
		}
		return self::$cache;
	}

	/**
	 * @param string $key     Setting key.
	 * @param mixed  $default Fallback.
	 * @return mixed
	 */
	public static function get( $key, $default = null ) {
		$all   = self::all();
		$value = array_key_exists( $key, $all ) ? $all[ $key ] : $default;
		return apply_filters( 'speedpage_option', $value, $key );
	}

	/**
	 * @param string $key Setting key.
	 * @return bool
	 */
	public static function enabled( $key ) {
		return (bool) self::get( $key, false );
	}

	/**
	 * @param array $values Raw values to persist.
	 */
	public static function update( array $values ) {
		$clean = wp_parse_args( $values, self::all() );
		update_option( self::OPTION, $clean );
		self::$cache = null;
	}

	public static function install_defaults() {
		if ( false === get_option( self::OPTION, false ) ) {
			add_option( self::OPTION, self::defaults() );
		}
	}

	/**
	 * Repair stored settings written by an older version.
	 */
	public static function maybe_upgrade() {
		$saved = get_option( self::OPTION, false );

		if ( false === $saved || ! is_array( $saved ) ) {
			return;
		}

		$version = isset( $saved['_schema'] ) ? (int) $saved['_schema'] : 0;

		if ( $version >= self::SCHEMA_VERSION ) {
			return;
		}

		$defaults = self::defaults();

		foreach ( self::INTERNAL_KEYS as $key ) {
			if ( empty( $saved[ $key ] ) && ! empty( $defaults[ $key ] ) ) {
				$saved[ $key ] = $defaults[ $key ];
			}
		}

		$saved['_schema'] = self::SCHEMA_VERSION;

		update_option( self::OPTION, $saved );
		self::$cache = null;
	}

	/**
	 * Split a textarea of one-per-line values into a clean array.
	 *
	 * @param string $key Setting key.
	 * @return array
	 */
	public static function lines( $key ) {
		$raw = (string) self::get( $key, '' );

		if ( '' === trim( $raw ) ) {
			return array();
		}

		return array_values( array_filter( array_map( 'trim', preg_split( '/[\r\n,]+/', $raw ) ) ) );
	}

	/**
	 * Settings inherited from the combined SEO + performance plugin this was
	 * split out of.
	 *
	 * Someone upgrading has already tuned these once; making them do it again
	 * because the folder name changed would be a poor welcome. Only keys this
	 * plugin actually owns are taken, so nothing SEO-related leaks across.
	 *
	 * @return int Number of settings carried over.
	 */
	public static function import_legacy() {
		if ( false !== get_option( self::OPTION, false ) ) {
			return 0; // Already configured here; never overwrite.
		}

		$legacy = get_option( 'wpd_seo_settings', false );

		if ( ! is_array( $legacy ) ) {
			return 0;
		}

		$defaults = self::defaults();
		$carried  = array();

		foreach ( $defaults as $key => $value ) {
			if ( '_schema' !== $key && array_key_exists( $key, $legacy ) ) {
				$carried[ $key ] = $legacy[ $key ];
			}
		}

		if ( ! $carried ) {
			return 0;
		}

		add_option( self::OPTION, wp_parse_args( $carried, $defaults ) );
		self::$cache = null;

		return count( $carried );
	}
}

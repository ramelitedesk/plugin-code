<?php
/**
 * Plugin Name: SpeedPage Loader (must-use)
 * Description: Loads SpeedPage from wp-content/plugins/speedpage as a must-use plugin, so a client cannot deactivate it by accident.
 * Version:     1.0.0
 *
 * INSTALL: copy this single file to wp-content/mu-plugins/speedpage-loader.php
 * (create the mu-plugins directory if it does not exist) and keep the suite
 * itself at wp-content/plugins/seo/.
 *
 * Do not activate the plugin normally as well — it would load twice.
 *
 * @package SpeedPage
 */

defined( 'ABSPATH' ) || exit;

$speedpage_bootstrap = WP_PLUGIN_DIR . '/speedpage/speedpage.php';

if ( file_exists( $speedpage_bootstrap ) ) {
	require_once $speedpage_bootstrap;
} elseif ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
	add_action(
		'admin_notices',
		function () {
			echo '<div class="notice notice-error"><p>SpeedPage loader: wp-content/plugins/speedpage/speedpage.php not found.</p></div>';
		}
	);
}

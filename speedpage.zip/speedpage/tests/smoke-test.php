<?php
/**
 * Runtime smoke test.
 *
 * Loads the whole plugin against stubbed WordPress functions and actually
 * calls every output path, so undefined methods, bad argument counts,
 * null-to-string deprecations and type errors surface here rather than on a
 * live site.
 *
 * The cases that matter most are the ones asserting that a filter hands back
 * the page unchanged when it cannot do its job. An optimisation plugin that
 * returns null from a preg_replace, or an empty string from a minifier, serves
 * a blank page — and it does it to visitors, not to the person who installed
 * it, so nobody finds out for days.
 *
 * @package SpeedPage
 */

if ( 'cli' !== PHP_SAPI ) {
	http_response_code( 404 );
	exit;
}

require __DIR__ . '/bootstrap.php';

$pass = 0;
$fail = 0;

$errors = array();
set_error_handler(
	function ( $no, $str, $file, $line ) use ( &$errors ) {
		$errors[] = sprintf( '%s in %s:%d', $str, basename( $file ), $line );
		return true;
	}
);

/**
 * @param string   $label Step name.
 * @param callable $fn    Step.
 */
function step( $label, callable $fn ) {
	global $pass, $fail;

	try {
		$fn();
		$pass++;
		printf( "  ok    %s\n", $label );
	} catch ( \Throwable $e ) {
		$fail++;
		printf( "  FAIL  %s :: %s: %s @ %s:%d\n", $label, get_class( $e ), $e->getMessage(), basename( $e->getFile() ), $e->getLine() );
	}
}

/**
 * @param string $label Assertion.
 * @param bool   $ok    Result.
 * @param string $note  Shown on failure.
 */
function check( $label, $ok, $note = '' ) {
	global $pass, $fail;

	if ( $ok ) {
		$pass++;
		printf( "  ok    %s\n", $label );
		return;
	}

	$fail++;
	printf( "  FAIL  %s%s\n", $label, '' !== $note ? ' :: ' . $note : '' );
}

echo "\n=== Everything instantiates ===\n";

step( 'Options::defaults', function () { SPDP_Options::defaults(); } );
step( 'Options::all', function () { SPDP_Options::all(); } );
step( 'Options::maybe_upgrade', function () { SPDP_Options::maybe_upgrade(); } );
step( 'Options::lines', function () { SPDP_Options::lines( 'preconnect' ); } );
step( 'Context', function () { SPDP_Context::instance()->type(); } );
step( 'Builder_Detect', function () { SPDP_Builder_Detect::instance()->summary(); } );
step( 'Perf', function () { SPDP_Perf::instance(); } );
step( 'Assets', function () { SPDP_Assets::instance(); } );
step( 'Images', function () { SPDP_Images::instance(); } );
step( 'Fonts', function () { SPDP_Fonts::instance(); } );
step( 'Html', function () { SPDP_Html::instance(); } );
step( 'Headers', function () { SPDP_Headers::instance(); } );
step( 'Custom_Theme', function () { SPDP_Custom_Theme::instance(); } );
step( 'Woo', function () { SPDP_Woo::instance(); } );

echo "\n=== The optimisation gate ===\n";

step( 'should_optimize answers', function () { spdp_should_optimize(); } );
step( 'is_builder_editor answers', function () { spdp_is_builder_editor(); } );

check( 'a logged-out front-end request is optimised', spdp_should_optimize() );

$GLOBALS['spdp_state']['loggedin'] = true;
check( 'a logged-in request is not', ! spdp_should_optimize(), 'the admin bar and editors must see the real page' );
$GLOBALS['spdp_state']['loggedin'] = false;

echo "\n=== Rewrites hand back the original when they cannot work ===\n";

/*
 * This is the single most important property in the plugin. Every filter below
 * takes the whole page HTML and returns it. If any of them can return null, an
 * empty string, or mangled bytes, the site goes blank for visitors.
 */
$html = "<!doctype html>\n<html>\n<head>\n<title>Test</title>\n<meta name=\"viewport\" content=\"width=device-width\">\n</head>\n"
	. "<body>\n<h1>Hello</h1>\n<p>Some   text</p>\n"
	. "<script>var x = 'a  b'; // keep   spacing\nvar t = '</p>';</script>\n"
	. "<pre>  preformatted\n  spacing  </pre>\n"
	. "<style>.a {  color : red }</style>\n"
	. "<a href=\"https://example.com\" target=\"_blank\">out</a>\n"
	. "<img src=\"/a.jpg\">\n</body>\n</html>";

$minified = SPDP_Html::instance()->process( $html );

check( 'minify returns a non-empty string', is_string( $minified ) && '' !== $minified );
check( 'minify keeps the doctype', false !== stripos( $minified, '<!doctype html>' ) );
check( 'minify keeps the body text', false !== strpos( $minified, 'Hello' ) );
check( 'minify does not touch script bodies', false !== strpos( $minified, "var x = 'a  b';" ), 'inline JS spacing must survive' );
check( 'minify does not touch pre', false !== strpos( $minified, "  preformatted" ) );

// Invalid UTF-8 is what actually blanks pages in the wild: the /u modifier
// makes PCRE fail, preg_replace returns null, and null becomes the response.
$broken = $html . "\xC3\x28\xFF\xFE invalid utf8";
$out    = SPDP_Html::instance()->process( $broken );
check( 'minify survives invalid UTF-8', is_string( $out ) && '' !== $out, 'must return the original, never null' );

$repaired = SPDP_Custom_Theme::instance()->repair_markup( $html );
check( 'repair_markup returns a string', is_string( $repaired ) && '' !== $repaired );
check( 'repair_markup adds lang to <html>', false !== stripos( $repaired, 'lang=' ) );
check( 'repair_markup adds rel=noopener', false !== stripos( $repaired, 'noopener' ) );
check( 'repair_markup leaves inline JS alone', false !== strpos( $repaired, "var t = '</p>';" ), 'a script containing markup must not be rewritten' );

$two_viewports = str_replace( '</head>', '<meta name="viewport" content="width=1024"></head>', $html );
$fixed         = SPDP_Custom_Theme::instance()->repair_markup( $two_viewports );
check( 'a duplicate viewport is removed', 1 === preg_match_all( '/name=["\']viewport["\']/i', $fixed ), 'found ' . preg_match_all( '/name=["\']viewport["\']/i', $fixed ) );

check( 'repair_markup survives invalid UTF-8', '' !== SPDP_Custom_Theme::instance()->repair_markup( $broken ) );

echo "\n=== spdp_preg_replace never destroys its subject ===\n";

check( 'a working replace works', 'b' === spdp_preg_replace( '/a/', 'b', 'a' ) );
check( 'a failing replace keeps the subject', "\xC3\x28" === spdp_preg_replace( '/\p{L}/u', 'x', "\xC3\x28" ), 'invalid UTF-8 with /u must not blank the page' );
check( 'a catastrophic pattern keeps the subject', is_string( spdp_preg_replace( '/(a+)+$/', 'x', str_repeat( 'a', 60 ) . 'b' ) ) );

echo "\n=== Helpers ===\n";

check( 'absolute_url leaves absolute URLs alone', 'https://a.test/x' === spdp_absolute_url( 'https://a.test/x' ) );
check( 'absolute_url expands root-relative', 0 === strpos( spdp_absolute_url( '/x' ), 'http' ) );
check( 'absolute_url expands protocol-relative', 0 === strpos( spdp_absolute_url( '//a.test/x' ), 'http' ) );
check( 'absolute_url tolerates an empty string', '' === spdp_absolute_url( '' ) );
check( 'is_local_asset recognises a local path', spdp_is_local_asset( '/wp-content/x.js' ) );
check( 'is_local_asset recognises a third party', ! spdp_is_local_asset( 'https://cdn.example.net/x.js' ) );

echo "\n=== Settings cannot be silently switched off ===\n";

/*
 * The bug this guards against was real in the plugin this was split out of:
 * saving the settings form switched off every module key the form does not
 * render, disabling the whole optimisation layer while reporting success.
 */
$defaults = SPDP_Options::defaults();

foreach ( SPDP_Options::INTERNAL_KEYS as $key ) {
	check( "module key '$key' has a default", array_key_exists( $key, $defaults ), 'missing from defaults()' );
}

check( 'every internal key defaults to on', count( array_filter( array_intersect_key( $defaults, array_flip( SPDP_Options::INTERNAL_KEYS ) ) ) ) === count( SPDP_Options::INTERNAL_KEYS ) );

echo "\n=== Nothing SEO-shaped came across in the split ===\n";

$seo_keys = array( 'title_separator', 'og_enabled', 'twitter_card', 'org_name', 'noindex_search', 'woo_schema', 'woo_noindex_pages' );

foreach ( $seo_keys as $key ) {
	check( "'$key' is not a SpeedPage setting", ! array_key_exists( $key, $defaults ) );
}

foreach ( array( 'SPDP_Meta', 'SPDP_Schema', 'SPDP_Sitemap', 'SPDP_Robots', 'SPDP_Breadcrumbs' ) as $class ) {
	check( "$class does not exist here", ! class_exists( $class ) );
}

echo "\n=== Legacy settings are carried over, not invented ===\n";

$GLOBALS['wp_options']['wpd_seo_settings'] = array(
	'defer_js'        => 0,
	'lazy_images'     => 0,
	'preconnect'      => 'https://carried.example',
	'title_separator' => '-',
	'og_enabled'      => 1,
);
unset( $GLOBALS['wp_options']['speedpage_settings'] );

$ref = new ReflectionProperty( 'SPDP_Options', 'cache' );
$ref->setAccessible( true );
$ref->setValue( null );

$carried = SPDP_Options::import_legacy();

check( 'settings were carried over', $carried > 0, "carried $carried" );
check( 'a tuned value survived', 'https://carried.example' === SPDP_Options::get( 'preconnect' ) );
check( 'an "off" choice survived', ! SPDP_Options::enabled( 'defer_js' ), 'importing must not silently re-enable things' );
check( 'SEO keys did not come with it', null === SPDP_Options::get( 'title_separator', null ) );

// A second import must never overwrite settings already configured here.
SPDP_Options::update( array( 'preconnect' => 'https://mine.example' ) );
$ref->setValue( null );
SPDP_Options::import_legacy();
check( 'a second import leaves existing settings alone', 'https://mine.example' === SPDP_Options::get( 'preconnect' ) );

/* ------------------------------------------------------------------ */

restore_error_handler();

if ( $errors ) {
	printf( "\nPHP notices raised (%d):\n", count( $errors ) );
	foreach ( array_slice( array_unique( $errors ), 0, 15 ) as $error ) {
		printf( "  %s\n", $error );
	}
}

printf( "\n----\npassed: %d   failed: %d\n", $pass, $fail );

exit( $fail > 0 ? 1 : 0 );

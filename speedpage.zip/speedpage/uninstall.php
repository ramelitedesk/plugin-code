<?php
/**
 * Runs when the plugin is deleted.
 *
 * @package SpeedPage
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'speedpage_settings' );

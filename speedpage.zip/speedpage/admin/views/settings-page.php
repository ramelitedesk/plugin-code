<?php
/**
 * Settings screen markup.
 *
 * @var array                   $settings Current settings.
 * @var SPDP_Builder_Detect|null $detect  Builder detector.
 *
 * @package SpeedPage
 */

defined( 'ABSPATH' ) || exit;

/**
 * A checkbox row that also declares itself to the save handler.
 *
 * @param string $key      Setting key.
 * @param string $label    Field label.
 * @param string $help     Help text.
 * @param array  $settings Settings array.
 */
$spdp_toggle = static function ( $key, $label, $help, $settings ) {
	?>
	<tr>
		<th scope="row"><?php echo esc_html( $label ); ?></th>
		<td>
			<label>
				<?php // Declares that this checkbox was on the form, so an unchecked box means "off" rather than "not shown". ?>
				<input type="hidden" name="spdp_present[]" value="<?php echo esc_attr( $key ); ?>" />
				<input type="checkbox" name="<?php echo esc_attr( $key ); ?>" value="1" <?php checked( ! empty( $settings[ $key ] ) ); ?> />
				<?php echo esc_html( $help ); ?>
			</label>
		</td>
	</tr>
	<?php
};

/**
 * @param string $key      Setting key.
 * @param string $label    Field label.
 * @param string $help     Help text.
 * @param array  $settings Settings array.
 * @param string $type     text|textarea.
 */
$spdp_field = static function ( $key, $label, $help, $settings, $type = 'text' ) {
	$value = isset( $settings[ $key ] ) ? $settings[ $key ] : '';
	?>
	<tr>
		<th scope="row"><label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
		<td>
			<?php if ( 'textarea' === $type ) : ?>
				<textarea id="<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>" rows="4" class="large-text code"><?php echo esc_textarea( (string) $value ); ?></textarea>
			<?php else : ?>
				<input type="text" id="<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>" class="regular-text" value="<?php echo esc_attr( (string) $value ); ?>" />
			<?php endif; ?>
			<p class="description"><?php echo esc_html( $help ); ?></p>
		</td>
	</tr>
	<?php
};
?>
<div class="wrap spdp-wrap">
	<h1><?php esc_html_e( 'SpeedPage', 'speedpage' ); ?></h1>

	<?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
	<?php if ( isset( $_GET['updated'] ) ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Settings saved.', 'speedpage' ); ?></p></div>
	<?php endif; ?>

	<div class="spdp-panel">
		<h2><?php esc_html_e( 'What actually decides your score', 'speedpage' ); ?></h2>
		<p class="description">
			<?php esc_html_e( 'Everything below this panel is worth doing. None of it outweighs the things in it — a page cache, HTTP/2, compression and a current PHP version move the numbers further than any option on this screen.', 'speedpage' ); ?>
		</p>
		<table class="spdp-health">
			<?php foreach ( SPDP_Admin::health_checks() as $check ) : ?>
				<tr class="status-<?php echo esc_attr( $check['status'] ); ?>">
					<td class="dot"><span></span></td>
					<th scope="row"><?php echo esc_html( $check['label'] ); ?></th>
					<td><?php echo esc_html( $check['note'] ); ?></td>
				</tr>
			<?php endforeach; ?>
		</table>
	</div>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="speedpage_save" />
		<?php wp_nonce_field( SPDP_Admin::NONCE ); ?>

		<div class="spdp-panel">
			<h2><?php esc_html_e( 'JavaScript', 'speedpage' ); ?></h2>
			<table class="form-table" role="presentation">
				<?php
				$spdp_toggle( 'defer_js', __( 'Defer scripts', 'speedpage' ), __( 'Load scripts after the HTML is parsed instead of blocking it', 'speedpage' ), $settings );
				$spdp_toggle( 'delay_js_until_input', __( 'Delay until interaction', 'speedpage' ), __( 'Hold every script until the first scroll, tap or key press', 'speedpage' ), $settings );
				$spdp_toggle( 'remove_emojis', __( 'Emoji script', 'speedpage' ), __( 'Remove the emoji detection script and its stylesheet', 'speedpage' ), $settings );
				$spdp_toggle( 'remove_embeds', __( 'oEmbed script', 'speedpage' ), __( 'Remove wp-embed.js, used only to embed this site inside another', 'speedpage' ), $settings );
				$spdp_toggle( 'jquery_migrate', __( 'jQuery Migrate', 'speedpage' ), __( 'Remove jquery-migrate, needed only by code written for jQuery 1.x', 'speedpage' ), $settings );
				$spdp_toggle( 'disable_dashicons', __( 'Dashicons', 'speedpage' ), __( 'Remove the admin icon font from the front end for logged-out visitors', 'speedpage' ), $settings );
				$spdp_toggle( 'remove_block_css', __( 'Block editor CSS', 'speedpage' ), __( 'Remove wp-block-library CSS — only safe on themes that do not use block markup', 'speedpage' ), $settings );
				$spdp_toggle( 'heartbeat_throttle', __( 'Heartbeat', 'speedpage' ), __( 'Slow the admin heartbeat and stop it entirely on the front end', 'speedpage' ), $settings );
				?>
			</table>

			<div class="notice notice-warning inline">
				<p>
					<strong><?php esc_html_e( 'Delay until interaction is the one to be careful with.', 'speedpage' ); ?></strong>
					<?php esc_html_e( 'It is the largest single score improvement available and the most likely thing here to break a slider, a sticky header, a chat widget or an analytics beacon. Turn it on, then load the site in a private window and use it — do not judge it from the score alone.', 'speedpage' ); ?>
				</p>
			</div>
		</div>

		<div class="spdp-panel">
			<h2><?php esc_html_e( 'Images', 'speedpage' ); ?></h2>
			<table class="form-table" role="presentation">
				<?php
				$spdp_toggle( 'lazy_images', __( 'Lazy loading', 'speedpage' ), __( 'Defer images below the fold until they are needed', 'speedpage' ), $settings );
				$spdp_toggle( 'lcp_priority', __( 'Hero image priority', 'speedpage' ), __( 'Load the largest above-the-fold image eagerly, with fetchpriority="high"', 'speedpage' ), $settings );
				$spdp_toggle( 'add_dimensions', __( 'Width and height', 'speedpage' ), __( 'Add missing dimensions so the browser reserves the space and the layout does not jump', 'speedpage' ), $settings );
				?>
			</table>
			<p class="description">
				<?php esc_html_e( 'Hero image priority is the setting that moves Largest Contentful Paint. Lazy-loading the image someone is waiting to see makes the score worse, not better, which is why it is detected and excluded rather than lazy-loaded with everything else.', 'speedpage' ); ?>
			</p>
		</div>

		<div class="spdp-panel">
			<h2><?php esc_html_e( 'Fonts', 'speedpage' ); ?></h2>
			<table class="form-table" role="presentation">
				<?php
				$spdp_toggle( 'font_display_swap', __( 'font-display: swap', 'speedpage' ), __( 'Show text in a fallback face immediately rather than leaving it invisible', 'speedpage' ), $settings );
				$spdp_field( 'preload_fonts', __( 'Preload', 'speedpage' ), __( 'One font URL per line. Only the one or two faces used above the fold — preloading everything delays the very thing you are trying to speed up.', 'speedpage' ), $settings, 'textarea' );
				$spdp_field( 'preconnect', __( 'Preconnect', 'speedpage' ), __( 'One origin per line. Opens the connection early to hosts you are certain will be used.', 'speedpage' ), $settings, 'textarea' );
				?>
			</table>
		</div>

		<div class="spdp-panel">
			<h2><?php esc_html_e( 'HTML and delivery', 'speedpage' ); ?></h2>
			<table class="form-table" role="presentation">
				<?php
				$spdp_toggle( 'minify_html', __( 'Minify HTML', 'speedpage' ), __( 'Collapse whitespace and drop comments, leaving script, style and pre untouched', 'speedpage' ), $settings );
				$spdp_toggle( 'cache_headers', __( 'Cache headers', 'speedpage' ), __( 'Send long-lived cache headers for static assets', 'speedpage' ), $settings );
				$spdp_field( 'critical_css', __( 'Critical CSS', 'speedpage' ), __( 'Inlined in the head, above every stylesheet. Leave empty unless you have generated it for this theme.', 'speedpage' ), $settings, 'textarea' );
				?>
			</table>
		</div>

		<?php if ( class_exists( 'SPDP_Woo' ) && SPDP_Woo::is_active() ) : ?>
			<div class="spdp-panel">
				<h2><?php esc_html_e( 'WooCommerce', 'speedpage' ); ?></h2>
				<table class="form-table" role="presentation">
					<?php
					$spdp_toggle( 'woo_conditional_assets', __( 'Store assets', 'speedpage' ), __( 'Dequeue WooCommerce styles and scripts on pages that are not part of the store', 'speedpage' ), $settings );
					$spdp_toggle( 'woo_disable_cart_fragments', __( 'Cart fragments', 'speedpage' ), __( 'Stop the uncached AJAX cart request on pages with no cart on them', 'speedpage' ), $settings );
					?>
				</table>
				<p class="description">
					<?php esc_html_e( 'Cart, checkout and account pages are never optimised, whatever is set above. A cart that empties itself is not a trade worth making for a score.', 'speedpage' ); ?>
				</p>
			</div>
		<?php endif; ?>

		<?php submit_button( __( 'Save changes', 'speedpage' ) ); ?>
	</form>

	<div class="spdp-panel">
		<h2><?php esc_html_e( 'Diagnostics', 'speedpage' ); ?></h2>
		<p class="description">
			<?php esc_html_e( 'A report of what was optimised on a given page, why the gate opened or closed, and which scripts were deferred, delayed or left alone. Add this to the end of any front-end URL:', 'speedpage' ); ?>
		</p>
		<p>
			<input
				type="text"
				class="large-text code"
				readonly
				onfocus="this.select()"
				value="<?php echo esc_attr( add_query_arg( 'speedpage-debug', (string) SPDP_Options::get( 'debug_token', '' ), home_url( '/' ) ) ); ?>"
			/>
		</p>
		<p class="description">
			<?php esc_html_e( 'It prints file paths and asset URLs, so treat the token as a password. Most of the time the answer it gives is "the gate was closed because you are logged in" — open it in a private window.', 'speedpage' ); ?>
		</p>
	</div>
</div>

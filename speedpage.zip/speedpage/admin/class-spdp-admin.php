<?php
/**
 * Admin: the settings screen and a health panel reporting what was detected.
 *
 * @package SpeedPage
 */

defined( 'ABSPATH' ) || exit;

class SPDP_Admin {

	const PAGE  = 'speedpage';
	const NONCE = 'speedpage_save';

	/** @var SPDP_Admin|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_init', array( $this, 'ensure_debug_token' ) );
		add_action( 'admin_post_speedpage_save', array( $this, 'handle_save' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
	}

	/**
	 * The debug URL token. Generated once, in admin only, so the front end
	 * never writes to options.
	 */
	public function ensure_debug_token() {
		if ( '' === (string) SPDP_Options::get( 'debug_token', '' ) ) {
			SPDP_Options::update( array( 'debug_token' => wp_generate_password( 16, false ) ) );
		}
	}

	public function add_menu() {
		add_menu_page(
			__( 'SpeedPage', 'speedpage' ),
			__( 'SpeedPage', 'speedpage' ),
			'manage_options',
			self::PAGE,
			array( $this, 'render_page' ),
			'dashicons-performance',
			66
		);
	}

	/**
	 * @param string $hook Current admin page.
	 */
	public function enqueue( $hook ) {
		if ( false === strpos( (string) $hook, self::PAGE ) ) {
			return;
		}
		wp_enqueue_style( 'speedpage-admin', SPDP_URL . 'assets/css/admin.css', array(), SPDP_VERSION );
	}

	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'speedpage' ) );
		}

		$settings = SPDP_Options::all();
		$detect   = class_exists( 'SPDP_Builder_Detect' ) ? SPDP_Builder_Detect::instance() : null;

		require SPDP_DIR . 'admin/views/settings-page.php';
	}

	public function handle_save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'speedpage' ) );
		}
		check_admin_referer( self::NONCE );

		$defaults = SPDP_Options::defaults();
		$current  = SPDP_Options::all();
		$clean    = array();

		/*
		 * The form posts the name of every checkbox it rendered.
		 *
		 * Without this list, an unchecked box and a field the form never showed
		 * look identical in $_POST. That is not a hypothetical: in the plugin
		 * this was split out of, saving the settings screen switched off every
		 * module key with no checkbox — silently disabling the whole
		 * optimisation layer while reporting that the settings were saved.
		 */
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked above.
		$rendered = isset( $_POST['spdp_present'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['spdp_present'] ) ) : array();

		foreach ( $defaults as $key => $default ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked above.
			$posted = isset( $_POST[ $key ] );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked above.
			$raw = $posted ? wp_unslash( $_POST[ $key ] ) : null;

			if ( '_schema' === $key ) {
				$clean[ $key ] = SPDP_Options::SCHEMA_VERSION;
				continue;
			}

			// Anything this form did not render keeps its stored value.
			if ( ! $posted && ! in_array( $key, $rendered, true ) ) {
				$clean[ $key ] = isset( $current[ $key ] ) ? $current[ $key ] : $default;
				continue;
			}

			if ( is_int( $default ) ) {
				$clean[ $key ] = ( null === $raw ) ? 0 : 1;
				continue;
			}

			if ( 'critical_css' === $key ) {
				$clean[ $key ] = is_string( $raw ) ? wp_strip_all_tags( $raw ) : '';
				continue;
			}

			if ( in_array( $key, array( 'preload_fonts', 'preconnect' ), true ) ) {
				$clean[ $key ] = is_string( $raw ) ? sanitize_textarea_field( $raw ) : '';
				continue;
			}

			$clean[ $key ] = is_string( $raw ) ? sanitize_text_field( $raw ) : $default;
		}

		SPDP_Options::update( $clean );

		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE, 'updated' => '1' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Environment checks shown on the settings screen.
	 *
	 * Every one of these is something this plugin cannot fix from PHP but which
	 * outweighs most of what it can. Saying so is more useful than a green tick
	 * on a setting that is not the bottleneck.
	 *
	 * @return array List of array( 'label', 'status' => ok|warn|fail, 'note' ).
	 */
	public static function health_checks() {
		$checks = array();

		$checks[] = array(
			'label'  => __( 'Page cache', 'speedpage' ),
			'status' => ( defined( 'WP_CACHE' ) && WP_CACHE ) ? 'ok' : 'warn',
			'note'   => ( defined( 'WP_CACHE' ) && WP_CACHE )
				? __( 'WP_CACHE is on.', 'speedpage' )
				: __( 'No page cache detected. Nothing in this plugin moves Time to First Byte the way a page cache does — add one at the host level or with a caching plugin, and treat everything here as what you do afterwards.', 'speedpage' ),
		);

		$checks[] = array(
			'label'  => __( 'HTTPS', 'speedpage' ),
			'status' => is_ssl() ? 'ok' : 'warn',
			'note'   => is_ssl()
				? __( 'Serving over HTTPS.', 'speedpage' )
				: __( 'No TLS, so no HTTP/2 or HTTP/3 either — every asset queues behind the connection limit.', 'speedpage' ),
		);

		$checks[] = array(
			'label'  => __( 'Compression', 'speedpage' ),
			'status' => self::compression_active() ? 'ok' : 'warn',
			'note'   => self::compression_active()
				? __( 'Responses are being compressed by the server.', 'speedpage' )
				: __( 'No gzip or brotli detected on this response. That is a server setting, not a PHP one — see config/htaccess-rules.conf or config/nginx-rules.conf.', 'speedpage' ),
		);

		$php_ok   = version_compare( PHP_VERSION, '8.0', '>=' );
		$checks[] = array(
			'label'  => __( 'PHP version', 'speedpage' ),
			'status' => $php_ok ? 'ok' : 'warn',
			'note'   => $php_ok
				? PHP_VERSION
				: sprintf(
					/* translators: %s: PHP version. */
					__( '%s. Moving to PHP 8 is usually a larger real-world win than every option on this screen combined.', 'speedpage' ),
					PHP_VERSION
				),
		);

		$checks[] = array(
			'label'  => __( 'Object cache', 'speedpage' ),
			'status' => wp_using_ext_object_cache() ? 'ok' : 'warn',
			'note'   => wp_using_ext_object_cache()
				? __( 'A persistent object cache is in use.', 'speedpage' )
				: __( 'No persistent object cache. On a database-heavy site this is worth more than asset optimisation.', 'speedpage' ),
		);

		if ( class_exists( 'SPDP_Woo' ) && SPDP_Woo::is_active() ) {
			$checks[] = array(
				'label'  => __( 'WooCommerce', 'speedpage' ),
				'status' => 'ok',
				'note'   => __( 'Store mode active: cart, checkout and account pages are excluded from optimisation, and store assets are dequeued on pages that are not part of the store.', 'speedpage' ),
			);
		}

		if ( $detect = self::detector() ) { // phpcs:ignore WordPress.CodeAnalysis.AssignmentInCondition.FoundInWhileCondition
			$checks[] = array(
				'label'  => __( 'Page builders', 'speedpage' ),
				'status' => 'ok',
				'note'   => sprintf(
					/* translators: %s: comma-separated builder names, or "none". */
					__( 'Detected: %s. Editor and preview requests are never optimised.', 'speedpage' ),
					$detect->summary()
				),
			);
		}

		return $checks;
	}

	/**
	 * @return SPDP_Builder_Detect|null
	 */
	private static function detector() {
		return class_exists( 'SPDP_Builder_Detect' ) ? SPDP_Builder_Detect::instance() : null;
	}

	/**
	 * Is the server compressing this response?
	 *
	 * Read from the request rather than guessed from configuration: what the
	 * browser is actually being sent is the only answer that matters, and
	 * plenty of hosts compress at a layer PHP cannot see.
	 *
	 * @return bool
	 */
	private static function compression_active() {
		if ( function_exists( 'headers_list' ) ) {
			foreach ( headers_list() as $header ) {
				if ( 0 === stripos( $header, 'content-encoding:' ) && preg_match( '/gzip|br|deflate|zstd/i', $header ) ) {
					return true;
				}
			}
		}

		return ( ini_get( 'zlib.output_compression' ) && '0' !== ini_get( 'zlib.output_compression' ) )
			|| in_array( 'ob_gzhandler', array_map( 'strtolower', (array) ob_list_handlers() ), true );
	}
}

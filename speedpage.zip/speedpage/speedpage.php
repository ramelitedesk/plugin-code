<?php
/**
 * Plugin Name:       SpeedPage
 * Plugin URI:        https://webart.technology/
 * Description:       Page speed and Core Web Vitals optimisation for any WordPress site — script deferral, image and font loading, HTML minification, cache headers. Builder-aware (Elementor, WPBakery, Bricks, Beaver Builder, Divi, Oxygen, Gutenberg) so an editor session is never optimised.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Ramakrishna
 * License:           GPL-2.0-or-later
 * Text Domain:       speedpage
 *
 * @package SpeedPage
 */

defined( 'ABSPATH' ) || exit;

define( 'SPDP_VERSION', '1.0.0' );
define( 'SPDP_FILE', __FILE__ );
define( 'SPDP_DIR', plugin_dir_path( __FILE__ ) );
define( 'SPDP_URL', plugin_dir_url( __FILE__ ) );

/**
 * One idea runs through every module here: an optimisation that breaks the page
 * is worse than no optimisation at all.
 *
 * A slow site still sells things. A site whose slider stopped moving because a
 * script was deferred, or whose layout collapsed because the HTML was minified
 * inside a builder's preview iframe, does not — and the person who notices is
 * the one who can uninstall this. So the builder layer loads before anything
 * else and tells every other module when to stand down, and every rewrite of
 * the page is written so that a failure returns the original bytes untouched.
 */
final class SpeedPage {

	/** @var SpeedPage|null */
	private static $instance = null;

	/** @var array Runtime module registry. */
	private $modules = array();

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->boot();
		}
		return self::$instance;
	}

	private function boot() {
		require_once SPDP_DIR . 'includes/helpers.php';
		require_once SPDP_DIR . 'includes/class-spdp-options.php';
		require_once SPDP_DIR . 'includes/class-spdp-context.php';

		// The builder layer must load first: it tells every other module what
		// to skip, and a module that asks before it exists optimises an editor.
		require_once SPDP_DIR . 'builders/class-spdp-builder-base.php';
		require_once SPDP_DIR . 'builders/class-spdp-builder-detect.php';

		require_once SPDP_DIR . 'performance/class-spdp-perf.php';
		require_once SPDP_DIR . 'performance/class-spdp-assets.php';
		require_once SPDP_DIR . 'performance/class-spdp-images.php';
		require_once SPDP_DIR . 'performance/class-spdp-fonts.php';
		require_once SPDP_DIR . 'performance/class-spdp-html.php';
		require_once SPDP_DIR . 'performance/class-spdp-headers.php';

		require_once SPDP_DIR . 'custom/class-spdp-custom-theme.php';
		require_once SPDP_DIR . 'woocommerce/class-spdp-woo.php';

		require_once SPDP_DIR . 'includes/class-spdp-debug.php';

		if ( is_admin() ) {
			require_once SPDP_DIR . 'admin/class-spdp-admin.php';
		}

		add_action( 'init', array( $this, 'load_textdomain' ), 1 );
		add_action( 'plugins_loaded', array( $this, 'init_modules' ), 5 );

		register_activation_hook( SPDP_FILE, array( __CLASS__, 'on_activate' ) );
		register_deactivation_hook( SPDP_FILE, array( __CLASS__, 'on_deactivate' ) );
	}

	public function load_textdomain() {
		load_plugin_textdomain( 'speedpage', false, dirname( plugin_basename( SPDP_FILE ) ) . '/languages' );
	}

	public function init_modules() {
		// Repair settings written by an older version before reading them.
		SPDP_Options::maybe_upgrade();

		// Detection runs before anything reads SPDP_Context.
		SPDP_Builder_Detect::instance();

		$map = array(
			'context' => 'SPDP_Context',
			'perf'    => 'SPDP_Perf',
			'assets'  => 'SPDP_Assets',
			'images'  => 'SPDP_Images',
			'fonts'   => 'SPDP_Fonts',
			'html'    => 'SPDP_Html',
			'headers' => 'SPDP_Headers',
			'custom'  => 'SPDP_Custom_Theme',
			'woo'     => 'SPDP_Woo',
		);

		foreach ( $map as $key => $class ) {
			if ( ! class_exists( $class ) ) {
				continue;
			}

			/**
			 * Disable any single module:
			 *   add_filter( 'speedpage_module_images', '__return_false' );
			 */
			if ( ! apply_filters( "speedpage_module_{$key}", SPDP_Options::enabled( $key ) ) ) {
				continue;
			}

			$this->modules[ $key ] = $class::instance();
		}

		if ( is_admin() && class_exists( 'SPDP_Admin' ) ) {
			$this->modules['admin'] = SPDP_Admin::instance();
		}

		// Loaded last so its script counter sees every other module's output.
		if ( class_exists( 'SPDP_Debug' ) && SPDP_Debug::is_enabled() ) {
			SPDP_Debug::instance();
		}

		do_action( 'speedpage_loaded', $this );
	}

	/**
	 * @param string $key Module key.
	 * @return object|null
	 */
	public function module( $key ) {
		return isset( $this->modules[ $key ] ) ? $this->modules[ $key ] : null;
	}

	/**
	 * @return string[] Keys of the modules that actually initialised.
	 */
	public function active_modules() {
		return array_keys( $this->modules );
	}

	public static function on_activate() {
		require_once SPDP_DIR . 'includes/class-spdp-options.php';

		/*
		 * Carry settings over from the combined SEO + performance plugin this
		 * was split out of, if it is present and this one has never been
		 * configured. Someone who has already tuned deferral and lazy-loading
		 * once should not have to do it again because the folder name changed.
		 */
		SPDP_Options::import_legacy();
		SPDP_Options::install_defaults();
	}

	public static function on_deactivate() {}
}

SpeedPage::instance();

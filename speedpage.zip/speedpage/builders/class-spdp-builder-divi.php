<?php
/**
 * Divi Builder adapter.
 *
 * @package SpeedPage
 */

defined( 'ABSPATH' ) || exit;

class SPDP_Builder_Divi extends SPDP_Builder_Base {

	protected $slug  = 'divi';
	protected $label = 'Divi Builder';

	public function is_active() {
		return defined( 'ET_BUILDER_VERSION' ) || function_exists( 'et_setup_theme' );
	}

	public function built_with( $post_id ) {
		if ( ! $this->is_active() ) {
			return false;
		}
		if ( 'on' === get_post_meta( $post_id, '_et_pb_use_builder', true ) ) {
			return true;
		}
		$post = get_post( $post_id );
		return $post && false !== strpos( (string) $post->post_content, '[et_pb_section' );
	}

	public function is_editing() {
		if ( ! $this->is_active() ) {
			return false;
		}
		if ( $this->has_query_arg( array( 'et_fb', 'et_bfb' ) ) ) {
			return true;
		}
		if ( function_exists( 'et_core_is_fb_enabled' ) ) {
			return (bool) et_core_is_fb_enabled();
		}
		return false;
	}

	public function get_text( $post_id ) {
		$raw = parent::get_text( $post_id );
		$raw = spdp_preg_replace( '/\[\/?et_pb_[^\]]*\]/', ' ', $raw );
		return trim( (string) $raw );
	}

	public function protected_handles() {
		return array( 'divi-custom-script', 'et-builder-modules-script', 'et-core-common', 'magnific-popup', 'salvattore' );
	}

	public function protected_styles() {
		return array( 'divi-style', 'et-builder-modules-style', 'et-core-unified' );
	}
}

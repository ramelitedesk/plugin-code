<?php
/**
 * Beaver Builder adapter.
 *
 * @package SpeedPage
 */

defined( 'ABSPATH' ) || exit;

class SPDP_Builder_Beaver extends SPDP_Builder_Base {

	protected $slug  = 'beaver';
	protected $label = 'Beaver Builder';

	public function is_active() {
		return class_exists( 'FLBuilder' ) || defined( 'FL_BUILDER_VERSION' );
	}

	public function built_with( $post_id ) {
		if ( ! $this->is_active() ) {
			return false;
		}
		return (bool) get_post_meta( $post_id, '_fl_builder_enabled', true );
	}

	public function is_editing() {
		if ( ! $this->is_active() ) {
			return false;
		}
		if ( $this->has_query_arg( array( 'fl_builder', 'fl_builder_preview' ) ) ) {
			return true;
		}
		if ( class_exists( 'FLBuilderModel' ) && method_exists( 'FLBuilderModel', 'is_builder_active' ) ) {
			return (bool) FLBuilderModel::is_builder_active();
		}
		return false;
	}

	public function get_text( $post_id ) {
		$data = get_post_meta( $post_id, '_fl_builder_data', true );
		if ( ! is_array( $data ) ) {
			return parent::get_text( $post_id );
		}

		$text = '';
		foreach ( $data as $node ) {
			if ( ! is_object( $node ) || empty( $node->settings ) ) {
				continue;
			}
			foreach ( array( 'text', 'heading', 'title' ) as $key ) {
				if ( ! empty( $node->settings->{$key} ) && is_string( $node->settings->{$key} ) ) {
					$text .= ' ' . $node->settings->{$key};
				}
			}
			if ( mb_strlen( $text ) > 1200 ) {
				break;
			}
		}

		$text = trim( $text );
		return '' !== $text ? $text : parent::get_text( $post_id );
	}

	public function protected_handles() {
		return array( 'fl-builder-layout', 'jquery-bxslider', 'imagesloaded', 'fl-slideshow' );
	}

	public function protected_styles() {
		return array( 'fl-builder-layout', 'fl-builder-google-fonts' );
	}
}

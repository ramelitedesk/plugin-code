<?php
/**
 * Oxygen Builder adapter.
 *
 * @package SpeedPage
 */

defined( 'ABSPATH' ) || exit;

class SPDP_Builder_Oxygen extends SPDP_Builder_Base {

	protected $slug  = 'oxygen';
	protected $label = 'Oxygen Builder';

	public function is_active() {
		return defined( 'CT_VERSION' ) || function_exists( 'ct_template_output' );
	}

	public function built_with( $post_id ) {
		if ( ! $this->is_active() ) {
			return false;
		}
		return ! empty( get_post_meta( $post_id, 'ct_builder_shortcodes', true ) );
	}

	public function is_editing() {
		if ( ! $this->is_active() ) {
			return false;
		}
		return $this->has_query_arg( array( 'ct_builder', 'oxygen_iframe', 'ct_inner' ) );
	}

	public function get_text( $post_id ) {
		$raw = (string) get_post_meta( $post_id, 'ct_builder_shortcodes', true );
		if ( '' === $raw ) {
			return parent::get_text( $post_id );
		}
		$raw = spdp_preg_replace( '/\[\/?(?:ct_|oxy)[^\]]*\]/', ' ', $raw );
		return trim( (string) $raw );
	}

	public function protected_handles() {
		return array( 'oxygen-aos', 'ct-lightbox', 'oxygen-scripts' );
	}

	public function protected_styles() {
		return array( 'oxygen-styles', 'oxygen-universal-styles' );
	}
}

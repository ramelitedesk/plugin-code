<?php
/**
 * WPBakery Page Builder (Visual Composer) adapter.
 *
 * @package SpeedPage
 */

defined( 'ABSPATH' ) || exit;

class SPDP_Builder_WPBakery extends SPDP_Builder_Base {

	protected $slug  = 'wpbakery';
	protected $label = 'WPBakery Page Builder';

	public function is_active() {
		return defined( 'WPB_VC_VERSION' ) || class_exists( 'Vc_Manager' );
	}

	public function built_with( $post_id ) {
		if ( ! $this->is_active() ) {
			return false;
		}
		if ( 'true' === get_post_meta( $post_id, '_wpb_vc_js_status', true ) ) {
			return true;
		}
		$post = get_post( $post_id );
		return $post && false !== strpos( (string) $post->post_content, '[vc_row' );
	}

	public function is_editing() {
		if ( ! $this->is_active() ) {
			return false;
		}
		if ( $this->has_query_arg( array( 'vc_editable', 'vc_action', 'vc_inline' ) ) ) {
			return true;
		}
		if ( $this->is_ajax_action( 'vc_' ) ) {
			return true;
		}
		return function_exists( 'vc_is_inline' ) && vc_is_inline();
	}

	public function get_text( $post_id ) {
		$raw = parent::get_text( $post_id );
		// Strip the shortcode wrappers but keep the copy inside them.
		$raw = spdp_preg_replace( '/\[\/?vc_[^\]]*\]/', ' ', $raw );
		$raw = spdp_preg_replace( '/\[\/?(?:ult|rev_slider|trx)[^\]]*\]/', ' ', $raw );
		return trim( (string) $raw );
	}

	public function protected_handles() {
		return array( 'wpb_composer_front_js', 'vc_woocommerce-add-to-cart-js', 'isotope' );
	}

	public function protected_styles() {
		return array( 'js_composer_front', 'vc_font_awesome_5', 'vc_openiconic', 'animate-css' );
	}
}

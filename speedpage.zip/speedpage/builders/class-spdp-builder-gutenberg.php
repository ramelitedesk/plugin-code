<?php
/**
 * Core block editor (Gutenberg / FSE) adapter — also the graceful fallback for
 * sites with no third-party builder at all.
 *
 * @package SpeedPage
 */

defined( 'ABSPATH' ) || exit;

class SPDP_Builder_Gutenberg extends SPDP_Builder_Base {

	protected $slug  = 'gutenberg';
	protected $label = 'Block Editor';

	public function is_active() {
		return function_exists( 'has_blocks' );
	}

	public function built_with( $post_id ) {
		return function_exists( 'has_blocks' ) && has_blocks( $post_id );
	}

	public function is_editing() {
		// The block editor lives in wp-admin; the front end is plain HTML.
		return false;
	}

	public function get_text( $post_id ) {
		$post = get_post( $post_id );
		if ( ! $post ) {
			return '';
		}
		if ( function_exists( 'excerpt_remove_blocks' ) ) {
			return excerpt_remove_blocks( (string) $post->post_content );
		}
		return (string) $post->post_content;
	}

	public function get_hero_image_id( $post_id ) {
		$post = get_post( $post_id );
		if ( ! $post || ! function_exists( 'parse_blocks' ) ) {
			return 0;
		}
		foreach ( parse_blocks( (string) $post->post_content ) as $block ) {
			$name = isset( $block['blockName'] ) ? $block['blockName'] : '';
			if ( in_array( $name, array( 'core/image', 'core/cover', 'core/media-text' ), true ) && ! empty( $block['attrs']['id'] ) ) {
				return (int) $block['attrs']['id'];
			}
		}
		return 0;
	}

	public function protected_styles() {
		return array( 'wp-block-library', 'global-styles' );
	}
}

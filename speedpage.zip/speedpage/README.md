# SpeedPage

Page speed and Core Web Vitals optimisation for any WordPress site. Builder-aware, so an editor session is never optimised.

Split out of the WPD SEO & Performance Suite. This is the performance half; the SEO half is now the **SEO Fixing** plugin. They share nothing and can be installed independently.

---

## The rule everything here follows

**An optimisation that breaks the page is worse than no optimisation at all.**

A slow site still sells things. A site whose slider stopped moving because a script was deferred, or whose layout collapsed because the HTML was minified inside a builder's preview iframe, does not — and the person who notices is the one building the site, who will simply uninstall this.

So two things are true throughout:

- **The builder layer loads first** and tells every other module when to stand down. Editor and preview requests are never touched.
- **Every rewrite of the page can fail safely.** `spdp_preg_replace()` returns the original string whenever PCRE fails — invalid UTF-8 with the `/u` modifier, or a blown backtrack limit on a large page. Assigning `null` back to the page HTML is how an optimisation plugin serves a blank screen to visitors, and nobody finds out for days.

---

## What it does

### JavaScript
Defer scripts. Remove the emoji detector, `wp-embed.js`, jQuery Migrate and Dashicons. Throttle the heartbeat. Optionally hold every script until the first scroll, tap or key press.

### Images
Lazy-load below the fold — and, more importantly, *don't* lazy-load the hero. Lazy-loading the image someone is waiting to see makes Largest Contentful Paint worse, not better, so the hero is detected (asked of the builder first, because a builder hero is rarely the featured image) and loaded eagerly with `fetchpriority="high"`. Missing width and height are filled in so the layout does not jump.

### Fonts
`font-display: swap`, preload for the one or two faces used above the fold, preconnect for origins you are certain of.

### HTML
Whitespace and comments collapsed, leaving `script`, `style` and `pre` untouched. Optional inlined critical CSS. Long-lived cache headers on static assets.

### WooCommerce
Store CSS and JS dequeued on pages that are not part of the store, and the cart-fragments AJAX call — the most common single cause of a slow Woo TTFB — stopped where there is no cart on screen. **Cart, checkout and account pages are never optimised at any setting**, and neither is a visitor who already has something in their basket.

---

## Two settings to be careful with

| Setting | Why |
| --- | --- |
| **Delay until interaction** | The single biggest score improvement available and the single most likely thing here to break a slider, a sticky header, a chat widget or an analytics beacon. Off by default. Turn it on, load the site in a private window, and *use* it — do not judge it from the score. |
| **Block editor CSS** | Only safe on a theme that uses no block markup anywhere. |

---

## Install

1. Copy the folder to `wp-content/plugins/speedpage/` and activate.
2. Open **SpeedPage** and read the top panel before touching anything below it.
3. Apply the server config — `config/htaccess-rules.conf` or `config/nginx-rules.conf`.

If the SEO & Performance Suite was installed, your tuned performance settings are carried across on activation. SEO settings are not, and the plugin has no place to put them.

### The top panel is not decoration

A page cache, HTTP/2, compression and a current PHP version move the numbers further than every option on the settings screen combined. The plugin says so on its own screen rather than showing a green tick on a setting that is not the bottleneck.

---

## Diagnostics

```
https://example.com/?speedpage-debug=YOUR_TOKEN
```

Reports why the optimisation gate opened or closed, which scripts were deferred, delayed or left alone, and what the minifier saved. Most of the time the answer is "the gate was closed because you are logged in" — open it in a private window. The token is on the settings screen; treat it as a password, since the report prints file paths and asset URLs.

---

## Structure

```
speedpage/
├── speedpage.php                  Bootstrap: load order, module registry
├── includes/
│   ├── helpers.php                The optimisation gate, safe regex wrapper
│   ├── class-spdp-options.php     Settings, defaults, legacy import
│   ├── class-spdp-context.php     Page type and the LCP hero image
│   └── class-spdp-debug.php       The token-gated report
├── builders/                      Detection + one adapter per builder
├── performance/
│   ├── class-spdp-perf.php        Core dequeues, heartbeat
│   ├── class-spdp-assets.php      Deferral, delay-until-input, critical CSS
│   ├── class-spdp-images.php      Lazy loading, LCP priority, dimensions
│   ├── class-spdp-fonts.php       display:swap, preload, preconnect
│   ├── class-spdp-html.php        Minification
│   └── class-spdp-headers.php     Cache headers
├── custom/                        Viewport, lang, noopener for hand-coded themes
├── woocommerce/                   Store-aware asset control
├── admin/                         The settings screen
├── config/                        Server rules — outside PHP's reach
└── tests/                         Runnable without WordPress
```

---

## Tests

```bash
cd speedpage/tests
php smoke-test.php    # 66 cases
```

No WordPress, no database, no PHPUnit.

The cases that matter are the ones asserting a filter hands back the page unchanged when it cannot do its job — including invalid UTF-8, which is what actually blanks pages in the wild. There is also a set asserting that nothing SEO-shaped survived the split, and that a legacy import carries your settings without inventing any.

---

## Honest limits

- **A page cache beats all of this.** Nothing here moves Time to First Byte the way one does. Treat everything on the settings screen as what you do *after* that.
- **Compression and HTTP/2 are server settings.** PHP cannot turn them on. Hence `config/`.
- **Logged-in users see the unoptimised page** unless you filter `speedpage_optimize_logged_in`. They are the ones editing the site, and an admin bar that stopped working because its script was delayed is a support ticket, not a score.
- **Builder adapters are written against documented APIs** but verified here against stubs, not live installs. Test one save per builder you deploy to.

## Requirements

WordPress 5.8+, PHP 7.4+. No dependencies, no build step, no outbound calls.

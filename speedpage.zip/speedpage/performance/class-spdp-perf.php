<?php
/**
 * Core-Web-Vitals baseline: strip the front-end payload WordPress ships that
 * almost no site uses, and calm down background traffic.
 *
 * Everything here is reversible with a one-line filter, and nothing runs inside
 * a builder editor.
 *
 * @package SpeedPage
 */

defined( 'ABSPATH' ) || exit;

class SPDP_Perf {

	/** @var SPDP_Perf|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'init', array( $this, 'init' ), 20 );
		add_action( 'wp_enqueue_scripts', array( $this, 'late_cleanup' ), 100 );

		if ( SPDP_Options::enabled( 'heartbeat_throttle' ) ) {
			add_filter( 'heartbeat_settings', array( $this, 'throttle_heartbeat' ) );
			// Deliberately not on `init`: deregistering there forces WP_Scripts
			// to initialise before plugins have registered their own handles.
			add_action( 'wp_enqueue_scripts', array( $this, 'limit_heartbeat' ), 1 );
		}
	}

	public function init() {
		if ( ! spdp_should_optimize() ) {
			return;
		}

		if ( SPDP_Options::enabled( 'remove_emojis' ) ) {
			$this->disable_emojis();
		}
		if ( SPDP_Options::enabled( 'remove_embeds' ) ) {
			$this->disable_embeds();
		}

		// Head clutter with no SEO value and a small parse cost.
		remove_action( 'wp_head', 'wp_generator' );
		remove_action( 'wp_head', 'wlwmanifest_link' );
		remove_action( 'wp_head', 'rsd_link' );
		remove_action( 'wp_head', 'wp_shortlink_wp_head', 10 );
		remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10 );
		remove_action( 'wp_head', 'feed_links_extra', 3 );

		// DNS prefetch for s.w.org is dead weight once emojis are gone.
		add_filter( 'wp_resource_hints', array( $this, 'clean_resource_hints' ), 10, 2 );

		/*
		 * XML-RPC is dead weight on most sites, but Jetpack, the WordPress
		 * mobile apps and some backup/migration services authenticate through
		 * it. Disabling it under them looks like "the app stopped connecting"
		 * with nothing in the logs, so bail out when we can see one.
		 */
		$xmlrpc_in_use = class_exists( 'Jetpack' )
			|| defined( 'JETPACK__VERSION' )
			|| class_exists( 'Automattic\Jetpack\Connection\Manager' );

		if ( ! $xmlrpc_in_use && apply_filters( 'speedpage_disable_xmlrpc', true ) ) {
			add_filter( 'xmlrpc_enabled', '__return_false' );
			add_filter( 'wp_headers', array( $this, 'remove_pingback_header' ) );
			SPDP_Debug::log( 'note', 'xmlrpc', 'disabled' );
		}
	}

	/**
	 * Runs after every theme/plugin has enqueued, so handles actually exist.
	 */
	public function late_cleanup() {
		if ( ! spdp_should_optimize() ) {
			return;
		}

		// Dequeue only — deregistering breaks any style that lists dashicons
		// as a dependency (several popular plugins do).
		if ( SPDP_Options::enabled( 'disable_dashicons' ) && ! is_admin_bar_showing() ) {
			wp_dequeue_style( 'dashicons' );
			SPDP_Debug::log( 'asset', 'dashicons', 'dequeued' );
		}

		if ( SPDP_Options::enabled( 'jquery_migrate' ) ) {
			$jquery = wp_scripts()->registered['jquery'] ?? null;
			if ( $jquery && ! empty( $jquery->deps ) ) {
				$jquery->deps = array_diff( $jquery->deps, array( 'jquery-migrate' ) );
			}
		}

		if ( SPDP_Options::enabled( 'remove_block_css' ) && ! $this->page_uses_blocks() ) {
			wp_dequeue_style( 'wp-block-library' );
			wp_dequeue_style( 'wp-block-library-theme' );
			wp_dequeue_style( 'classic-theme-styles' );
			wp_dequeue_style( 'global-styles' );
		}

		/**
		 * Extra handles to drop on the front end:
		 *   add_filter( 'speedpage_dequeue_styles', fn( $h ) => array_merge( $h, [ 'contact-form-7' ] ) );
		 */
		foreach ( (array) apply_filters( 'speedpage_dequeue_styles', array() ) as $handle ) {
			wp_dequeue_style( $handle );
		}
		foreach ( (array) apply_filters( 'speedpage_dequeue_scripts', array() ) as $handle ) {
			wp_dequeue_script( $handle );
		}
	}

	/**
	 * @return bool
	 */
	private function page_uses_blocks() {
		$post_id = get_queried_object_id();
		if ( ! $post_id || ! function_exists( 'has_blocks' ) ) {
			return true; // Be conservative.
		}
		return has_blocks( $post_id );
	}

	private function disable_emojis() {
		remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
		remove_action( 'wp_print_styles', 'print_emoji_styles' );
		remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
		remove_action( 'admin_print_styles', 'print_emoji_styles' );
		remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
		remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
		remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
		add_filter( 'tiny_mce_plugins', array( $this, 'remove_tinymce_emoji' ) );
		add_filter( 'emoji_svg_url', '__return_false' );
	}

	/**
	 * @param array $plugins TinyMCE plugins.
	 * @return array
	 */
	public function remove_tinymce_emoji( $plugins ) {
		return is_array( $plugins ) ? array_diff( $plugins, array( 'wpemoji' ) ) : array();
	}

	private function disable_embeds() {
		remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
		remove_action( 'wp_head', 'wp_oembed_add_host_js' );
		add_filter( 'embed_oembed_discover', '__return_false' );
		add_action(
			'wp_footer',
			function () {
				wp_dequeue_script( 'wp-embed' );
			},
			1
		);
	}

	/**
	 * @param array  $hints    URLs.
	 * @param string $relation Hint type.
	 * @return array
	 */
	public function clean_resource_hints( $hints, $relation ) {
		if ( 'dns-prefetch' !== $relation ) {
			return $hints;
		}
		return array_values(
			array_filter(
				$hints,
				static function ( $hint ) {
					$url = is_array( $hint ) ? ( $hint['href'] ?? '' ) : $hint;
					return false === strpos( (string) $url, 's.w.org' );
				}
			)
		);
	}

	/**
	 * @param array $headers Response headers.
	 * @return array
	 */
	public function remove_pingback_header( $headers ) {
		unset( $headers['X-Pingback'] );
		return $headers;
	}

	/**
	 * @param array $settings Heartbeat settings.
	 * @return array
	 */
	public function throttle_heartbeat( $settings ) {
		$settings['interval'] = (int) apply_filters( 'speedpage_heartbeat_interval', 60 );
		return $settings;
	}

	/**
	 * The front end has no use for the heartbeat at all; the post editor does.
	 */
	public function limit_heartbeat() {
		if ( is_admin() ) {
			return;
		}
		/*
		 * Dequeue, never deregister. Deregistering removes the handle, and any
		 * plugin script that declares 'heartbeat' as a dependency then fails to
		 * enqueue at all — silently taking that plugin's front end with it.
		 */
		wp_dequeue_script( 'heartbeat' );
		SPDP_Debug::log( 'asset', 'heartbeat', 'dequeued on front end' );
	}
}

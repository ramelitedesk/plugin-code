<?php
/**
 * Web font handling: preload the fonts that render above the fold, force
 * font-display:swap so text is never invisible, and open connections to font
 * hosts early.
 *
 * @package SpeedPage
 */

defined( 'ABSPATH' ) || exit;

class SPDP_Fonts {

	/** @var SPDP_Fonts|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_head', array( $this, 'preconnect' ), 1 );
		add_action( 'wp_head', array( $this, 'preload_fonts' ), 3 );

		if ( SPDP_Options::enabled( 'font_display_swap' ) ) {
			add_filter( 'style_loader_tag', array( $this, 'force_swap_on_google_fonts' ), 10, 4 );
			add_action( 'wp_head', array( $this, 'font_display_override' ), 4 );
		}
	}

	/**
	 * preconnect (not just dns-prefetch) saves the TLS handshake on the
	 * critical path for the font host.
	 */
	public function preconnect() {
		if ( ! spdp_should_optimize() ) {
			return;
		}

		$hosts = SPDP_Options::lines( 'preconnect' );

		/**
		 * @param string[] $hosts Origins to preconnect to.
		 */
		$hosts = (array) apply_filters( 'speedpage_preconnect', $hosts );

		foreach ( array_unique( $hosts ) as $host ) {
			$host = esc_url_raw( trim( $host ) );
			if ( '' === $host ) {
				continue;
			}
			$crossorigin = ( false !== strpos( $host, 'gstatic' ) || false !== strpos( $host, 'fonts' ) ) ? ' crossorigin' : '';
			printf( '<link rel="preconnect" href="%s"%s />' . "\n", esc_url( $host ), $crossorigin ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}

	/**
	 * Preload self-hosted woff2 files. One or two faces only — preloading every
	 * weight is a net loss.
	 */
	public function preload_fonts() {
		if ( ! spdp_should_optimize() ) {
			return;
		}

		$fonts = SPDP_Options::lines( 'preload_fonts' );

		/**
		 * @param string[] $fonts Absolute or site-relative font URLs.
		 */
		$fonts = (array) apply_filters( 'speedpage_preload_fonts', $fonts );

		$count = 0;
		foreach ( $fonts as $font ) {
			if ( $count >= 4 ) {
				break; // Hard stop: more preloads than this hurt.
			}
			$url = spdp_absolute_url( $font );
			if ( '' === $url ) {
				continue;
			}
			$ext  = strtolower( pathinfo( wp_parse_url( $url, PHP_URL_PATH ), PATHINFO_EXTENSION ) );
			$type = 'woff2' === $ext ? 'font/woff2' : ( 'woff' === $ext ? 'font/woff' : 'font/' . $ext );

			printf(
				'<link rel="preload" as="font" type="%s" href="%s" crossorigin />' . "\n",
				esc_attr( $type ),
				esc_url( $url )
			);
			$count++;
		}
	}

	/**
	 * Google Fonts URLs without &display=swap block text rendering for up to
	 * 3 seconds. Append it if the theme forgot.
	 *
	 * @param string $tag    Link tag.
	 * @param string $handle Handle.
	 * @param string $href   URL.
	 * @param string $media  Media.
	 * @return string
	 */
	public function force_swap_on_google_fonts( $tag, $handle, $href, $media ) {
		if ( false === strpos( $href, 'fonts.googleapis.com' ) ) {
			return $tag;
		}
		if ( false !== strpos( $href, 'display=' ) ) {
			return $tag;
		}
		$new = add_query_arg( 'display', 'swap', $href );
		return str_replace( $href, $new, $tag );
	}

	/**
	 * Catch-all for @font-face blocks printed by themes/builders: this cannot
	 * rewrite their CSS, so it declares the descriptor at the document level
	 * for any face the browser has not already resolved.
	 */
	public function font_display_override() {
		if ( ! spdp_should_optimize() ) {
			return;
		}
		$families = (array) apply_filters( 'speedpage_swap_families', array() );
		if ( ! $families ) {
			return;
		}

		$css = '';
		foreach ( $families as $family => $url ) {
			$css .= sprintf(
				'@font-face{font-family:%s;src:url(%s) format("woff2");font-display:swap;}',
				wp_json_encode( (string) $family ),
				esc_url( $url )
			);
		}
		printf( '<style id="spdp-font-display">%s</style>' . "\n", $css ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- values escaped above.
	}
}

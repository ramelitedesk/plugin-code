<?php
/**
 * Image handling for LCP and CLS.
 *
 * Three jobs:
 *   1. The LCP image must NOT be lazy-loaded, and should carry fetchpriority.
 *   2. Everything below the fold must be lazy + async-decoded.
 *   3. Every img needs width/height so the browser reserves space (CLS).
 *
 * @package SpeedPage
 */

defined( 'ABSPATH' ) || exit;

class SPDP_Images {

	/** @var SPDP_Images|null */
	private static $instance = null;

	/** @var int Images seen so far in this request. */
	private $seen = 0;

	/** @var bool Whether the LCP hint has been emitted. */
	private $lcp_done = false;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		if ( SPDP_Options::enabled( 'lcp_priority' ) ) {
			add_action( 'wp_head', array( $this, 'preload_lcp_image' ), 2 );
			add_filter( 'wp_get_attachment_image_attributes', array( $this, 'attachment_attributes' ), 20, 3 );
		}

		if ( SPDP_Options::enabled( 'lazy_images' ) ) {
			add_filter( 'wp_lazy_loading_enabled', array( $this, 'enable_core_lazy' ), 10, 3 );
			add_filter( 'the_content', array( $this, 'process_content_images' ), 25 );
			add_filter( 'post_thumbnail_html', array( $this, 'process_content_images' ), 25 );
			add_filter( 'speedpage_html', array( $this, 'process_content_images' ), 20 );
		}

		if ( SPDP_Options::enabled( 'add_dimensions' ) ) {
			add_filter( 'wp_get_attachment_image_attributes', array( $this, 'ensure_dimensions' ), 21, 3 );
		}

		// Iframes (YouTube embeds etc.) are a classic LCP/TBT drag.
		add_filter( 'embed_oembed_html', array( $this, 'lazy_iframe' ), 20 );
	}

	/**
	 * Preload the hero image so it starts downloading in the first round trip.
	 */
	public function preload_lcp_image() {
		if ( ! spdp_should_optimize() ) {
			return;
		}

		$image_id = SPDP_Context::instance()->image_id();
		if ( ! $image_id ) {
			return;
		}

		$src = wp_get_attachment_image_src( $image_id, 'full' );
		if ( ! $src ) {
			return;
		}

		$srcset = wp_get_attachment_image_srcset( $image_id, 'full' );
		$sizes  = wp_get_attachment_image_sizes( $image_id, 'full' );

		printf(
			'<link rel="preload" as="image" href="%s"%s%s fetchpriority="high" />' . "\n",
			esc_url( $src[0] ),
			$srcset ? ' imagesrcset="' . esc_attr( $srcset ) . '"' : '',
			$sizes ? ' imagesizes="' . esc_attr( $sizes ) . '"' : ''
		);

		$this->lcp_done = true;
	}

	/**
	 * Core's own lazy-loading is fine — we only steer the first image.
	 *
	 * @param bool   $enabled  Whether to lazy-load.
	 * @param string $tag_name Tag being filtered.
	 * @param string $context  Filter context.
	 * @return bool
	 */
	public function enable_core_lazy( $enabled, $tag_name, $context ) {
		if ( ! spdp_should_optimize() ) {
			return $enabled;
		}
		if ( 'img' === $tag_name && 'wp_get_attachment_image' === $context && $this->seen < 1 ) {
			return false;
		}
		return $enabled;
	}

	/**
	 * @param array        $attr       Attributes.
	 * @param WP_Post      $attachment Attachment.
	 * @param string|array $size       Size.
	 * @return array
	 */
	public function attachment_attributes( $attr, $attachment, $size ) {
		if ( ! spdp_should_optimize() ) {
			return $attr;
		}

		$this->seen++;

		$hero = SPDP_Context::instance()->image_id();
		if ( $hero && (int) $attachment->ID === (int) $hero ) {
			$attr['fetchpriority'] = 'high';
			$attr['loading']       = 'eager';
			$attr['decoding']      = 'sync';
			unset( $attr['data-spdp-lazy'] );
			return $attr;
		}

		if ( empty( $attr['loading'] ) ) {
			$attr['loading'] = 'lazy';
		}
		if ( empty( $attr['decoding'] ) ) {
			$attr['decoding'] = 'async';
		}

		return $attr;
	}

	/**
	 * Fill in missing width/height from the attachment metadata.
	 *
	 * @param array        $attr       Attributes.
	 * @param WP_Post      $attachment Attachment.
	 * @param string|array $size       Size.
	 * @return array
	 */
	public function ensure_dimensions( $attr, $attachment, $size ) {
		if ( ! empty( $attr['width'] ) && ! empty( $attr['height'] ) ) {
			return $attr;
		}
		$src = wp_get_attachment_image_src( $attachment->ID, $size );
		if ( $src && ! empty( $src[1] ) && ! empty( $src[2] ) ) {
			$attr['width']  = $src[1];
			$attr['height'] = $src[2];
		}
		return $attr;
	}

	/**
	 * Post-process raw HTML (content or full page): first image eager + high
	 * priority, the rest lazy + async decode.
	 *
	 * Builder markup goes through here too, which is why it is regex over the
	 * rendered output rather than a hook on the builder's own render pipeline.
	 *
	 * @param string $html HTML.
	 * @return string
	 */
	public function process_content_images( $html ) {
		if ( ! spdp_should_optimize() || '' === trim( (string) $html ) ) {
			return $html;
		}
		if ( false === stripos( $html, '<img' ) ) {
			return $html;
		}

		$html = preg_replace_callback(
			'/<img\s[^>]*>/i',
			function ( $matches ) {
				$tag = $matches[0];

				$label = preg_match( '/src=["\']([^"\']+)["\']/i', $tag, $m ) ? basename( $m[1] ) : 'image';

				// Skip anything a builder or plugin already manages.
				if ( preg_match( '/data-(src|lazy-src|bg|skip-lazy)=/i', $tag ) || false !== stripos( $tag, 'skip-lazy' ) ) {
					SPDP_Debug::log( 'image', $label, 'skipped — another lazy loader owns it' );
					return $tag;
				}

				$this->seen++;
				$is_lcp = ( 1 === $this->seen );

				if ( ! preg_match( '/\swidth=/i', $tag ) || ! preg_match( '/\sheight=/i', $tag ) ) {
					SPDP_Debug::log( 'image', $label, 'no width/height in markup — possible layout shift' );
				}

				SPDP_Debug::log( 'image', $label, $is_lcp ? 'LCP candidate — eager + fetchpriority=high' : 'lazy + decoding=async' );

				if ( $is_lcp ) {
					$tag = $this->set_attr( $tag, 'loading', 'eager' );
					$tag = $this->set_attr( $tag, 'fetchpriority', 'high' );
					$tag = $this->set_attr( $tag, 'decoding', 'sync' );
				} else {
					if ( ! preg_match( '/\sloading=/i', $tag ) ) {
						$tag = $this->set_attr( $tag, 'loading', 'lazy' );
					}
					if ( ! preg_match( '/\sdecoding=/i', $tag ) ) {
						$tag = $this->set_attr( $tag, 'decoding', 'async' );
					}
				}

				return $tag;
			},
			$html
		);

		return (string) $html;
	}

	/**
	 * @param string $html Iframe HTML.
	 * @return string
	 */
	public function lazy_iframe( $html ) {
		if ( ! spdp_should_optimize() || false === stripos( (string) $html, '<iframe' ) ) {
			return $html;
		}
		if ( false !== stripos( $html, 'loading=' ) ) {
			return $html;
		}
		return str_ireplace( '<iframe ', '<iframe loading="lazy" ', $html );
	}

	/**
	 * Set (or replace) one attribute on a tag string.
	 *
	 * @param string $tag   Tag HTML.
	 * @param string $name  Attribute name.
	 * @param string $value Attribute value.
	 * @return string
	 */
	private function set_attr( $tag, $name, $value ) {
		$pattern = '/\s' . preg_quote( $name, '/' ) . '=("|\')[^"\']*\1/i';
		if ( preg_match( $pattern, $tag ) ) {
			return spdp_preg_replace( $pattern, ' ' . $name . '="' . $value . '"', $tag );
		}
		return spdp_preg_replace( '/<img\s/i', '<img ' . $name . '="' . $value . '" ', $tag, 1 );
	}
}

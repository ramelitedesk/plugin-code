<?php
/**
 * Removing the plugin's data when it is deleted.
 *
 * @package WPD_Dynamic_Pricing
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'wcdp_fingerprint' );

/*
 * The rules themselves are left alone.
 *
 * They are posts. Somebody who spent an afternoon building a season's pricing
 * is entitled to deactivate the plugin, work out whether it was the cause of
 * something, reinstall, and find their rules still there. WordPress does not
 * delete a post type's posts when its plugin goes, and neither does this.
 *
 * Deleting them is a decision for the person doing it, made from the Pricing
 * Rules screen — not a side effect of uninstalling.
 *
 * Nothing is left running either way: with the plugin gone, nothing reads them
 * and no price is affected.
 */

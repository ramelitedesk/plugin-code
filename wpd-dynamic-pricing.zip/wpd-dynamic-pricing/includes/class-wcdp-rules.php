<?php
/**
 * What a rule is, where it lives, and how it is cleaned on the way in.
 *
 * One schema, one sanitiser. Sanitising in two places is how one of them ends
 * up weaker than the other, and on a plugin that sets prices the weaker one is
 * the one that lets a -200% discount through.
 *
 * @package WPD_Dynamic_Pricing
 */

defined( 'ABSPATH' ) || exit;

class WCDP_Rules {

	const POST_TYPE = 'wcdp_rule';

	const META = '_wcdp_rule';

	/** Bumped whenever any rule changes, and mixed into every cache key. */
	const FINGERPRINT = 'wcdp_fingerprint';

	/** @var array<int,array>|null Rules read this request. */
	private static $cache = null;

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ), 5 );

		/*
		 * Any change to a rule invalidates every price WooCommerce has cached.
		 * Bumping a fingerprint that is mixed into the cache keys is cheaper and
		 * safer than trying to find and delete the transients — WooCommerce
		 * makes one per variable product per price-hash, and a big shop has
		 * thousands.
		 */
		add_action( 'save_post_' . self::POST_TYPE, array( __CLASS__, 'bump_fingerprint' ) );
		add_action( 'deleted_post', array( __CLASS__, 'bump_fingerprint' ) );
		add_action( 'trashed_post', array( __CLASS__, 'bump_fingerprint' ) );
		add_action( 'untrashed_post', array( __CLASS__, 'bump_fingerprint' ) );
	}

	public static function register() {
		register_post_type(
			self::POST_TYPE,
			array(
				'labels'          => array(
					'name'               => __( 'Pricing Rules', 'wpd-dynamic-pricing' ),
					'singular_name'      => __( 'Pricing Rule', 'wpd-dynamic-pricing' ),
					'add_new'            => __( 'Add New', 'wpd-dynamic-pricing' ),
					'add_new_item'       => __( 'Add Pricing Rule', 'wpd-dynamic-pricing' ),
					'edit_item'          => __( 'Edit Pricing Rule', 'wpd-dynamic-pricing' ),
					'search_items'       => __( 'Search Rules', 'wpd-dynamic-pricing' ),
					'not_found'          => __( 'No pricing rules yet.', 'wpd-dynamic-pricing' ),
					'not_found_in_trash' => __( 'Nothing in the bin.', 'wpd-dynamic-pricing' ),
				),
				'public'          => false,
				'show_ui'         => true,
				'show_in_menu'    => 'woocommerce',
				'supports'        => array( 'title', 'page-attributes' ),
				'capability_type' => 'shop_order',
				'map_meta_cap'    => true,
				// The whole rule is one meta array the block editor cannot see,
				// so opening one in Gutenberg would show an empty document.
				'show_in_rest'    => false,
			)
		);
	}

	/* ------------------------------------------------------------------ *
	 * Schema
	 * ------------------------------------------------------------------ */

	/**
	 * @return array A brand new rule.
	 */
	public static function defaults() {
		return array(
			'enabled'   => 1,

			// simple | bulk | cart | bogo
			'type'      => 'simple',

			/*
			 * Lower runs first. Ties break on post ID so the order is stable —
			 * without that, two rules of the same priority swap places between
			 * requests and the price flickers.
			 */
			'priority'  => 10,

			// Stop considering later rules for any product this one matched.
			'exclusive' => 0,

			'label'     => '',

			'apply_to'  => array(
				// all | products | categories | tags
				'mode'               => 'all',
				'products'           => array(),
				'categories'         => array(),
				'tags'               => array(),
				'exclude_products'   => array(),
				'exclude_categories' => array(),
				/*
				 * On by default, and it is the single most consequential
				 * default here. Stacking a rule on top of a product that is
				 * already reduced is how a £40 jacket ends up at £14 during a
				 * sale nobody authorised.
				 */
				'exclude_on_sale'    => 1,
			),

			'who'       => array(
				// everyone | roles | users | guests
				'mode'  => 'everyone',
				'roles' => array(),
				'users' => array(),
			),

			'when'      => array(
				'start' => '',
				'end'   => '',
				// 0 = Sunday. Empty means any day.
				'days'  => array(),
			),

			// For type = simple. method: percent | amount | fixed
			'adjust'    => array(
				'method' => 'percent',
				'value'  => 0,
			),

			// For type = bulk. Each tier: min, max (0 = no ceiling), method, value.
			'tiers'     => array(),

			/*
			 * How the quantity for a tier is counted:
			 *   line     — this product's own quantity in the cart
			 *   matched  — every cart line this rule matches, added together
			 *
			 * "matched" is what makes "any 3 shirts for 10% off" work. Counting
			 * per line would require three of the SAME shirt.
			 */
			'tier_scope' => 'line',

			// For type = cart. basis: subtotal | quantity
			'cart'      => array(
				'basis' => 'subtotal',
				'min'   => 0,
				'max'   => 0,
			),

			// For type = bogo.
			'bogo'      => array(
				'buy'    => 2,
				'get'    => 1,
				'method' => 'percent',
				'value'  => 100,
				// Whether the offer applies again at 4, 6, 8 …
				'repeat' => 1,
			),

			'limits'    => array(
				// A ceiling on what one rule can take off a line, in store
				// currency. 0 means no ceiling.
				'max_discount' => 0,
			),
		);
	}

	/* ------------------------------------------------------------------ *
	 * Reading
	 * ------------------------------------------------------------------ */

	/**
	 * Every enabled rule, in the order they should be considered.
	 *
	 * @return array[] Each with an 'id' key.
	 */
	public static function active() {
		if ( null !== self::$cache ) {
			return self::$cache;
		}

		$ids = get_posts(
			array(
				'post_type'        => self::POST_TYPE,
				'post_status'      => 'publish',
				'numberposts'      => 200,
				'fields'           => 'ids',
				'orderby'          => array(
					'menu_order' => 'ASC',
					'ID'         => 'ASC',
				),
				'no_found_rows'    => true,
				'suppress_filters' => false,
			)
		);

		$rules = array();

		foreach ( (array) $ids as $id ) {
			$rule = self::get( $id );

			if ( ! empty( $rule['enabled'] ) ) {
				$rules[] = $rule;
			}
		}

		usort(
			$rules,
			static function ( $a, $b ) {
				// ID breaks the tie, so the order never changes between two
				// requests with the same rules.
				return array( $a['priority'], $a['id'] ) <=> array( $b['priority'], $b['id'] );
			}
		);

		self::$cache = $rules;

		return $rules;
	}

	/**
	 * @param int $id Rule post id.
	 * @return array
	 */
	public static function get( $id ) {
		$stored = get_post_meta( (int) $id, self::META, true );

		$rule = self::merge( is_array( $stored ) ? $stored : array() );

		$rule['id']    = (int) $id;
		$rule['title'] = get_the_title( $id );

		return $rule;
	}

	/**
	 * Build a complete rule from a partial one.
	 *
	 * Public because more than one thing needs it: the reader, the test suite,
	 * and any code that wants to ask "what would this rule do" without saving
	 * it first. Everything goes through the same merge, so a rule assembled by
	 * hand behaves exactly like one read from the database.
	 *
	 * @param array $partial Some or all of a rule.
	 * @return array
	 */
	public static function from_array( array $partial ) {
		$rule = self::merge( $partial );

		$rule['id']    = (int) ( $partial['id'] ?? 0 );
		$rule['title'] = (string) ( $partial['title'] ?? '' );

		return $rule;
	}

	/**
	 * Fill in whatever a stored rule is missing.
	 *
	 * Group by group rather than one flat merge: a flat merge replaces a whole
	 * group, so a rule saved before a new key existed comes back without it and
	 * the engine reads null where it expects a number.
	 *
	 * @param array $stored From the database.
	 * @return array
	 */
	private static function merge( array $stored ) {
		$rule = self::defaults();

		foreach ( array( 'apply_to', 'who', 'when', 'adjust', 'cart', 'bogo', 'limits' ) as $group ) {
			if ( isset( $stored[ $group ] ) && is_array( $stored[ $group ] ) ) {
				$rule[ $group ] = array_merge( $rule[ $group ], $stored[ $group ] );
			}
		}

		foreach ( array( 'enabled', 'type', 'priority', 'exclusive', 'label', 'tier_scope' ) as $key ) {
			if ( isset( $stored[ $key ] ) ) {
				$rule[ $key ] = $stored[ $key ];
			}
		}

		if ( ! empty( $stored['tiers'] ) && is_array( $stored['tiers'] ) ) {
			$rule['tiers'] = $stored['tiers'];
		}

		return $rule;
	}

	/* ------------------------------------------------------------------ *
	 * Writing
	 * ------------------------------------------------------------------ */

	/**
	 * Clean and store one rule.
	 *
	 * @param int   $id  Rule post id.
	 * @param array $raw Unsanitised input.
	 */
	public static function save( $id, array $raw ) {
		$clean = self::defaults();

		$clean['enabled']   = empty( $raw['enabled'] ) ? 0 : 1;
		$clean['exclusive'] = empty( $raw['exclusive'] ) ? 0 : 1;
		$clean['label']     = sanitize_text_field( $raw['label'] ?? '' );

		$clean['type'] = in_array( $raw['type'] ?? '', array( 'simple', 'bulk', 'cart', 'bogo' ), true )
			? $raw['type']
			: 'simple';

		$clean['priority'] = max( 0, min( 999, (int) ( $raw['priority'] ?? 10 ) ) );

		$clean['tier_scope'] = ( 'matched' === ( $raw['tier_scope'] ?? '' ) ) ? 'matched' : 'line';

		/* ---------------- what it applies to ---------------- */

		$clean['apply_to']['mode'] = in_array( $raw['apply_to']['mode'] ?? '', array( 'all', 'products', 'categories', 'tags' ), true )
			? $raw['apply_to']['mode']
			: 'all';

		foreach ( array( 'products', 'categories', 'tags', 'exclude_products', 'exclude_categories' ) as $list ) {
			$clean['apply_to'][ $list ] = self::ids( $raw['apply_to'][ $list ] ?? array() );
		}

		$clean['apply_to']['exclude_on_sale'] = empty( $raw['apply_to']['exclude_on_sale'] ) ? 0 : 1;

		/* ---------------- who it applies to ---------------- */

		$clean['who']['mode'] = in_array( $raw['who']['mode'] ?? '', array( 'everyone', 'roles', 'users', 'guests' ), true )
			? $raw['who']['mode']
			: 'everyone';

		$roles = array();

		foreach ( (array) ( $raw['who']['roles'] ?? array() ) as $role ) {
			$role = sanitize_key( $role );

			// Only roles this site really has. A rule naming a role that was
			// deleted matches nobody and looks like it should match somebody.
			if ( '' !== $role && ( wp_roles()->is_role( $role ) || 'guest' === $role ) ) {
				$roles[] = $role;
			}
		}

		$clean['who']['roles'] = array_values( array_unique( $roles ) );
		$clean['who']['users'] = self::ids( $raw['who']['users'] ?? array() );

		/* ---------------- when ---------------- */

		foreach ( array( 'start', 'end' ) as $bound ) {
			$value = trim( (string) ( $raw['when'][ $bound ] ?? '' ) );

			// Stored as the store's local time, in a shape strtotime and the
			// datetime-local input both accept.
			$clean['when'][ $bound ] = preg_match( '/^\d{4}-\d{2}-\d{2}([T ]\d{2}:\d{2})?$/', $value )
				? str_replace( 'T', ' ', $value )
				: '';
		}

		$days = array();

		foreach ( (array) ( $raw['when']['days'] ?? array() ) as $day ) {
			$day = (int) $day;

			if ( $day >= 0 && $day <= 6 ) {
				$days[] = $day;
			}
		}

		sort( $days );

		$clean['when']['days'] = array_values( array_unique( $days ) );

		/* ---------------- the money ---------------- */

		$clean['adjust'] = self::adjustment( $raw['adjust'] ?? array() );

		$tiers = array();

		foreach ( (array) ( $raw['tiers'] ?? array() ) as $tier ) {
			if ( ! is_array( $tier ) ) {
				continue;
			}

			$min = max( 1, (int) ( $tier['min'] ?? 0 ) );
			$max = max( 0, (int) ( $tier['max'] ?? 0 ) );

			// A ceiling below the floor can never be satisfied, so the tier
			// would sit in the editor looking configured and never fire.
			if ( $max > 0 && $max < $min ) {
				$max = 0;
			}

			$tiers[] = array_merge(
				array(
					'min' => $min,
					'max' => $max,
				),
				self::adjustment( $tier )
			);
		}

		// Sorted by threshold, so the engine can take the last match and stop
		// rather than comparing every tier against every other.
		usort(
			$tiers,
			static function ( $a, $b ) {
				return $a['min'] <=> $b['min'];
			}
		);

		$clean['tiers'] = $tiers;

		/* ---------------- cart-level ---------------- */

		$clean['cart']['basis'] = ( 'quantity' === ( $raw['cart']['basis'] ?? '' ) ) ? 'quantity' : 'subtotal';
		$clean['cart']['min']   = max( 0, (float) ( $raw['cart']['min'] ?? 0 ) );
		$clean['cart']['max']   = max( 0, (float) ( $raw['cart']['max'] ?? 0 ) );

		if ( $clean['cart']['max'] > 0 && $clean['cart']['max'] < $clean['cart']['min'] ) {
			$clean['cart']['max'] = 0;
		}

		/* ---------------- buy X get Y ---------------- */

		$clean['bogo']['buy']    = max( 1, (int) ( $raw['bogo']['buy'] ?? 1 ) );
		$clean['bogo']['get']    = max( 1, (int) ( $raw['bogo']['get'] ?? 1 ) );
		$clean['bogo']['repeat'] = empty( $raw['bogo']['repeat'] ) ? 0 : 1;

		$bogo_adjust              = self::adjustment( $raw['bogo'] ?? array() );
		$clean['bogo']['method']  = $bogo_adjust['method'];
		$clean['bogo']['value']   = $bogo_adjust['value'];

		/* ---------------- limits ---------------- */

		$clean['limits']['max_discount'] = max( 0, (float) ( $raw['limits']['max_discount'] ?? 0 ) );

		update_post_meta( (int) $id, self::META, $clean );

		// menu_order carries the priority so the list table can sort on it
		// without unserialising every rule.
		wp_update_post(
			array(
				'ID'         => (int) $id,
				'menu_order' => $clean['priority'],
			)
		);

		self::$cache = null;

		self::bump_fingerprint();
	}

	/**
	 * One adjustment, clamped to something that cannot produce a negative price.
	 *
	 * @param array $raw method, value.
	 * @return array{method:string,value:float}
	 */
	public static function adjustment( array $raw ) {
		$method = in_array( $raw['method'] ?? '', array( 'percent', 'amount', 'fixed' ), true )
			? $raw['method']
			: 'percent';

		$value = (float) ( $raw['value'] ?? 0 );

		// Never negative: a "-10% discount" is a price increase, and somebody
		// typing a minus sign because the field says "discount" would raise
		// every price in the shop.
		$value = max( 0, $value );

		if ( 'percent' === $method ) {
			// 100% is free. Above that is meaningless, and the engine floors at
			// zero anyway — but clamping here means the editor shows the number
			// that will actually be used.
			$value = min( 100, $value );
		}

		return array(
			'method' => $method,
			'value'  => $value,
		);
	}

	/**
	 * @param mixed $value Untrusted list of ids.
	 * @return int[]
	 */
	private static function ids( $value ) {
		if ( is_string( $value ) ) {
			$value = explode( ',', $value );
		}

		$ids = array();

		foreach ( (array) $value as $id ) {
			$id = absint( $id );

			if ( $id ) {
				$ids[] = $id;
			}
		}

		return array_values( array_unique( $ids ) );
	}

	/* ------------------------------------------------------------------ *
	 * Cache invalidation
	 * ------------------------------------------------------------------ */

	/**
	 * A short string that changes whenever any rule does.
	 *
	 * Mixed into WooCommerce's variation price hash and into this plugin's own
	 * per-request memoisation. Changing a rule then has to change every cached
	 * price, and this is the cheap way to do that — the alternative is finding
	 * and deleting one transient per variable product.
	 *
	 * @return string
	 */
	public static function fingerprint() {
		$value = get_option( self::FINGERPRINT );

		if ( ! is_string( $value ) || '' === $value ) {
			/*
			 * Creating the first one must NOT flush the rule cache, and this is
			 * not a subtlety — it was a bug.
			 *
			 * fingerprint() is a read, called from inside cache_key() while a
			 * price is being worked out. When it flushed, the rules loaded a
			 * moment earlier were thrown away in the middle of pricing, and on
			 * a fresh install the very first price of the day came back with no
			 * rules applied at all. A read that mutates state is how that
			 * happens; the mutation now lives only in the writer.
			 */
			$value = self::mint_fingerprint();
		}

		return $value;
	}

	/**
	 * Store a new fingerprint, and nothing else.
	 *
	 * @return string
	 */
	private static function mint_fingerprint() {
		$value = substr( md5( uniqid( 'wcdp', true ) ), 0, 12 );

		update_option( self::FINGERPRINT, $value, true );

		return $value;
	}

	/**
	 * A rule changed: new fingerprint, and forget what was loaded.
	 *
	 * Hooked to save, delete and trash — the only moments when the rules this
	 * request loaded are genuinely out of date.
	 *
	 * @return string The new fingerprint.
	 */
	public static function bump_fingerprint() {
		self::$cache = null;

		return self::mint_fingerprint();
	}

	/**
	 * Forget this request's rules. Tests, and after a save.
	 */
	public static function flush() {
		self::$cache = null;
	}

	/**
	 * Load a specific set of rules. Tests only.
	 *
	 * @param array[] $rules Rules.
	 */
	public static function seed( array $rules ) {
		$prepared = array();

		foreach ( $rules as $index => $rule ) {
			$merged = self::from_array( $rule );

			if ( ! $merged['id'] ) {
				$merged['id'] = $index + 1;
			}

			$prepared[] = $merged;
		}

		usort(
			$prepared,
			static function ( $a, $b ) {
				return array( $a['priority'], $a['id'] ) <=> array( $b['priority'], $b['id'] );
			}
		);

		self::$cache = $prepared;
	}
}

<?php
/**
 * The arithmetic. One place, called by everything.
 *
 * The catalogue filter, the cart calculation and the price HTML all come
 * through here with the same arguments and get the same answer. That is the
 * whole reason this class exists as its own thing: two code paths that both
 * compute a price will disagree eventually, and a shop where the catalogue says
 * £18 and the cart says £24 is a refund request, not a bug report.
 *
 * @package WPD_Dynamic_Pricing
 */

defined( 'ABSPATH' ) || exit;

class WCDP_Engine {

	/** @var array<string,array> Prices already worked out this request. */
	private static $cache = array();

	/**
	 * What should this product cost?
	 *
	 * @param WC_Product $product  Product.
	 * @param float      $base     The price before any rule.
	 * @param int        $quantity How many, for tiered rules.
	 * @param array      $context  matched_quantity, cart_subtotal, cart_quantity.
	 * @return array{price:float,original:float,applied:array,saved:float}
	 */
	public static function price( $product, $base, $quantity = 1, array $context = array() ) {
		$base = (float) $base;

		$nothing = array(
			'price'    => $base,
			'original' => $base,
			'applied'  => array(),
			'saved'    => 0.0,
		);

		/*
		 * A product with no price is not a product with a price of zero. It is
		 * a variable parent, an unconfigured variation, or a "price on
		 * application" product — and turning any of those into 0.00 puts a free
		 * item in the shop.
		 */
		if ( ! $product instanceof WC_Product || $base <= 0 ) {
			return $nothing;
		}

		$key = self::cache_key( $product, $base, $quantity, $context );

		if ( isset( self::$cache[ $key ] ) ) {
			return self::$cache[ $key ];
		}

		$result = self::calculate( $product, $base, $quantity, $context );

		self::$cache[ $key ] = $result;

		return $result;
	}

	/**
	 * @param WC_Product $product  Product.
	 * @param float      $base     Starting price.
	 * @param int        $quantity Quantity.
	 * @param array      $context  Cart context.
	 * @return array
	 */
	private static function calculate( WC_Product $product, $base, $quantity, array $context ) {
		$price   = $base;
		$applied = array();

		foreach ( WCDP_Rules::active() as $rule ) {
			// Cart-level rules discount the cart, not a line, so they are not
			// considered here at all.
			if ( 'cart' === $rule['type'] || 'bogo' === $rule['type'] ) {
				continue;
			}

			if ( ! WCDP_Conditions::applies( $rule, $product ) ) {
				continue;
			}

			$adjustment = self::adjustment_for( $rule, $quantity, $context );

			if ( ! $adjustment ) {
				continue;
			}

			$before = $price;
			$price  = self::apply( $price, $adjustment, $rule['limits']['max_discount'] );

			if ( $price !== $before ) {
				$applied[] = array(
					'id'    => $rule['id'],
					'label' => self::label( $rule ),
					'saved' => $before - $price,
				);
			}

			/*
			 * An exclusive rule stops here whether or not it changed anything.
			 *
			 * "Stop after this one" has to mean that literally. If a rule that
			 * matched but happened to compute a zero discount let the next rule
			 * through, a shop owner's carefully ordered stack would behave
			 * differently at different quantities for no visible reason.
			 */
			if ( ! empty( $rule['exclusive'] ) ) {
				break;
			}
		}

		/*
		 * Rounded once, here, and not in the loop.
		 *
		 * Rounding after every rule compounds the error: three 10% rules on
		 * £19.99 rounded at each step lands a penny away from the same three
		 * applied in full precision, and the penny shows up as a cart total
		 * that does not match the sum of its lines.
		 */
		$price = self::round( max( 0, $price ) );

		return array(
			'price'    => $price,
			'original' => $base,
			'applied'  => $applied,
			'saved'    => max( 0, self::round( $base - $price ) ),
		);
	}

	/**
	 * Which adjustment does this rule make at this quantity?
	 *
	 * @param array $rule     Rule.
	 * @param int   $quantity Quantity of this line.
	 * @param array $context  Cart context.
	 * @return array|null method, value.
	 */
	public static function adjustment_for( array $rule, $quantity, array $context = array() ) {
		if ( 'simple' === $rule['type'] ) {
			return $rule['adjust']['value'] > 0 ? $rule['adjust'] : null;
		}

		if ( 'bulk' !== $rule['type'] || ! $rule['tiers'] ) {
			return null;
		}

		/*
		 * Which quantity the tiers are read against.
		 *
		 * 'matched' totals every cart line the rule covers, which is what makes
		 * "any 3 shirts for 10% off" work — counting per line would demand
		 * three of the same shirt. Outside the cart there is no such total, so
		 * it falls back to the line quantity rather than to zero, and a
		 * catalogue page still shows the tier table.
		 */
		$count = ( 'matched' === $rule['tier_scope'] && isset( $context['matched_quantity'] ) )
			? (int) $context['matched_quantity']
			: (int) $quantity;

		return self::tier_for( $rule['tiers'], $count );
	}

	/**
	 * The tier a quantity falls into.
	 *
	 * @param array[] $tiers  Sorted by min ascending.
	 * @param int     $count  Quantity.
	 * @return array|null
	 */
	public static function tier_for( array $tiers, $count ) {
		$found = null;

		foreach ( $tiers as $tier ) {
			if ( $count < $tier['min'] ) {
				continue;
			}

			// max of 0 means "and above".
			if ( $tier['max'] > 0 && $count > $tier['max'] ) {
				continue;
			}

			// The last matching tier wins, so overlapping tiers resolve to the
			// most generous threshold the customer actually reached rather than
			// the first one written.
			$found = $tier;
		}

		return ( $found && $found['value'] > 0 ) ? $found : null;
	}

	/**
	 * Apply one adjustment to one price.
	 *
	 * @param float      $price        Current price.
	 * @param array      $adjustment   method, value.
	 * @param float      $max_discount Ceiling in currency, 0 for none.
	 * @return float
	 */
	public static function apply( $price, array $adjustment, $max_discount = 0 ) {
		$price = (float) $price;
		$value = (float) $adjustment['value'];

		switch ( $adjustment['method'] ) {
			case 'percent':
				$new = $price - ( $price * ( $value / 100 ) );
				break;

			case 'amount':
				$new = $price - $value;
				break;

			case 'fixed':
				/*
				 * Set the price to this, but never upwards.
				 *
				 * A "fixed price" rule is a discount tool. If the fixed price
				 * is above what the product already costs — a £20 rule against
				 * a £15 product on clearance — raising it would charge more
				 * than the shop advertises, which is the one outcome this
				 * plugin must never produce.
				 */
				$new = min( $price, $value );
				break;

			default:
				return $price;
		}

		$new = max( 0, $new );

		if ( $max_discount > 0 && ( $price - $new ) > $max_discount ) {
			$new = $price - $max_discount;
		}

		return $new;
	}

	/**
	 * Round to the store's decimal setting.
	 *
	 * @param float $amount Amount.
	 * @return float
	 */
	public static function round( $amount ) {
		$decimals = function_exists( 'wc_get_price_decimals' ) ? wc_get_price_decimals() : 2;

		return round( (float) $amount, (int) $decimals );
	}

	/**
	 * @param array $rule Rule.
	 * @return string
	 */
	public static function label( array $rule ) {
		if ( '' !== trim( (string) $rule['label'] ) ) {
			return $rule['label'];
		}

		return '' !== trim( (string) ( $rule['title'] ?? '' ) )
			? $rule['title']
			: __( 'Discount', 'wpd-dynamic-pricing' );
	}

	/**
	 * A cache key that cannot collide across customers or rule sets.
	 *
	 * @param WC_Product $product  Product.
	 * @param float      $base     Base price.
	 * @param int        $quantity Quantity.
	 * @param array      $context  Context.
	 * @return string
	 */
	private static function cache_key( WC_Product $product, $base, $quantity, array $context ) {
		return implode(
			'|',
			array(
				$product->get_id(),
				$base,
				$quantity,
				// The role is in the key because rules target roles. Without
				// it the first visitor of the day warms the cache and everybody
				// after them gets that visitor's price.
				WCDP_Conditions::customer_key(),
				WCDP_Rules::fingerprint(),
				$context['matched_quantity'] ?? '',
			)
		);
	}

	/**
	 * Forget this request's prices.
	 */
	public static function flush() {
		self::$cache = array();

		WCDP_Conditions::flush();
	}
}

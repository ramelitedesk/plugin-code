<?php
/**
 * Telling the customer what happened.
 *
 * A discount the customer cannot see is a discount that does not sell anything,
 * and a price that changed with no explanation reads as an error rather than an
 * offer. So: the saving on the product page, the tier table where a bulk rule
 * applies, and the rule's name on the cart line.
 *
 * @package WPD_Dynamic_Pricing
 */

defined( 'ABSPATH' ) || exit;

class WCDP_Display {

	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );

		add_action( 'woocommerce_single_product_summary', array( __CLASS__, 'saving' ), 11 );
		add_action( 'woocommerce_single_product_summary', array( __CLASS__, 'tier_table' ), 12 );

		add_filter( 'woocommerce_cart_item_name', array( __CLASS__, 'cart_item_note' ), 10, 3 );
	}

	public static function assets() {
		if ( ! function_exists( 'is_woocommerce' ) || ! ( is_woocommerce() || is_cart() || is_checkout() ) ) {
			return;
		}

		wp_enqueue_style( 'wcdp', WCDP_URL . 'assets/front.css', array(), WCDP_VERSION );
	}

	/**
	 * "You save £4.00 (20%)" under the price.
	 */
	public static function saving() {
		global $product;

		if ( ! $product instanceof WC_Product || $product->is_type( 'variable' ) ) {
			// A variable product has a range, not a price, so there is no single
			// saving to state. The variation dropdown shows the real one once a
			// choice is made.
			return;
		}

		$regular = (float) $product->get_regular_price( 'edit' );

		if ( $regular <= 0 ) {
			return;
		}

		$result = WCDP_Engine::price( $product, $regular, 1 );

		if ( ! $result['applied'] || $result['saved'] <= 0 ) {
			return;
		}

		$percent = (int) round( ( $result['saved'] / $regular ) * 100 );

		printf(
			'<p class="wcdp-saving">%s</p>',
			esc_html(
				sprintf(
					/* translators: 1: money saved, 2: percentage. */
					__( 'You save %1$s (%2$d%%)', 'wpd-dynamic-pricing' ),
					wp_strip_all_tags( wc_price( $result['saved'] ) ),
					$percent
				)
			)
		);
	}

	/**
	 * "Buy 3 for 10% off, buy 10 for 20% off" — the table that sells the offer.
	 */
	public static function tier_table() {
		global $product;

		if ( ! $product instanceof WC_Product ) {
			return;
		}

		$rows = array();

		foreach ( WCDP_Rules::active() as $rule ) {
			if ( 'bulk' !== $rule['type'] || ! $rule['tiers'] ) {
				continue;
			}

			if ( ! WCDP_Conditions::applies( $rule, $product ) ) {
				continue;
			}

			$base = (float) $product->get_regular_price( 'edit' );

			foreach ( $rule['tiers'] as $tier ) {
				if ( $tier['value'] <= 0 ) {
					continue;
				}

				$rows[] = array(
					'label' => self::tier_label( $tier, $rule ),
					'price' => $base > 0 ? WCDP_Engine::round( WCDP_Engine::apply( $base, $tier, $rule['limits']['max_discount'] ) ) : null,
				);
			}

			if ( ! empty( $rule['exclusive'] ) ) {
				break;
			}
		}

		if ( ! $rows ) {
			return;
		}

		echo '<table class="wcdp-tiers"><caption>' . esc_html__( 'Buy more, pay less', 'wpd-dynamic-pricing' ) . '</caption><tbody>';

		foreach ( $rows as $row ) {
			echo '<tr><th scope="row">' . esc_html( $row['label'] ) . '</th><td>';

			if ( null !== $row['price'] ) {
				// wc_price returns markup with a currency span in it, so it is
				// allowed through rather than escaped into visible tags.
				echo wp_kses_post( wc_price( $row['price'] ) );
				echo ' <span class="wcdp-tiers__each">' . esc_html__( 'each', 'wpd-dynamic-pricing' ) . '</span>';
			}

			echo '</td></tr>';
		}

		echo '</tbody></table>';
	}

	/**
	 * @param array $tier One tier.
	 * @param array $rule Its rule.
	 * @return string
	 */
	private static function tier_label( array $tier, array $rule ) {
		$scope = ( 'matched' === $rule['tier_scope'] )
			? __( 'Any %s', 'wpd-dynamic-pricing' )
			: __( 'Buy %s', 'wpd-dynamic-pricing' );

		$range = ( $tier['max'] > 0 )
			? sprintf( '%d–%d', $tier['min'], $tier['max'] )
			: sprintf(
				/* translators: %d: minimum quantity. */
				__( '%d or more', 'wpd-dynamic-pricing' ),
				$tier['min']
			);

		return sprintf( $scope, $range );
	}

	/**
	 * Name the rule on the cart line, so a changed price has a reason beside it.
	 *
	 * @param string $name Item name markup.
	 * @param array  $item Cart item.
	 * @param string $key  Cart item key.
	 * @return string
	 */
	public static function cart_item_note( $name, $item, $key ) {
		if ( empty( $item['wcdp']['applied'] ) || is_admin() ) {
			return $name;
		}

		$labels = array();

		foreach ( $item['wcdp']['applied'] as $applied ) {
			if ( ! empty( $applied['label'] ) ) {
				$labels[] = $applied['label'];
			}
		}

		if ( ! $labels ) {
			return $name;
		}

		return $name . sprintf(
			'<div class="wcdp-cart-note"><s>%1$s</s> %2$s</div>',
			wp_kses_post( wc_price( $item['wcdp']['original'] ) ),
			esc_html( implode( ', ', array_unique( $labels ) ) )
		);
	}
}

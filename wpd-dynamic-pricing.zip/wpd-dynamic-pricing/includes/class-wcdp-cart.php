<?php
/**
 * Prices in the cart, where quantity is finally known.
 *
 * A catalogue page can only price one of a thing. Tiers, cart thresholds and
 * buy-X-get-Y all need the basket, so this is where they are settled.
 *
 * TWO THINGS ABOUT before_calculate_totals THAT MATTER MORE THAN THE FEATURES:
 *
 *   1. It runs more than once per request. WooCommerce recalculates when items
 *      change, when shipping is chosen, when a coupon is applied, and again on
 *      the checkout render. A discount applied to whatever price is currently
 *      on the cart item compounds — three passes of 10% off is 27% off, and it
 *      is different depending on how the customer got to the page. Every pass
 *      here therefore recomputes from the product's ORIGINAL price.
 *
 *   2. The prices on cart items are already this plugin's catalogue prices,
 *      because WooCommerce built the cart item from a filtered product object.
 *      So the original has to be fetched deliberately, with the filters stood
 *      down, rather than read off the object in front of us.
 *
 * @package WPD_Dynamic_Pricing
 */

defined( 'ABSPATH' ) || exit;

class WCDP_Cart {

	public static function init() {
		add_action( 'woocommerce_before_calculate_totals', array( __CLASS__, 'apply' ), 20, 1 );

		// Cart-level rules become fee lines, so they show as their own row
		// rather than silently changing what each product cost.
		add_action( 'woocommerce_cart_calculate_fees', array( __CLASS__, 'cart_discounts' ), 20, 1 );
	}

	/* ------------------------------------------------------------------ *
	 * Line pricing
	 * ------------------------------------------------------------------ */

	/**
	 * @param WC_Cart $cart Cart.
	 */
	public static function apply( $cart ) {
		if ( ! $cart instanceof WC_Cart || did_action( 'woocommerce_before_calculate_totals' ) < 1 ) {
			return;
		}

		// Every pass starts clean: the product-match cache holds "is on sale"
		// answers that this plugin's own earlier pass may have influenced.
		WCDP_Engine::flush();

		$items = $cart->get_cart();

		if ( ! $items ) {
			return;
		}

		$matched = self::matched_quantities( $items );

		foreach ( $items as $key => $item ) {
			if ( empty( $item['data'] ) || ! $item['data'] instanceof WC_Product ) {
				continue;
			}

			$product = $item['data'];

			$original = self::original_price( $product );

			if ( $original <= 0 ) {
				continue;
			}

			$result = WCDP_Engine::price(
				$product,
				$original,
				(int) $item['quantity'],
				array( 'matched_quantity' => $matched[ $key ] ?? (int) $item['quantity'] )
			);

			$result = self::apply_bogo( $result, $product, (int) $item['quantity'] );

			$product->set_price( $result['price'] );

			/*
			 * Recorded on the cart item so the templates can say what happened
			 * without recomputing it. A second computation on the display side
			 * is the other way a catalogue and a cart end up disagreeing.
			 */
			$cart->cart_contents[ $key ]['wcdp'] = array(
				'original' => $result['original'],
				'price'    => $result['price'],
				'saved'    => $result['saved'],
				'applied'  => $result['applied'],
			);
		}
	}

	/**
	 * The product's price with none of this plugin's rules on it.
	 *
	 * The cart item's product object has already been through the catalogue
	 * filters, so reading get_price() here would read a discounted price and
	 * discount it again. The filters are stood down for the length of one read.
	 *
	 * @param WC_Product $product Product.
	 * @return float
	 */
	public static function original_price( WC_Product $product ) {
		/*
		 * 'edit' context reads the raw stored value and skips the
		 * woocommerce_product_get_* filters entirely, which is exactly what is
		 * wanted — it is the price the shop owner typed, before any rule.
		 */
		$sale    = $product->get_sale_price( 'edit' );
		$regular = $product->get_regular_price( 'edit' );

		if ( '' !== $sale && null !== $sale && (float) $sale > 0 ) {
			return (float) $sale;
		}

		if ( '' !== $regular && null !== $regular && (float) $regular > 0 ) {
			return (float) $regular;
		}

		// Nothing stored — a "price on application" product, or one whose price
		// comes entirely from another plugin. Left alone.
		return 0.0;
	}

	/**
	 * How many of each rule's matching products are in the cart.
	 *
	 * This is what makes "any 3 shirts, 10% off" work rather than "3 of the
	 * same shirt". Counted once per pass and reused for every line, because
	 * doing it per line is O(items²) and a fifty-line cart notices.
	 *
	 * @param array $items Cart contents.
	 * @return array<string,int> Cart item key => quantity to read tiers against.
	 */
	private static function matched_quantities( array $items ) {
		$totals = array();

		foreach ( WCDP_Rules::active() as $rule ) {
			if ( 'bulk' !== $rule['type'] || 'matched' !== $rule['tier_scope'] ) {
				continue;
			}

			$total = 0;

			foreach ( $items as $item ) {
				if ( ! empty( $item['data'] ) && WCDP_Conditions::applies( $rule, $item['data'] ) ) {
					$total += (int) $item['quantity'];
				}
			}

			$totals[ $rule['id'] ] = $total;
		}

		if ( ! $totals ) {
			return array();
		}

		$out = array();

		foreach ( $items as $key => $item ) {
			$best = (int) $item['quantity'];

			foreach ( WCDP_Rules::active() as $rule ) {
				if ( isset( $totals[ $rule['id'] ] )
					&& ! empty( $item['data'] )
					&& WCDP_Conditions::applies( $rule, $item['data'] ) ) {
					$best = max( $best, $totals[ $rule['id'] ] );
				}
			}

			$out[ $key ] = $best;
		}

		return $out;
	}

	/* ------------------------------------------------------------------ *
	 * Buy X get Y
	 * ------------------------------------------------------------------ */

	/**
	 * Spread a buy-X-get-Y discount across a line.
	 *
	 * WooCommerce prices a line as quantity × price, with one price for the
	 * whole line — there is no way to say "two at full price and one free". So
	 * the discount on the free items is averaged across every unit, which
	 * produces the correct line total and a per-unit price that is not a round
	 * number. That is a real limitation and it is stated in the README rather
	 * than hidden.
	 *
	 * @param array      $result   From the engine.
	 * @param WC_Product $product  Product.
	 * @param int        $quantity Line quantity.
	 * @return array
	 */
	private static function apply_bogo( array $result, WC_Product $product, $quantity ) {
		foreach ( WCDP_Rules::active() as $rule ) {
			if ( 'bogo' !== $rule['type'] || ! WCDP_Conditions::applies( $rule, $product ) ) {
				continue;
			}

			$buy = max( 1, (int) $rule['bogo']['buy'] );
			$get = max( 1, (int) $rule['bogo']['get'] );

			$block = $buy + $get;

			if ( $quantity < $block ) {
				continue;
			}

			$sets = empty( $rule['bogo']['repeat'] ) ? 1 : (int) floor( $quantity / $block );

			$free_units = min( $sets * $get, $quantity - $buy );

			if ( $free_units < 1 ) {
				continue;
			}

			$discounted_unit = WCDP_Engine::apply(
				$result['price'],
				array(
					'method' => $rule['bogo']['method'],
					'value'  => $rule['bogo']['value'],
				)
			);

			$saving_per_unit = $result['price'] - $discounted_unit;

			if ( $saving_per_unit <= 0 ) {
				continue;
			}

			$line_saving = $saving_per_unit * $free_units;

			if ( $rule['limits']['max_discount'] > 0 ) {
				$line_saving = min( $line_saving, $rule['limits']['max_discount'] );
			}

			$new_unit = WCDP_Engine::round( max( 0, $result['price'] - ( $line_saving / $quantity ) ) );

			$result['applied'][] = array(
				'id'    => $rule['id'],
				'label' => WCDP_Engine::label( $rule ),
				'saved' => $result['price'] - $new_unit,
			);

			$result['price'] = $new_unit;
			$result['saved'] = max( 0, WCDP_Engine::round( $result['original'] - $new_unit ) );

			if ( ! empty( $rule['exclusive'] ) ) {
				break;
			}
		}

		return $result;
	}

	/* ------------------------------------------------------------------ *
	 * Cart-level discounts
	 * ------------------------------------------------------------------ */

	/**
	 * "Spend £100, get 10% off" — added as a negative fee.
	 *
	 * A fee rather than a change to each line, because the customer should see
	 * why their total dropped. A cart that silently reprices every product when
	 * the subtotal crosses a threshold looks like a pricing error.
	 *
	 * @param WC_Cart $cart Cart.
	 */
	public static function cart_discounts( $cart ) {
		if ( ! $cart instanceof WC_Cart || is_admin() && ! wp_doing_ajax() ) {
			return;
		}

		$subtotal = (float) $cart->get_subtotal();
		$quantity = (int) $cart->get_cart_contents_count();

		foreach ( WCDP_Rules::active() as $rule ) {
			if ( 'cart' !== $rule['type'] ) {
				continue;
			}

			if ( ! WCDP_Conditions::matches_now( $rule ) || ! WCDP_Conditions::matches_customer( $rule ) ) {
				continue;
			}

			$measure = ( 'quantity' === $rule['cart']['basis'] ) ? $quantity : $subtotal;

			if ( $measure < $rule['cart']['min'] ) {
				continue;
			}

			if ( $rule['cart']['max'] > 0 && $measure > $rule['cart']['max'] ) {
				continue;
			}

			$discounted = WCDP_Engine::apply( $subtotal, $rule['adjust'], $rule['limits']['max_discount'] );

			$amount = WCDP_Engine::round( $subtotal - $discounted );

			if ( $amount <= 0 ) {
				continue;
			}

			$cart->add_fee(
				WCDP_Engine::label( $rule ),
				-$amount,
				/*
				 * Not taxable. The discount comes off a subtotal that has
				 * already had tax worked out on it, so taxing the negative fee
				 * again would take the tax off twice and under-report VAT.
				 */
				false
			);

			if ( ! empty( $rule['exclusive'] ) ) {
				break;
			}
		}
	}
}

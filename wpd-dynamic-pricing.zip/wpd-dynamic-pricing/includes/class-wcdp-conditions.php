<?php
/**
 * Does this rule apply — to this product, to this customer, at this moment?
 *
 * Kept apart from the arithmetic on purpose. "Which rules apply" and "what do
 * they do to the number" are different questions, and a bug in one is much
 * easier to find when it cannot be a bug in the other.
 *
 * @package WPD_Dynamic_Pricing
 */

defined( 'ABSPATH' ) || exit;

class WCDP_Conditions {

	/** @var array<string,bool> Product matches already worked out this request. */
	private static $product_cache = array();

	/**
	 * Everything at once: product, customer and clock.
	 *
	 * @param array      $rule    Rule.
	 * @param WC_Product $product Product.
	 * @return bool
	 */
	public static function applies( array $rule, $product ) {
		return self::matches_now( $rule )
			&& self::matches_customer( $rule )
			&& self::matches_product( $rule, $product );
	}

	/* ------------------------------------------------------------------ *
	 * Product
	 * ------------------------------------------------------------------ */

	/**
	 * @param array      $rule    Rule.
	 * @param WC_Product $product Product.
	 * @return bool
	 */
	public static function matches_product( array $rule, $product ) {
		if ( ! $product instanceof WC_Product ) {
			return false;
		}

		$key = $rule['id'] . ':' . $product->get_id();

		if ( isset( self::$product_cache[ $key ] ) ) {
			return self::$product_cache[ $key ];
		}

		self::$product_cache[ $key ] = self::test_product( $rule, $product );

		return self::$product_cache[ $key ];
	}

	/**
	 * @param array      $rule    Rule.
	 * @param WC_Product $product Product.
	 * @return bool
	 */
	private static function test_product( array $rule, WC_Product $product ) {
		$apply = $rule['apply_to'];

		/*
		 * A variation's categories live on its parent, not on itself. Asking
		 * the variation for its terms returns nothing, so a "10% off Shirts"
		 * rule would price the simple shirts and quietly skip every variable
		 * one — which is the shape of bug that gets found at the till.
		 */
		$owner_id = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();

		if ( in_array( $product->get_id(), $apply['exclude_products'], true )
			|| in_array( $owner_id, $apply['exclude_products'], true ) ) {
			return false;
		}

		if ( $apply['exclude_categories'] && self::in_terms( $owner_id, 'product_cat', $apply['exclude_categories'] ) ) {
			return false;
		}

		/*
		 * Already reduced, and the rule says leave those alone.
		 *
		 * Checked against the product's own sale price rather than against
		 * whatever this plugin has already done to it — otherwise the first
		 * rule marks the product "on sale" and every later rule excludes
		 * itself, which reads as rules randomly not working.
		 */
		if ( ! empty( $apply['exclude_on_sale'] ) && self::natively_on_sale( $product ) ) {
			return false;
		}

		switch ( $apply['mode'] ) {
			case 'products':
				return in_array( $product->get_id(), $apply['products'], true )
					|| in_array( $owner_id, $apply['products'], true );

			case 'categories':
				return self::in_terms( $owner_id, 'product_cat', $apply['categories'] );

			case 'tags':
				return self::in_terms( $owner_id, 'product_tag', $apply['tags'] );
		}

		return true;
	}

	/**
	 * Is this product on sale by the store's own doing?
	 *
	 * @param WC_Product $product Product.
	 * @return bool
	 */
	public static function natively_on_sale( WC_Product $product ) {
		$sale = $product->get_sale_price( 'edit' );

		return '' !== $sale && null !== $sale && (float) $sale > 0;
	}

	/**
	 * @param int    $product_id Product or parent id.
	 * @param string $taxonomy   Taxonomy.
	 * @param int[]  $wanted     Term ids.
	 * @return bool
	 */
	private static function in_terms( $product_id, $taxonomy, array $wanted ) {
		if ( ! $wanted ) {
			return false;
		}

		$terms = wp_get_post_terms( $product_id, $taxonomy, array( 'fields' => 'ids' ) );

		if ( is_wp_error( $terms ) || ! $terms ) {
			return false;
		}

		if ( array_intersect( $wanted, $terms ) ) {
			return true;
		}

		/*
		 * A rule naming a parent category covers its children.
		 *
		 * Somebody who writes "10% off Clothing" means the shirts inside it.
		 * Requiring them to list every subcategory is a rule that silently
		 * covers less than it says, and grows less accurate every time
		 * somebody adds a subcategory.
		 */
		if ( is_taxonomy_hierarchical( $taxonomy ) ) {
			foreach ( $terms as $term_id ) {
				if ( array_intersect( $wanted, get_ancestors( $term_id, $taxonomy, 'taxonomy' ) ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/* ------------------------------------------------------------------ *
	 * Customer
	 * ------------------------------------------------------------------ */

	/**
	 * @param array $rule Rule.
	 * @return bool
	 */
	public static function matches_customer( array $rule ) {
		$who = $rule['who'];

		if ( 'everyone' === $who['mode'] ) {
			return true;
		}

		$user_id = get_current_user_id();

		if ( 'guests' === $who['mode'] ) {
			return 0 === $user_id;
		}

		if ( 'users' === $who['mode'] ) {
			return $user_id && in_array( $user_id, $who['users'], true );
		}

		if ( 'roles' === $who['mode'] ) {
			if ( ! $user_id ) {
				// "Guest" is offered as a pseudo-role, because "wholesale
				// customers and people not logged in" is a real rule and there
				// is nowhere else to say it.
				return in_array( 'guest', $who['roles'], true );
			}

			$user = wp_get_current_user();

			return (bool) array_intersect( $who['roles'], (array) $user->roles );
		}

		return true;
	}

	/**
	 * The current customer's role, for cache keys.
	 *
	 * @return string
	 */
	public static function customer_key() {
		$user_id = get_current_user_id();

		if ( ! $user_id ) {
			return 'guest';
		}

		$user = wp_get_current_user();

		$roles = (array) $user->roles;

		sort( $roles );

		/*
		 * The user id is in the key as well as the roles, because a rule can
		 * name specific users. Without it, two customers with the same role
		 * share a cache entry and the one named in the rule leaks their price
		 * to the one who is not.
		 */
		return $user_id . ':' . implode( ',', $roles );
	}

	/* ------------------------------------------------------------------ *
	 * Clock
	 * ------------------------------------------------------------------ */

	/**
	 * @param array    $rule Rule.
	 * @param int|null $now  Timestamp, for tests.
	 * @return bool
	 */
	public static function matches_now( array $rule, $now = null ) {
		$when = $rule['when'];

		if ( '' === $when['start'] && '' === $when['end'] && ! $when['days'] ) {
			return true;
		}

		/*
		 * The store's local time, not the server's.
		 *
		 * A sale set to end at midnight is meant to end at midnight where the
		 * shop is. current_time() applies the WordPress timezone; time() would
		 * end the sale several hours early or late depending on where the
		 * server happens to be.
		 */
		$now = ( null === $now ) ? (int) current_time( 'timestamp' ) : (int) $now;

		if ( '' !== $when['start'] ) {
			$start = strtotime( $when['start'] );

			if ( $start && $now < $start ) {
				return false;
			}
		}

		if ( '' !== $when['end'] ) {
			$end = strtotime( $when['end'] );

			/*
			 * A date with no time means the whole of that day.
			 *
			 * "ends 2026-09-30" typed by a shop owner means the end of the
			 * 30th, not one second past midnight at its start — which would
			 * cut the last day off every sale they ever schedule.
			 */
			if ( $end && ! preg_match( '/\d{2}:\d{2}/', $when['end'] ) ) {
				$end += DAY_IN_SECONDS - 1;
			}

			if ( $end && $now > $end ) {
				return false;
			}
		}

		if ( $when['days'] && ! in_array( (int) wp_date( 'w', $now ), $when['days'], true ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Forget cached product matches. Tests, and between cart recalculations.
	 */
	public static function flush() {
		self::$product_cache = array();
	}
}

<?php
/**
 * The rule editor, under WooCommerce → Pricing Rules.
 *
 * @package WPD_Dynamic_Pricing
 */

defined( 'ABSPATH' ) || exit;

class WCDP_Admin {

	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'meta_boxes' ) );
		add_action( 'save_post_' . WCDP_Rules::POST_TYPE, array( __CLASS__, 'save' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );

		add_filter( 'manage_' . WCDP_Rules::POST_TYPE . '_posts_columns', array( __CLASS__, 'columns' ) );
		add_action( 'manage_' . WCDP_Rules::POST_TYPE . '_posts_custom_column', array( __CLASS__, 'column' ), 10, 2 );
		add_filter( 'manage_edit-' . WCDP_Rules::POST_TYPE . '_sortable_columns', array( __CLASS__, 'sortable' ) );
	}

	public static function meta_boxes() {
		add_meta_box( 'wcdp-what', __( 'What this rule does', 'wpd-dynamic-pricing' ), array( __CLASS__, 'panel_what' ), WCDP_Rules::POST_TYPE, 'normal', 'high' );
		add_meta_box( 'wcdp-which', __( 'Which products', 'wpd-dynamic-pricing' ), array( __CLASS__, 'panel_which' ), WCDP_Rules::POST_TYPE, 'normal', 'default' );
		add_meta_box( 'wcdp-who', __( 'Which customers', 'wpd-dynamic-pricing' ), array( __CLASS__, 'panel_who' ), WCDP_Rules::POST_TYPE, 'normal', 'default' );
		add_meta_box( 'wcdp-when', __( 'When', 'wpd-dynamic-pricing' ), array( __CLASS__, 'panel_when' ), WCDP_Rules::POST_TYPE, 'side', 'default' );
		add_meta_box( 'wcdp-order', __( 'Order and limits', 'wpd-dynamic-pricing' ), array( __CLASS__, 'panel_order' ), WCDP_Rules::POST_TYPE, 'side', 'default' );
	}

	/* ------------------------------------------------------------------ *
	 * Panels
	 * ------------------------------------------------------------------ */

	public static function panel_what( $post ) {
		$rule = WCDP_Rules::get( $post->ID );

		wp_nonce_field( 'wcdp_save', 'wcdp_nonce' );

		$types = array(
			'simple' => array( __( 'A straight discount', 'wpd-dynamic-pricing' ), __( 'Percentage, an amount off, or a set price. The everyday rule.', 'wpd-dynamic-pricing' ) ),
			'bulk'   => array( __( 'Buy more, pay less', 'wpd-dynamic-pricing' ), __( 'Quantity tiers — 3 or more at 10% off, 10 or more at 20%.', 'wpd-dynamic-pricing' ) ),
			'bogo'   => array( __( 'Buy X, get Y', 'wpd-dynamic-pricing' ), __( 'Buy two, get one free — or at any discount you choose.', 'wpd-dynamic-pricing' ) ),
			'cart'   => array( __( 'Whole-cart discount', 'wpd-dynamic-pricing' ), __( 'Spend over an amount, or buy over a quantity, and take a discount off the cart total. Shown as its own line.', 'wpd-dynamic-pricing' ) ),
		);
		?>
		<label class="wcdp-live">
			<input type="checkbox" name="wcdp[enabled]" value="1" <?php checked( ! empty( $rule['enabled'] ) ); ?> />
			<strong><?php esc_html_e( 'This rule is live', 'wpd-dynamic-pricing' ); ?></strong>
		</label>

		<div class="wcdp-types">
			<?php foreach ( $types as $key => $meta ) : ?>
				<label class="wcdp-type">
					<input type="radio" name="wcdp[type]" value="<?php echo esc_attr( $key ); ?>" <?php checked( $rule['type'], $key ); ?> />
					<strong><?php echo esc_html( $meta[0] ); ?></strong>
					<span><?php echo esc_html( $meta[1] ); ?></span>
				</label>
			<?php endforeach; ?>
		</div>

		<p class="wcdp-field">
			<label for="wcdp-label"><?php esc_html_e( 'Label the customer sees', 'wpd-dynamic-pricing' ); ?></label>
			<input type="text" id="wcdp-label" name="wcdp[label]" class="regular-text"
				value="<?php echo esc_attr( $rule['label'] ); ?>"
				placeholder="<?php echo esc_attr( get_the_title( $post ) ? get_the_title( $post ) : __( 'Discount', 'wpd-dynamic-pricing' ) ); ?>" />
			<span class="description"><?php esc_html_e( 'Appears on the cart line and on the cart discount row. Left blank, the rule title is used.', 'wpd-dynamic-pricing' ); ?></span>
		</p>

		<div class="wcdp-for wcdp-for--simple wcdp-for--cart">
			<h4><?php esc_html_e( 'The discount', 'wpd-dynamic-pricing' ); ?></h4>
			<?php self::adjustment_fields( 'wcdp[adjust]', $rule['adjust'] ); ?>
		</div>

		<div class="wcdp-for wcdp-for--bulk">
			<h4><?php esc_html_e( 'Quantity tiers', 'wpd-dynamic-pricing' ); ?></h4>

			<p class="wcdp-field">
				<label><?php esc_html_e( 'Count the quantity as', 'wpd-dynamic-pricing' ); ?></label>
				<select name="wcdp[tier_scope]">
					<option value="line" <?php selected( $rule['tier_scope'], 'line' ); ?>><?php esc_html_e( 'How many of this one product', 'wpd-dynamic-pricing' ); ?></option>
					<option value="matched" <?php selected( $rule['tier_scope'], 'matched' ); ?>><?php esc_html_e( 'How many products this rule covers, added together', 'wpd-dynamic-pricing' ); ?></option>
				</select>
				<span class="description"><?php esc_html_e( 'The second is what makes "any 3 shirts for 10% off" work. The first would need three of the same shirt.', 'wpd-dynamic-pricing' ); ?></span>
			</p>

			<table class="widefat wcdp-tiers-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'From', 'wpd-dynamic-pricing' ); ?></th>
						<th><?php esc_html_e( 'To', 'wpd-dynamic-pricing' ); ?></th>
						<th><?php esc_html_e( 'Discount', 'wpd-dynamic-pricing' ); ?></th>
						<th></th>
					</tr>
				</thead>
				<tbody id="wcdp-tiers">
					<?php
					$tiers = $rule['tiers'] ? $rule['tiers'] : array( array( 'min' => 3, 'max' => 0, 'method' => 'percent', 'value' => 0 ) );

					foreach ( $tiers as $index => $tier ) {
						self::tier_row( $index, $tier );
					}
					?>
				</tbody>
			</table>

			<p><button type="button" class="button" id="wcdp-add-tier"><?php esc_html_e( '+ Add tier', 'wpd-dynamic-pricing' ); ?></button></p>

			<script type="text/html" id="tmpl-wcdp-tier">
				<?php self::tier_row( '__INDEX__', array( 'min' => 1, 'max' => 0, 'method' => 'percent', 'value' => 0 ) ); ?>
			</script>
		</div>

		<div class="wcdp-for wcdp-for--bogo">
			<h4><?php esc_html_e( 'The offer', 'wpd-dynamic-pricing' ); ?></h4>

			<p class="wcdp-field wcdp-field--inline">
				<label><?php esc_html_e( 'Buy', 'wpd-dynamic-pricing' ); ?></label>
				<input type="number" min="1" step="1" class="small-text" name="wcdp[bogo][buy]" value="<?php echo esc_attr( $rule['bogo']['buy'] ); ?>" />
				<label><?php esc_html_e( 'get', 'wpd-dynamic-pricing' ); ?></label>
				<input type="number" min="1" step="1" class="small-text" name="wcdp[bogo][get]" value="<?php echo esc_attr( $rule['bogo']['get'] ); ?>" />
			</p>

			<?php self::adjustment_fields( 'wcdp[bogo]', array( 'method' => $rule['bogo']['method'], 'value' => $rule['bogo']['value'] ) ); ?>

			<p class="wcdp-field">
				<label>
					<input type="checkbox" name="wcdp[bogo][repeat]" value="1" <?php checked( ! empty( $rule['bogo']['repeat'] ) ); ?> />
					<?php esc_html_e( 'Apply again for each further set', 'wpd-dynamic-pricing' ); ?>
				</label>
			</p>

			<div class="notice notice-info inline">
				<p>
					<?php esc_html_e( 'WooCommerce prices a cart line as quantity × one price, so a free item cannot be shown as its own zero-priced row. The saving is spread across every unit on the line instead: the line total is exactly right, and the per-unit price is not a round number.', 'wpd-dynamic-pricing' ); ?>
				</p>
			</div>
		</div>

		<div class="wcdp-for wcdp-for--cart">
			<h4><?php esc_html_e( 'Cart has to reach', 'wpd-dynamic-pricing' ); ?></h4>

			<p class="wcdp-field wcdp-field--inline">
				<select name="wcdp[cart][basis]">
					<option value="subtotal" <?php selected( $rule['cart']['basis'], 'subtotal' ); ?>><?php esc_html_e( 'Subtotal', 'wpd-dynamic-pricing' ); ?></option>
					<option value="quantity" <?php selected( $rule['cart']['basis'], 'quantity' ); ?>><?php esc_html_e( 'Item count', 'wpd-dynamic-pricing' ); ?></option>
				</select>
				<label><?php esc_html_e( 'from', 'wpd-dynamic-pricing' ); ?></label>
				<input type="number" min="0" step="any" class="small-text" name="wcdp[cart][min]" value="<?php echo esc_attr( $rule['cart']['min'] ); ?>" />
				<label><?php esc_html_e( 'to', 'wpd-dynamic-pricing' ); ?></label>
				<input type="number" min="0" step="any" class="small-text" name="wcdp[cart][max]" value="<?php echo esc_attr( $rule['cart']['max'] ); ?>" />
				<span class="description"><?php esc_html_e( '0 for no upper limit.', 'wpd-dynamic-pricing' ); ?></span>
			</p>
		</div>
		<?php
	}

	/**
	 * @param int|string $index Row index.
	 * @param array      $tier  Tier.
	 */
	private static function tier_row( $index, array $tier ) {
		$name = 'wcdp[tiers][' . $index . ']';
		?>
		<tr class="wcdp-tier">
			<td><input type="number" min="1" step="1" class="small-text" name="<?php echo esc_attr( $name ); ?>[min]" value="<?php echo esc_attr( $tier['min'] ); ?>" /></td>
			<td>
				<input type="number" min="0" step="1" class="small-text" name="<?php echo esc_attr( $name ); ?>[max]" value="<?php echo esc_attr( $tier['max'] ); ?>" />
				<span class="description"><?php esc_html_e( '0 = and above', 'wpd-dynamic-pricing' ); ?></span>
			</td>
			<td><?php self::adjustment_fields( $name, $tier, true ); ?></td>
			<td><button type="button" class="button-link wcdp-remove-tier" aria-label="<?php esc_attr_e( 'Remove tier', 'wpd-dynamic-pricing' ); ?>">&times;</button></td>
		</tr>
		<?php
	}

	/**
	 * @param string $name   Field name prefix.
	 * @param array  $adjust method, value.
	 * @param bool   $inline Whether this sits inside a table cell.
	 */
	private static function adjustment_fields( $name, array $adjust, $inline = false ) {
		?>
		<span class="wcdp-adjust<?php echo $inline ? ' wcdp-adjust--inline' : ''; ?>">
			<select name="<?php echo esc_attr( $name ); ?>[method]">
				<option value="percent" <?php selected( $adjust['method'], 'percent' ); ?>><?php esc_html_e( 'Percentage off', 'wpd-dynamic-pricing' ); ?></option>
				<option value="amount" <?php selected( $adjust['method'], 'amount' ); ?>><?php esc_html_e( 'Amount off', 'wpd-dynamic-pricing' ); ?></option>
				<option value="fixed" <?php selected( $adjust['method'], 'fixed' ); ?>><?php esc_html_e( 'Set price to', 'wpd-dynamic-pricing' ); ?></option>
			</select>
			<input type="number" min="0" step="any" class="small-text" name="<?php echo esc_attr( $name ); ?>[value]" value="<?php echo esc_attr( $adjust['value'] ); ?>" />
		</span>
		<?php
	}

	public static function panel_which( $post ) {
		$rule  = WCDP_Rules::get( $post->ID );
		$apply = $rule['apply_to'];

		$modes = array(
			'all'        => __( 'Every product', 'wpd-dynamic-pricing' ),
			'products'   => __( 'Only these products', 'wpd-dynamic-pricing' ),
			'categories' => __( 'Products in these categories', 'wpd-dynamic-pricing' ),
			'tags'       => __( 'Products with these tags', 'wpd-dynamic-pricing' ),
		);
		?>
		<p class="wcdp-field">
			<?php foreach ( $modes as $key => $label ) : ?>
				<label class="wcdp-inline">
					<input type="radio" name="wcdp[apply_to][mode]" value="<?php echo esc_attr( $key ); ?>" <?php checked( $apply['mode'], $key ); ?> />
					<?php echo esc_html( $label ); ?>
				</label>
			<?php endforeach; ?>
		</p>

		<p class="wcdp-field wcdp-when-mode-products">
			<label for="wcdp-products"><?php esc_html_e( 'Product IDs', 'wpd-dynamic-pricing' ); ?></label>
			<input type="text" id="wcdp-products" class="regular-text" name="wcdp[apply_to][products]" value="<?php echo esc_attr( implode( ',', $apply['products'] ) ); ?>" />
			<span class="description"><?php esc_html_e( 'Comma separated. A variable product\'s ID covers all of its variations.', 'wpd-dynamic-pricing' ); ?></span>
		</p>

		<?php
		self::term_checkboxes( 'product_cat', __( 'Categories', 'wpd-dynamic-pricing' ), 'wcdp[apply_to][categories][]', $apply['categories'], 'wcdp-when-mode-categories' );
		self::term_checkboxes( 'product_tag', __( 'Tags', 'wpd-dynamic-pricing' ), 'wcdp[apply_to][tags][]', $apply['tags'], 'wcdp-when-mode-tags' );
		?>

		<h4><?php esc_html_e( 'Leave out', 'wpd-dynamic-pricing' ); ?></h4>

		<p class="wcdp-field">
			<label for="wcdp-exclude-products"><?php esc_html_e( 'Product IDs to exclude', 'wpd-dynamic-pricing' ); ?></label>
			<input type="text" id="wcdp-exclude-products" class="regular-text" name="wcdp[apply_to][exclude_products]" value="<?php echo esc_attr( implode( ',', $apply['exclude_products'] ) ); ?>" />
		</p>

		<p class="wcdp-field">
			<label>
				<input type="checkbox" name="wcdp[apply_to][exclude_on_sale]" value="1" <?php checked( ! empty( $apply['exclude_on_sale'] ) ); ?> />
				<strong><?php esc_html_e( 'Skip products that are already on sale', 'wpd-dynamic-pricing' ); ?></strong>
			</label>
			<span class="description">
				<?php esc_html_e( 'On by default, and worth leaving on. Stacking a rule on top of an existing reduction is how a £40 jacket ends up at £14 during a sale nobody authorised.', 'wpd-dynamic-pricing' ); ?>
			</span>
		</p>
		<?php
	}

	/**
	 * @param string $taxonomy Taxonomy.
	 * @param string $heading  Heading.
	 * @param string $name     Field name.
	 * @param int[]  $chosen   Selected term ids.
	 * @param string $class    Extra class.
	 */
	private static function term_checkboxes( $taxonomy, $heading, $name, array $chosen, $class ) {
		$terms = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
				'number'     => 300,
			)
		);

		if ( is_wp_error( $terms ) || ! $terms ) {
			return;
		}
		?>
		<div class="wcdp-field <?php echo esc_attr( $class ); ?>">
			<label><?php echo esc_html( $heading ); ?></label>
			<div class="wcdp-terms">
				<?php foreach ( $terms as $term ) : ?>
					<label>
						<input type="checkbox" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $term->term_id ); ?>"
							<?php checked( in_array( (int) $term->term_id, $chosen, true ) ); ?> />
						<?php echo esc_html( $term->name ); ?>
					</label>
				<?php endforeach; ?>
			</div>
			<?php if ( is_taxonomy_hierarchical( $taxonomy ) ) : ?>
				<span class="description"><?php esc_html_e( 'Choosing a parent category covers everything inside it.', 'wpd-dynamic-pricing' ); ?></span>
			<?php endif; ?>
		</div>
		<?php
	}

	public static function panel_who( $post ) {
		$rule = WCDP_Rules::get( $post->ID );
		$who  = $rule['who'];

		$modes = array(
			'everyone' => __( 'Everybody', 'wpd-dynamic-pricing' ),
			'roles'    => __( 'These roles', 'wpd-dynamic-pricing' ),
			'users'    => __( 'These specific customers', 'wpd-dynamic-pricing' ),
			'guests'   => __( 'Only visitors who are not logged in', 'wpd-dynamic-pricing' ),
		);
		?>
		<p class="wcdp-field">
			<?php foreach ( $modes as $key => $label ) : ?>
				<label class="wcdp-inline">
					<input type="radio" name="wcdp[who][mode]" value="<?php echo esc_attr( $key ); ?>" <?php checked( $who['mode'], $key ); ?> />
					<?php echo esc_html( $label ); ?>
				</label>
			<?php endforeach; ?>
		</p>

		<div class="wcdp-field wcdp-who-roles">
			<label><?php esc_html_e( 'Roles', 'wpd-dynamic-pricing' ); ?></label>
			<div class="wcdp-terms">
				<label>
					<input type="checkbox" name="wcdp[who][roles][]" value="guest" <?php checked( in_array( 'guest', $who['roles'], true ) ); ?> />
					<?php esc_html_e( 'Not logged in', 'wpd-dynamic-pricing' ); ?>
				</label>
				<?php foreach ( wp_roles()->get_names() as $key => $label ) : ?>
					<label>
						<input type="checkbox" name="wcdp[who][roles][]" value="<?php echo esc_attr( $key ); ?>" <?php checked( in_array( $key, $who['roles'], true ) ); ?> />
						<?php echo esc_html( translate_user_role( $label ) ); ?>
					</label>
				<?php endforeach; ?>
			</div>
		</div>

		<p class="wcdp-field wcdp-who-users">
			<label for="wcdp-users"><?php esc_html_e( 'User IDs', 'wpd-dynamic-pricing' ); ?></label>
			<input type="text" id="wcdp-users" class="regular-text" name="wcdp[who][users]" value="<?php echo esc_attr( implode( ',', $who['users'] ) ); ?>" />
		</p>

		<div class="notice notice-warning inline">
			<p>
				<strong><?php esc_html_e( 'Targeting by role and page caching.', 'wpd-dynamic-pricing' ); ?></strong>
				<?php esc_html_e( 'This plugin keys WooCommerce\'s own price caches by role, but a full-page cache in front of your site knows nothing about that. If you use one, exclude the shop and product pages from it, or wholesale prices will be served to the public.', 'wpd-dynamic-pricing' ); ?>
			</p>
		</div>
		<?php
	}

	public static function panel_when( $post ) {
		$rule = WCDP_Rules::get( $post->ID );
		$when = $rule['when'];
		?>
		<p class="wcdp-field">
			<label for="wcdp-start"><?php esc_html_e( 'Starts', 'wpd-dynamic-pricing' ); ?></label>
			<input type="datetime-local" id="wcdp-start" name="wcdp[when][start]" value="<?php echo esc_attr( str_replace( ' ', 'T', $when['start'] ) ); ?>" />
		</p>

		<p class="wcdp-field">
			<label for="wcdp-end"><?php esc_html_e( 'Ends', 'wpd-dynamic-pricing' ); ?></label>
			<input type="datetime-local" id="wcdp-end" name="wcdp[when][end]" value="<?php echo esc_attr( str_replace( ' ', 'T', $when['end'] ) ); ?>" />
		</p>

		<p class="description"><?php esc_html_e( 'Store time, not server time. Leave both blank to run always.', 'wpd-dynamic-pricing' ); ?></p>

		<div class="wcdp-field">
			<label><?php esc_html_e( 'Only on these days', 'wpd-dynamic-pricing' ); ?></label>
			<?php
			global $wp_locale;

			for ( $day = 0; $day <= 6; $day++ ) :
				?>
				<label class="wcdp-day">
					<input type="checkbox" name="wcdp[when][days][]" value="<?php echo esc_attr( $day ); ?>" <?php checked( in_array( $day, $when['days'], true ) ); ?> />
					<?php echo esc_html( $wp_locale->get_weekday_abbrev( $wp_locale->get_weekday( $day ) ) ); ?>
				</label>
			<?php endfor; ?>
			<span class="description"><?php esc_html_e( 'None ticked means any day.', 'wpd-dynamic-pricing' ); ?></span>
		</div>
		<?php
	}

	public static function panel_order( $post ) {
		$rule = WCDP_Rules::get( $post->ID );
		?>
		<p class="wcdp-field">
			<label for="wcdp-priority"><?php esc_html_e( 'Priority', 'wpd-dynamic-pricing' ); ?></label>
			<input type="number" id="wcdp-priority" min="0" max="999" step="1" class="small-text" name="wcdp[priority]" value="<?php echo esc_attr( $rule['priority'] ); ?>" />
			<span class="description"><?php esc_html_e( 'Lower runs first. Rules stack unless one stops them.', 'wpd-dynamic-pricing' ); ?></span>
		</p>

		<p class="wcdp-field">
			<label>
				<input type="checkbox" name="wcdp[exclusive]" value="1" <?php checked( ! empty( $rule['exclusive'] ) ); ?> />
				<?php esc_html_e( 'Stop after this rule', 'wpd-dynamic-pricing' ); ?>
			</label>
			<span class="description"><?php esc_html_e( 'Nothing lower-priority is considered for a product this rule matched.', 'wpd-dynamic-pricing' ); ?></span>
		</p>

		<p class="wcdp-field">
			<label for="wcdp-max"><?php esc_html_e( 'Never take off more than', 'wpd-dynamic-pricing' ); ?></label>
			<input type="number" id="wcdp-max" min="0" step="any" class="small-text" name="wcdp[limits][max_discount]" value="<?php echo esc_attr( $rule['limits']['max_discount'] ); ?>" />
			<span class="description"><?php esc_html_e( '0 for no ceiling. A safety net against a mistyped percentage.', 'wpd-dynamic-pricing' ); ?></span>
		</p>
		<?php
	}

	/* ------------------------------------------------------------------ *
	 * Saving
	 * ------------------------------------------------------------------ */

	/**
	 * @param int     $post_id Rule.
	 * @param WP_Post $post    Post.
	 */
	public static function save( $post_id, $post ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}

		if ( ! isset( $_POST['wcdp_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wcdp_nonce'] ) ), 'wcdp_save' ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		/*
		 * Raw on purpose. WCDP_Rules::save() is the single sanitiser, key by
		 * key, and it is the only thing that decides what a value may be.
		 */
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash
		$raw = isset( $_POST['wcdp'] ) && is_array( $_POST['wcdp'] ) ? wp_unslash( $_POST['wcdp'] ) : array();

		WCDP_Rules::save( $post_id, $raw );
	}

	/* ------------------------------------------------------------------ *
	 * The list table
	 * ------------------------------------------------------------------ */

	public static function columns( $columns ) {
		$date = $columns['date'] ?? null;

		unset( $columns['date'] );

		$columns['wcdp_type']     = __( 'Type', 'wpd-dynamic-pricing' );
		$columns['wcdp_discount'] = __( 'Discount', 'wpd-dynamic-pricing' );
		$columns['wcdp_applies']  = __( 'Applies to', 'wpd-dynamic-pricing' );
		$columns['wcdp_when']     = __( 'When', 'wpd-dynamic-pricing' );
		$columns['wcdp_priority'] = __( 'Priority', 'wpd-dynamic-pricing' );
		$columns['wcdp_status']   = __( 'Live', 'wpd-dynamic-pricing' );

		if ( $date ) {
			$columns['date'] = $date;
		}

		return $columns;
	}

	public static function sortable( $columns ) {
		$columns['wcdp_priority'] = 'menu_order';

		return $columns;
	}

	public static function column( $column, $post_id ) {
		$rule = WCDP_Rules::get( $post_id );

		switch ( $column ) {
			case 'wcdp_type':
				$names = array(
					'simple' => __( 'Discount', 'wpd-dynamic-pricing' ),
					'bulk'   => __( 'Quantity tiers', 'wpd-dynamic-pricing' ),
					'bogo'   => __( 'Buy X get Y', 'wpd-dynamic-pricing' ),
					'cart'   => __( 'Whole cart', 'wpd-dynamic-pricing' ),
				);

				echo esc_html( $names[ $rule['type'] ] ?? $rule['type'] );
				break;

			case 'wcdp_discount':
				echo esc_html( self::describe_discount( $rule ) );
				break;

			case 'wcdp_applies':
				$modes = array(
					'all'        => __( 'Everything', 'wpd-dynamic-pricing' ),
					'products'   => __( 'Chosen products', 'wpd-dynamic-pricing' ),
					'categories' => __( 'Chosen categories', 'wpd-dynamic-pricing' ),
					'tags'       => __( 'Chosen tags', 'wpd-dynamic-pricing' ),
				);

				echo esc_html( $modes[ $rule['apply_to']['mode'] ] ?? '' );

				if ( 'everyone' !== $rule['who']['mode'] ) {
					echo '<br /><small>' . esc_html__( 'some customers only', 'wpd-dynamic-pricing' ) . '</small>';
				}
				break;

			case 'wcdp_when':
				if ( '' === $rule['when']['start'] && '' === $rule['when']['end'] && ! $rule['when']['days'] ) {
					echo esc_html__( 'Always', 'wpd-dynamic-pricing' );
					break;
				}

				echo esc_html( trim( $rule['when']['start'] . ' — ' . $rule['when']['end'], ' —' ) );

				/*
				 * A scheduled rule that has already finished is worth saying so
				 * in the list. Otherwise it sits there looking live, and the
				 * shop owner spends an afternoon working out why it does
				 * nothing.
				 */
				if ( ! WCDP_Conditions::matches_now( $rule ) ) {
					echo '<br /><small style="color:#996800">' . esc_html__( 'not running right now', 'wpd-dynamic-pricing' ) . '</small>';
				}
				break;

			case 'wcdp_priority':
				echo esc_html( $rule['priority'] );

				if ( ! empty( $rule['exclusive'] ) ) {
					echo '<br /><small>' . esc_html__( 'stops others', 'wpd-dynamic-pricing' ) . '</small>';
				}
				break;

			case 'wcdp_status':
				echo empty( $rule['enabled'] )
					? '<span style="color:#b32d2e">' . esc_html__( 'Off', 'wpd-dynamic-pricing' ) . '</span>'
					: '<span style="color:#00794a">' . esc_html__( 'On', 'wpd-dynamic-pricing' ) . '</span>';
				break;
		}
	}

	/**
	 * @param array $rule Rule.
	 * @return string
	 */
	private static function describe_discount( array $rule ) {
		if ( 'bulk' === $rule['type'] ) {
			return sprintf(
				/* translators: %d: number of tiers. */
				_n( '%d tier', '%d tiers', count( $rule['tiers'] ), 'wpd-dynamic-pricing' ),
				count( $rule['tiers'] )
			);
		}

		if ( 'bogo' === $rule['type'] ) {
			return sprintf(
				/* translators: 1: buy quantity, 2: free quantity. */
				__( 'Buy %1$d get %2$d', 'wpd-dynamic-pricing' ),
				$rule['bogo']['buy'],
				$rule['bogo']['get']
			);
		}

		$adjust = $rule['adjust'];

		if ( 'percent' === $adjust['method'] ) {
			return $adjust['value'] . '%';
		}

		if ( 'fixed' === $adjust['method'] ) {
			return sprintf(
				/* translators: %s: money. */
				__( 'Set to %s', 'wpd-dynamic-pricing' ),
				wp_strip_all_tags( wc_price( $adjust['value'] ) )
			);
		}

		return wp_strip_all_tags( wc_price( $adjust['value'] ) );
	}

	/**
	 * @param string $hook Screen.
	 */
	public static function assets( $hook ) {
		if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			return;
		}

		$screen = get_current_screen();

		if ( ! $screen || WCDP_Rules::POST_TYPE !== $screen->post_type ) {
			return;
		}

		wp_enqueue_style( 'wcdp-admin', WCDP_URL . 'assets/admin.css', array(), WCDP_VERSION );
		wp_enqueue_script( 'wcdp-admin', WCDP_URL . 'assets/admin.js', array(), WCDP_VERSION, true );
	}
}

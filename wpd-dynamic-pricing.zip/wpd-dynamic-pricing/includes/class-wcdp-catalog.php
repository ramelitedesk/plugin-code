<?php
/**
 * Prices in the shop: listings, product pages, variation dropdowns.
 *
 * THE IMPORTANT PART OF THIS FILE IS THE CACHE HASH, not the price filters.
 *
 * WooCommerce caches the min and max price of every variable product in a
 * transient, keyed by a hash it builds from things it knows affect the price —
 * tax settings, the customer's tax location, and whatever plugins add to
 * woocommerce_get_variation_prices_hash.
 *
 * A pricing plugin that filters variation prices and does NOT add to that hash
 * produces this: the first visitor of the day warms the cache, and every
 * visitor afterwards is served that visitor's prices. If any rule targets a
 * role, the wholesale customer's price is now the public price on the shop
 * page. It is silent, it survives a page-cache purge, and it is by a distance
 * the most common serious bug in this category of plugin.
 *
 * So the customer's role and the rule set's fingerprint both go into the hash,
 * and the price range is correct per customer and changes the moment a rule
 * does.
 *
 * @package WPD_Dynamic_Pricing
 */

defined( 'ABSPATH' ) || exit;

class WCDP_Catalog {

	/** @var bool Guard against a filter re-entering itself. */
	private static $inside = false;

	public static function init() {
		/*
		 * Priority 100, so the store's own sale price is already in place. A
		 * rule that excludes on-sale products has to be able to see that the
		 * product is on sale, and at priority 10 it cannot.
		 */
		add_filter( 'woocommerce_product_get_price', array( __CLASS__, 'price' ), 100, 2 );
		add_filter( 'woocommerce_product_get_sale_price', array( __CLASS__, 'sale_price' ), 100, 2 );

		add_filter( 'woocommerce_product_variation_get_price', array( __CLASS__, 'price' ), 100, 2 );
		add_filter( 'woocommerce_product_variation_get_sale_price', array( __CLASS__, 'sale_price' ), 100, 2 );

		// The per-variation prices behind a variable product's range.
		add_filter( 'woocommerce_variation_prices_price', array( __CLASS__, 'variation_price' ), 100, 3 );
		add_filter( 'woocommerce_variation_prices_sale_price', array( __CLASS__, 'variation_price' ), 100, 3 );

		// The one that makes all of the above safe to cache.
		add_filter( 'woocommerce_get_variation_prices_hash', array( __CLASS__, 'price_hash' ), 100, 1 );

		/*
		 * A product this plugin has discounted should show as on sale, so it
		 * gets the shop's sale badge and appears in "on sale" widgets and
		 * shortcodes like any other reduction.
		 */
		add_filter( 'woocommerce_product_is_on_sale', array( __CLASS__, 'is_on_sale' ), 100, 2 );
	}

	/**
	 * @param string|float $price   The price WooCommerce has.
	 * @param WC_Product   $product Product.
	 * @return string|float
	 */
	public static function price( $price, $product ) {
		if ( '' === $price || null === $price || ! $product instanceof WC_Product ) {
			return $price;
		}

		/*
		 * The re-entry guard.
		 *
		 * The engine asks conditions whether the product is on sale, which
		 * calls get_sale_price(), which fires this filter's sibling, which
		 * calls the engine. Without the guard that is an infinite loop ending
		 * in a memory exhaustion fatal on the shop page — and it only shows up
		 * once somebody writes a rule with "exclude on sale" ticked.
		 */
		if ( self::$inside ) {
			return $price;
		}

		self::$inside = true;

		$result = WCDP_Engine::price( $product, (float) $price, 1 );

		self::$inside = false;

		return $result['price'];
	}

	/**
	 * The sale price, so the struck-through original reads correctly.
	 *
	 * @param string|float $price   Sale price.
	 * @param WC_Product   $product Product.
	 * @return string|float
	 */
	public static function sale_price( $price, $product ) {
		if ( ! $product instanceof WC_Product || self::$inside ) {
			return $price;
		}

		self::$inside = true;

		// Measured against the regular price, so what is shown struck through
		// is what the product would cost with no rule running.
		$regular = (float) $product->get_regular_price( 'edit' );

		$result = ( $regular > 0 ) ? WCDP_Engine::price( $product, $regular, 1 ) : null;

		self::$inside = false;

		if ( ! $result || ! $result['applied'] ) {
			return $price;
		}

		// A rule that beats the store's own sale price replaces it; one that
		// does not, leaves it alone. Whichever is cheaper is what the customer
		// will actually be charged, and it must be what they are shown.
		if ( '' !== $price && null !== $price && (float) $price > 0 && (float) $price <= $result['price'] ) {
			return $price;
		}

		return $result['price'];
	}

	/**
	 * @param string|float $price     Price.
	 * @param WC_Product   $variation Variation.
	 * @param WC_Product   $parent    Parent product.
	 * @return string|float
	 */
	public static function variation_price( $price, $variation, $parent ) {
		if ( '' === $price || null === $price || ! $variation instanceof WC_Product ) {
			return $price;
		}

		$result = WCDP_Engine::price( $variation, (float) $price, 1 );

		return $result['price'];
	}

	/**
	 * Mix this plugin into WooCommerce's variation price cache key.
	 *
	 * @param array $hash What WooCommerce will hash.
	 * @return array
	 */
	public static function price_hash( $hash ) {
		$hash['wcdp'] = array(
			// Changes the moment any rule is edited, added or deleted.
			WCDP_Rules::fingerprint(),
			// Changes per customer, because rules can target roles and users.
			WCDP_Conditions::customer_key(),
		);

		/*
		 * The date is in there because rules can be scheduled. Without it a
		 * sale that starts at midnight would not appear on a variable product
		 * until something else happened to bust the transient — which might be
		 * days.
		 */
		$hash['wcdp'][] = wp_date( 'Y-m-d-H' );

		return $hash;
	}

	/**
	 * @param bool       $on_sale Whether WooCommerce thinks it is on sale.
	 * @param WC_Product $product Product.
	 * @return bool
	 */
	public static function is_on_sale( $on_sale, $product ) {
		if ( $on_sale || ! $product instanceof WC_Product || self::$inside ) {
			return $on_sale;
		}

		self::$inside = true;

		$regular = (float) $product->get_regular_price( 'edit' );

		$result = ( $regular > 0 ) ? WCDP_Engine::price( $product, $regular, 1 ) : null;

		self::$inside = false;

		return $result ? ! empty( $result['applied'] ) : $on_sale;
	}
}

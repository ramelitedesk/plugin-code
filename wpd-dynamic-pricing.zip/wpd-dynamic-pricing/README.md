# WPD Dynamic Pricing Rules

Discount rules for WooCommerce — percentages, amounts off, set prices, quantity
tiers, buy-X-get-Y and whole-cart thresholds — targeted by product, category,
tag, customer role, specific customer, date, and day of the week.

**WooCommerce → Pricing Rules.**

---

## Rule types

| | |
| --- | --- |
| **A straight discount** | 10% off, £5 off, or set the price to £19.99. The everyday rule. |
| **Buy more, pay less** | Quantity tiers: 3–5 at 10% off, 6 or more at 20%. Counted per product, or across every product the rule covers so "any 3 shirts" works. |
| **Buy X, get Y** | Buy two get one free, or at any discount you choose. Optionally repeating for each further set. |
| **Whole-cart discount** | Spend over £100, or buy over 10 items, and take a discount off the cart total. Appears as its own line, not as a silent reprice. |

## Targeting

**Products** — everything, chosen products, chosen categories, chosen tags.
Choosing a parent category covers everything inside it, because "10% off
Clothing" means the shirts in it. Exclusions for products, and a default-on
**skip products already on sale**.

**Customers** — everybody, chosen roles, chosen customers, or only visitors who
are not logged in. "Not logged in" is offered as a role, because "wholesale
customers and guests" is a real rule and there is nowhere else to say it.

**When** — start and end datetimes in *store* time, plus specific days of the
week. An end date with no time covers the whole of that day, so a scheduled sale
does not lose its last day.

**Order** — rules stack in priority order, lowest first. Any rule can be marked
*stop after this one*. Each rule can carry a maximum discount in currency, as a
safety net against a mistyped percentage.

---

## The three traps this plugin is written around

**Variable-product price caching.** WooCommerce caches the min and max price of
every variable product in a transient, keyed by a hash. A pricing plugin that
filters variation prices and does not add to
`woocommerce_get_variation_prices_hash` produces this: the first visitor of the
day warms the cache, and everyone afterwards is served that visitor's prices. If
any rule targets a role, the wholesale price becomes the public price on the
shop page. It is silent, it survives a page-cache purge, and it is the most
common serious bug in this category of plugin. The customer's role and a rule-set
fingerprint both go into that hash here.

**`before_calculate_totals` runs more than once per request.** WooCommerce
recalculates when items change, when shipping is chosen, when a coupon is
applied, and again on checkout. A discount applied to whatever price is already
on the cart item compounds — three passes of 10% off is 27% off, and it varies
with how the customer reached the page. Every pass here recomputes from the
product's original stored price, read in `edit` context so the plugin's own
filters are bypassed.

**Rounding.** Money is rounded once, at the end, to the store's decimal setting.
Rounding after every rule compounds the error and produces a cart total that
does not match the sum of its lines.

---

## Prices only ever go down

Deliberate, and enforced in more than one place:

- A negative percentage or amount is clamped to zero on save. Somebody typing
  `-10` into a field labelled "discount" would otherwise raise every price in
  the shop.
- Over 100% is clamped to 100.
- **Set price to** never raises a price. A £20 fixed-price rule against a £15
  clearance product leaves it at £15 — charging more than the shop advertises is
  the one outcome this must never produce.
- Nothing goes below zero.
- A product with no price is left alone, not turned into 0.00 — that would make
  variable parents and price-on-application products free.

---

## What the customer sees

"You save £4.00 (20%)" under the price, the tier table on products a bulk rule
covers, and the rule's name with the original struck through on the cart line. A
discounted product also reports itself as on sale, so it picks up the theme's
sale badge and appears in on-sale widgets like any other reduction.

---

## Honest limits

- **Buy-X-get-Y spreads the saving across the line.** WooCommerce prices a cart
  line as quantity × one price, so a free item cannot be its own zero-priced
  row. The line total is exactly right; the per-unit price is not a round
  number. The editor says so where you configure it.
- **Full-page caching still needs configuring.** This keys WooCommerce's own
  caches by role, but a page cache in front of your site knows nothing about
  that. If you target roles, exclude shop and product pages from it.
- **Cart-level discounts are a negative fee, untaxed.** The discount comes off a
  subtotal that already had tax worked out, so taxing the negative fee again
  would remove the tax twice.
- **No coupon interaction.** These rules and WooCommerce coupons both apply;
  there is no "cannot combine with coupons" switch yet.
- **No usage limits or per-customer caps.** A rule runs whenever it matches.

---

## Tests

```bash
php tests/test.php
```

59 assertions, no WordPress, no WooCommerce, no PHPUnit.

Weighted towards the arithmetic and towards every path where a rule could make a
price go *up*, because a pricing bug is not a crash — it is a number that is
wrong by 40p on every order for three weeks until the accounts notice.

It has already earned its keep: `fingerprint()` is a read, called while a price
is being calculated, and it lazily created the first fingerprint by calling
`bump_fingerprint()` — which flushed the rule cache. The rules loaded a moment
earlier were thrown away mid-calculation, so on a fresh install **the first
price of the day came back with no rules applied at all**. Fixed by moving the
mutation into the writer where it belongs.

## Requirements

WordPress 5.8+, WooCommerce 6.0+, PHP 7.4+. No dependencies, no outbound calls.
Declares HPOS compatibility.

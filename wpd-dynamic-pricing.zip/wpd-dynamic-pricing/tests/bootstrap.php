<?php
/**
 * Enough of WordPress and WooCommerce to exercise the pricing decisions.
 *
 * The engine, the conditions and the rule sanitiser are pure decisions about
 * numbers and arrays. They need the function names, not the platforms.
 *
 * @package WPD_Dynamic_Pricing
 */

if ( 'cli' !== PHP_SAPI ) {
	http_response_code( 404 );
	exit;
}

define( 'ABSPATH', __DIR__ );
define( 'DAY_IN_SECONDS', 86400 );

define( 'WCDP_VERSION', 'test' );
define( 'WCDP_DIR', dirname( __DIR__ ) . '/' );
define( 'WCDP_URL', 'http://example.test/' );
define( 'WCDP_FILE', WCDP_DIR . 'wpd-dynamic-pricing.php' );

$GLOBALS['wcdp_test'] = array(
	'options'  => array(),
	'user'     => 0,
	'roles'    => array(),
	'terms'    => array(),
	'ancestors' => array(),
	'now'      => null,
);

/* ---------------- WordPress ---------------- */

function __( $t, $d = '' ) { return $t; }
function _n( $s, $p, $n, $d = '' ) { return 1 === (int) $n ? $s : $p; }
function esc_html( $t ) { return htmlspecialchars( (string) $t, ENT_QUOTES ); }
function absint( $v ) { return abs( (int) $v ); }
function sanitize_key( $v ) { return preg_replace( '/[^a-z0-9_\-]/', '', strtolower( (string) $v ) ); }
function sanitize_text_field( $v ) { return trim( strip_tags( (string) $v ) ); }
function apply_filters( $tag, $value ) { return $value; }
function add_action() {}
function add_filter() {}
function do_action() {}

function get_option( $k, $d = false ) { return $GLOBALS['wcdp_test']['options'][ $k ] ?? $d; }
function update_option( $k, $v, $a = null ) { $GLOBALS['wcdp_test']['options'][ $k ] = $v; return true; }

function get_post_meta( $id, $key = '', $single = false ) { return $single ? '' : array(); }
function update_post_meta( $id, $key, $value ) { return true; }
function get_the_title( $id ) { return 'Rule ' . $id; }
function get_posts( $args = array() ) { return array(); }
function wp_update_post( $args ) { return true; }

function get_current_user_id() { return (int) $GLOBALS['wcdp_test']['user']; }

function wp_get_current_user() {
	return (object) array(
		'ID'    => $GLOBALS['wcdp_test']['user'],
		'roles' => $GLOBALS['wcdp_test']['roles'],
	);
}

function current_time( $type ) {
	return null === $GLOBALS['wcdp_test']['now'] ? time() : $GLOBALS['wcdp_test']['now'];
}

function wp_date( $format, $timestamp = null ) { return gmdate( $format, $timestamp ?? time() ); }

function wp_get_post_terms( $post_id, $taxonomy, $args = array() ) {
	return $GLOBALS['wcdp_test']['terms'][ $post_id ][ $taxonomy ] ?? array();
}

function get_ancestors( $term_id, $taxonomy, $type = '' ) {
	return $GLOBALS['wcdp_test']['ancestors'][ $term_id ] ?? array();
}

function is_taxonomy_hierarchical( $taxonomy ) { return 'product_cat' === $taxonomy; }

class WP_Error {}
function is_wp_error( $thing ) { return $thing instanceof WP_Error; }

class WP_Roles_Stub {
	public function is_role( $role ) {
		return in_array( $role, array( 'customer', 'wholesale', 'administrator', 'subscriber' ), true );
	}
	public function get_names() {
		return array( 'customer' => 'Customer', 'wholesale' => 'Wholesale', 'administrator' => 'Administrator' );
	}
}

function wp_roles() {
	static $roles = null;

	if ( null === $roles ) { $roles = new WP_Roles_Stub(); }

	return $roles;
}

/* ---------------- WooCommerce ---------------- */

function wc_get_price_decimals() { return 2; }
function wc_price( $amount ) { return '&pound;' . number_format( (float) $amount, 2 ); }

/**
 * Just enough of a product to price one.
 */
class WC_Product {
	private $id;
	private $type;
	private $regular;
	private $sale;
	private $parent;

	public function __construct( $id, $regular, $sale = '', $type = 'simple', $parent = 0 ) {
		$this->id      = (int) $id;
		$this->regular = $regular;
		$this->sale    = $sale;
		$this->type    = $type;
		$this->parent  = (int) $parent;
	}

	public function get_id() { return $this->id; }
	public function get_parent_id() { return $this->parent; }
	public function is_type( $type ) { return $this->type === $type; }
	public function get_regular_price( $context = 'view' ) { return $this->regular; }
	public function get_sale_price( $context = 'view' ) { return $this->sale; }
	public function get_price( $context = 'view' ) { return '' !== $this->sale ? $this->sale : $this->regular; }
	public function set_price( $price ) { $this->regular = $price; }
}

/* ---------------- the plugin ---------------- */

require_once WCDP_DIR . 'includes/class-wcdp-rules.php';
require_once WCDP_DIR . 'includes/class-wcdp-conditions.php';
require_once WCDP_DIR . 'includes/class-wcdp-engine.php';

/**
 * Reset the fake shop.
 */
function wcdp_test_reset() {
	$GLOBALS['wcdp_test']['options']   = array();
	$GLOBALS['wcdp_test']['user']      = 0;
	$GLOBALS['wcdp_test']['roles']     = array();
	$GLOBALS['wcdp_test']['terms']     = array();
	$GLOBALS['wcdp_test']['ancestors'] = array();
	$GLOBALS['wcdp_test']['now']       = null;

	WCDP_Rules::flush();
	WCDP_Engine::flush();
}

/**
 * Sign in as somebody.
 *
 * @param int      $id    User id, 0 for a guest.
 * @param string[] $roles Their roles.
 */
function wcdp_login( $id, array $roles = array() ) {
	$GLOBALS['wcdp_test']['user']  = $id;
	$GLOBALS['wcdp_test']['roles'] = $roles;

	WCDP_Engine::flush();
}

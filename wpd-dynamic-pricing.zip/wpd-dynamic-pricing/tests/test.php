<?php
/**
 * What has to stay true about the money.
 *
 * A pricing bug is not a crash. It is a number that is wrong by 40p on every
 * order for three weeks, and nobody notices until the accounts do. So the
 * weighting here is: every arithmetic path, every clamp, and every case where
 * a rule could make a price go UP.
 *
 * @package WPD_Dynamic_Pricing
 */

require __DIR__ . '/bootstrap.php';

$pass = 0;
$fail = 0;

/**
 * @param string $label What is asserted.
 * @param bool   $ok    Whether it holds.
 * @param string $note  Shown on failure.
 */
function check( $label, $ok, $note = '' ) {
	global $pass, $fail;

	if ( $ok ) {
		$pass++;
		printf( "  ok    %s\n", $label );

		return;
	}

	$fail++;
	printf( "  FAIL  %s%s\n", $label, '' !== $note ? ' :: ' . $note : '' );
}

/**
 * @param float $expected Expected.
 * @param float $actual   Actual.
 * @return bool
 */
function money_is( $expected, $actual ) {
	return abs( (float) $expected - (float) $actual ) < 0.0001;
}

wcdp_test_reset();

$product = new WC_Product( 10, '100.00' );

/* ================================================================ *
 * The arithmetic
 * ================================================================ */

echo "\n=== One adjustment at a time ===\n";

check( '10% off 100 is 90', money_is( 90, WCDP_Engine::apply( 100, array( 'method' => 'percent', 'value' => 10 ) ) ) );
check( '£15 off 100 is 85', money_is( 85, WCDP_Engine::apply( 100, array( 'method' => 'amount', 'value' => 15 ) ) ) );
check( 'set-to-60 makes it 60', money_is( 60, WCDP_Engine::apply( 100, array( 'method' => 'fixed', 'value' => 60 ) ) ) );

check(
	'set-to-price never raises a price',
	money_is( 15, WCDP_Engine::apply( 15, array( 'method' => 'fixed', 'value' => 20 ) ) ),
	'a fixed-price rule is a discount tool; charging more than the shop advertises is the one outcome that must never happen'
);

check(
	'an amount bigger than the price floors at zero, never negative',
	money_is( 0, WCDP_Engine::apply( 10, array( 'method' => 'amount', 'value' => 50 ) ) )
);

check( '100% off is free', money_is( 0, WCDP_Engine::apply( 100, array( 'method' => 'percent', 'value' => 100 ) ) ) );
check( 'a zero-value adjustment changes nothing', money_is( 100, WCDP_Engine::apply( 100, array( 'method' => 'percent', 'value' => 0 ) ) ) );

check(
	'a discount ceiling caps the saving',
	money_is( 95, WCDP_Engine::apply( 100, array( 'method' => 'percent', 'value' => 50 ), 5 ) ),
	'50% of 100 is 50 off, but the rule says never more than 5'
);

check( 'a ceiling above the discount does nothing', money_is( 90, WCDP_Engine::apply( 100, array( 'method' => 'percent', 'value' => 10 ), 50 ) ) );

/* ================================================================ *
 * Sanitising
 * ================================================================ */

echo "\n=== A rule cannot be saved in a shape that raises prices ===\n";

$negative = WCDP_Rules::adjustment( array( 'method' => 'percent', 'value' => -10 ) );

check(
	'a negative percentage becomes zero',
	money_is( 0, $negative['value'] ),
	'somebody typing -10 into a field labelled "discount" would otherwise raise every price in the shop'
);

check( 'a negative amount becomes zero', money_is( 0, WCDP_Rules::adjustment( array( 'method' => 'amount', 'value' => -5 ) )['value'] ) );
check( 'over 100% is clamped to 100', money_is( 100, WCDP_Rules::adjustment( array( 'method' => 'percent', 'value' => 500 ) )['value'] ) );
check( 'a nonsense method falls back to percent', 'percent' === WCDP_Rules::adjustment( array( 'method' => 'wat', 'value' => 5 ) )['method'] );

/* ================================================================ *
 * Stacking
 * ================================================================ */

echo "\n=== Several rules at once ===\n";

WCDP_Rules::seed(
	array(
		array( 'id' => 1, 'priority' => 10, 'adjust' => array( 'method' => 'percent', 'value' => 10 ) ),
		array( 'id' => 2, 'priority' => 20, 'adjust' => array( 'method' => 'amount', 'value' => 5 ) ),
	)
);

WCDP_Engine::flush();

$result = WCDP_Engine::price( $product, 100 );

check( 'rules stack in priority order', money_is( 85, $result['price'] ), '100 less 10% is 90, less 5 is 85' );
check( 'both are recorded', 2 === count( $result['applied'] ) );
check( 'the original is kept', money_is( 100, $result['original'] ) );
check( 'the saving is the difference', money_is( 15, $result['saved'] ) );

/* --- priority order actually matters --- */

WCDP_Rules::seed(
	array(
		array( 'id' => 1, 'priority' => 20, 'adjust' => array( 'method' => 'percent', 'value' => 10 ) ),
		array( 'id' => 2, 'priority' => 10, 'adjust' => array( 'method' => 'amount', 'value' => 5 ) ),
	)
);

WCDP_Engine::flush();

check(
	'reversing the priorities changes the answer',
	money_is( 85.5, WCDP_Engine::price( $product, 100 )['price'] ),
	'100 less 5 is 95, less 10% is 85.50 — order is not cosmetic'
);

/* --- exclusive --- */

WCDP_Rules::seed(
	array(
		array( 'id' => 1, 'priority' => 10, 'exclusive' => 1, 'adjust' => array( 'method' => 'percent', 'value' => 10 ) ),
		array( 'id' => 2, 'priority' => 20, 'adjust' => array( 'method' => 'amount', 'value' => 50 ) ),
	)
);

WCDP_Engine::flush();

$result = WCDP_Engine::price( $product, 100 );

check( 'an exclusive rule stops the ones after it', money_is( 90, $result['price'] ) );
check( 'and only it is recorded', 1 === count( $result['applied'] ) );

/* --- a price of nothing --- */

WCDP_Rules::seed( array( array( 'id' => 1, 'adjust' => array( 'method' => 'percent', 'value' => 50 ) ) ) );
WCDP_Engine::flush();

check(
	'a product with no price is left alone, not made free',
	money_is( 0, WCDP_Engine::price( new WC_Product( 11, '' ), 0 )['price'] ),
	'a variable parent or a price-on-application product must not become 0.00'
);

check( 'and no rule is recorded against it', array() === WCDP_Engine::price( new WC_Product( 11, '' ), 0 )['applied'] );

/* ================================================================ *
 * Tiers
 * ================================================================ */

echo "\n=== Quantity tiers ===\n";

$tiers = array(
	array( 'min' => 3,  'max' => 5, 'method' => 'percent', 'value' => 10 ),
	array( 'min' => 6,  'max' => 0, 'method' => 'percent', 'value' => 20 ),
);

check( 'below the first threshold, nothing', null === WCDP_Engine::tier_for( $tiers, 2 ) );
check( 'at the threshold, the first tier', 10.0 === (float) WCDP_Engine::tier_for( $tiers, 3 )['value'] );
check( 'inside the first tier', 10.0 === (float) WCDP_Engine::tier_for( $tiers, 5 )['value'] );
check( 'at the second threshold', 20.0 === (float) WCDP_Engine::tier_for( $tiers, 6 )['value'] );
check( 'well past it, the open-ended tier holds', 20.0 === (float) WCDP_Engine::tier_for( $tiers, 500 )['value'] );

check(
	'a gap between tiers gives no discount',
	null === WCDP_Engine::tier_for(
		array(
			array( 'min' => 3, 'max' => 4, 'method' => 'percent', 'value' => 10 ),
			array( 'min' => 8, 'max' => 0, 'method' => 'percent', 'value' => 20 ),
		),
		6
	),
	'a quantity in the gap must not silently take the lower tier'
);

WCDP_Rules::seed( array( array( 'id' => 1, 'type' => 'bulk', 'tiers' => $tiers ) ) );
WCDP_Engine::flush();

check( 'buying one pays full price', money_is( 100, WCDP_Engine::price( $product, 100, 1 )['price'] ) );
check( 'buying three gets the first tier', money_is( 90, WCDP_Engine::price( $product, 100, 3 )['price'] ) );
check( 'buying ten gets the second', money_is( 80, WCDP_Engine::price( $product, 100, 10 )['price'] ) );

/* --- counting across matching lines --- */

WCDP_Rules::seed( array( array( 'id' => 1, 'type' => 'bulk', 'tier_scope' => 'matched', 'tiers' => $tiers ) ) );
WCDP_Engine::flush();

check(
	'"any 3" reads the matched total, not the line',
	money_is( 90, WCDP_Engine::price( $product, 100, 1, array( 'matched_quantity' => 4 ) )['price'] ),
	'one of this shirt plus three of another is still four shirts'
);

check(
	'and falls back to the line quantity outside a cart',
	money_is( 90, WCDP_Engine::price( $product, 100, 3 )['price'] ),
	'a catalogue page has no cart total, and should still show the tier working'
);

/* ================================================================ *
 * Who it applies to
 * ================================================================ */

echo "\n=== Customers ===\n";

$wholesale = array(
	'id'  => 1,
	'who' => array( 'mode' => 'roles', 'roles' => array( 'wholesale' ) ),
	'adjust' => array( 'method' => 'percent', 'value' => 30 ),
);

WCDP_Rules::seed( array( $wholesale ) );

wcdp_login( 0 );
check( 'a guest does not get the wholesale price', money_is( 100, WCDP_Engine::price( $product, 100 )['price'] ) );

wcdp_login( 5, array( 'customer' ) );
check( 'nor does an ordinary customer', money_is( 100, WCDP_Engine::price( $product, 100 )['price'] ) );

wcdp_login( 6, array( 'wholesale' ) );
check( 'the wholesale customer does', money_is( 70, WCDP_Engine::price( $product, 100 )['price'] ) );

check(
	'the cache key separates them',
	WCDP_Conditions::customer_key() !== ( function () {
		wcdp_login( 5, array( 'customer' ) );
		return WCDP_Conditions::customer_key();
	} )(),
	'sharing a key is how one customer\'s price is served to another'
);

/* --- guests as a pseudo-role --- */

WCDP_Rules::seed(
	array(
		array( 'id' => 1, 'who' => array( 'mode' => 'roles', 'roles' => array( 'guest' ) ), 'adjust' => array( 'method' => 'percent', 'value' => 5 ) ),
	)
);

wcdp_login( 0 );
check( '"not logged in" works as a role', money_is( 95, WCDP_Engine::price( $product, 100 )['price'] ) );

wcdp_login( 7, array( 'customer' ) );
check( 'and does not leak to logged-in customers', money_is( 100, WCDP_Engine::price( $product, 100 )['price'] ) );

wcdp_login( 0 );

/* ================================================================ *
 * Which products
 * ================================================================ */

echo "\n=== Products ===\n";

$GLOBALS['wcdp_test']['terms'][ 20 ]['product_cat'] = array( 55 );
$GLOBALS['wcdp_test']['terms'][ 21 ]['product_cat'] = array( 66 );
$GLOBALS['wcdp_test']['ancestors'][ 66 ]           = array( 55 );

$shirt = new WC_Product( 20, '50.00' );
$sub   = new WC_Product( 21, '50.00' );
$other = new WC_Product( 22, '50.00' );

$rule = array(
	'id'       => 1,
	'apply_to' => array( 'mode' => 'categories', 'categories' => array( 55 ) ),
	'adjust'   => array( 'method' => 'percent', 'value' => 10 ),
);

check( 'a product in the category matches', WCDP_Conditions::matches_product( WCDP_Rules::from_array( $rule ), $shirt ) );
check(
	'a product in a CHILD category matches too',
	WCDP_Conditions::matches_product( WCDP_Rules::from_array( $rule ), $sub ),
	'"10% off Clothing" means the shirts inside it, or the rule silently covers less than it says'
);
check( 'a product in neither does not', ! WCDP_Conditions::matches_product( WCDP_Rules::from_array( $rule ), $other ) );

/* --- variations inherit their parent's categories --- */

$variation = new WC_Product( 30, '50.00', '', 'variation', 20 );

WCDP_Conditions::flush();

check(
	'a variation is matched by its parent\'s category',
	WCDP_Conditions::matches_product( WCDP_Rules::from_array( $rule ), $variation ),
	'a variation has no terms of its own, so checking it directly skips every variable product'
);

/* --- already on sale --- */

$reduced = new WC_Product( 40, '50.00', '35.00' );

WCDP_Conditions::flush();

$excluding = WCDP_Rules::from_array( array( 'id' => 2, 'apply_to' => array( 'exclude_on_sale' => 1 ) ) );
$including = WCDP_Rules::from_array( array( 'id' => 3, 'apply_to' => array( 'exclude_on_sale' => 0 ) ) );

check( 'an already-reduced product is skipped by default', ! WCDP_Conditions::matches_product( $excluding, $reduced ) );
check( 'a full-price one is not', WCDP_Conditions::matches_product( $excluding, $shirt ) );

WCDP_Conditions::flush();

check( 'unticking the box lets rules stack on a sale price', WCDP_Conditions::matches_product( $including, $reduced ) );

/* --- exclusions --- */

WCDP_Conditions::flush();

$with_exclusion = WCDP_Rules::from_array(
	array( 'id' => 4, 'apply_to' => array( 'mode' => 'all', 'exclude_products' => array( 20 ) ) )
);

check( 'an excluded product is left alone', ! WCDP_Conditions::matches_product( $with_exclusion, $shirt ) );
check( 'and everything else is not', WCDP_Conditions::matches_product( $with_exclusion, $other ) );

/* ================================================================ *
 * Scheduling
 * ================================================================ */

echo "\n=== Scheduling ===\n";

$august = strtotime( '2026-08-15 12:00:00' );

$window = WCDP_Rules::from_array(
	array( 'id' => 1, 'when' => array( 'start' => '2026-08-01', 'end' => '2026-08-31', 'days' => array() ) )
);

check( 'inside the window it runs', WCDP_Conditions::matches_now( $window, $august ) );
check( 'before it starts, it does not', ! WCDP_Conditions::matches_now( $window, strtotime( '2026-07-31 12:00:00' ) ) );
check( 'after it ends, it does not', ! WCDP_Conditions::matches_now( $window, strtotime( '2026-09-01 12:00:00' ) ) );

check(
	'an end date with no time covers the whole of that day',
	WCDP_Conditions::matches_now( $window, strtotime( '2026-08-31 23:30:00' ) ),
	'otherwise every scheduled sale loses its last day'
);

$open_ended = WCDP_Rules::from_array( array( 'id' => 2, 'when' => array( 'start' => '2026-08-01', 'end' => '', 'days' => array() ) ) );

check( 'a start with no end runs forever after', WCDP_Conditions::matches_now( $open_ended, strtotime( '2030-01-01' ) ) );

// 2026-08-15 is a Saturday.
$weekend = WCDP_Rules::from_array( array( 'id' => 3, 'when' => array( 'start' => '', 'end' => '', 'days' => array( 0, 6 ) ) ) );

check( 'a weekend rule runs on a Saturday', WCDP_Conditions::matches_now( $weekend, $august ) );
check( 'and not on a Wednesday', ! WCDP_Conditions::matches_now( $weekend, strtotime( '2026-08-12 12:00:00' ) ) );

$always = WCDP_Rules::from_array( array( 'id' => 4 ) );

check( 'a rule with no schedule always runs', WCDP_Conditions::matches_now( $always, $august ) );

/* ================================================================ *
 * Rounding
 * ================================================================ */

echo "\n=== Rounding ===\n";

WCDP_Rules::seed(
	array(
		array( 'id' => 1, 'priority' => 10, 'adjust' => array( 'method' => 'percent', 'value' => 10 ) ),
		array( 'id' => 2, 'priority' => 20, 'adjust' => array( 'method' => 'percent', 'value' => 10 ) ),
		array( 'id' => 3, 'priority' => 30, 'adjust' => array( 'method' => 'percent', 'value' => 10 ) ),
	)
);

WCDP_Engine::flush();

$result = WCDP_Engine::price( $product, 19.99 );

check(
	'three 10% rules round once at the end',
	money_is( 14.57, $result['price'] ),
	'19.99 × 0.9³ is 14.5767, which is 14.58 rounded once and 14.57 rounded at each step — pick one and keep it'
);

check( 'the price has no more decimals than the store uses', $result['price'] === round( $result['price'], 2 ) );
check( 'the saving matches the difference exactly', money_is( 19.99 - $result['price'], $result['saved'] ) );

printf( "\n----\npassed: %d   failed: %d\n", $pass, $fail );

exit( $fail > 0 ? 1 : 0 );

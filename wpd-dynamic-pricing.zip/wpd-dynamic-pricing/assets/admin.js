/**
 * The rule editor: showing only the fields the chosen rule type uses, and
 * managing tier rows.
 *
 * @package WPD_Dynamic_Pricing
 */
( function () {
	'use strict';

	var form = document.getElementById( 'post' );

	if ( ! form || ! form.querySelector( '[name="wcdp[type]"]' ) ) {
		return;
	}

	/**
	 * Show the panels belonging to the selected rule type.
	 *
	 * Sections are hidden rather than removed, so their fields still submit.
	 * Removing them would mean switching type to look at it and back again
	 * silently wipes the settings of the type you switched away from — which is
	 * how somebody loses a tier table they spent ten minutes on.
	 */
	function syncType() {
		var chosen = form.querySelector( '[name="wcdp[type]"]:checked' );
		var type = chosen ? chosen.value : 'simple';

		form.querySelectorAll( '.wcdp-for' ).forEach( function ( section ) {
			section.hidden = ! section.classList.contains( 'wcdp-for--' + type );
		} );
	}

	/**
	 * Show only the product-target fields the chosen mode uses.
	 */
	function syncApplyMode() {
		var chosen = form.querySelector( '[name="wcdp[apply_to][mode]"]:checked' );
		var mode = chosen ? chosen.value : 'all';

		[ 'products', 'categories', 'tags' ].forEach( function ( name ) {
			form.querySelectorAll( '.wcdp-when-mode-' + name ).forEach( function ( node ) {
				node.hidden = ( mode !== name );
			} );
		} );
	}

	function syncWhoMode() {
		var chosen = form.querySelector( '[name="wcdp[who][mode]"]:checked' );
		var mode = chosen ? chosen.value : 'everyone';

		form.querySelectorAll( '.wcdp-who-roles' ).forEach( function ( node ) {
			node.hidden = ( mode !== 'roles' );
		} );

		form.querySelectorAll( '.wcdp-who-users' ).forEach( function ( node ) {
			node.hidden = ( mode !== 'users' );
		} );
	}

	/**
	 * Renumber tier rows after an add or a remove.
	 *
	 * PHP reads wcdp[tiers][N] as an ordered list, so a gap left by a deleted
	 * row drops everything after it on save.
	 */
	function renumberTiers() {
		var body = document.getElementById( 'wcdp-tiers' );

		if ( ! body ) {
			return;
		}

		body.querySelectorAll( '.wcdp-tier' ).forEach( function ( row, index ) {
			row.querySelectorAll( 'input, select' ).forEach( function ( field ) {
				if ( field.name ) {
					field.name = field.name.replace( /wcdp\[tiers\]\[[^\]]*\]/, 'wcdp[tiers][' + index + ']' );
				}
			} );
		} );
	}

	form.addEventListener( 'change', function ( event ) {
		if ( ! event.target.name ) {
			return;
		}

		if ( event.target.name === 'wcdp[type]' ) {
			syncType();
		}

		if ( event.target.name === 'wcdp[apply_to][mode]' ) {
			syncApplyMode();
		}

		if ( event.target.name === 'wcdp[who][mode]' ) {
			syncWhoMode();
		}
	} );

	form.addEventListener( 'click', function ( event ) {
		var add = event.target.closest ? event.target.closest( '#wcdp-add-tier' ) : null;

		if ( add ) {
			var template = document.getElementById( 'tmpl-wcdp-tier' );
			var body = document.getElementById( 'wcdp-tiers' );

			if ( template && body ) {
				var count = body.querySelectorAll( '.wcdp-tier' ).length;

				body.insertAdjacentHTML( 'beforeend', template.innerHTML.replace( /__INDEX__/g, count ) );

				renumberTiers();
			}

			return;
		}

		var remove = event.target.closest ? event.target.closest( '.wcdp-remove-tier' ) : null;

		if ( remove ) {
			var row = remove.closest( '.wcdp-tier' );

			// Never remove the last row. An empty tier table looks broken and
			// there is nothing to click to get a row back.
			if ( row && row.parentNode.querySelectorAll( '.wcdp-tier' ).length > 1 ) {
				row.remove();

				renumberTiers();
			}
		}
	} );

	syncType();
	syncApplyMode();
	syncWhoMode();
}() );

<?php
/**
 * Plugin Name:       WPD Dynamic Pricing Rules
 * Plugin URI:        https://webart.technology/
 * Description:       Percentage, fixed and set-price discounts on WooCommerce products, with quantity tiers, cart-level thresholds, buy-X-get-Y, role and customer targeting, and scheduling. Rules are priced consistently in the catalogue and in the cart, because a price that changes between the two is a refund request.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * WC requires at least: 6.0
 * WC tested up to:   9.4
 * Author:            Ramakrishna
 * License:           GPL-2.0-or-later
 * Text Domain:       wpd-dynamic-pricing
 *
 * @package WPD_Dynamic_Pricing
 */

defined( 'ABSPATH' ) || exit;

define( 'WCDP_VERSION', '1.0.0' );
define( 'WCDP_FILE', __FILE__ );
define( 'WCDP_DIR', plugin_dir_path( __FILE__ ) );
define( 'WCDP_URL', plugin_dir_url( __FILE__ ) );

/**
 * A pricing plugin has one failure mode that matters and it is not "the
 * discount did not apply".
 *
 * That one is loud. The customer sees the full price, does not buy, and
 * somebody notices within a day. The expensive failure is the opposite: the
 * catalogue says £18 and the cart says £24, or two customers see two different
 * prices for the same product because one of them warmed a cache. Nobody
 * reports it as a bug — they report it as "your site charged me more than it
 * said", and by then it is a refund, a chargeback, or in some jurisdictions a
 * trading standards problem.
 *
 * So the rules this is built on:
 *
 *   • ONE engine decides the price. The catalogue filter, the cart calculation
 *     and the price HTML all call the same method with the same arguments. Two
 *     code paths that both compute a price will disagree eventually, and the
 *     disagreement is invisible from the inside.
 *   • Every cache key WooCommerce builds gets the customer's role and the rule
 *     set's fingerprint mixed in. WooCommerce caches variable-product price
 *     ranges in a transient; a plugin that changes prices per role and forgets
 *     woocommerce_get_variation_prices_hash serves the wholesale price to the
 *     public. That is the single most common bug in this category of plugin.
 *   • The cart is recalculated from the ORIGINAL price every time, never from
 *     the price already on the cart item. before_calculate_totals fires more
 *     than once per request, and compounding a 10% discount three times is 27%.
 *   • Money is rounded once, at the end, to the store's decimal setting. Every
 *     intermediate step stays in full precision.
 *   • Nothing is applied to a price of zero, and no discount is allowed to take
 *     a price below zero.
 */
final class WPD_Dynamic_Pricing {

	/** @var WPD_Dynamic_Pricing|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->boot();
		}

		return self::$instance;
	}

	private function boot() {
		add_action( 'plugins_loaded', array( $this, 'init' ), 20 );

		register_activation_hook( WCDP_FILE, array( __CLASS__, 'activate' ) );

		/*
		 * Declared before WooCommerce initialises, or the store shows a
		 * compatibility warning on its status screen. This plugin stores rules
		 * as a post type and never touches the orders tables directly, so
		 * high-performance order storage changes nothing for it.
		 */
		add_action(
			'before_woocommerce_init',
			static function () {
				if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
					\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', WCDP_FILE, true );
				}
			}
		);
	}

	public function init() {
		/*
		 * Everything below needs WooCommerce. Without it the rule editor would
		 * offer product categories that do not exist and the price filters
		 * would hook nothing — so the plugin says why and stops, rather than
		 * half-loading.
		 */
		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action( 'admin_notices', array( __CLASS__, 'missing_woocommerce' ) );

			return;
		}

		require_once WCDP_DIR . 'includes/class-wcdp-rules.php';
		require_once WCDP_DIR . 'includes/class-wcdp-conditions.php';
		require_once WCDP_DIR . 'includes/class-wcdp-engine.php';
		require_once WCDP_DIR . 'includes/class-wcdp-catalog.php';
		require_once WCDP_DIR . 'includes/class-wcdp-cart.php';
		require_once WCDP_DIR . 'includes/class-wcdp-display.php';

		if ( is_admin() ) {
			require_once WCDP_DIR . 'includes/class-wcdp-admin.php';
		}

		WCDP_Rules::init();
		WCDP_Catalog::init();
		WCDP_Cart::init();
		WCDP_Display::init();

		if ( is_admin() && class_exists( 'WCDP_Admin' ) ) {
			WCDP_Admin::init();
		}

		load_plugin_textdomain( 'wpd-dynamic-pricing', false, dirname( plugin_basename( WCDP_FILE ) ) . '/languages' );

		do_action( 'wcdp_loaded', $this );
	}

	public static function missing_woocommerce() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		printf(
			'<div class="notice notice-warning"><p><strong>%s</strong> %s</p></div>',
			esc_html__( 'WPD Dynamic Pricing Rules:', 'wpd-dynamic-pricing' ),
			esc_html__( 'WooCommerce is not active, so no pricing rules are running.', 'wpd-dynamic-pricing' )
		);
	}

	public static function activate() {
		// Nothing to install. Rules are a post type registered on init and there
		// are no rules until somebody writes one, so activating this plugin
		// changes not a single price.
		WCDP_Rules::bump_fingerprint();
	}
}

WPD_Dynamic_Pricing::instance();

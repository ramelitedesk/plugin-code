<?php
/**
 * Which tasks exist, and which of them apply to this site.
 *
 * @package Database_Cleaner
 */

defined( 'ABSPATH' ) || exit;

class DBC_Registry {

	/** @var DBC_Task[]|null */
	private static $tasks = null;

	/**
	 * @return DBC_Task[] Keyed by task key.
	 */
	public static function all() {
		if ( null !== self::$tasks ) {
			return self::$tasks;
		}

		$classes = array(
			'DBC_Task_Revisions',
			'DBC_Task_Auto_Drafts',
			'DBC_Task_Trashed_Posts',
			'DBC_Task_Orphan_Postmeta',
			'DBC_Task_Orphan_Commentmeta',
			'DBC_Task_Orphan_Termmeta',
			'DBC_Task_Orphan_Usermeta',
			'DBC_Task_Orphan_Relationships',
			'DBC_Task_Duplicate_Postmeta',
			'DBC_Task_Expired_Transients',
			'DBC_Task_Oembed_Cache',
			'DBC_Task_Spam_Comments',
			'DBC_Task_Trashed_Comments',
			'DBC_Task_Pingbacks',
			'DBC_Task_Action_Scheduler',
		);

		/**
		 * Register another cleanup task.
		 *
		 * @param string[] $classes Class names extending DBC_Task.
		 */
		$classes = (array) apply_filters( 'dbc_tasks', $classes );

		$tasks = array();

		foreach ( $classes as $class ) {
			if ( ! class_exists( $class ) ) {
				continue;
			}

			$task = new $class();

			if ( ! $task instanceof DBC_Task ) {
				continue;
			}

			// A task can decline to appear at all — Action Scheduler's tables
			// are not on most sites, and an empty row for something that does
			// not exist is noise, not information.
			if ( method_exists( $task, 'available' ) && ! $task->available() ) {
				continue;
			}

			$tasks[ $task->key() ] = $task;
		}

		self::$tasks = $tasks;

		return $tasks;
	}

	/**
	 * @param string $key Task key.
	 * @return DBC_Task|null
	 */
	public static function get( $key ) {
		$tasks = self::all();

		return isset( $tasks[ $key ] ) ? $tasks[ $key ] : null;
	}

	/**
	 * Tasks grouped by their heading, each with its current count.
	 *
	 * Counting is the expensive part — several of these are full table scans —
	 * so it happens once here rather than once per template loop.
	 *
	 * @return array<string,array[]>
	 */
	public static function grouped() {
		$out = array();

		foreach ( self::all() as $task ) {
			$out[ $task->group() ][] = array(
				'task'  => $task,
				'count' => $task->count(),
			);
		}

		return $out;
	}

	/**
	 * @return DBC_Task[] Tasks that may run unattended.
	 */
	public static function schedulable() {
		return array_filter(
			self::all(),
			static function ( $task ) {
				return $task->schedulable();
			}
		);
	}

	public static function flush() {
		self::$tasks = null;
	}
}

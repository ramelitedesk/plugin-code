<?php
/**
 * Settings, and the record of what has been cleaned.
 *
 * @package Database_Cleaner
 */

defined( 'ABSPATH' ) || exit;

class DBC_Options {

	const OPTION = 'dbc_settings';

	/** @var array|null */
	private static $cache = null;

	/**
	 * @return array
	 */
	public static function defaults() {
		return apply_filters(
			'dbc_default_settings',
			array(
				'_schema'           => 1,

				// Revisions are the only undo an editor has. Keeping three
				// costs almost nothing and is the difference between "I can put
				// that back" and "it is gone".
				'keep_revisions'    => 3,

				'keep_actions_days' => 30,

				// Scheduling is off until somebody turns it on. A plugin that
				// starts deleting on a timer because it was activated is not a
				// plugin, it is an accident waiting for a date.
				'schedule'          => 'off',
				'scheduled_tasks'   => array(),

				// Shown until dismissed, and it should be.
				'backup_ack'        => 0,
			)
		);
	}

	/**
	 * @return array
	 */
	public static function all() {
		if ( null === self::$cache ) {
			$saved       = get_option( self::OPTION, array() );
			self::$cache = wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
		}

		return self::$cache;
	}

	/**
	 * @param string $key     Key.
	 * @param mixed  $default Fallback.
	 * @return mixed
	 */
	public static function get( $key, $default = null ) {
		$all = self::all();

		return array_key_exists( $key, $all ) ? $all[ $key ] : $default;
	}

	/**
	 * @param string $key Key.
	 * @return bool
	 */
	public static function enabled( $key ) {
		return (bool) self::get( $key, false );
	}

	/**
	 * @param array $values Values.
	 */
	public static function update( array $values ) {
		update_option( self::OPTION, wp_parse_args( $values, self::all() ), false );

		self::$cache = null;
	}

	public static function install_defaults() {
		if ( false === get_option( self::OPTION, false ) ) {
			add_option( self::OPTION, self::defaults(), '', false );
		}
	}
}

/**
 * What was cleaned, when, and how much of it.
 *
 * Kept for one reason above all others: when something breaks a week after a
 * cleanup, the first question is "what did that plugin actually delete?" — and
 * "I do not know" is an unacceptable answer from a tool that deletes things.
 */
class DBC_Log {

	const OPTION = 'dbc_log';

	const MAX = 200;

	/**
	 * @param string $task    Task key.
	 * @param string $message What happened.
	 * @param int    $removed Rows removed.
	 */
	public static function record( $task, $message, $removed ) {
		$entries = self::all();

		array_unshift(
			$entries,
			array(
				'time'    => time(),
				'task'    => (string) $task,
				'message' => (string) $message,
				'removed' => (int) $removed,
				'user'    => function_exists( 'get_current_user_id' ) ? (int) get_current_user_id() : 0,
				'site'    => function_exists( 'get_current_blog_id' ) ? (int) get_current_blog_id() : 0,
			)
		);

		update_option( self::OPTION, array_slice( $entries, 0, self::MAX ), false );
	}

	/**
	 * @return array[]
	 */
	public static function all() {
		$stored = get_option( self::OPTION, array() );

		return is_array( $stored ) ? $stored : array();
	}

	/**
	 * @return int Rows removed in total, ever.
	 */
	public static function total_removed() {
		$total = 0;

		foreach ( self::all() as $entry ) {
			$total += (int) $entry['removed'];
		}

		return $total;
	}

	public static function clear() {
		delete_option( self::OPTION );
	}
}

<?php
/**
 * Refuse updates that are not ours.
 *
 * WordPress has no idea where a plugin came from. On every update check it
 * sends the folder name of everything installed to api.wordpress.org, and the
 * API answers with whatever plugin holds that slug in the public directory. If
 * the version there is higher than the one in the header — and 1.0.0 is lower
 * than almost everything — the plugins screen offers an update.
 *
 * Pressing it does not update this plugin. It deletes it and installs a
 * different plugin, by a different author, that happens to share a folder name.
 * The site keeps running, the plugin list still shows a plausible entry, and the
 * only sign anything happened is that all your settings are gone and the screens
 * look unfamiliar.
 *
 * This plugin hit exactly that: the slug "database-cleaner" belongs to a plugin
 * by Jordy Meow on WordPress.org. The folder is now prefixed, which is the
 * primary fix. This is the second one, and it is the one that keeps working
 * when somebody claims the new slug in a year's time.
 *
 * The correct answer for a plugin distributed outside the directory is to say
 * so: this plugin is not on WordPress.org, so nothing WordPress.org offers for
 * it is an update to it.
 *
 * @package Database_Cleaner
 */

defined( 'ABSPATH' ) || exit;

class DBC_Updates {

	public static function hook() {
		add_filter( 'site_transient_update_plugins', array( __CLASS__, 'remove_foreign_update' ), 100 );
		add_filter( 'plugins_api_result', array( __CLASS__, 'remove_foreign_details' ), 100, 3 );
	}

	/**
	 * Drop any update offered for this plugin file.
	 *
	 * @param mixed $transient The update_plugins transient.
	 * @return mixed
	 */
	public static function remove_foreign_update( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}

		$basename = plugin_basename( DBC_FILE );

		/**
		 * Allow an update through — for a private update server, say.
		 *
		 * @param bool $block Whether to refuse WordPress.org updates.
		 */
		if ( ! apply_filters( 'dbc_block_directory_updates', true ) ) {
			return $transient;
		}

		if ( isset( $transient->response[ $basename ] ) ) {
			unset( $transient->response[ $basename ] );
		}

		// no_update drives the "automatic updates" column. An entry there is
		// still an entry describing somebody else's plugin.
		if ( isset( $transient->no_update[ $basename ] ) ) {
			unset( $transient->no_update[ $basename ] );
		}

		return $transient;
	}

	/**
	 * Stop the "View details" panel describing the wrong plugin.
	 *
	 * @param object|WP_Error $result Result from the API.
	 * @param string          $action API action.
	 * @param object          $args   Request args.
	 * @return object|WP_Error
	 */
	public static function remove_foreign_details( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) ) {
			return $result;
		}

		$ours = dirname( plugin_basename( DBC_FILE ) );

		if ( $args->slug !== $ours ) {
			return $result;
		}

		return new WP_Error(
			'dbc_not_in_directory',
			__( 'This plugin is not on WordPress.org, so there is no listing to show. Anything the directory offers under this name is a different plugin.', 'wpd-database-cleaner' )
		);
	}
}

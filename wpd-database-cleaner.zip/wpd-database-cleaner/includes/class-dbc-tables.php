<?php
/**
 * Tables: what is here, how big it is, and which of it nothing owns.
 *
 * This is the most dangerous screen in the plugin and it is built to be slow to
 * use on purpose.
 *
 * "Unused table" is a guess. There is no register of which plugin owns which
 * table — the only evidence available is a name that looks like a plugin's
 * slug, and that evidence is weak. A table can look abandoned and be the only
 * copy of something irreplaceable: an order history from a shop plugin that was
 * deactivated for a fortnight, a form's submissions, a membership list. So
 * nothing here is ever dropped automatically, dropping is never offered in
 * bulk, and each drop needs the table's own name typed out by hand.
 *
 * What this screen is genuinely for is the first half of the job: showing you
 * that 400 MB of a 460 MB database belongs to three tables from a plugin you
 * removed in 2021. Deciding they can go is still yours.
 *
 * @package Database_Cleaner
 */

defined( 'ABSPATH' ) || exit;

class DBC_Tables {

	/** @var array|null */
	private static $names = null;

	/**
	 * Every table this WordPress install can see.
	 *
	 * @return array[] name, rows, data, index, total, engine, collation
	 */
	public static function all() {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results( 'SHOW TABLE STATUS', ARRAY_A );

		$out = array();

		foreach ( (array) $rows as $row ) {
			$data  = (int) ( $row['Data_length'] ?? 0 );
			$index = (int) ( $row['Index_length'] ?? 0 );

			$out[] = array(
				'name'      => (string) $row['Name'],
				'rows'      => (int) ( $row['Rows'] ?? 0 ),
				'data'      => $data,
				'index'     => $index,
				'overhead'  => (int) ( $row['Data_free'] ?? 0 ),
				'total'     => $data + $index,
				'engine'    => (string) ( $row['Engine'] ?? '' ),
				'collation' => (string) ( $row['Collation'] ?? '' ),
				'core'      => self::is_core( (string) $row['Name'] ),
				'ours'      => self::has_prefix( (string) $row['Name'] ),
				'claimed'   => self::claimed_by( (string) $row['Name'] ),
			);
		}

		usort(
			$out,
			static function ( $a, $b ) {
				return $b['total'] <=> $a['total'];
			}
		);

		return $out;
	}

	/**
	 * @return int Total bytes across every table.
	 */
	public static function total_size() {
		$total = 0;

		foreach ( self::all() as $table ) {
			$total += $table['total'];
		}

		return $total;
	}

	/**
	 * Tables that carry this install's prefix but belong to no core table and
	 * no active plugin or theme.
	 *
	 * @return array[]
	 */
	public static function unclaimed() {
		$out = array();

		foreach ( self::all() as $table ) {
			if ( $table['core'] || ! $table['ours'] || '' !== $table['claimed'] ) {
				continue;
			}

			$out[] = $table;
		}

		return $out;
	}

	/**
	 * Does this table belong to WordPress itself?
	 *
	 * Checked against wpdb's own lists rather than a hard-coded set, so it stays
	 * right across versions and covers multisite's extra tables and any table a
	 * plugin has registered through $wpdb->tables.
	 *
	 * @param string $name Table name.
	 * @return bool
	 */
	public static function is_core( $name ) {
		global $wpdb;

		if ( null === self::$names ) {
			$names = array();

			foreach ( array( 'all', 'global', 'ms_global', 'blog' ) as $scope ) {
				foreach ( (array) $wpdb->tables( $scope, true ) as $table ) {
					$names[ strtolower( $table ) ] = true;
				}
			}

			/*
			 * On multisite, every site's tables are core tables — wp_7_posts is
			 * not an abandoned table just because we are looking from site 1.
			 */
			if ( is_multisite() && function_exists( 'get_sites' ) ) {
				foreach ( get_sites( array( 'number' => 0, 'fields' => 'ids' ) ) as $blog_id ) {
					foreach ( (array) $wpdb->tables( 'blog', true, (int) $blog_id ) as $table ) {
						$names[ strtolower( $table ) ] = true;
					}
				}
			}

			self::$names = $names;
		}

		return isset( self::$names[ strtolower( $name ) ] );
	}

	/**
	 * @param string $name Table name.
	 * @return bool Whether it carries this install's table prefix.
	 */
	public static function has_prefix( $name ) {
		global $wpdb;

		$prefix = strtolower( $wpdb->base_prefix );

		return '' !== $prefix && 0 === strpos( strtolower( $name ), $prefix );
	}

	/**
	 * Which active plugin or theme, if any, looks like it owns this table.
	 *
	 * A name match, and nothing more. It is stated as a guess on screen because
	 * that is what it is: a plugin is free to name its tables anything, and
	 * several deliberately do not use their own slug.
	 *
	 * @param string $name Table name.
	 * @return string Plugin name, or ''.
	 */
	public static function claimed_by( $name ) {
		global $wpdb;

		$suffix = strtolower( substr( $name, strlen( $wpdb->base_prefix ) ) );

		if ( '' === $suffix ) {
			return '';
		}

		foreach ( self::active_slugs() as $slug => $label ) {
			$slug = strtolower( $slug );

			if ( '' === $slug || strlen( $slug ) < 3 ) {
				continue;
			}

			if ( 0 === strpos( $suffix, $slug ) || 0 === strpos( $suffix, str_replace( '-', '_', $slug ) ) ) {
				return $label;
			}
		}

		return '';
	}

	/**
	 * @return array<string,string> slug => human name, for everything active.
	 */
	private static function active_slugs() {
		$out = array();

		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$active = (array) get_option( 'active_plugins', array() );

		if ( is_multisite() ) {
			$active = array_merge( $active, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
		}

		$all = function_exists( 'get_plugins' ) ? get_plugins() : array();

		foreach ( $active as $file ) {
			$slug  = dirname( $file );
			$slug  = ( '.' === $slug ) ? basename( $file, '.php' ) : $slug;
			$label = isset( $all[ $file ]['Name'] ) ? $all[ $file ]['Name'] : $slug;

			$out[ $slug ] = $label;

			// Plugins routinely shorten their own slug for table names —
			// "woocommerce" becomes "wc_", "gravityforms" becomes "gf_".
			$short = preg_replace( '/[^a-z]/', '', strtolower( $slug ) );

			if ( strlen( $short ) >= 4 ) {
				$out[ substr( $short, 0, 2 ) ] = $label;
			}
		}

		$theme = wp_get_theme();

		if ( $theme && $theme->get_stylesheet() ) {
			$out[ $theme->get_stylesheet() ] = $theme->get( 'Name' );
		}

		/**
		 * Claim a table prefix for something this cannot detect.
		 *
		 * @param array<string,string> $out slug => label.
		 */
		return (array) apply_filters( 'dbc_table_owners', $out );
	}

	/**
	 * @param string $name Table name.
	 * @return bool
	 */
	public static function exists( $name ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
		return (bool) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $name ) ) );
	}

	/**
	 * Drop one table, named in full and confirmed by name.
	 *
	 * The confirmation is not decoration. Typing "wp_old_plugin_data" is a
	 * different act from clicking a button next to it, and the difference is
	 * exactly the moment of attention this needs.
	 *
	 * @param string $name      Table to drop.
	 * @param string $confirmed What the person typed.
	 * @return true|WP_Error
	 */
	public static function drop( $name, $confirmed ) {
		global $wpdb;

		$name      = trim( (string) $name );
		$confirmed = trim( (string) $confirmed );

		if ( ! hash_equals( $name, $confirmed ) ) {
			return new WP_Error(
				'dbc_not_confirmed',
				__( 'The name typed did not match the table. Nothing was dropped.', 'wpd-database-cleaner' )
			);
		}

		if ( ! preg_match( '/^[A-Za-z0-9_]+$/', $name ) ) {
			return new WP_Error( 'dbc_bad_name', __( 'That is not a valid table name.', 'wpd-database-cleaner' ) );
		}

		if ( self::is_core( $name ) ) {
			return new WP_Error(
				'dbc_core_table',
				__( 'That is a WordPress table. It will not be dropped from here at any confirmation — restoring one means restoring a backup.', 'wpd-database-cleaner' )
			);
		}

		if ( ! self::has_prefix( $name ) ) {
			return new WP_Error(
				'dbc_foreign_table',
				__( 'That table does not carry this install\'s prefix, so it belongs to something else sharing this database. It will not be dropped from here.', 'wpd-database-cleaner' )
			);
		}

		if ( ! self::exists( $name ) ) {
			return new WP_Error( 'dbc_missing', __( 'That table is not there any more.', 'wpd-database-cleaner' ) );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( "DROP TABLE `{$name}`" );

		if ( self::exists( $name ) ) {
			return new WP_Error( 'dbc_drop_failed', __( 'The database refused to drop that table. The user WordPress connects as may not have DROP permission.', 'wpd-database-cleaner' ) );
		}

		DBC_Log::record( 'table_dropped', sprintf( 'Dropped table %s', $name ), 0 );

		return true;
	}

	/**
	 * Reclaim space left behind by deleted rows.
	 *
	 * On MyISAM this is what "overhead" means and OPTIMIZE genuinely reclaims
	 * it. On InnoDB — which is everything modern — OPTIMIZE is a full table
	 * rebuild that locks the table for its duration and often reclaims nothing,
	 * because InnoDB reuses that space itself. Both facts are on screen, because
	 * running this on a 4 GB orders table during business hours is a way to take
	 * a shop offline for ten minutes.
	 *
	 * @param string[] $names Tables to optimise. Empty for all with overhead.
	 * @return array{done:string[],failed:string[],reclaimed:int}
	 */
	public static function optimize( array $names = array() ) {
		global $wpdb;

		$before = array();
		$result = array( 'done' => array(), 'failed' => array(), 'reclaimed' => 0 );

		foreach ( self::all() as $table ) {
			if ( $names && ! in_array( $table['name'], $names, true ) ) {
				continue;
			}

			if ( ! $names && $table['overhead'] <= 0 ) {
				continue;
			}

			if ( ! self::has_prefix( $table['name'] ) ) {
				continue; // Not ours to touch.
			}

			$before[ $table['name'] ] = $table['total'] + $table['overhead'];
		}

		foreach ( array_keys( $before ) as $name ) {
			if ( ! preg_match( '/^[A-Za-z0-9_]+$/', $name ) ) {
				continue;
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$ok = $wpdb->query( "OPTIMIZE TABLE `{$name}`" );

			if ( false === $ok ) {
				$result['failed'][] = $name;
				continue;
			}

			$result['done'][] = $name;
		}

		foreach ( self::all() as $table ) {
			if ( isset( $before[ $table['name'] ] ) ) {
				$result['reclaimed'] += max( 0, $before[ $table['name'] ] - ( $table['total'] + $table['overhead'] ) );
			}
		}

		return $result;
	}

	/**
	 * @return int Total reclaimable overhead across every table.
	 */
	public static function total_overhead() {
		$total = 0;

		foreach ( self::all() as $table ) {
			$total += max( 0, $table['overhead'] );
		}

		return $total;
	}
}

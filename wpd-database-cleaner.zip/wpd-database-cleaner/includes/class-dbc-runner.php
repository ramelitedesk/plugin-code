<?php
/**
 * Running tasks: by hand, across a network, and on a schedule.
 *
 * @package Database_Cleaner
 */

defined( 'ABSPATH' ) || exit;

class DBC_Runner {

	/** @var DBC_Runner|null */
	private static $instance = null;

	const CRON_HOOK = 'dbc_scheduled_clean';

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( self::CRON_HOOK, array( $this, 'run_scheduled' ) );
	}

	/**
	 * Seconds one request may spend deleting.
	 *
	 * Most of the available execution time, capped — a host with no limit at
	 * all should not have a worker tied up for minutes, and stopping early is a
	 * normal outcome here rather than a failure.
	 *
	 * @return float microtime() to stop at.
	 */
	public static function deadline() {
		$limit  = (int) ini_get( 'max_execution_time' );
		$budget = ( $limit > 0 ) ? max( 5, (int) floor( $limit * 0.7 ) ) : 30;

		/**
		 * @param int $budget Seconds one cleanup request may spend.
		 */
		$budget = (int) apply_filters( 'dbc_time_budget', min( $budget, 30 ) );

		return microtime( true ) + $budget;
	}

	/**
	 * Run one task on the current site.
	 *
	 * @param string $key Task key.
	 * @return array|WP_Error
	 */
	public static function run( $key ) {
		$task = DBC_Registry::get( $key );

		if ( ! $task ) {
			return new WP_Error( 'dbc_unknown_task', __( 'That is not a task this plugin knows about.', 'wpd-database-cleaner' ) );
		}

		$before = $task->count();
		$result = $task->clean( self::deadline() );

		DBC_Log::record(
			$task->key(),
			sprintf(
				/* translators: 1: task name, 2: rows removed, 3: rows left. */
				__( '%1$s: removed %2$d, %3$d left', 'wpd-database-cleaner' ),
				$task->label(),
				$result['removed'],
				$result['remaining']
			),
			$result['removed']
		);

		return $result + array( 'before' => $before, 'label' => $task->label() );
	}

	/**
	 * Run several tasks, sharing one time budget between them.
	 *
	 * @param string[] $keys Task keys.
	 * @return array
	 */
	public static function run_many( array $keys ) {
		$deadline = self::deadline();
		$report   = array( 'removed' => 0, 'tasks' => array(), 'ran_out' => false );

		foreach ( $keys as $key ) {
			$task = DBC_Registry::get( $key );

			if ( ! $task ) {
				continue;
			}

			if ( microtime( true ) >= $deadline ) {
				$report['ran_out'] = true;
				break;
			}

			$result = $task->clean( $deadline );

			$report['removed']         += $result['removed'];
			$report['tasks'][ $key ]    = $result + array( 'label' => $task->label() );

			if ( ! $result['finished'] ) {
				$report['ran_out'] = true;
			}
		}

		if ( $report['removed'] > 0 ) {
			DBC_Log::record(
				'batch',
				sprintf(
					/* translators: 1: rows removed, 2: task count. */
					__( 'Cleanup: removed %1$d rows across %2$d tasks', 'wpd-database-cleaner' ),
					$report['removed'],
					count( $report['tasks'] )
				),
				$report['removed']
			);
		}

		return $report;
	}

	/**
	 * Run across every site on a network.
	 *
	 * switch_to_blog() is what makes this work at all: $wpdb->posts and friends
	 * point at the switched site's tables, so every task runs unmodified. The
	 * registry is flushed between sites because a task can decline to appear
	 * based on which tables exist, and that answer differs per site.
	 *
	 * @param string[] $keys Task keys.
	 * @return array site_id => report
	 */
	public static function run_network( array $keys ) {
		if ( ! is_multisite() ) {
			return array( get_current_blog_id() => self::run_many( $keys ) );
		}

		$out = array();

		foreach ( get_sites( array( 'number' => 0, 'fields' => 'ids' ) ) as $blog_id ) {
			switch_to_blog( (int) $blog_id );

			DBC_Registry::flush();

			$out[ (int) $blog_id ] = self::run_many( $keys );

			restore_current_blog();
		}

		DBC_Registry::flush();

		return $out;
	}

	/* ------------------------------------------------------------------ *
	 * Scheduling
	 * ------------------------------------------------------------------ */

	/**
	 * @param string $frequency off|daily|weekly|monthly.
	 */
	public static function reschedule( $frequency ) {
		wp_clear_scheduled_hook( self::CRON_HOOK );

		if ( 'off' === $frequency || '' === $frequency ) {
			return;
		}

		$map = array(
			'daily'   => 'daily',
			'weekly'  => 'weekly',
			'monthly' => 'dbc_monthly',
		);

		if ( ! isset( $map[ $frequency ] ) ) {
			return;
		}

		wp_schedule_event( time() + HOUR_IN_SECONDS, $map[ $frequency ], self::CRON_HOOK );
	}

	/**
	 * @param array $schedules Cron schedules.
	 * @return array
	 */
	public static function add_schedule( $schedules ) {
		$schedules['dbc_monthly'] = array(
			'interval' => 30 * DAY_IN_SECONDS,
			'display'  => __( 'Once a month', 'wpd-database-cleaner' ),
		);

		return $schedules;
	}

	/**
	 * The scheduled run.
	 *
	 * Deliberately narrower than what the buttons offer. Only tasks whose risk
	 * level is "safe" can be scheduled at all, and the list is filtered again
	 * here — so a task that is later reclassified as risky stops running
	 * unattended without anyone having to remember to untick it.
	 */
	public function run_scheduled() {
		$chosen = (array) DBC_Options::get( 'scheduled_tasks', array() );

		if ( ! $chosen ) {
			return;
		}

		$allowed = array_keys( DBC_Registry::schedulable() );
		$keys    = array_values( array_intersect( $chosen, $allowed ) );

		if ( ! $keys ) {
			return;
		}

		self::run_many( $keys );
	}
}

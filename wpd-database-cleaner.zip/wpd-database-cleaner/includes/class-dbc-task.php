<?php
/**
 * One cleanup task.
 *
 * Every task answers three questions, in this order, and never skips ahead:
 *
 *   1. How many rows would this remove?   count()
 *   2. Which ones, specifically?          sample()
 *   3. Remove them.                       clean()
 *
 * The order is the whole safety design. A cleaner that goes straight to step 3
 * is asking someone to trust a number they have not seen and cannot check, and
 * the thing on the other side of that trust is their content. So the admin
 * screen never offers a button for a task whose count is zero, always shows the
 * sample before the button, and the button is a POST with a nonce — there is no
 * URL anywhere in this plugin that deletes something when you visit it.
 *
 * Deletion is batched against a time budget rather than run as one statement.
 * A site with 400,000 revisions will not delete them in one request: PHP dies
 * at max_execution_time, MySQL rolls back, and the person watching learns
 * nothing except that the page went white. Batching means the work is done in
 * pieces, the count goes down visibly, and stopping half-way is a normal
 * outcome rather than a failure.
 *
 * @package Database_Cleaner
 */

defined( 'ABSPATH' ) || exit;

abstract class DBC_Task {

	/** Risk levels, used to decide what may be scheduled and what may not. */
	const SAFE      = 'safe';
	const CONSIDER  = 'consider';
	const DANGEROUS = 'dangerous';

	/** Rows removed per statement. */
	const BATCH = 500;

	/**
	 * @return string Machine key.
	 */
	abstract public function key();

	/**
	 * @return string Human name.
	 */
	abstract public function label();

	/**
	 * What this removes and why it is or is not safe. Shown in full on the
	 * screen — this is the text someone reads before deleting their data, so it
	 * is not a tooltip and it is not marketing.
	 *
	 * @return string
	 */
	abstract public function description();

	/**
	 * @return int Rows this would remove right now.
	 */
	abstract public function count();

	/**
	 * Remove up to $limit rows.
	 *
	 * @param int $limit Maximum rows.
	 * @return int Rows actually removed.
	 */
	abstract protected function delete( $limit );

	/**
	 * A few of the actual rows, so the count can be checked rather than
	 * believed.
	 *
	 * @param int $limit How many.
	 * @return array[] Rows of label => value pairs.
	 */
	public function sample( $limit = 8 ) {
		return array();
	}

	/**
	 * @return string SAFE|CONSIDER|DANGEROUS
	 */
	public function risk() {
		return self::SAFE;
	}

	/**
	 * @return bool Whether this task may run on a schedule.
	 */
	public function schedulable() {
		return self::SAFE === $this->risk();
	}

	/**
	 * @return string Group heading on the admin screen.
	 */
	public function group() {
		return __( 'Content', 'wpd-database-cleaner' );
	}

	/**
	 * Anything worth saying before someone presses the button — a warning that
	 * applies only on this site, a caveat about this task's limits.
	 *
	 * @return string
	 */
	public function warning() {
		return '';
	}

	/**
	 * Run the task in batches until it is finished or out of time.
	 *
	 * @param float $deadline microtime() value to stop at. 0 for no limit.
	 * @return array{removed:int,remaining:int,finished:bool}
	 */
	public function clean( $deadline = 0 ) {
		$removed = 0;

		/*
		 * The deadline is checked at the END of the loop, so one batch always
		 * runs. Checking it first looks tidier and has a nasty failure: on a
		 * server slow enough that the budget is already spent by the time this
		 * is called, every press of the button would remove nothing, report
		 * nothing, and leave the job exactly where it was. Guaranteeing
		 * forward progress on every press means a large job always converges,
		 * however many presses it takes.
		 */
		do {
			$batch = (int) $this->delete( self::BATCH );

			$removed += $batch;

			if ( $batch < self::BATCH ) {
				break; // Nothing left to take.
			}
		} while ( 0 === $deadline || microtime( true ) < $deadline );

		$remaining = $this->count();

		return array(
			'removed'   => $removed,
			'remaining' => $remaining,
			'finished'  => 0 === $remaining,
		);
	}

	/* ------------------------------------------------------------------ *
	 * Shared helpers
	 * ------------------------------------------------------------------ */

	/**
	 * @return wpdb
	 */
	protected function db() {
		global $wpdb;

		return $wpdb;
	}

	/**
	 * Shorten a value for display without breaking multi-byte characters.
	 *
	 * @param string $value Value.
	 * @param int    $limit Length.
	 * @return string
	 */
	protected function shorten( $value, $limit = 60 ) {
		$value = trim( preg_replace( '/\s+/u', ' ', (string) $value ) );

		return mb_strlen( $value ) > $limit ? mb_substr( $value, 0, $limit ) . '…' : $value;
	}
}

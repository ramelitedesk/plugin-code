<?php
/**
 * Autoloaded options.
 *
 * The highest-value thing on this plugin's screens, and the only one that is
 * not a deletion.
 *
 * Every option marked autoload='yes' is fetched, unserialised and held in
 * memory on *every single request* — front end, admin, AJAX, cron. It is one
 * query, so it never shows up as a slow query, which is exactly why it goes
 * unnoticed while it grows. A megabyte of autoloaded options is a megabyte
 * read and unserialised before WordPress has decided what page you asked for.
 *
 * A plugin that stores a 4 MB cached API response as an autoloaded option — and
 * this is common — costs the site more than every revision in it.
 *
 * Nothing here deletes anything. Switching an option to autoload='no' leaves
 * the value exactly where it is; it only stops it being read on requests that
 * never asked for it. Every change is recorded so it can be put straight back.
 *
 * @package Database_Cleaner
 */

defined( 'ABSPATH' ) || exit;

class DBC_Autoload {

	/** Options this plugin has switched off, so they can be switched back. */
	const CHANGED_OPTION = 'dbc_autoload_changed';

	/**
	 * Anything above this is worth a person's attention.
	 */
	const LARGE = 51200; // 50 KB.

	/**
	 * @return int Total bytes autoloaded on every request.
	 */
	public static function total() {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
		return (int) $wpdb->get_var( "SELECT SUM(LENGTH(option_value)) FROM {$wpdb->options} WHERE autoload IN ('yes','on','auto','auto-on')" );
	}

	/**
	 * @return int How many options are autoloaded.
	 */
	public static function count() {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->options} WHERE autoload IN ('yes','on','auto','auto-on')" );
	}

	/**
	 * The biggest offenders.
	 *
	 * @param int $limit How many to return.
	 * @return array[] name, size, protected, guess
	 */
	public static function largest( $limit = 25 ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT option_name, LENGTH(option_value) AS size FROM {$wpdb->options}
				 WHERE autoload IN ('yes','on','auto','auto-on')
				 ORDER BY size DESC LIMIT %d",
				(int) $limit
			)
		);

		$out = array();

		foreach ( (array) $rows as $row ) {
			$out[] = array(
				'name'      => (string) $row->option_name,
				'size'      => (int) $row->size,
				'protected' => self::is_protected( (string) $row->option_name ),
				'guess'     => self::describe( (string) $row->option_name ),
			);
		}

		return $out;
	}

	/**
	 * Options that must keep autoloading whatever their size.
	 *
	 * WordPress reads these before plugins have loaded and, in several cases,
	 * before it has decided whether it is installed. Switching one off does not
	 * break the site slowly; it breaks it on the next request.
	 *
	 * @param string $name Option name.
	 * @return bool
	 */
	public static function is_protected( $name ) {
		$core = array(
			'siteurl', 'home', 'blogname', 'blogdescription', 'users_can_register',
			'admin_email', 'start_of_week', 'use_balanceTags', 'use_smilies',
			'require_name_email', 'comments_notify', 'posts_per_rss', 'rss_use_excerpt',
			'mailserver_url', 'mailserver_login', 'mailserver_pass', 'mailserver_port',
			'default_category', 'default_comment_status', 'default_ping_status',
			'default_pingback_flag', 'posts_per_page', 'date_format', 'time_format',
			'links_updated_date_format', 'comment_moderation', 'moderation_notify',
			'permalink_structure', 'rewrite_rules', 'hack_file', 'blog_charset',
			'moderation_keys', 'active_plugins', 'category_base', 'ping_sites',
			'comment_max_links', 'gmt_offset', 'default_email_category',
			'template', 'stylesheet', 'comment_registration', 'html_type',
			'use_trackback', 'default_role', 'db_version', 'uploads_use_yearmonth_folders',
			'upload_path', 'blog_public', 'default_link_category', 'show_on_front',
			'tag_base', 'show_avatars', 'avatar_rating', 'upload_url_path',
			'thumbnail_size_w', 'thumbnail_size_h', 'thumbnail_crop', 'medium_size_w',
			'medium_size_h', 'avatar_default', 'large_size_w', 'large_size_h',
			'image_default_link_type', 'image_default_size', 'image_default_align',
			'close_comments_for_old_posts', 'close_comments_days_old',
			'thread_comments', 'thread_comments_depth', 'page_comments',
			'comments_per_page', 'default_comments_page', 'comment_order',
			'sticky_posts', 'widget_categories', 'widget_text', 'widget_rss',
			'timezone_string', 'page_for_posts', 'page_on_front', 'default_post_format',
			'link_manager_enabled', 'finished_splitting_shared_terms',
			'site_icon', 'medium_large_size_w', 'medium_large_size_h',
			'wp_page_for_privacy_policy', 'show_comments_cookies_opt_in',
			'admin_email_lifespan', 'disallowed_keys', 'comment_previously_approved',
			'auto_plugin_theme_update_emails', 'auto_update_core_dev',
			'auto_update_core_minor', 'auto_update_core_major', 'wp_force_deactivated_plugins',
			'initial_db_version', 'fresh_site', 'user_count', 'cron', 'theme_switched',
		);

		if ( in_array( $name, $core, true ) ) {
			return true;
		}

		// Theme mods and widget definitions are read on every page render.
		if ( 0 === strpos( $name, 'theme_mods_' ) || 0 === strpos( $name, 'widget_' ) || 0 === strpos( $name, 'sidebars_' ) ) {
			return true;
		}

		/**
		 * Protect an option this list does not know about.
		 *
		 * @param bool   $protected Whether it must keep autoloading.
		 * @param string $name      Option name.
		 */
		return (bool) apply_filters( 'dbc_protect_autoload', false, $name );
	}

	/**
	 * A hint about what an option is, from its name alone.
	 *
	 * @param string $name Option name.
	 * @return string
	 */
	private static function describe( $name ) {
		if ( 0 === strpos( $name, '_transient_' ) || 0 === strpos( $name, '_site_transient_' ) ) {
			return __( 'A cached value. Caches should not be autoloaded — this one will be re-fetched when something needs it.', 'wpd-database-cleaner' );
		}

		if ( preg_match( '/(cache|_log$|_logs$|history|backup|report|stats|statistics)/i', $name ) ) {
			return __( 'The name suggests a cache, a log or a history. Data of that shape is read occasionally and is rarely worth loading on every request.', 'wpd-database-cleaner' );
		}

		if ( self::is_protected( $name ) ) {
			return __( 'WordPress reads this before plugins load. It has to stay autoloaded.', 'wpd-database-cleaner' );
		}

		return '';
	}

	/**
	 * Stop an option loading on every request. Reversible.
	 *
	 * @param string $name Option name.
	 * @return true|WP_Error
	 */
	public static function stop_autoloading( $name ) {
		global $wpdb;

		$name = trim( (string) $name );

		if ( '' === $name ) {
			return new WP_Error( 'dbc_no_option', __( 'No option named.', 'wpd-database-cleaner' ) );
		}

		if ( self::is_protected( $name ) ) {
			return new WP_Error(
				'dbc_protected',
				sprintf(
					/* translators: %s: option name. */
					__( '%s is read before plugins load. Switching it off would break the site on the next request, so it is not offered.', 'wpd-database-cleaner' ),
					$name
				)
			);
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$updated = $wpdb->update( $wpdb->options, array( 'autoload' => 'no' ), array( 'option_name' => $name ), array( '%s' ), array( '%s' ) );

		if ( false === $updated ) {
			return new WP_Error( 'dbc_update_failed', __( 'The database refused the change.', 'wpd-database-cleaner' ) );
		}

		$changed          = self::changed();
		$changed[ $name ] = time();

		update_option( self::CHANGED_OPTION, $changed, false );

		wp_cache_flush_group( 'options' );

		DBC_Log::record( 'autoload_off', sprintf( 'Stopped autoloading %s', $name ), 0 );

		return true;
	}

	/**
	 * Put one back.
	 *
	 * @param string $name Option name.
	 * @return true|WP_Error
	 */
	public static function resume_autoloading( $name ) {
		global $wpdb;

		$name = trim( (string) $name );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$updated = $wpdb->update( $wpdb->options, array( 'autoload' => 'yes' ), array( 'option_name' => $name ), array( '%s' ), array( '%s' ) );

		if ( false === $updated ) {
			return new WP_Error( 'dbc_update_failed', __( 'The database refused the change.', 'wpd-database-cleaner' ) );
		}

		$changed = self::changed();
		unset( $changed[ $name ] );

		update_option( self::CHANGED_OPTION, $changed, false );

		wp_cache_flush_group( 'options' );

		return true;
	}

	/**
	 * @return array<string,int> Option name => when it was switched off.
	 */
	public static function changed() {
		$stored = get_option( self::CHANGED_OPTION, array() );

		return is_array( $stored ) ? $stored : array();
	}
}

<?php
/**
 * Post revisions, auto-drafts and the trash.
 *
 * @package Database_Cleaner
 */

defined( 'ABSPATH' ) || exit;

/**
 * Revisions, keeping the most recent few per post.
 *
 * Deleting every revision is the default behaviour of most cleaners and it is
 * the wrong default. Revisions are the only undo a client has after they paste
 * over a page and save it — the thing they will ring you about at five o'clock.
 * Keeping the last handful costs almost nothing and is the difference between
 * "I can put that back" and "it is gone".
 */
class DBC_Task_Revisions extends DBC_Task {

	public function key() {
		return 'revisions';
	}

	public function label() {
		return __( 'Post revisions', 'wpd-database-cleaner' );
	}

	public function description() {
		return __( 'Every save of a post keeps a full copy of the old content in the posts table. On a site edited for a few years these are usually the single largest thing in the database, and by a long way.', 'wpd-database-cleaner' );
	}

	public function warning() {
		$keep = self::keep();

		if ( 0 === $keep ) {
			return __( 'Set to keep none. Revisions are the only undo an editor has after pasting over a page and saving it — keeping two or three costs almost nothing.', 'wpd-database-cleaner' );
		}

		return sprintf(
			/* translators: %d: number of revisions kept. */
			_n( 'The most recent revision of each post is kept.', 'The %d most recent revisions of each post are kept.', $keep, 'wpd-database-cleaner' ),
			$keep
		);
	}

	/**
	 * @return int How many revisions to keep per post.
	 */
	public static function keep() {
		return max( 0, (int) DBC_Options::get( 'keep_revisions', 3 ) );
	}

	public function count() {
		$ids = $this->target_ids( 0 );

		return count( $ids );
	}

	public function sample( $limit = 8 ) {
		$db  = $this->db();
		$ids = $this->target_ids( $limit );

		if ( ! $ids ) {
			return array();
		}

		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $db->get_results(
			$db->prepare(
				"SELECT r.ID, r.post_modified, p.post_title FROM {$db->posts} r
				 LEFT JOIN {$db->posts} p ON p.ID = r.post_parent
				 WHERE r.ID IN ($placeholders)",
				$ids
			)
		);

		$out = array();

		foreach ( (array) $rows as $row ) {
			$out[] = array(
				__( 'Revision of', 'wpd-database-cleaner' ) => $this->shorten( $row->post_title ? $row->post_title : __( '(deleted post)', 'wpd-database-cleaner' ) ),
				__( 'Saved', 'wpd-database-cleaner' )       => (string) $row->post_modified,
			);
		}

		return $out;
	}

	/**
	 * Revision IDs eligible for deletion.
	 *
	 * The "keep the newest N per post" rule is applied in PHP rather than SQL.
	 * The SQL version needs a correlated subquery or a window function; the
	 * first is unusably slow at scale and the second needs MySQL 8, which this
	 * plugin cannot assume. Walking an ordered ID list is neither elegant nor
	 * slow, and it works on every version WordPress supports.
	 *
	 * @param int $limit Stop after this many. 0 for all.
	 * @return int[]
	 */
	private function target_ids( $limit = 0 ) {
		$db   = $this->db();
		$keep = self::keep();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $db->get_results(
			"SELECT ID, post_parent FROM {$db->posts}
			 WHERE post_type = 'revision'
			 ORDER BY post_parent ASC, ID DESC"
		);

		$seen = array();
		$out  = array();

		foreach ( (array) $rows as $row ) {
			$parent = (int) $row->post_parent;

			$seen[ $parent ] = isset( $seen[ $parent ] ) ? $seen[ $parent ] + 1 : 1;

			if ( $seen[ $parent ] <= $keep ) {
				continue;
			}

			$out[] = (int) $row->ID;

			if ( $limit > 0 && count( $out ) >= $limit ) {
				break;
			}
		}

		return $out;
	}

	protected function delete( $limit ) {
		$ids = $this->target_ids( $limit );

		if ( ! $ids ) {
			return 0;
		}

		$removed = 0;

		foreach ( $ids as $id ) {
			/*
			 * wp_delete_post_revision(), not a DELETE. It fires the hooks other
			 * plugins listen to and removes the revision's own meta rows, which
			 * a raw DELETE would leave behind — turning one kind of bloat into
			 * another and making this plugin the cause of the orphaned meta it
			 * reports on the next screen.
			 */
			if ( wp_delete_post_revision( $id ) ) {
				$removed++;
			}
		}

		return $removed;
	}
}

/**
 * Auto-drafts: the empty post WordPress creates the moment you click "Add New"
 * and abandon it.
 */
class DBC_Task_Auto_Drafts extends DBC_Task {

	public function key() {
		return 'auto_drafts';
	}

	public function label() {
		return __( 'Abandoned auto-drafts', 'wpd-database-cleaner' );
	}

	public function description() {
		return __( 'WordPress creates an empty post the moment you click "Add New", before you have typed anything. Close the tab and it stays. Core deletes them after seven days on its own; these are the ones older than that.', 'wpd-database-cleaner' );
	}

	public function count() {
		$db = $this->db();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $db->get_var(
			$db->prepare(
				"SELECT COUNT(*) FROM {$db->posts} WHERE post_status = 'auto-draft' AND post_date < %s",
				gmdate( 'Y-m-d H:i:s', time() - ( 7 * DAY_IN_SECONDS ) )
			)
		);
	}

	protected function delete( $limit ) {
		$db = $this->db();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$ids = $db->get_col(
			$db->prepare(
				"SELECT ID FROM {$db->posts} WHERE post_status = 'auto-draft' AND post_date < %s LIMIT %d",
				gmdate( 'Y-m-d H:i:s', time() - ( 7 * DAY_IN_SECONDS ) ),
				(int) $limit
			)
		);

		$removed = 0;

		foreach ( (array) $ids as $id ) {
			if ( wp_delete_post( (int) $id, true ) ) {
				$removed++;
			}
		}

		return $removed;
	}
}

/**
 * Posts sitting in the trash.
 */
class DBC_Task_Trashed_Posts extends DBC_Task {

	public function key() {
		return 'trashed_posts';
	}

	public function label() {
		return __( 'Posts in the trash', 'wpd-database-cleaner' );
	}

	public function description() {
		return __( 'Trashed posts are still in the database, with all their meta. Core empties the trash after thirty days by default; this empties it now.', 'wpd-database-cleaner' );
	}

	public function risk() {
		return self::CONSIDER;
	}

	public function warning() {
		return __( 'These are posts somebody deleted but could still restore. Once this runs, they cannot. Look at the list before you press it.', 'wpd-database-cleaner' );
	}

	public function count() {
		$db = $this->db();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $db->get_var( "SELECT COUNT(*) FROM {$db->posts} WHERE post_status = 'trash'" );
	}

	public function sample( $limit = 8 ) {
		$db = $this->db();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $db->get_results(
			$db->prepare( "SELECT post_title, post_type, post_modified FROM {$db->posts} WHERE post_status = 'trash' ORDER BY post_modified DESC LIMIT %d", (int) $limit )
		);

		$out = array();

		foreach ( (array) $rows as $row ) {
			$out[] = array(
				__( 'Title', 'wpd-database-cleaner' )   => $this->shorten( $row->post_title ? $row->post_title : __( '(no title)', 'wpd-database-cleaner' ) ),
				__( 'Type', 'wpd-database-cleaner' )    => (string) $row->post_type,
				__( 'Trashed', 'wpd-database-cleaner' ) => (string) $row->post_modified,
			);
		}

		return $out;
	}

	protected function delete( $limit ) {
		$db = $this->db();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$ids = $db->get_col( $db->prepare( "SELECT ID FROM {$db->posts} WHERE post_status = 'trash' LIMIT %d", (int) $limit ) );

		$removed = 0;

		foreach ( (array) $ids as $id ) {
			if ( wp_delete_post( (int) $id, true ) ) {
				$removed++;
			}
		}

		return $removed;
	}
}

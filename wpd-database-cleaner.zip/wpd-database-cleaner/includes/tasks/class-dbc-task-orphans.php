<?php
/**
 * Metadata whose owner no longer exists.
 *
 * These are the rows nothing can ever read again. A postmeta row whose post was
 * deleted is not reachable by any query WordPress makes, cannot be edited, and
 * cannot be restored into anything — it is simply weight. That makes this the
 * safest category in the plugin, and it is usually the largest one after
 * revisions on a site that has had a few plugins come and go.
 *
 * The queries are LEFT JOIN ... IS NULL rather than NOT IN (SELECT ...). Both
 * are correct; only one of them finishes on a table with two million rows.
 *
 * @package Database_Cleaner
 */

defined( 'ABSPATH' ) || exit;

/**
 * Shared shape: a meta table, its owner table, and the column joining them.
 */
abstract class DBC_Task_Orphan_Meta extends DBC_Task {

	/**
	 * @return array{meta:string,meta_id:string,owner:string,owner_id:string,fk:string}
	 */
	abstract protected function tables();

	public function group() {
		return __( 'Orphaned data', 'wpd-database-cleaner' );
	}

	public function count() {
		$db = $this->db();
		$t  = $this->tables();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $db->get_var(
			"SELECT COUNT(*) FROM {$t['meta']} m
			 LEFT JOIN {$t['owner']} o ON o.{$t['owner_id']} = m.{$t['fk']}
			 WHERE o.{$t['owner_id']} IS NULL"
		);
	}

	public function sample( $limit = 8 ) {
		$db = $this->db();
		$t  = $this->tables();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $db->get_results(
			$db->prepare(
				"SELECT m.meta_key, m.meta_value, m.{$t['fk']} AS owner FROM {$t['meta']} m
				 LEFT JOIN {$t['owner']} o ON o.{$t['owner_id']} = m.{$t['fk']}
				 WHERE o.{$t['owner_id']} IS NULL LIMIT %d",
				(int) $limit
			)
		);

		$out = array();

		foreach ( (array) $rows as $row ) {
			$out[] = array(
				__( 'Key', 'wpd-database-cleaner' )       => $this->shorten( $row->meta_key, 40 ),
				__( 'Value', 'wpd-database-cleaner' )     => $this->shorten( $row->meta_value, 50 ),
				__( 'Belonged to', 'wpd-database-cleaner' ) => '#' . (int) $row->owner,
			);
		}

		return $out;
	}

	protected function delete( $limit ) {
		$db = $this->db();
		$t  = $this->tables();

		/*
		 * Selected then deleted by primary key, rather than DELETE ... JOIN
		 * with a LIMIT. MySQL refuses LIMIT on a multi-table DELETE, and
		 * without a LIMIT the batching that keeps this from timing out on a
		 * large table disappears.
		 */
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$ids = $db->get_col(
			$db->prepare(
				"SELECT m.{$t['meta_id']} FROM {$t['meta']} m
				 LEFT JOIN {$t['owner']} o ON o.{$t['owner_id']} = m.{$t['fk']}
				 WHERE o.{$t['owner_id']} IS NULL LIMIT %d",
				(int) $limit
			)
		);

		if ( ! $ids ) {
			return 0;
		}

		$ids = array_map( 'intval', $ids );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $db->query( "DELETE FROM {$t['meta']} WHERE {$t['meta_id']} IN (" . implode( ',', $ids ) . ')' );
	}
}

class DBC_Task_Orphan_Postmeta extends DBC_Task_Orphan_Meta {

	public function key() {
		return 'orphan_postmeta';
	}

	public function label() {
		return __( 'Post meta with no post', 'wpd-database-cleaner' );
	}

	public function description() {
		return __( 'Custom fields belonging to posts that no longer exist. Left behind by plugins that delete a post with a direct query instead of wp_delete_post(). Nothing can read these rows.', 'wpd-database-cleaner' );
	}

	protected function tables() {
		$db = $this->db();

		return array( 'meta' => $db->postmeta, 'meta_id' => 'meta_id', 'owner' => $db->posts, 'owner_id' => 'ID', 'fk' => 'post_id' );
	}
}

class DBC_Task_Orphan_Commentmeta extends DBC_Task_Orphan_Meta {

	public function key() {
		return 'orphan_commentmeta';
	}

	public function label() {
		return __( 'Comment meta with no comment', 'wpd-database-cleaner' );
	}

	public function description() {
		return __( 'Metadata attached to comments that have been deleted. Anti-spam plugins are the usual source — they store a verdict against every comment and do not always clean up after one is removed.', 'wpd-database-cleaner' );
	}

	protected function tables() {
		$db = $this->db();

		return array( 'meta' => $db->commentmeta, 'meta_id' => 'meta_id', 'owner' => $db->comments, 'owner_id' => 'comment_ID', 'fk' => 'comment_id' );
	}
}

class DBC_Task_Orphan_Termmeta extends DBC_Task_Orphan_Meta {

	public function key() {
		return 'orphan_termmeta';
	}

	public function label() {
		return __( 'Term meta with no term', 'wpd-database-cleaner' );
	}

	public function description() {
		return __( 'Metadata for categories, tags or custom taxonomy terms that have been deleted.', 'wpd-database-cleaner' );
	}

	protected function tables() {
		$db = $this->db();

		return array( 'meta' => $db->termmeta, 'meta_id' => 'meta_id', 'owner' => $db->terms, 'owner_id' => 'term_id', 'fk' => 'term_id' );
	}
}

/**
 * User meta is deliberately NOT a simple orphan join.
 *
 * On multisite the users table is shared across the whole network while usermeta
 * is per-site, so a "missing" user is routinely a user who simply belongs to
 * another site. Deleting on that basis would remove real people's real settings.
 * The join therefore runs against the network-wide users table, which is the
 * same table on a single site and the correct one on a network.
 */
class DBC_Task_Orphan_Usermeta extends DBC_Task_Orphan_Meta {

	public function key() {
		return 'orphan_usermeta';
	}

	public function label() {
		return __( 'User meta with no user', 'wpd-database-cleaner' );
	}

	public function description() {
		return __( 'Profile fields and preferences for user accounts that have been deleted.', 'wpd-database-cleaner' );
	}

	public function warning() {
		if ( is_multisite() ) {
			return __( 'On multisite the users table is shared across the network, so this is checked against every user on the network — not just this site\'s members.', 'wpd-database-cleaner' );
		}

		return '';
	}

	protected function tables() {
		$db = $this->db();

		return array( 'meta' => $db->usermeta, 'meta_id' => 'umeta_id', 'owner' => $db->users, 'owner_id' => 'ID', 'fk' => 'user_id' );
	}
}

/**
 * Taxonomy relationships pointing at a post that is gone.
 */
class DBC_Task_Orphan_Relationships extends DBC_Task {

	public function key() {
		return 'orphan_relationships';
	}

	public function label() {
		return __( 'Taxonomy links with no post', 'wpd-database-cleaner' );
	}

	public function description() {
		return __( 'Rows saying "this post is in this category" where the post no longer exists. As well as being dead weight, these inflate the post counts shown next to your categories and tags.', 'wpd-database-cleaner' );
	}

	public function group() {
		return __( 'Orphaned data', 'wpd-database-cleaner' );
	}

	public function warning() {
		return __( 'Category and tag counts are recalculated afterwards, so the numbers on your archive pages become correct rather than merely smaller.', 'wpd-database-cleaner' );
	}

	public function count() {
		$db = $this->db();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $db->get_var(
			"SELECT COUNT(*) FROM {$db->term_relationships} tr
			 LEFT JOIN {$db->posts} p ON p.ID = tr.object_id
			 WHERE p.ID IS NULL"
		);
	}

	protected function delete( $limit ) {
		$db = $this->db();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $db->get_results(
			$db->prepare(
				"SELECT tr.object_id, tr.term_taxonomy_id FROM {$db->term_relationships} tr
				 LEFT JOIN {$db->posts} p ON p.ID = tr.object_id
				 WHERE p.ID IS NULL LIMIT %d",
				(int) $limit
			)
		);

		if ( ! $rows ) {
			return 0;
		}

		$removed  = 0;
		$affected = array();

		foreach ( $rows as $row ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$removed += (int) $db->query(
				$db->prepare(
					"DELETE FROM {$db->term_relationships} WHERE object_id = %d AND term_taxonomy_id = %d",
					(int) $row->object_id,
					(int) $row->term_taxonomy_id
				)
			);

			$affected[] = (int) $row->term_taxonomy_id;
		}

		if ( $affected ) {
			wp_update_term_count( array_unique( $affected ) );
		}

		return $removed;
	}
}

/**
 * Duplicate meta rows: the same key and the same value, on the same post.
 */
class DBC_Task_Duplicate_Postmeta extends DBC_Task {

	public function key() {
		return 'duplicate_postmeta';
	}

	public function label() {
		return __( 'Duplicate post meta', 'wpd-database-cleaner' );
	}

	public function description() {
		return __( 'The same custom field, with the same value, stored more than once on the same post. Usually a plugin using add_post_meta() where it meant update_post_meta(). WordPress returns every copy, so these slow down page rendering as well as taking up room.', 'wpd-database-cleaner' );
	}

	public function group() {
		return __( 'Orphaned data', 'wpd-database-cleaner' );
	}

	public function risk() {
		return self::CONSIDER;
	}

	public function warning() {
		return __( 'The oldest copy of each is kept. A handful of plugins deliberately store repeated identical values as a list — if one of yours does, it will lose them. This is why it is not scheduled automatically.', 'wpd-database-cleaner' );
	}

	public function count() {
		$db = $this->db();

		// MD5 on the value, because meta_value is LONGTEXT and MySQL will not
		// group by it without a length limit that would produce false matches.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $db->get_var(
			"SELECT COALESCE(SUM(c - 1), 0) FROM (
				SELECT COUNT(*) AS c FROM {$db->postmeta}
				GROUP BY post_id, meta_key, MD5(meta_value) HAVING c > 1
			) AS dupes"
		);
	}

	protected function delete( $limit ) {
		$db = $this->db();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$keep = $db->get_col(
			$db->prepare(
				"SELECT MIN(meta_id) FROM {$db->postmeta}
				 GROUP BY post_id, meta_key, MD5(meta_value)
				 HAVING COUNT(*) > 1 LIMIT %d",
				(int) $limit
			)
		);

		if ( ! $keep ) {
			return 0;
		}

		$removed = 0;

		foreach ( $keep as $survivor ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$row = $db->get_row( $db->prepare( "SELECT post_id, meta_key, MD5(meta_value) AS h FROM {$db->postmeta} WHERE meta_id = %d", (int) $survivor ) );

			if ( ! $row ) {
				continue;
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$removed += (int) $db->query(
				$db->prepare(
					"DELETE FROM {$db->postmeta}
					 WHERE post_id = %d AND meta_key = %s AND MD5(meta_value) = %s AND meta_id > %d",
					(int) $row->post_id,
					$row->meta_key,
					$row->h,
					(int) $survivor
				)
			);
		}

		return $removed;
	}
}

<?php
/**
 * Transients, comments and scheduled-action logs.
 *
 * @package Database_Cleaner
 */

defined( 'ABSPATH' ) || exit;

/**
 * Expired transients, and the timeout rows left behind by them.
 *
 * The distinction that matters here, and that most cleaners get wrong:
 *
 *   A transient with no timeout row has NO EXPIRY. It is not orphaned, it is
 *   permanent by design — that is what set_transient() with no expiry does.
 *   Sweeping "transients without a timeout" deletes live data, and the symptom
 *   is a plugin quietly losing its licence key or its cached API token.
 *
 * So only two things are removed: transients whose timeout has passed, and
 * timeout rows whose transient is already gone.
 */
class DBC_Task_Expired_Transients extends DBC_Task {

	public function key() {
		return 'expired_transients';
	}

	public function label() {
		return __( 'Expired transients', 'wpd-database-cleaner' );
	}

	public function description() {
		return __( 'Cached values that have passed their expiry date. WordPress only clears these when something asks for them again, so a transient set once by a plugin you have since removed sits in the options table forever.', 'wpd-database-cleaner' );
	}

	public function group() {
		return __( 'Caches', 'wpd-database-cleaner' );
	}

	public function warning() {
		if ( wp_using_ext_object_cache() ) {
			return __( 'This site has a persistent object cache, so most transients are stored there and never reach the database. A low number here does not mean there are few transients.', 'wpd-database-cleaner' );
		}

		return __( 'Transients with no expiry date are never touched. Those are permanent by design — licence keys and API tokens live there — and deleting them is how a cleaner breaks a plugin.', 'wpd-database-cleaner' );
	}

	/**
	 * @return string[] The option_names to remove.
	 */
	private function targets( $limit = 0 ) {
		$db  = $this->db();
		$now = time();

		$cap = $limit > 0 ? ' LIMIT ' . (int) $limit : '';

		// Expired timeouts, and the transient each one guards.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$expired = $db->get_col(
			$db->prepare(
				"SELECT option_name FROM {$db->options}
				 WHERE option_name LIKE %s AND option_value < %d" . $cap,
				$db->esc_like( '_transient_timeout_' ) . '%',
				$now
			)
		);

		$names = array();

		foreach ( (array) $expired as $timeout ) {
			$names[] = $timeout;
			$names[] = '_transient_' . substr( $timeout, strlen( '_transient_timeout_' ) );
		}

		// Site transients behave the same way and live in the same table on a
		// single-site install.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$expired_site = $db->get_col(
			$db->prepare(
				"SELECT option_name FROM {$db->options}
				 WHERE option_name LIKE %s AND option_value < %d" . $cap,
				$db->esc_like( '_site_transient_timeout_' ) . '%',
				$now
			)
		);

		foreach ( (array) $expired_site as $timeout ) {
			$names[] = $timeout;
			$names[] = '_site_transient_' . substr( $timeout, strlen( '_site_transient_timeout_' ) );
		}

		// Timeout rows whose transient has already gone. These genuinely are
		// orphans — the value is the thing, and it is not there.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$stranded = $db->get_col(
			$db->prepare(
				"SELECT t.option_name FROM {$db->options} t
				 LEFT JOIN {$db->options} v
				   ON v.option_name = CONCAT('_transient_', SUBSTRING(t.option_name, %d))
				 WHERE t.option_name LIKE %s AND v.option_name IS NULL" . $cap,
				strlen( '_transient_timeout_' ) + 1,
				$db->esc_like( '_transient_timeout_' ) . '%'
			)
		);

		foreach ( (array) $stranded as $timeout ) {
			$names[] = $timeout;
		}

		return array_values( array_unique( array_filter( $names ) ) );
	}

	public function count() {
		$db    = $this->db();
		$names = $this->targets();

		if ( ! $names ) {
			return 0;
		}

		// The list includes value rows that may not exist, so the honest count
		// is how many of these names are actually in the table.
		$placeholders = implode( ',', array_fill( 0, count( $names ), '%s' ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $db->get_var( $db->prepare( "SELECT COUNT(*) FROM {$db->options} WHERE option_name IN ($placeholders)", $names ) );
	}

	public function sample( $limit = 8 ) {
		$names = array_slice( $this->targets( $limit ), 0, $limit );
		$out   = array();

		foreach ( $names as $name ) {
			$out[] = array( __( 'Option', 'wpd-database-cleaner' ) => $this->shorten( $name, 70 ) );
		}

		return $out;
	}

	protected function delete( $limit ) {
		$db    = $this->db();
		$names = $this->targets( max( 1, (int) ( $limit / 2 ) ) );

		if ( ! $names ) {
			return 0;
		}

		$placeholders = implode( ',', array_fill( 0, count( $names ), '%s' ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$removed = (int) $db->query( $db->prepare( "DELETE FROM {$db->options} WHERE option_name IN ($placeholders)", $names ) );

		// The options cache still holds what was just deleted.
		wp_cache_flush_group( 'options' );

		return $removed;
	}
}

/**
 * The oEmbed response cache, stored as postmeta.
 */
class DBC_Task_Oembed_Cache extends DBC_Task {

	public function key() {
		return 'oembed_cache';
	}

	public function label() {
		return __( 'Embedded media cache', 'wpd-database-cleaner' );
	}

	public function description() {
		return __( 'WordPress caches the HTML for every YouTube, Twitter or Vimeo embed as hidden custom fields on the post. On a site with many embeds this is thousands of rows, and it is regenerated on demand.', 'wpd-database-cleaner' );
	}

	public function group() {
		return __( 'Caches', 'wpd-database-cleaner' );
	}

	public function warning() {
		return __( 'Clearing this makes the first view of each embedded post slower while WordPress fetches the embed again. It is a cache, so nothing is lost.', 'wpd-database-cleaner' );
	}

	public function count() {
		$db = $this->db();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $db->get_var( $db->prepare( "SELECT COUNT(*) FROM {$db->postmeta} WHERE meta_key LIKE %s", $db->esc_like( '_oembed_' ) . '%' ) );
	}

	protected function delete( $limit ) {
		$db = $this->db();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$ids = $db->get_col( $db->prepare( "SELECT meta_id FROM {$db->postmeta} WHERE meta_key LIKE %s LIMIT %d", $db->esc_like( '_oembed_' ) . '%', (int) $limit ) );

		if ( ! $ids ) {
			return 0;
		}

		$ids = array_map( 'intval', $ids );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $db->query( "DELETE FROM {$db->postmeta} WHERE meta_id IN (" . implode( ',', $ids ) . ')' );
	}
}

/**
 * Spam comments.
 */
class DBC_Task_Spam_Comments extends DBC_Task {

	public function key() {
		return 'spam_comments';
	}

	public function label() {
		return __( 'Spam comments', 'wpd-database-cleaner' );
	}

	public function description() {
		return __( 'Comments marked as spam, and their metadata. On a site with open comments and no captcha this can be the largest table in the database.', 'wpd-database-cleaner' );
	}

	public function group() {
		return __( 'Comments', 'wpd-database-cleaner' );
	}

	public function count() {
		$db = $this->db();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $db->get_var( "SELECT COUNT(*) FROM {$db->comments} WHERE comment_approved = 'spam'" );
	}

	protected function delete( $limit ) {
		return $this->remove_by_status( 'spam', $limit );
	}

	/**
	 * @param string $status Comment status.
	 * @param int    $limit  Batch size.
	 * @return int
	 */
	protected function remove_by_status( $status, $limit ) {
		$db = $this->db();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$ids = $db->get_col( $db->prepare( "SELECT comment_ID FROM {$db->comments} WHERE comment_approved = %s LIMIT %d", $status, (int) $limit ) );

		$removed = 0;

		foreach ( (array) $ids as $id ) {
			// Through the API, so comment counts on posts stay correct and the
			// comment's own meta goes with it.
			if ( wp_delete_comment( (int) $id, true ) ) {
				$removed++;
			}
		}

		return $removed;
	}
}

/**
 * Comments in the trash.
 */
class DBC_Task_Trashed_Comments extends DBC_Task_Spam_Comments {

	public function key() {
		return 'trashed_comments';
	}

	public function label() {
		return __( 'Comments in the trash', 'wpd-database-cleaner' );
	}

	public function description() {
		return __( 'Comments somebody deleted but which are still recoverable. This makes that permanent.', 'wpd-database-cleaner' );
	}

	public function risk() {
		return self::CONSIDER;
	}

	public function count() {
		$db = $this->db();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $db->get_var( "SELECT COUNT(*) FROM {$db->comments} WHERE comment_approved = 'trash'" );
	}

	protected function delete( $limit ) {
		return $this->remove_by_status( 'trash', $limit );
	}
}

/**
 * Pingbacks and trackbacks.
 */
class DBC_Task_Pingbacks extends DBC_Task {

	public function key() {
		return 'pingbacks';
	}

	public function label() {
		return __( 'Pingbacks and trackbacks', 'wpd-database-cleaner' );
	}

	public function description() {
		return __( 'Automatic notifications from other sites that linked to yours. Almost always spam, and a feature most sites turned off years ago without clearing what had already arrived.', 'wpd-database-cleaner' );
	}

	public function group() {
		return __( 'Comments', 'wpd-database-cleaner' );
	}

	public function risk() {
		return self::CONSIDER;
	}

	public function count() {
		$db = $this->db();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $db->get_var( "SELECT COUNT(*) FROM {$db->comments} WHERE comment_type IN ('pingback','trackback')" );
	}

	protected function delete( $limit ) {
		$db = $this->db();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$ids = $db->get_col( $db->prepare( "SELECT comment_ID FROM {$db->comments} WHERE comment_type IN ('pingback','trackback') LIMIT %d", (int) $limit ) );

		$removed = 0;

		foreach ( (array) $ids as $id ) {
			if ( wp_delete_comment( (int) $id, true ) ) {
				$removed++;
			}
		}

		return $removed;
	}
}

/**
 * Action Scheduler's finished jobs.
 *
 * Present on every WooCommerce site and a growing number of others. It keeps a
 * row per completed job plus several log lines each, and by default it prunes
 * far less aggressively than the volume warrants — a busy store can carry
 * hundreds of thousands of rows nobody will ever read.
 */
class DBC_Task_Action_Scheduler extends DBC_Task {

	public function key() {
		return 'action_scheduler';
	}

	public function label() {
		return __( 'Completed scheduled actions', 'wpd-database-cleaner' );
	}

	public function description() {
		return __( 'Action Scheduler — used by WooCommerce and many other plugins — keeps a record of every background job it has finished, plus a log line for each. These are history, not work still to do.', 'wpd-database-cleaner' );
	}

	public function group() {
		return __( 'Background jobs', 'wpd-database-cleaner' );
	}

	public function warning() {
		return __( 'Only actions that have completed or failed are removed. Anything pending, in progress or scheduled for the future is left exactly where it is.', 'wpd-database-cleaner' );
	}

	/**
	 * @return bool Whether Action Scheduler's tables exist here.
	 */
	public function available() {
		return DBC_Tables::exists( $this->db()->prefix . 'actionscheduler_actions' );
	}

	public function count() {
		if ( ! $this->available() ) {
			return 0;
		}

		$db    = $this->db();
		$table = $db->prefix . 'actionscheduler_actions';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $db->get_var(
			$db->prepare(
				"SELECT COUNT(*) FROM {$table} WHERE status IN ('complete','failed','canceled') AND scheduled_date_gmt < %s",
				gmdate( 'Y-m-d H:i:s', time() - ( (int) DBC_Options::get( 'keep_actions_days', 30 ) * DAY_IN_SECONDS ) )
			)
		);
	}

	protected function delete( $limit ) {
		if ( ! $this->available() ) {
			return 0;
		}

		$db      = $this->db();
		$actions = $db->prefix . 'actionscheduler_actions';
		$logs    = $db->prefix . 'actionscheduler_logs';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$ids = $db->get_col(
			$db->prepare(
				"SELECT action_id FROM {$actions} WHERE status IN ('complete','failed','canceled') AND scheduled_date_gmt < %s LIMIT %d",
				gmdate( 'Y-m-d H:i:s', time() - ( (int) DBC_Options::get( 'keep_actions_days', 30 ) * DAY_IN_SECONDS ) ),
				(int) $limit
			)
		);

		if ( ! $ids ) {
			return 0;
		}

		$ids  = array_map( 'intval', $ids );
		$list = implode( ',', $ids );

		if ( DBC_Tables::exists( $logs ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$db->query( "DELETE FROM {$logs} WHERE action_id IN ($list)" );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $db->query( "DELETE FROM {$actions} WHERE action_id IN ($list)" );
	}
}

<?php
/**
 * Runs when the plugin is deleted.
 *
 * @package Database_Cleaner
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

foreach ( array( 'dbc_settings', 'dbc_log', 'dbc_autoload_changed' ) as $option ) {
	delete_option( $option );
}

wp_clear_scheduled_hook( 'dbc_scheduled_clean' );

/*
 * Options this plugin stopped autoloading are deliberately left as they are.
 *
 * Their values were never touched, so nothing is lost either way — but
 * switching several megabytes of plugin caches back on at the moment somebody
 * removes a tool they no longer want is a strange parting gift. If they should
 * autoload again, the Autoloaded options screen puts them back one at a time
 * before the plugin is deleted.
 */

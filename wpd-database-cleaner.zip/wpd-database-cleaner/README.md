# WPD Database Cleaner

Finds transients, revisions, orphaned metadata, unused tables and database bloat — and shows you exactly what it would remove before it removes anything.

Works on single sites and multisite networks.

---

## The admission this is built around

**It cannot tell what matters to you.**

A row that is obviously junk to a query is somebody's only copy of something. Orphaned postmeta is genuinely unreachable and safe to drop. A table left behind by a plugin removed two years ago might hold the entire order history of a shop that ran for a fortnight. Nothing here can tell those apart, so the design does not pretend to:

- **Everything is counted and sampled before anything is deleted.** No screen offers a button for something you have not been shown. Nothing is ticked by default.
- **Nothing runs on activation.** A plugin that starts deleting because it was activated has taken a decision that was not its to take.
- **Nothing runs on a schedule** until you turn scheduling on and choose what it may touch — and only from the tasks that cannot lose recoverable data. The trash is not on that list.
- **Tables are never dropped in bulk and never automatically.** Each one needs its own name typed out by hand.
- **Deletions go through `wp_delete_post()`, `wp_delete_comment()` and friends** wherever those exist, so hooks fire and dependent rows go with them. A raw `DELETE` on revisions strands their meta rows — turning one kind of bloat into another, and making the cleaner the cause of the orphans it reports on the next screen.
- **Every run is recorded.** When something breaks a week later, "what did that plugin delete?" needs an answer.

And the one thing no plugin can do for you is on every screen: **take a backup first.** Not because this is expected to go wrong — because nothing here can undo itself.

---

## What it finds

### Content
| | |
| --- | --- |
| **Post revisions** | Usually the largest thing in an old database. **The most recent few per post are kept** — revisions are the only undo an editor has after pasting over a page and saving it. Most cleaners delete all of them by default; that is the wrong default. |
| **Abandoned auto-drafts** | The empty post WordPress creates the moment you click "Add New" and close the tab. |
| **Posts in the trash** | Recoverable until this runs. Not schedulable, on purpose. |

### Orphaned data
Metadata whose owner no longer exists — post, comment, term and user meta, plus taxonomy links pointing at deleted posts. These rows cannot be read by any query WordPress makes. Usually the largest category after revisions on a site that has had a few plugins come and go.

Also duplicate post meta: the same key with the same value on the same post, which WordPress returns twice.

### Caches
| | |
| --- | --- |
| **Expired transients** | Only ones whose expiry has passed, plus timeout rows whose value is already gone. |
| **Embedded media cache** | The cached HTML for every YouTube and Twitter embed, stored as hidden custom fields. |

### Comments
Spam, trash, and pingbacks/trackbacks.

### Background jobs
Action Scheduler's completed and failed actions plus their logs — present on every WooCommerce site, and often hundreds of thousands of rows. Anything pending or in progress is never touched.

---

## The transient trap

Most cleaners get this wrong, so it is worth stating:

> **A transient with no timeout row has no expiry. It is not orphaned — it is permanent by design.**

That is exactly what `set_transient()` with no expiry does, and it is where plugins keep licence keys and API tokens. Sweeping "transients without a timeout" deletes live data, and the symptom is a plugin quietly losing its licence a week later.

This removes two things only: transients whose timeout has passed, and timeout rows whose transient is already gone. There is a test for each.

---

## Autoloaded options — the one that is not a deletion

The highest-value screen here.

Every option marked `autoload = yes` is fetched, unserialised and held in memory on **every single request** — front end, admin, AJAX, cron. It is one query, so it never appears in a slow query log, which is exactly why it grows unnoticed. A plugin storing a few megabytes of cached API response as an autoloaded option — and this is common — costs the site more than every revision in it.

Under about 800 KB is unremarkable. Several megabytes is worth an afternoon.

**Nothing on that screen deletes anything.** Switching an option off leaves its value exactly where it is; it only stops being read on requests that never asked for it. Anything that needs it still gets it, one query later. Options WordPress reads before plugins load are marked *required* and are not offered — switching one of those off would not slow the site down, it would break it on the next request. Every change is listed so it can be put straight back.

---

## Unused tables

"Unused" here is a **guess, and a weak one.** There is no register of which plugin owns which table; the only evidence available is a name that looks like a plugin slug, and plugins are free to name their tables anything.

So this screen is good at one thing: showing you that 400 MB of a 460 MB database belongs to three tables from a plugin you removed in 2021. Deciding they can go is still yours.

Dropping needs the table's own name typed out. That is not decoration — it is a different act from clicking a button next to it, and the difference is the moment of attention this needs. Core tables and tables belonging to another install sharing the database are refused at any confirmation.

### On OPTIMIZE

On MyISAM it reclaims the space deleted rows left behind. On InnoDB — which is everything modern — it is a **full table rebuild that locks the table** and frequently reclaims nothing, because InnoDB reuses that space itself. On a large orders table that lock can last minutes, during which the site is effectively down. The screen says so when it detects InnoDB.

---

## Large sites

A site with 400,000 revisions will not clear them in one request: PHP dies at `max_execution_time`, MySQL rolls back, and you learn nothing except that the page went white.

So work is batched against a time budget. It **stops before your server does**, tells you what is left, and picks up where it stopped when you press again. At least one batch always runs, so every press makes progress — a job always converges, however many presses it takes.

---

## Multisite

Every task runs against the current site's tables. A network admin gets a "run on all sites" option that works through each site in turn via `switch_to_blog()` and reports them separately.

Two multisite-specific traps are handled: user meta is checked against the **network-wide** users table (a "missing" user is routinely someone who belongs to another site), and every site's tables count as core tables — `wp_7_posts` is not abandoned just because you are looking from site 1.

---

## Tests

```bash
cd wpd-database-cleaner/tests
php test.php           # 122 cases
php updates-test.php   # 14 cases
```

No WordPress, no PHPUnit — but a **real SQLite database**, not a hand-written fake. A fake that returns canned answers tests the fake; SQLite runs the actual statements, so the orphan joins, the duplicate detection and the `LIMIT` that makes batching work all have to be right.

Most assertions are of the form *"this must still be there afterwards"*: the live meta row beside the orphan, the unexpired transient, the transient with no expiry at all, the multi-value custom field that is not a duplicate, the comment awaiting moderation that is not spam. There are also tests that deletion went through the WordPress API rather than a raw `DELETE`, that core tables cannot be dropped at any confirmation, and that no risky task can reach the schedulable list.

---

## Honest limits

- **Nothing here can be undone.** Take a backup. It is the first thing on every screen for a reason.
- **"Unused table" is a guess.** See above. It is presented as one.
- **Duplicate meta removal can be wrong.** A handful of plugins deliberately store repeated identical values as a list. This is why it is not schedulable and says so before you press it.
- **WP-Cron is not a clock.** Schedules fire when somebody visits the site. On a quiet site a "daily" clean may happen every few days. A real cron job calling `wp-cron.php` is the fix, and it is a hosting setting.
- **This is not a performance plugin.** A smaller database is tidier and backs up faster. It is rarely the reason a site is slow — the autoloaded options screen is the exception, and it is the one worth your time.

## Requirements

WordPress 5.8+, PHP 7.4+. No dependencies, no build step, no outbound calls.

---

## Why the folder is prefixed

Because it was not, and that broke a live site.

The plugin originally shipped in a folder named `database-cleaner`. That slug belongs to a **different plugin, by Jordy Meow, on WordPress.org**. WordPress does not know or care where a plugin came from — on every update check it sends the folder name of everything installed to api.wordpress.org, gets back whatever holds that slug, sees a higher version than `1.0.0`, and offers it as an update.

Pressing that button does not update this plugin. It deletes it and installs his.

What makes it dangerous is how quiet it is: the site keeps working, the plugins list still shows a plausible entry, nothing errors. The only symptom is that the settings are gone and the screens look unfamiliar — which reads as "the update changed things" rather than "this is different software".

Two fixes, both applied:

1. **The folder is `wpd-database-cleaner`,** which nobody in the directory claims.
2. **The plugin refuses directory updates for itself** ([`class-dbc-updates.php`](includes/class-dbc-updates.php)). That is the one that still works when somebody claims the new slug in a year. Other plugins' updates are untouched — blocking those would stop real security fixes, and there is a test for it.

Override with `add_filter( 'dbc_block_directory_updates', '__return_false' )` if you ever put this on a private update server.

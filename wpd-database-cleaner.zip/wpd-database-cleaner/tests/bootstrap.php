<?php
/**
 * Minimal WordPress stand-in so the plugin can be exercised without a site.
 *
 * @package Database_Cleaner
 */

if ( 'cli' !== PHP_SAPI ) {
	http_response_code( 404 );
	exit;
}

error_reporting( E_ALL );
ini_set( 'display_errors', '1' );

define( 'ABSPATH', dirname( __DIR__ ) . '/' );
define( 'DAY_IN_SECONDS', 86400 );
define( 'HOUR_IN_SECONDS', 3600 );
define( 'MINUTE_IN_SECONDS', 60 );
define( 'WEEK_IN_SECONDS', 604800 );

define( 'DBC_VERSION', '1.0.0' );
define( 'DBC_DIR', dirname( __DIR__ ) . '/' );
define( 'DBC_URL', 'https://example.test/wp-content/plugins/database-cleaner/' );
define( 'DBC_FILE', DBC_DIR . 'wpd-database-cleaner.php' );

$GLOBALS['dbc_options']   = array();
$GLOBALS['dbc_multisite'] = false;
$GLOBALS['dbc_caps']      = true;

function apply_filters( $tag, $value = null ) { return $value; }
function add_action() {}
function add_filter() {}
function do_action() {}
function __( $text, $domain = '' ) { return $text; }
function _n( $single, $plural, $number, $domain = '' ) { return 1 === (int) $number ? $single : $plural; }
function esc_html( $text ) { return htmlspecialchars( (string) $text, ENT_QUOTES, 'UTF-8' ); }
function is_multisite() { return (bool) $GLOBALS['dbc_multisite']; }
function get_current_blog_id() { return 1; }
function get_current_user_id() { return 1; }
function wp_parse_args( $args, $defaults = array() ) { return array_merge( $defaults, (array) $args ); }
function wp_cache_flush_group( $group ) { return true; }
function wp_using_ext_object_cache() { return false; }
function wp_next_scheduled( $hook ) { return false; }
function wp_schedule_event() { return true; }
function wp_clear_scheduled_hook() { return true; }
function wp_update_term_count( $ids ) { $GLOBALS['dbc_term_counts'] = $ids; return true; }
function wp_get_theme() { return null; }
function get_site_option( $key, $default = false ) { return $default; }
function number_format_i18n( $n, $d = 0 ) { return number_format( (float) $n, (int) $d ); }
function size_format( $bytes, $decimals = 0 ) { return round( $bytes / 1024, $decimals ) . ' KB'; }
function is_wp_error( $thing ) { return $thing instanceof WP_Error; }

class WP_Error {
	private $code;
	private $message;
	public function __construct( $code = '', $message = '' ) { $this->code = $code; $this->message = $message; }
	public function get_error_code() { return $this->code; }
	public function get_error_message() { return $this->message; }
}

function get_option( $key, $default = false ) {
	return array_key_exists( $key, $GLOBALS['dbc_options'] ) ? $GLOBALS['dbc_options'][ $key ] : $default;
}
function update_option( $key, $value, $autoload = null ) { $GLOBALS['dbc_options'][ $key ] = $value; return true; }
function add_option( $key, $value, $x = '', $a = null ) { $GLOBALS['dbc_options'][ $key ] = $value; return true; }
function delete_option( $key ) { unset( $GLOBALS['dbc_options'][ $key ] ); return true; }

/**
 * Deletions that go through the WordPress API are recorded rather than run, so
 * a test can assert that a task used wp_delete_post() and not a raw DELETE.
 * That distinction is the difference between removing a revision and leaving
 * its meta rows behind as the orphans this plugin reports on the next screen.
 */
$GLOBALS['dbc_api_calls'] = array();

function wp_delete_post_revision( $id ) {
	$GLOBALS['dbc_api_calls'][] = array( 'wp_delete_post_revision', (int) $id );
	return $GLOBALS['wpdb']->remove_row( 'posts', 'ID', (int) $id );
}

function wp_delete_post( $id, $force = false ) {
	$GLOBALS['dbc_api_calls'][] = array( 'wp_delete_post', (int) $id );
	return $GLOBALS['wpdb']->remove_row( 'posts', 'ID', (int) $id );
}

function wp_delete_comment( $id, $force = false ) {
	$GLOBALS['dbc_api_calls'][] = array( 'wp_delete_comment', (int) $id );
	return $GLOBALS['wpdb']->remove_row( 'comments', 'comment_ID', (int) $id );
}

/**
 * A wpdb stand-in backed by SQLite.
 *
 * A hand-written fake that returns canned answers would test the fake. SQLite
 * runs the actual statements — the LEFT JOIN ... IS NULL orphan queries, the
 * GROUP BY ... HAVING duplicate detection, the LIMIT that makes batching work —
 * so a mistake in one of them fails here rather than on somebody's site.
 *
 * The SQL differences that matter are handled in query(): SQLite has no
 * SHOW TABLE STATUS and spells a few functions differently.
 */
class DBC_Test_DB {

	public $prefix      = 'wp_';
	public $base_prefix = 'wp_';

	public $posts;
	public $postmeta;
	public $comments;
	public $commentmeta;
	public $terms;
	public $termmeta;
	public $term_relationships;
	public $term_taxonomy;
	public $users;
	public $usermeta;
	public $options;

	/** @var PDO */
	private $pdo;

	/** @var string[] Every statement run, for assertions. */
	public $log = array();

	public function __construct() {
		foreach ( array( 'posts', 'postmeta', 'comments', 'commentmeta', 'terms', 'termmeta', 'term_relationships', 'term_taxonomy', 'users', 'usermeta', 'options' ) as $table ) {
			$this->$table = $this->prefix . $table;
		}

		$this->pdo = new PDO( 'sqlite::memory:' );
		$this->pdo->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );

		$this->schema();
	}

	private function schema() {
		$statements = array(
			"CREATE TABLE {$this->posts} (ID INTEGER PRIMARY KEY, post_parent INTEGER DEFAULT 0, post_type TEXT, post_status TEXT, post_title TEXT, post_date TEXT, post_modified TEXT)",
			"CREATE TABLE {$this->postmeta} (meta_id INTEGER PRIMARY KEY, post_id INTEGER, meta_key TEXT, meta_value TEXT)",
			"CREATE TABLE {$this->comments} (comment_ID INTEGER PRIMARY KEY, comment_approved TEXT, comment_type TEXT)",
			"CREATE TABLE {$this->commentmeta} (meta_id INTEGER PRIMARY KEY, comment_id INTEGER, meta_key TEXT, meta_value TEXT)",
			"CREATE TABLE {$this->terms} (term_id INTEGER PRIMARY KEY, name TEXT)",
			"CREATE TABLE {$this->termmeta} (meta_id INTEGER PRIMARY KEY, term_id INTEGER, meta_key TEXT, meta_value TEXT)",
			"CREATE TABLE {$this->term_relationships} (object_id INTEGER, term_taxonomy_id INTEGER)",
			"CREATE TABLE {$this->users} (ID INTEGER PRIMARY KEY, user_login TEXT)",
			"CREATE TABLE {$this->usermeta} (umeta_id INTEGER PRIMARY KEY, user_id INTEGER, meta_key TEXT, meta_value TEXT)",
			"CREATE TABLE {$this->options} (option_id INTEGER PRIMARY KEY, option_name TEXT UNIQUE, option_value TEXT, autoload TEXT DEFAULT 'yes')",
		);

		foreach ( $statements as $sql ) {
			$this->pdo->exec( $sql );
		}
	}

	/**
	 * SQLite speaks a slightly different dialect. Only the differences this
	 * plugin actually depends on are translated.
	 *
	 * @param string $sql Statement.
	 * @return string
	 */
	private function translate( $sql ) {
		// SQLite has MD5 only as an extension; the duplicate check needs a
		// stable hash of the value and does not care which one.
		$sql = preg_replace( '/MD5\(\s*([A-Za-z_.]+)\s*\)/i', '$1', $sql );

		// UNIX_TIMESTAMP() has no SQLite equivalent in this form.
		$sql = str_ireplace( 'UNIX_TIMESTAMP()', (string) time(), $sql );

		// SUBSTRING(x, n) is SUBSTR in SQLite; CONCAT is ||.
		$sql = preg_replace( '/SUBSTRING\(/i', 'SUBSTR(', $sql );
		$sql = preg_replace_callback(
			'/CONCAT\(([^()]*(?:\([^()]*\)[^()]*)*)\)/i',
			static function ( $m ) {
				return implode( ' || ', array_map( 'trim', preg_split( '/,(?![^(]*\))/', $m[1] ) ) );
			},
			$sql
		);

		return $sql;
	}

	public function prepare( $sql, ...$args ) {
		if ( 1 === count( $args ) && is_array( $args[0] ) ) {
			$args = $args[0];
		}

		foreach ( $args as $arg ) {
			$replacement = is_int( $arg ) || is_float( $arg )
				? (string) $arg
				: "'" . str_replace( "'", "''", (string) $arg ) . "'";

			$sql = preg_replace( '/%[sdfF]/', $replacement, $sql, 1 );
		}

		return $sql;
	}

	/**
	 * A passthrough, deliberately.
	 *
	 * MySQL reads "\_" inside a LIKE pattern as a literal underscore. SQLite
	 * has no default escape character at all, so the escaped pattern real wpdb
	 * produces matches nothing here and every transient test would pass by
	 * finding zero rows — the worst kind of green.
	 *
	 * Leaving the pattern unescaped means "_" stays a single-character
	 * wildcard, which matches a superset of what MySQL would. That is fine for
	 * these fixtures and keeps the assertions meaningful: the "option that
	 * merely contains the word transient" case still has to be excluded on its
	 * own merits rather than by an escape.
	 */
	public function esc_like( $text ) {
		return (string) $text;
	}

	/**
	 * @param string $sql Statement.
	 * @return int Rows affected.
	 */
	public function query( $sql ) {
		$this->log[] = $sql;

		try {
			return (int) $this->pdo->exec( $this->translate( $sql ) );
		} catch ( PDOException $e ) {
			$this->last_error = $e->getMessage();
			return false;
		}
	}

	public function get_var( $sql ) {
		$row = $this->get_row( $sql, ARRAY_A );

		return is_array( $row ) ? reset( $row ) : null;
	}

	public function get_row( $sql, $output = OBJECT ) {
		$rows = $this->get_results( $sql, ARRAY_A );

		if ( ! $rows ) {
			return null;
		}

		return ARRAY_A === $output ? $rows[0] : (object) $rows[0];
	}

	public function get_col( $sql ) {
		$out = array();

		foreach ( $this->get_results( $sql, ARRAY_A ) as $row ) {
			$out[] = reset( $row );
		}

		return $out;
	}

	public function get_results( $sql, $output = OBJECT ) {
		$this->log[] = $sql;

		try {
			$statement = $this->pdo->query( $this->translate( $sql ) );
			$rows      = $statement ? $statement->fetchAll( PDO::FETCH_ASSOC ) : array();
		} catch ( PDOException $e ) {
			$this->last_error = $e->getMessage();
			return array();
		}

		if ( ARRAY_A === $output ) {
			return $rows;
		}

		return array_map( static function ( $row ) { return (object) $row; }, $rows );
	}

	public function update( $table, $data, $where, $format = null, $where_format = null ) {
		$sets = array();

		foreach ( $data as $column => $value ) {
			$sets[] = $column . " = '" . str_replace( "'", "''", (string) $value ) . "'";
		}

		$conditions = array();

		foreach ( $where as $column => $value ) {
			$conditions[] = $column . " = '" . str_replace( "'", "''", (string) $value ) . "'";
		}

		return $this->query( "UPDATE {$table} SET " . implode( ', ', $sets ) . ' WHERE ' . implode( ' AND ', $conditions ) );
	}

	public function tables( $scope = 'all', $prefix = true, $blog_id = 0 ) {
		$core = array( 'posts', 'postmeta', 'comments', 'commentmeta', 'terms', 'termmeta', 'term_relationships', 'term_taxonomy', 'users', 'usermeta', 'options', 'links' );

		return array_map( function ( $name ) { return $this->prefix . $name; }, $core );
	}

	/* -------- helpers the tests use -------- */

	/**
	 * @param string $table  Bare table name.
	 * @param array  $row    Column => value.
	 */
	public function insert_row( $table, array $row ) {
		$name    = $this->prefix . $table;
		$columns = implode( ', ', array_keys( $row ) );
		$values  = array();

		foreach ( $row as $value ) {
			$values[] = is_int( $value ) ? (string) $value : "'" . str_replace( "'", "''", (string) $value ) . "'";
		}

		$this->pdo->exec( "INSERT INTO {$name} ({$columns}) VALUES (" . implode( ', ', $values ) . ')' );
	}

	/**
	 * @param string $table  Bare table name.
	 * @param string $column Key column.
	 * @param int    $id     Key.
	 * @return bool
	 */
	public function remove_row( $table, $column, $id ) {
		$name = $this->prefix . $table;

		return (bool) $this->pdo->exec( "DELETE FROM {$name} WHERE {$column} = " . (int) $id );
	}

	/**
	 * @param string $table Bare table name.
	 * @return int
	 */
	public function count_rows( $table ) {
		$name = $this->prefix . $table;

		return (int) $this->pdo->query( "SELECT COUNT(*) FROM {$name}" )->fetchColumn();
	}

	public function truncate_all() {
		foreach ( array( 'posts', 'postmeta', 'comments', 'commentmeta', 'terms', 'termmeta', 'term_relationships', 'users', 'usermeta', 'options' ) as $table ) {
			$this->pdo->exec( 'DELETE FROM ' . $this->prefix . $table );
		}
	}
}

if ( ! defined( 'OBJECT' ) ) {
	define( 'OBJECT', 'OBJECT' );
}
if ( ! defined( 'ARRAY_A' ) ) {
	define( 'ARRAY_A', 'ARRAY_A' );
}

$GLOBALS['wpdb'] = new DBC_Test_DB();

require_once DBC_DIR . 'includes/class-dbc-options.php';
require_once DBC_DIR . 'includes/class-dbc-task.php';
require_once DBC_DIR . 'includes/class-dbc-tables.php';
require_once DBC_DIR . 'includes/class-dbc-autoload.php';
require_once DBC_DIR . 'includes/tasks/class-dbc-task-revisions.php';
require_once DBC_DIR . 'includes/tasks/class-dbc-task-orphans.php';
require_once DBC_DIR . 'includes/tasks/class-dbc-task-transients.php';
require_once DBC_DIR . 'includes/class-dbc-registry.php';
require_once DBC_DIR . 'includes/class-dbc-runner.php';

/**
 * Start from nothing.
 */
function dbc_reset() {
	$GLOBALS['wpdb']->truncate_all();
	$GLOBALS['wpdb']->log      = array();
	$GLOBALS['dbc_options']    = array();
	$GLOBALS['dbc_api_calls']  = array();
	$GLOBALS['dbc_term_counts'] = array();

	$ref = new ReflectionProperty( 'DBC_Options', 'cache' );
	$ref->setAccessible( true );
	$ref->setValue( null );

	DBC_Registry::flush();
}

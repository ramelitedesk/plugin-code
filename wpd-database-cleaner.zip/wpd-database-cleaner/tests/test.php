<?php
/**
 * What gets deleted, and — the half that matters more — what does not.
 *
 * A cleaner has one catastrophic failure mode and it is not "missed some junk".
 * It is deleting something that mattered, from a place with no undo, on
 * somebody else's site. So most of the assertions below are of the form "this
 * must still be there afterwards".
 *
 * The database is real SQLite rather than a hand-written fake, so the actual
 * statements run: the LEFT JOIN ... IS NULL orphan queries, the GROUP BY
 * duplicate detection, the LIMIT that makes batching work. A mistake in one of
 * those fails here instead of on a live site.
 *
 * @package Database_Cleaner
 */

if ( 'cli' !== PHP_SAPI ) {
	http_response_code( 404 );
	exit;
}

require __DIR__ . '/bootstrap.php';

$pass = 0;
$fail = 0;

/**
 * @param string $label Assertion.
 * @param bool   $ok    Result.
 * @param string $note  Shown on failure.
 */
function check( $label, $ok, $note = '' ) {
	global $pass, $fail;

	if ( $ok ) {
		$pass++;
		printf( "  ok    %s\n", $label );
		return;
	}

	$fail++;
	printf( "  FAIL  %s%s\n", $label, '' !== $note ? ' :: ' . $note : '' );
}

/**
 * @return DBC_Test_DB
 */
function db() {
	return $GLOBALS['wpdb'];
}

/* ================================================================ *
 * Revisions
 * ================================================================ */

echo "\n=== Revisions: the newest few are kept ===\n";

dbc_reset();

db()->insert_row( 'posts', array( 'ID' => 1, 'post_type' => 'post', 'post_status' => 'publish', 'post_title' => 'A post' ) );

for ( $i = 10; $i <= 19; $i++ ) {
	db()->insert_row( 'posts', array( 'ID' => $i, 'post_parent' => 1, 'post_type' => 'revision', 'post_status' => 'inherit', 'post_title' => 'A post rev' ) );
}

$revisions = new DBC_Task_Revisions();

check( 'ten revisions, three kept, seven to go', 7 === $revisions->count(), (string) $revisions->count() );

DBC_Options::update( array( 'keep_revisions' => 0 ) );
check( 'keeping none means all ten', 10 === $revisions->count(), (string) $revisions->count() );

DBC_Options::update( array( 'keep_revisions' => 3 ) );

$result = $revisions->clean();

check( 'seven were removed', 7 === $result['removed'], (string) $result['removed'] );
check( 'and it finished', $result['finished'] );
check( 'three revisions survive', 3 === (int) db()->get_var( "SELECT COUNT(*) FROM wp_posts WHERE post_type = 'revision'" ) );
check( 'the post itself is untouched', 1 === (int) db()->get_var( "SELECT COUNT(*) FROM wp_posts WHERE post_type = 'post'" ) );

/*
 * A raw DELETE would leave every revision's own meta rows behind — turning one
 * kind of bloat into another, and making this plugin the cause of the orphaned
 * meta it reports two screens later.
 */
$used_api = false;

foreach ( $GLOBALS['dbc_api_calls'] as $call ) {
	if ( 'wp_delete_post_revision' === $call[0] ) {
		$used_api = true;
		break;
	}
}

check( 'deletion went through wp_delete_post_revision()', $used_api, 'a raw DELETE would strand the revision meta' );

check( 'the newest revisions are the survivors', 3 === (int) db()->get_var( 'SELECT COUNT(*) FROM wp_posts WHERE ID IN (17,18,19)' ) );

echo "\n=== Revisions belonging to different posts are counted separately ===\n";

dbc_reset();
DBC_Options::update( array( 'keep_revisions' => 2 ) );

foreach ( array( 1, 2 ) as $parent ) {
	db()->insert_row( 'posts', array( 'ID' => $parent, 'post_type' => 'post', 'post_status' => 'publish' ) );

	for ( $i = 0; $i < 5; $i++ ) {
		db()->insert_row( 'posts', array( 'ID' => ( $parent * 100 ) + $i, 'post_parent' => $parent, 'post_type' => 'revision', 'post_status' => 'inherit' ) );
	}
}

check( 'two posts, five revisions each, keep two: six to go', 6 === ( new DBC_Task_Revisions() )->count(), (string) ( new DBC_Task_Revisions() )->count() );

( new DBC_Task_Revisions() )->clean();

check( 'each post keeps its own two', 2 === (int) db()->get_var( 'SELECT COUNT(*) FROM wp_posts WHERE post_parent = 1' ) && 2 === (int) db()->get_var( 'SELECT COUNT(*) FROM wp_posts WHERE post_parent = 2' ) );

/* ================================================================ *
 * Orphaned metadata
 * ================================================================ */

echo "\n=== Orphaned meta ===\n";

dbc_reset();

db()->insert_row( 'posts', array( 'ID' => 1, 'post_type' => 'post', 'post_status' => 'publish' ) );
db()->insert_row( 'postmeta', array( 'meta_id' => 1, 'post_id' => 1, 'meta_key' => 'keep_me', 'meta_value' => 'live' ) );
db()->insert_row( 'postmeta', array( 'meta_id' => 2, 'post_id' => 999, 'meta_key' => 'orphan', 'meta_value' => 'dead' ) );
db()->insert_row( 'postmeta', array( 'meta_id' => 3, 'post_id' => 998, 'meta_key' => 'orphan', 'meta_value' => 'dead' ) );

$orphans = new DBC_Task_Orphan_Postmeta();

check( 'two orphaned rows found', 2 === $orphans->count(), (string) $orphans->count() );
check( 'the sample shows real rows', 2 === count( $orphans->sample() ) );

$orphans->clean();

check( 'the orphans are gone', 0 === $orphans->count() );
check( 'the live row survived', 1 === (int) db()->get_var( 'SELECT COUNT(*) FROM wp_postmeta WHERE meta_id = 1' ), 'meta belonging to a real post must never be touched' );

echo "\n=== Comment, term and user meta use the same rule ===\n";

dbc_reset();

db()->insert_row( 'comments', array( 'comment_ID' => 1, 'comment_approved' => '1' ) );
db()->insert_row( 'commentmeta', array( 'meta_id' => 1, 'comment_id' => 1, 'meta_key' => 'ok' ) );
db()->insert_row( 'commentmeta', array( 'meta_id' => 2, 'comment_id' => 42, 'meta_key' => 'orphan' ) );

db()->insert_row( 'terms', array( 'term_id' => 1, 'name' => 'News' ) );
db()->insert_row( 'termmeta', array( 'meta_id' => 1, 'term_id' => 1, 'meta_key' => 'ok' ) );
db()->insert_row( 'termmeta', array( 'meta_id' => 2, 'term_id' => 42, 'meta_key' => 'orphan' ) );

db()->insert_row( 'users', array( 'ID' => 1, 'user_login' => 'admin' ) );
db()->insert_row( 'usermeta', array( 'umeta_id' => 1, 'user_id' => 1, 'meta_key' => 'ok' ) );
db()->insert_row( 'usermeta', array( 'umeta_id' => 2, 'user_id' => 42, 'meta_key' => 'orphan' ) );

foreach ( array( 'DBC_Task_Orphan_Commentmeta', 'DBC_Task_Orphan_Termmeta', 'DBC_Task_Orphan_Usermeta' ) as $class ) {
	$task = new $class();

	check( $task->label() . ': one orphan found', 1 === $task->count(), (string) $task->count() );

	$task->clean();

	check( $task->label() . ': orphan removed, live row kept', 0 === $task->count() );
}

check( 'the live comment meta survived', 1 === (int) db()->get_var( 'SELECT COUNT(*) FROM wp_commentmeta' ) );
check( 'the live term meta survived', 1 === (int) db()->get_var( 'SELECT COUNT(*) FROM wp_termmeta' ) );
check( 'the live user meta survived', 1 === (int) db()->get_var( 'SELECT COUNT(*) FROM wp_usermeta' ) );

echo "\n=== Taxonomy links ===\n";

dbc_reset();

db()->insert_row( 'posts', array( 'ID' => 1, 'post_type' => 'post', 'post_status' => 'publish' ) );
db()->insert_row( 'term_relationships', array( 'object_id' => 1, 'term_taxonomy_id' => 5 ) );
db()->insert_row( 'term_relationships', array( 'object_id' => 999, 'term_taxonomy_id' => 5 ) );

$links = new DBC_Task_Orphan_Relationships();

check( 'one dead link found', 1 === $links->count(), (string) $links->count() );

$links->clean();

check( 'the dead link is gone', 1 === (int) db()->get_var( 'SELECT COUNT(*) FROM wp_term_relationships' ) );
check( 'the live link survived', 1 === (int) db()->get_var( 'SELECT COUNT(*) FROM wp_term_relationships WHERE object_id = 1' ) );
check( 'term counts were recalculated', ! empty( $GLOBALS['dbc_term_counts'] ), 'archive counts must be made correct, not merely smaller' );

echo "\n=== Duplicate meta: the oldest copy is kept ===\n";

dbc_reset();

db()->insert_row( 'posts', array( 'ID' => 1, 'post_type' => 'post', 'post_status' => 'publish' ) );
db()->insert_row( 'postmeta', array( 'meta_id' => 1, 'post_id' => 1, 'meta_key' => 'colour', 'meta_value' => 'blue' ) );
db()->insert_row( 'postmeta', array( 'meta_id' => 2, 'post_id' => 1, 'meta_key' => 'colour', 'meta_value' => 'blue' ) );
db()->insert_row( 'postmeta', array( 'meta_id' => 3, 'post_id' => 1, 'meta_key' => 'colour', 'meta_value' => 'blue' ) );
// Same key, different value — a genuine multi-value field, not a duplicate.
db()->insert_row( 'postmeta', array( 'meta_id' => 4, 'post_id' => 1, 'meta_key' => 'colour', 'meta_value' => 'green' ) );
// Same key and value, different post.
db()->insert_row( 'posts', array( 'ID' => 2, 'post_type' => 'post', 'post_status' => 'publish' ) );
db()->insert_row( 'postmeta', array( 'meta_id' => 5, 'post_id' => 2, 'meta_key' => 'colour', 'meta_value' => 'blue' ) );

$dupes = new DBC_Task_Duplicate_Postmeta();

check( 'two redundant copies found', 2 === $dupes->count(), (string) $dupes->count() );

$dupes->clean();

check( 'the oldest copy is the survivor', 1 === (int) db()->get_var( 'SELECT COUNT(*) FROM wp_postmeta WHERE meta_id = 1' ) );
check( 'a different value on the same key is kept', 1 === (int) db()->get_var( "SELECT COUNT(*) FROM wp_postmeta WHERE meta_value = 'green'" ), 'multi-value fields are not duplicates' );
check( 'the same value on another post is kept', 1 === (int) db()->get_var( 'SELECT COUNT(*) FROM wp_postmeta WHERE post_id = 2' ) );
check( 'three rows left in total', 3 === db()->count_rows( 'postmeta' ), (string) db()->count_rows( 'postmeta' ) );

/* ================================================================ *
 * Transients — the case most cleaners get wrong
 * ================================================================ */

echo "\n=== Transients ===\n";

dbc_reset();

$past   = time() - 3600;
$future = time() + 3600;

// Expired: both rows should go.
db()->insert_row( 'options', array( 'option_name' => '_transient_timeout_gone', 'option_value' => (string) $past ) );
db()->insert_row( 'options', array( 'option_name' => '_transient_gone', 'option_value' => 'stale' ) );

// Still valid: both rows must stay.
db()->insert_row( 'options', array( 'option_name' => '_transient_timeout_live', 'option_value' => (string) $future ) );
db()->insert_row( 'options', array( 'option_name' => '_transient_live', 'option_value' => 'fresh' ) );

/*
 * No timeout row at all. This is NOT an orphan — it is a transient set with no
 * expiry, which is permanent by design. Licence keys and API tokens live here,
 * and sweeping them is how a cleaner silently breaks a plugin.
 */
db()->insert_row( 'options', array( 'option_name' => '_transient_forever', 'option_value' => 'licence-key-abc' ) );

// A timeout whose value is already gone. This one genuinely is stranded.
db()->insert_row( 'options', array( 'option_name' => '_transient_timeout_stranded', 'option_value' => (string) $future ) );

// An ordinary option that merely looks a bit like one.
db()->insert_row( 'options', array( 'option_name' => 'my_plugin_transient_settings', 'option_value' => 'important' ) );

$transients = new DBC_Task_Expired_Transients();

$transients->clean();

check( 'the expired transient is gone', 0 === (int) db()->get_var( "SELECT COUNT(*) FROM wp_options WHERE option_name = '_transient_gone'" ) );
check( 'its timeout row is gone too', 0 === (int) db()->get_var( "SELECT COUNT(*) FROM wp_options WHERE option_name = '_transient_timeout_gone'" ) );

check( 'an unexpired transient is untouched', 1 === (int) db()->get_var( "SELECT COUNT(*) FROM wp_options WHERE option_name = '_transient_live'" ) );
check( 'its timeout is untouched', 1 === (int) db()->get_var( "SELECT COUNT(*) FROM wp_options WHERE option_name = '_transient_timeout_live'" ) );

check(
	'a transient with NO expiry is never deleted',
	1 === (int) db()->get_var( "SELECT COUNT(*) FROM wp_options WHERE option_name = '_transient_forever'" ),
	'permanent transients hold licence keys — sweeping them breaks plugins'
);

check( 'a stranded timeout row is removed', 0 === (int) db()->get_var( "SELECT COUNT(*) FROM wp_options WHERE option_name = '_transient_timeout_stranded'" ) );

check(
	'an option that merely contains "transient" is untouched',
	1 === (int) db()->get_var( "SELECT COUNT(*) FROM wp_options WHERE option_name = 'my_plugin_transient_settings'" )
);

/* ================================================================ *
 * Comments
 * ================================================================ */

echo "\n=== Comments ===\n";

dbc_reset();

db()->insert_row( 'comments', array( 'comment_ID' => 1, 'comment_approved' => '1', 'comment_type' => 'comment' ) );
db()->insert_row( 'comments', array( 'comment_ID' => 2, 'comment_approved' => 'spam', 'comment_type' => 'comment' ) );
db()->insert_row( 'comments', array( 'comment_ID' => 3, 'comment_approved' => 'trash', 'comment_type' => 'comment' ) );
db()->insert_row( 'comments', array( 'comment_ID' => 4, 'comment_approved' => '0', 'comment_type' => 'comment' ) );
db()->insert_row( 'comments', array( 'comment_ID' => 5, 'comment_approved' => '1', 'comment_type' => 'pingback' ) );

check( 'one spam comment found', 1 === ( new DBC_Task_Spam_Comments() )->count() );
check( 'one trashed comment found', 1 === ( new DBC_Task_Trashed_Comments() )->count() );
check( 'one pingback found', 1 === ( new DBC_Task_Pingbacks() )->count() );

( new DBC_Task_Spam_Comments() )->clean();

check( 'spam is gone', 0 === (int) db()->get_var( "SELECT COUNT(*) FROM wp_comments WHERE comment_approved = 'spam'" ) );
check( 'the approved comment survived', 1 === (int) db()->get_var( 'SELECT COUNT(*) FROM wp_comments WHERE comment_ID = 1' ) );
check( 'a comment awaiting moderation survived', 1 === (int) db()->get_var( 'SELECT COUNT(*) FROM wp_comments WHERE comment_ID = 4' ), 'unapproved is not spam' );

$used_api = false;

foreach ( $GLOBALS['dbc_api_calls'] as $call ) {
	if ( 'wp_delete_comment' === $call[0] ) {
		$used_api = true;
		break;
	}
}

check( 'deletion went through wp_delete_comment()', $used_api, 'so post comment counts stay correct' );

/* ================================================================ *
 * Batching
 * ================================================================ */

echo "\n=== Batching and the time budget ===\n";

dbc_reset();

db()->insert_row( 'posts', array( 'ID' => 1, 'post_type' => 'post', 'post_status' => 'publish' ) );

for ( $i = 1; $i <= 1200; $i++ ) {
	db()->insert_row( 'postmeta', array( 'meta_id' => $i, 'post_id' => 500 + $i, 'meta_key' => 'orphan', 'meta_value' => 'x' ) );
}

$task = new DBC_Task_Orphan_Postmeta();

check( '1,200 orphans found', 1200 === $task->count(), (string) $task->count() );

// A deadline already in the past: one batch runs, then it stops.
$result = $task->clean( microtime( true ) - 1 );

check( 'an expired budget stops after one batch', DBC_Task::BATCH === $result['removed'], (string) $result['removed'] );
check( 'and it reports that it did not finish', ! $result['finished'] );
check( 'and says how many are left', 700 === $result['remaining'], (string) $result['remaining'] );

$result = $task->clean();

check( 'running again clears the rest', $result['finished'] && 0 === $task->count() );

/* ================================================================ *
 * The guards
 * ================================================================ */

echo "\n=== Table drops are refused unless everything lines up ===\n";

dbc_reset();

$dropped = DBC_Tables::drop( 'wp_orphan_table', 'wp_wrong_name' );
check( 'a mistyped confirmation is refused', is_wp_error( $dropped ) && 'dbc_not_confirmed' === $dropped->get_error_code() );

$dropped = DBC_Tables::drop( 'wp_posts', 'wp_posts' );
check( 'a WordPress table is refused even when confirmed', is_wp_error( $dropped ) && 'dbc_core_table' === $dropped->get_error_code(), 'core tables must never be droppable from here' );

$dropped = DBC_Tables::drop( 'other_install_posts', 'other_install_posts' );
check( 'a table without our prefix is refused', is_wp_error( $dropped ) && 'dbc_foreign_table' === $dropped->get_error_code(), 'another install may share this database' );

$dropped = DBC_Tables::drop( 'wp_x; DROP TABLE wp_posts', 'wp_x; DROP TABLE wp_posts' );
check( 'a name that is not a bare identifier is refused', is_wp_error( $dropped ) );
check( 'and wp_posts is still there', null !== db()->get_var( 'SELECT COUNT(*) FROM wp_posts' ) );

check( 'wp_posts is recognised as core', DBC_Tables::is_core( 'wp_posts' ) );
check( 'an unknown table is not', ! DBC_Tables::is_core( 'wp_some_old_plugin' ) );
check( 'our prefix is recognised', DBC_Tables::has_prefix( 'wp_anything' ) );
check( 'a foreign prefix is not', ! DBC_Tables::has_prefix( 'other_anything' ) );

echo "\n=== Autoloaded options ===\n";

dbc_reset();

db()->insert_row( 'options', array( 'option_name' => 'siteurl', 'option_value' => 'https://example.test', 'autoload' => 'yes' ) );
db()->insert_row( 'options', array( 'option_name' => 'big_plugin_cache', 'option_value' => str_repeat( 'x', 4096 ), 'autoload' => 'yes' ) );
db()->insert_row( 'options', array( 'option_name' => 'small_thing', 'option_value' => 'y', 'autoload' => 'no' ) );

check( 'only autoloaded options are counted', 2 === DBC_Autoload::count(), (string) DBC_Autoload::count() );
check( 'the total is the sum of their sizes', DBC_Autoload::total() > 4000 );

$largest = DBC_Autoload::largest( 5 );
check( 'the biggest is listed first', 'big_plugin_cache' === $largest[0]['name'] );

check( 'siteurl is protected', DBC_Autoload::is_protected( 'siteurl' ) );
check( 'active_plugins is protected', DBC_Autoload::is_protected( 'active_plugins' ) );
check( 'theme_mods_* is protected', DBC_Autoload::is_protected( 'theme_mods_twentytwentyfour' ) );
check( 'a plugin cache is not protected', ! DBC_Autoload::is_protected( 'big_plugin_cache' ) );

$result = DBC_Autoload::stop_autoloading( 'siteurl' );
check( 'a protected option refuses to stop autoloading', is_wp_error( $result ), 'switching siteurl off breaks the site on the next request' );

$result = DBC_Autoload::stop_autoloading( 'big_plugin_cache' );
check( 'an unprotected one is switched off', true === $result );
check( 'the value is still there', 4096 === strlen( (string) db()->get_var( "SELECT option_value FROM wp_options WHERE option_name = 'big_plugin_cache'" ) ), 'this must never delete data' );
check( 'it no longer autoloads', 'no' === db()->get_var( "SELECT autoload FROM wp_options WHERE option_name = 'big_plugin_cache'" ) );
check( 'the change is recorded so it can be undone', array_key_exists( 'big_plugin_cache', DBC_Autoload::changed() ) );

DBC_Autoload::resume_autoloading( 'big_plugin_cache' );

check( 'it can be put back', 'yes' === db()->get_var( "SELECT autoload FROM wp_options WHERE option_name = 'big_plugin_cache'" ) );
check( 'and drops off the changed list', ! array_key_exists( 'big_plugin_cache', DBC_Autoload::changed() ) );

echo "\n=== Only safe tasks may run unattended ===\n";

dbc_reset();

$schedulable = DBC_Registry::schedulable();
$keys        = array_keys( $schedulable );

check( 'orphaned meta may be scheduled', in_array( 'orphan_postmeta', $keys, true ) );
check( 'expired transients may be scheduled', in_array( 'expired_transients', $keys, true ) );
check( 'the trash may NOT be scheduled', ! in_array( 'trashed_posts', $keys, true ), 'somebody may still want those back' );
check( 'trashed comments may NOT be scheduled', ! in_array( 'trashed_comments', $keys, true ) );
check( 'duplicate meta may NOT be scheduled', ! in_array( 'duplicate_postmeta', $keys, true ) );

foreach ( $schedulable as $task ) {
	if ( DBC_Task::SAFE !== $task->risk() ) {
		check( 'a non-safe task escaped into the schedulable list', false, $task->key() );
	}
}

check( 'every schedulable task is marked safe', true );

echo "\n=== Every task describes itself ===\n";

foreach ( DBC_Registry::all() as $key => $task ) {
	check( "$key has a label", '' !== $task->label() );
	check( "$key explains what it removes", strlen( $task->description() ) > 40, 'this is the text someone reads before deleting their data' );
	check( "$key counts without error", is_int( $task->count() ) );
}

/* ------------------------------------------------------------------ */

printf( "\n----\npassed: %d   failed: %d\n", $pass, $fail );

exit( $fail > 0 ? 1 : 0 );

<?php
/**
 * The guard against being replaced by somebody else's plugin.
 *
 * This exists because it already happened. The plugin shipped in a folder named
 * "database-cleaner"; that slug belongs to a plugin by Jordy Meow on
 * WordPress.org; WordPress offered his version as an update, and pressing the
 * button deleted this plugin and installed his.
 *
 * What makes that failure worth a test rather than a note is how quiet it is.
 * The site keeps working. The plugins list still shows an entry with a
 * plausible name. Nothing errors. The only symptom is that the settings are
 * gone and the screens look unfamiliar — which reads as "the update changed
 * things" rather than "this is a different piece of software".
 *
 * @package Database_Cleaner
 */

if ( 'cli' !== PHP_SAPI ) {
	http_response_code( 404 );
	exit;
}

require __DIR__ . '/bootstrap.php';

/**
 * plugin_basename() is not defined by the main bootstrap; the guard is the only
 * thing that needs it.
 */
if ( ! function_exists( 'plugin_basename' ) ) {
	function plugin_basename( $file ) {
		return 'wpd-database-cleaner/wpd-database-cleaner.php';
	}
}

require_once DBC_DIR . 'includes/class-dbc-updates.php';

$pass = 0;
$fail = 0;

/**
 * @param string $label Assertion.
 * @param bool   $ok    Result.
 * @param string $note  Shown on failure.
 */
function check( $label, $ok, $note = '' ) {
	global $pass, $fail;

	if ( $ok ) {
		$pass++;
		printf( "  ok    %s\n", $label );
		return;
	}

	$fail++;
	printf( "  FAIL  %s%s\n", $label, '' !== $note ? ' :: ' . $note : '' );
}

$ours = 'wpd-database-cleaner/wpd-database-cleaner.php';

echo "\n=== An update offered for this plugin is refused ===\n";

$transient = (object) array(
	'response'  => array(
		$ours                       => (object) array( 'new_version' => '9.9.9', 'slug' => 'database-cleaner' ),
		'akismet/akismet.php'       => (object) array( 'new_version' => '5.4' ),
	),
	'no_update' => array(
		$ours                 => (object) array( 'slug' => 'database-cleaner' ),
		'hello-dolly/hello.php' => (object) array( 'slug' => 'hello-dolly' ),
	),
);

$filtered = DBC_Updates::remove_foreign_update( $transient );

check( 'the offer for this plugin is gone', ! isset( $filtered->response[ $ours ] ), 'this is the one that replaces the plugin' );
check( 'the no_update entry is gone too', ! isset( $filtered->no_update[ $ours ] ), 'it still describes somebody else\'s plugin' );

check( 'another plugin\'s real update is untouched', isset( $filtered->response['akismet/akismet.php'] ), 'blocking everything would stop real security updates' );
check( 'another plugin\'s no_update entry is untouched', isset( $filtered->no_update['hello-dolly/hello.php'] ) );

echo "\n=== It survives whatever else is in that transient ===\n";

check( 'a transient with no response array', is_object( DBC_Updates::remove_foreign_update( (object) array() ) ) );
check( 'a transient that is not an object', false === DBC_Updates::remove_foreign_update( false ) );
check( 'an empty transient', is_object( DBC_Updates::remove_foreign_update( (object) array( 'response' => array(), 'no_update' => array() ) ) ) );

echo "\n=== The details panel does not describe the wrong plugin ===\n";

$result = DBC_Updates::remove_foreign_details( (object) array( 'name' => 'Somebody Else' ), 'plugin_information', (object) array( 'slug' => 'wpd-database-cleaner' ) );
check( 'asking about our slug returns an error, not their listing', is_wp_error( $result ) );

$other = (object) array( 'name' => 'Akismet' );
check( 'asking about another plugin is passed through', $other === DBC_Updates::remove_foreign_details( $other, 'plugin_information', (object) array( 'slug' => 'akismet' ) ) );
check( 'a different API action is passed through', $other === DBC_Updates::remove_foreign_details( $other, 'query_plugins', (object) array( 'slug' => 'wpd-database-cleaner' ) ) );
check( 'a request with no slug is passed through', $other === DBC_Updates::remove_foreign_details( $other, 'plugin_information', (object) array() ) );

echo "\n=== The folder name itself ===\n";

$header = file_get_contents( DBC_DIR . 'wpd-database-cleaner.php' );

check( 'the main file is named after the prefixed slug', is_string( $header ) );
check( 'the text domain is prefixed', false !== strpos( $header, 'Text Domain:       wpd-database-cleaner' ) );
check( 'no bare "database-cleaner" text domain is left', false === strpos( $header, "'database-cleaner'" ), 'the unprefixed slug is the one that collides' );

printf( "\n----\npassed: %d   failed: %d\n", $pass, $fail );

exit( $fail > 0 ? 1 : 0 );

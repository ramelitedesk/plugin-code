/**
 * Busy state on the action buttons.
 *
 * Progressive enhancement only. Without this every form still submits exactly
 * as before; the only thing lost is the spinner.
 *
 * A cleanup can take twenty seconds with nothing on screen to show for it, and
 * the reasonable conclusion from that is that the button is broken — followed
 * by the reasonable response, which is to click it again and start a second
 * deletion on top of the first.
 *
 * @package Database_Cleaner
 */
( function () {
	'use strict';

	document.addEventListener( 'submit', function ( event ) {
		var form = event.target;

		if ( ! form || ! form.hasAttribute || ! form.hasAttribute( 'data-dbc-form' ) ) {
			return;
		}

		var button = form.querySelector( 'button[type="submit"]' );

		if ( ! button || button.disabled ) {
			event.preventDefault();
			return;
		}

		button.textContent = button.getAttribute( 'data-busy-label' ) || 'Working…';
		button.classList.add( 'dbc-busy' );

		// Deferred: a disabled button's value is not submitted, and disabling
		// inside the handler cancels the submission in some browsers.
		window.setTimeout( function () {
			button.disabled = true;
		}, 0 );

		Array.prototype.forEach.call( document.querySelectorAll( '[data-dbc-form] button[type="submit"]' ), function ( other ) {
			if ( other !== button ) {
				window.setTimeout( function () {
					other.disabled = true;
				}, 0 );
			}
		} );
	} );

	/**
	 * A drop is only offered once the typed name matches, so the button cannot
	 * be pressed on the wrong row by muscle memory.
	 */
	Array.prototype.forEach.call( document.querySelectorAll( '.dbc-drop' ), function ( form ) {
		var field = form.querySelector( '.dbc-confirm' );
		var name = form.querySelector( '[name="table"]' );
		var button = form.querySelector( 'button' );

		if ( ! field || ! name || ! button ) {
			return;
		}

		function sync() {
			button.disabled = field.value.trim() !== name.value;
		}

		field.addEventListener( 'input', sync );
		sync();
	} );

	/**
	 * Restore the page after a back-button navigation. Without this, returning
	 * to a cleanup screen shows every button disabled and one of them still
	 * reading "Cleaning…" for an operation that finished long ago.
	 */
	window.addEventListener( 'pageshow', function ( event ) {
		if ( ! event.persisted ) {
			return;
		}
		window.location.reload();
	} );
}() );

<?php
/**
 * Plugin Name:       WPD Database Cleaner
 * Plugin URI:        https://webart.technology/
 * Description:       Finds transients, revisions, orphaned metadata, unused tables and database bloat — shows you exactly what it would remove before it removes anything. Works on single sites and multisite networks.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Ramakrishna
 * License:           GPL-2.0-or-later
 * Text Domain:       wpd-database-cleaner
 *
 * @package Database_Cleaner
 */

defined( 'ABSPATH' ) || exit;

define( 'DBC_VERSION', '1.0.0' );
define( 'DBC_FILE', __FILE__ );
define( 'DBC_DIR', plugin_dir_path( __FILE__ ) );
define( 'DBC_URL', plugin_dir_url( __FILE__ ) );

/**
 * This plugin deletes things, so it is built around one admission:
 *
 *     It cannot tell what matters to you.
 *
 * A row that is obviously junk to a query is somebody's only copy of something.
 * Orphaned postmeta is genuinely unreachable and safe to drop; a table left by a
 * plugin removed two years ago might hold the entire order history of a shop
 * that ran for a fortnight. Nothing here can tell those apart, so the design
 * does not pretend to:
 *
 *   • Everything is counted and sampled before anything is deleted. No screen
 *     offers a button for something you have not been shown.
 *   • Nothing runs on activation, and nothing runs on a schedule until somebody
 *     turns scheduling on and chooses what it may touch — only from the tasks
 *     that cannot lose recoverable data.
 *   • Tables are never dropped in bulk and never automatically. Each one needs
 *     its own name typed out.
 *   • Deletions go through wp_delete_post(), wp_delete_comment() and their
 *     relatives wherever those exist, so hooks fire and dependent rows go too.
 *     A raw DELETE would turn one kind of orphan into another.
 *   • Every run is recorded. When something breaks a week later, "what did that
 *     plugin delete?" needs an answer.
 *
 * And the thing no plugin can do for you is on every screen: take a backup
 * first. Not because this is expected to go wrong, but because nothing here can
 * undo itself.
 */
final class Database_Cleaner {

	/** @var Database_Cleaner|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->boot();
		}
		return self::$instance;
	}

	private function boot() {
		require_once DBC_DIR . 'includes/class-dbc-options.php';
		require_once DBC_DIR . 'includes/class-dbc-updates.php';
		require_once DBC_DIR . 'includes/class-dbc-task.php';
		require_once DBC_DIR . 'includes/class-dbc-tables.php';
		require_once DBC_DIR . 'includes/class-dbc-autoload.php';
		require_once DBC_DIR . 'includes/tasks/class-dbc-task-revisions.php';
		require_once DBC_DIR . 'includes/tasks/class-dbc-task-orphans.php';
		require_once DBC_DIR . 'includes/tasks/class-dbc-task-transients.php';
		require_once DBC_DIR . 'includes/class-dbc-registry.php';
		require_once DBC_DIR . 'includes/class-dbc-runner.php';

		if ( is_admin() ) {
			require_once DBC_DIR . 'admin/class-dbc-admin.php';
		}

		DBC_Updates::hook();

		add_filter( 'cron_schedules', array( 'DBC_Runner', 'add_schedule' ) ); // phpcs:ignore WordPress.WP.CronInterval.ChangeDetected
		add_action( 'init', array( $this, 'load_textdomain' ), 1 );
		add_action( 'plugins_loaded', array( $this, 'init' ), 5 );

		register_activation_hook( DBC_FILE, array( __CLASS__, 'on_activate' ) );
		register_deactivation_hook( DBC_FILE, array( __CLASS__, 'on_deactivate' ) );
	}

	public function load_textdomain() {
		load_plugin_textdomain( 'wpd-database-cleaner', false, dirname( plugin_basename( DBC_FILE ) ) . '/languages' );
	}

	public function init() {
		DBC_Runner::instance();

		if ( is_admin() && class_exists( 'DBC_Admin' ) ) {
			DBC_Admin::instance();
		}

		do_action( 'dbc_loaded', $this );
	}

	public static function on_activate() {
		require_once DBC_DIR . 'includes/class-dbc-options.php';
		require_once DBC_DIR . 'includes/class-dbc-updates.php';

		DBC_Options::install_defaults();

		/*
		 * Nothing is cleaned here, and nothing is scheduled.
		 *
		 * A plugin that starts deleting because it was activated has taken a
		 * decision that was not its to take. Activation gets you a screen
		 * showing what could go; the rest is a button somebody presses.
		 */
	}

	public static function on_deactivate() {
		wp_clear_scheduled_hook( DBC_Runner::CRON_HOOK );
	}
}

Database_Cleaner::instance();

<?php
/**
 * Admin: Tools → Database Cleaner.
 *
 * @package Database_Cleaner
 */

defined( 'ABSPATH' ) || exit;

class DBC_Admin {

	const PAGE  = 'wpd-database-cleaner';
	const NONCE = 'dbc_action';

	/** @var DBC_Admin|null */
	private static $instance = null;

	/** @var array|null Result of the action that redirected here. */
	private static $report = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'network_admin_menu', array( $this, 'add_network_menu' ) );
		add_action( 'admin_post_dbc_action', array( $this, 'handle_action' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
	}

	public function add_menu() {
		add_management_page(
			__( 'Database Cleaner', 'wpd-database-cleaner' ),
			__( 'Database Cleaner', 'wpd-database-cleaner' ),
			'manage_options',
			self::PAGE,
			array( $this, 'render' )
		);
	}

	public function add_network_menu() {
		add_submenu_page(
			'settings.php',
			__( 'Database Cleaner', 'wpd-database-cleaner' ),
			__( 'Database Cleaner', 'wpd-database-cleaner' ),
			'manage_network_options',
			self::PAGE,
			array( $this, 'render' )
		);
	}

	/**
	 * @param string $hook Current screen.
	 */
	public function enqueue( $hook ) {
		if ( false === strpos( (string) $hook, self::PAGE ) ) {
			return;
		}

		wp_enqueue_style( 'dbc-admin', DBC_URL . 'assets/admin.css', array(), DBC_VERSION );
		wp_enqueue_script( 'dbc-admin', DBC_URL . 'assets/admin.js', array(), DBC_VERSION, true );
	}

	/**
	 * @return bool
	 */
	private static function may_act() {
		return is_network_admin() ? current_user_can( 'manage_network_options' ) : current_user_can( 'manage_options' );
	}

	public function render() {
		if ( ! self::may_act() ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'wpd-database-cleaner' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'clean';

		$settings = DBC_Options::all();
		$report   = self::take_report();

		require DBC_DIR . 'admin/views/page.php';
	}

	/**
	 * Carry a run's result across the redirect.
	 *
	 * A query string cannot hold "removed 12,410 rows across six tasks, two of
	 * which did not finish", and putting counts in the URL means a refresh
	 * re-reports a run that did not happen.
	 *
	 * @param array $report Report.
	 */
	private static function stash_report( array $report ) {
		set_transient( 'dbc_report_' . get_current_user_id(), $report, 5 * MINUTE_IN_SECONDS );
	}

	/**
	 * @return array
	 */
	private static function take_report() {
		$key    = 'dbc_report_' . get_current_user_id();
		$report = get_transient( $key );

		if ( false === $report ) {
			return array();
		}

		delete_transient( $key );

		return is_array( $report ) ? $report : array();
	}

	public function handle_action() {
		if ( ! self::may_act() ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'wpd-database-cleaner' ) );
		}

		check_admin_referer( self::NONCE );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked above.
		$do  = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
		$tab = 'clean';

		switch ( $do ) {
			case 'run':
				// phpcs:ignore WordPress.Security.NonceVerification.Missing
				$key    = isset( $_POST['task'] ) ? sanitize_key( wp_unslash( $_POST['task'] ) ) : '';
				$result = DBC_Runner::run( $key );

				self::stash_report(
					is_wp_error( $result )
						? array( 'error' => $result->get_error_message() )
						: array( 'single' => $result )
				);
				break;

			case 'run_selected':
				// phpcs:ignore WordPress.Security.NonceVerification.Missing
				$keys = isset( $_POST['tasks'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['tasks'] ) ) : array();

				if ( ! $keys ) {
					self::stash_report( array( 'error' => __( 'Nothing was ticked, so nothing was run.', 'wpd-database-cleaner' ) ) );
					break;
				}

				// phpcs:ignore WordPress.Security.NonceVerification.Missing
				$network = ! empty( $_POST['network'] ) && is_multisite() && current_user_can( 'manage_network_options' );

				self::stash_report(
					$network
						? array( 'network' => DBC_Runner::run_network( $keys ) )
						: array( 'batch' => DBC_Runner::run_many( $keys ) )
				);
				break;

			case 'optimize':
				// phpcs:ignore WordPress.Security.NonceVerification.Missing
				$only = isset( $_POST['table'] ) ? array( sanitize_text_field( wp_unslash( $_POST['table'] ) ) ) : array();

				self::stash_report( array( 'optimize' => DBC_Tables::optimize( array_filter( $only ) ) ) );
				$tab = 'tables';
				break;

			case 'drop_table':
				// phpcs:ignore WordPress.Security.NonceVerification.Missing
				$name = isset( $_POST['table'] ) ? sanitize_text_field( wp_unslash( $_POST['table'] ) ) : '';
				// phpcs:ignore WordPress.Security.NonceVerification.Missing
				$typed = isset( $_POST['confirm'] ) ? sanitize_text_field( wp_unslash( $_POST['confirm'] ) ) : '';

				$dropped = DBC_Tables::drop( $name, $typed );

				self::stash_report(
					is_wp_error( $dropped )
						? array( 'error' => $dropped->get_error_message() )
						: array( 'dropped' => $name )
				);
				$tab = 'tables';
				break;

			case 'autoload_off':
				// phpcs:ignore WordPress.Security.NonceVerification.Missing
				$name   = isset( $_POST['option'] ) ? sanitize_text_field( wp_unslash( $_POST['option'] ) ) : '';
				$result = DBC_Autoload::stop_autoloading( $name );

				self::stash_report(
					is_wp_error( $result )
						? array( 'error' => $result->get_error_message() )
						: array( 'autoload_off' => $name )
				);
				$tab = 'autoload';
				break;

			case 'autoload_on':
				// phpcs:ignore WordPress.Security.NonceVerification.Missing
				$name   = isset( $_POST['option'] ) ? sanitize_text_field( wp_unslash( $_POST['option'] ) ) : '';
				$result = DBC_Autoload::resume_autoloading( $name );

				self::stash_report(
					is_wp_error( $result )
						? array( 'error' => $result->get_error_message() )
						: array( 'autoload_on' => $name )
				);
				$tab = 'autoload';
				break;

			case 'save':
				$this->save_settings();
				$tab = 'schedule';
				break;

			case 'ack_backup':
				DBC_Options::update( array( 'backup_ack' => time() ) );
				break;

			case 'clear_log':
				DBC_Log::clear();
				$tab = 'log';
				break;
		}

		$url = is_network_admin()
			? network_admin_url( 'settings.php' )
			: admin_url( 'tools.php' );

		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE, 'tab' => $tab ), $url ) );
		exit;
	}

	private function save_settings() {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked by the caller.
		$frequency = isset( $_POST['schedule'] ) ? sanitize_key( wp_unslash( $_POST['schedule'] ) ) : 'off';

		if ( ! in_array( $frequency, array( 'off', 'daily', 'weekly', 'monthly' ), true ) ) {
			$frequency = 'off';
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$chosen = isset( $_POST['scheduled_tasks'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['scheduled_tasks'] ) ) : array();

		// Only tasks that cannot lose recoverable data may run unattended,
		// whatever the form posted.
		$chosen = array_values( array_intersect( $chosen, array_keys( DBC_Registry::schedulable() ) ) );

		DBC_Options::update(
			array(
				'schedule'          => $frequency,
				'scheduled_tasks'   => $chosen,
				// phpcs:ignore WordPress.Security.NonceVerification.Missing
				'keep_revisions'    => isset( $_POST['keep_revisions'] ) ? max( 0, (int) wp_unslash( $_POST['keep_revisions'] ) ) : 3,
				// phpcs:ignore WordPress.Security.NonceVerification.Missing
				'keep_actions_days' => isset( $_POST['keep_actions_days'] ) ? max( 1, (int) wp_unslash( $_POST['keep_actions_days'] ) ) : 30,
			)
		);

		DBC_Runner::reschedule( $chosen ? $frequency : 'off' );
	}

	/**
	 * A POST button. There are no GET actions anywhere in this plugin.
	 *
	 * @param string $do      Action key.
	 * @param string $label   Button text.
	 * @param array  $fields  Hidden fields.
	 * @param string $classes CSS classes.
	 * @param string $busy    Text while running.
	 */
	public static function button( $do, $label, array $fields = array(), $classes = 'button', $busy = '' ) {
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline" data-dbc-form>
			<input type="hidden" name="action" value="dbc_action" />
			<input type="hidden" name="do" value="<?php echo esc_attr( $do ); ?>" />
			<?php foreach ( $fields as $name => $value ) : ?>
				<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>" />
			<?php endforeach; ?>
			<?php wp_nonce_field( self::NONCE ); ?>
			<button
				type="submit"
				class="<?php echo esc_attr( $classes ); ?>"
				data-busy-label="<?php echo esc_attr( '' !== $busy ? $busy : __( 'Working…', 'wpd-database-cleaner' ) ); ?>"
			><?php echo esc_html( $label ); ?></button>
		</form>
		<?php
	}
}

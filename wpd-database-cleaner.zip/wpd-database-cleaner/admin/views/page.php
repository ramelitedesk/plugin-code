<?php
/**
 * The admin screen.
 *
 * @var string $tab      Current tab.
 * @var array  $settings Settings.
 * @var array  $report   Result of whatever just ran.
 *
 * @package Database_Cleaner
 */

defined( 'ABSPATH' ) || exit;

$dbc_tabs = array(
	'clean'    => __( 'Clean up', 'wpd-database-cleaner' ),
	'tables'   => __( 'Tables', 'wpd-database-cleaner' ),
	'autoload' => __( 'Autoloaded options', 'wpd-database-cleaner' ),
	'schedule' => __( 'Schedule', 'wpd-database-cleaner' ),
	'log'      => __( 'History', 'wpd-database-cleaner' ),
);

$dbc_base = is_network_admin() ? network_admin_url( 'settings.php' ) : admin_url( 'tools.php' );
?>
<div class="wrap dbc-wrap">
	<h1><?php esc_html_e( 'Database Cleaner', 'wpd-database-cleaner' ); ?></h1>

	<div class="notice notice-warning dbc-backup">
		<p>
			<strong><?php esc_html_e( 'Take a backup before you use this.', 'wpd-database-cleaner' ); ?></strong>
			<?php esc_html_e( 'Not because something is expected to go wrong — because nothing on these screens can undo itself. Every count is checked before it is acted on and every deletion goes through WordPress\'s own functions, and none of that helps if a row turns out to have mattered.', 'wpd-database-cleaner' ); ?>
		</p>
	</div>

	<?php require DBC_DIR . 'admin/views/report.php'; ?>

	<nav class="nav-tab-wrapper">
		<?php foreach ( $dbc_tabs as $dbc_slug => $dbc_label ) : ?>
			<a
				class="nav-tab <?php echo $tab === $dbc_slug ? 'nav-tab-active' : ''; ?>"
				href="<?php echo esc_url( add_query_arg( array( 'page' => DBC_Admin::PAGE, 'tab' => $dbc_slug ), $dbc_base ) ); ?>"
			><?php echo esc_html( $dbc_label ); ?></a>
		<?php endforeach; ?>
	</nav>

	<?php if ( 'clean' === $tab ) : ?>

		<?php
		$dbc_groups = DBC_Registry::grouped();
		$dbc_total  = 0;

		foreach ( $dbc_groups as $dbc_rows ) {
			foreach ( $dbc_rows as $dbc_row ) {
				$dbc_total += $dbc_row['count'];
			}
		}
		?>

		<div class="dbc-summary">
			<div class="dbc-stat">
				<span class="n"><?php echo esc_html( number_format_i18n( $dbc_total ) ); ?></span>
				<span class="l"><?php esc_html_e( 'rows could be removed', 'wpd-database-cleaner' ); ?></span>
			</div>
			<div class="dbc-stat">
				<span class="n"><?php echo esc_html( size_format( DBC_Tables::total_size() ) ); ?></span>
				<span class="l"><?php esc_html_e( 'database size', 'wpd-database-cleaner' ); ?></span>
			</div>
			<div class="dbc-stat">
				<span class="n"><?php echo esc_html( size_format( DBC_Autoload::total() ) ); ?></span>
				<span class="l"><?php esc_html_e( 'loaded on every request', 'wpd-database-cleaner' ); ?></span>
			</div>
		</div>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-dbc-form>
			<input type="hidden" name="action" value="dbc_action" />
			<input type="hidden" name="do" value="run_selected" />
			<?php wp_nonce_field( DBC_Admin::NONCE ); ?>

			<?php foreach ( $dbc_groups as $dbc_group => $dbc_rows ) : ?>
				<div class="dbc-panel">
					<h2><?php echo esc_html( $dbc_group ); ?></h2>

					<?php foreach ( $dbc_rows as $dbc_row ) : ?>
						<?php
						$dbc_task  = $dbc_row['task'];
						$dbc_count = (int) $dbc_row['count'];
						$dbc_id    = 'dbc-' . $dbc_task->key();
						?>
						<div class="dbc-task <?php echo 0 === $dbc_count ? 'is-empty' : ''; ?> dbc-task--<?php echo esc_attr( $dbc_task->risk() ); ?>">
							<div class="dbc-task__head">
								<label class="dbc-task__pick">
									<input
										type="checkbox"
										name="tasks[]"
										id="<?php echo esc_attr( $dbc_id ); ?>"
										value="<?php echo esc_attr( $dbc_task->key() ); ?>"
										<?php disabled( 0 === $dbc_count ); ?>
									/>
									<span class="dbc-task__name"><?php echo esc_html( $dbc_task->label() ); ?></span>
								</label>

								<span class="dbc-task__count">
									<?php
									echo 0 === $dbc_count
										? esc_html__( 'nothing to remove', 'wpd-database-cleaner' )
										: esc_html(
											sprintf(
												/* translators: %s: row count. */
												_n( '%s row', '%s rows', $dbc_count, 'wpd-database-cleaner' ),
												number_format_i18n( $dbc_count )
											)
										);
									?>
								</span>

								<?php if ( DBC_Task::SAFE !== $dbc_task->risk() ) : ?>
									<span class="dbc-badge dbc-badge--consider"><?php esc_html_e( 'look first', 'wpd-database-cleaner' ); ?></span>
								<?php endif; ?>
							</div>

							<p class="dbc-task__desc"><?php echo esc_html( $dbc_task->description() ); ?></p>

							<?php if ( '' !== $dbc_task->warning() ) : ?>
								<p class="dbc-task__warn"><?php echo esc_html( $dbc_task->warning() ); ?></p>
							<?php endif; ?>

							<?php if ( $dbc_count > 0 ) : ?>
								<?php $dbc_sample = $dbc_task->sample(); ?>
								<?php if ( $dbc_sample ) : ?>
									<details class="dbc-sample">
										<summary><?php esc_html_e( 'Show me some of what would go', 'wpd-database-cleaner' ); ?></summary>
										<table class="widefat striped">
											<tbody>
												<?php foreach ( $dbc_sample as $dbc_entry ) : ?>
													<tr>
														<?php foreach ( $dbc_entry as $dbc_key => $dbc_value ) : ?>
															<td><strong><?php echo esc_html( $dbc_key ); ?>:</strong> <?php echo esc_html( $dbc_value ); ?></td>
														<?php endforeach; ?>
													</tr>
												<?php endforeach; ?>
											</tbody>
										</table>
									</details>
								<?php endif; ?>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endforeach; ?>

			<div class="dbc-panel dbc-run">
				<?php if ( is_multisite() && current_user_can( 'manage_network_options' ) ) : ?>
					<p>
						<label>
							<input type="checkbox" name="network" value="1" />
							<?php
							printf(
								/* translators: %d: site count. */
								esc_html__( 'Run on all %d sites on this network, not just this one', 'wpd-database-cleaner' ),
								(int) get_blog_count()
							);
							?>
						</label>
					</p>
					<p class="description"><?php esc_html_e( 'The counts above are for this site only. A network run works through every site in turn and reports each separately.', 'wpd-database-cleaner' ); ?></p>
				<?php endif; ?>

				<button type="submit" class="button button-primary" data-busy-label="<?php esc_attr_e( 'Cleaning…', 'wpd-database-cleaner' ); ?>">
					<?php esc_html_e( 'Clean up what I have ticked', 'wpd-database-cleaner' ); ?>
				</button>

				<p class="description">
					<?php esc_html_e( 'Nothing is ticked by default. A big job stops before your server does and tells you what is left — press it again to carry on.', 'wpd-database-cleaner' ); ?>
				</p>
			</div>
		</form>

	<?php elseif ( 'tables' === $tab ) : ?>

		<?php require DBC_DIR . 'admin/views/tables.php'; ?>

	<?php elseif ( 'autoload' === $tab ) : ?>

		<?php require DBC_DIR . 'admin/views/autoload.php'; ?>

	<?php elseif ( 'schedule' === $tab ) : ?>

		<?php require DBC_DIR . 'admin/views/schedule.php'; ?>

	<?php else : ?>

		<div class="dbc-panel">
			<h2><?php esc_html_e( 'What has been cleaned', 'wpd-database-cleaner' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'Kept because when something breaks a week after a cleanup, "what did that plugin delete?" needs an answer.', 'wpd-database-cleaner' ); ?>
			</p>

			<?php $dbc_log = DBC_Log::all(); ?>

			<?php if ( ! $dbc_log ) : ?>
				<p><?php esc_html_e( 'Nothing has been cleaned yet.', 'wpd-database-cleaner' ); ?></p>
			<?php else : ?>
				<table class="widefat striped">
					<thead>
						<tr>
							<th><?php esc_html_e( 'When', 'wpd-database-cleaner' ); ?></th>
							<th><?php esc_html_e( 'What', 'wpd-database-cleaner' ); ?></th>
							<th><?php esc_html_e( 'Rows', 'wpd-database-cleaner' ); ?></th>
							<th><?php esc_html_e( 'By', 'wpd-database-cleaner' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $dbc_log as $dbc_entry ) : ?>
							<tr>
								<td>
									<?php
									printf(
										/* translators: %s: human time difference. */
										esc_html__( '%s ago', 'wpd-database-cleaner' ),
										esc_html( human_time_diff( (int) $dbc_entry['time'] ) )
									);
									?>
								</td>
								<td><?php echo esc_html( $dbc_entry['message'] ); ?></td>
								<td><?php echo esc_html( number_format_i18n( (int) $dbc_entry['removed'] ) ); ?></td>
								<td>
									<?php
									$dbc_user = (int) $dbc_entry['user'];
									echo $dbc_user
										? esc_html( (string) get_the_author_meta( 'display_name', $dbc_user ) )
										: esc_html__( 'scheduled', 'wpd-database-cleaner' );
									?>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>

				<p><?php DBC_Admin::button( 'clear_log', __( 'Clear this history', 'wpd-database-cleaner' ) ); ?></p>
			<?php endif; ?>
		</div>

	<?php endif; ?>
</div>

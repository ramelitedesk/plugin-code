<?php
/**
 * The autoloaded-options screen.
 *
 * @package Database_Cleaner
 */

defined( 'ABSPATH' ) || exit;

$dbc_total   = DBC_Autoload::total();
$dbc_count   = DBC_Autoload::count();
$dbc_largest = DBC_Autoload::largest( 25 );
$dbc_changed = DBC_Autoload::changed();
?>

<div class="dbc-panel">
	<h2><?php esc_html_e( 'Loaded on every single request', 'wpd-database-cleaner' ); ?></h2>

	<div class="dbc-summary">
		<div class="dbc-stat <?php echo $dbc_total > 1048576 ? 'dbc-stat--bad' : ''; ?>">
			<span class="n"><?php echo esc_html( size_format( $dbc_total ) ); ?></span>
			<span class="l"><?php esc_html_e( 'autoloaded', 'wpd-database-cleaner' ); ?></span>
		</div>
		<div class="dbc-stat">
			<span class="n"><?php echo esc_html( number_format_i18n( $dbc_count ) ); ?></span>
			<span class="l"><?php esc_html_e( 'options', 'wpd-database-cleaner' ); ?></span>
		</div>
	</div>

	<p>
		<?php esc_html_e( 'Every option marked as autoloaded is fetched, unserialised and held in memory on every request your site serves — front end, admin, AJAX and cron alike. It is one query, so it never appears in a slow query log, which is exactly why it grows unnoticed.', 'wpd-database-cleaner' ); ?>
	</p>
	<p>
		<?php esc_html_e( 'A plugin that stores a few megabytes of cached API response as an autoloaded option — and this is common — costs the site more than every revision in it. Under about 800 KB is unremarkable. Several megabytes is worth an afternoon.', 'wpd-database-cleaner' ); ?>
	</p>

	<div class="notice notice-info inline">
		<p>
			<strong><?php esc_html_e( 'Nothing on this screen deletes anything.', 'wpd-database-cleaner' ); ?></strong>
			<?php esc_html_e( 'Switching an option off leaves its value exactly where it is — it only stops being read on requests that never asked for it. Anything that needs it still gets it, one query later. Every change is listed below so it can be put straight back.', 'wpd-database-cleaner' ); ?>
		</p>
	</div>
</div>

<div class="dbc-panel">
	<h2><?php esc_html_e( 'The biggest ones', 'wpd-database-cleaner' ); ?></h2>

	<table class="widefat striped">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Option', 'wpd-database-cleaner' ); ?></th>
				<th><?php esc_html_e( 'Size', 'wpd-database-cleaner' ); ?></th>
				<th><?php esc_html_e( 'Action', 'wpd-database-cleaner' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $dbc_largest as $dbc_row ) : ?>
				<tr class="<?php echo $dbc_row['size'] >= DBC_Autoload::LARGE ? 'dbc-row--large' : ''; ?>">
					<td>
						<span class="dbc-mono"><?php echo esc_html( $dbc_row['name'] ); ?></span>
						<?php if ( '' !== $dbc_row['guess'] ) : ?>
							<p class="description"><?php echo esc_html( $dbc_row['guess'] ); ?></p>
						<?php endif; ?>
					</td>
					<td><?php echo esc_html( size_format( $dbc_row['size'] ) ); ?></td>
					<td>
						<?php if ( $dbc_row['protected'] ) : ?>
							<span class="dbc-badge"><?php esc_html_e( 'required', 'wpd-database-cleaner' ); ?></span>
						<?php else : ?>
							<?php
							DBC_Admin::button(
								'autoload_off',
								__( 'Stop autoloading', 'wpd-database-cleaner' ),
								array( 'option' => $dbc_row['name'] ),
								'button button-small'
							);
							?>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>

	<p class="description">
		<?php esc_html_e( 'Options WordPress reads before plugins load are marked "required" and are not offered. Switching one of those off would not slow the site down — it would break it on the next request.', 'wpd-database-cleaner' ); ?>
	</p>
</div>

<?php if ( $dbc_changed ) : ?>
	<div class="dbc-panel">
		<h2><?php esc_html_e( 'Changed by this plugin', 'wpd-database-cleaner' ); ?></h2>
		<p class="description"><?php esc_html_e( 'If something started behaving oddly after a change here, this is the list to work back through.', 'wpd-database-cleaner' ); ?></p>

		<table class="widefat striped">
			<tbody>
				<?php foreach ( $dbc_changed as $dbc_name => $dbc_when ) : ?>
					<tr>
						<td class="dbc-mono"><?php echo esc_html( $dbc_name ); ?></td>
						<td>
							<?php
							printf(
								/* translators: %s: human time difference. */
								esc_html__( '%s ago', 'wpd-database-cleaner' ),
								esc_html( human_time_diff( (int) $dbc_when ) )
							);
							?>
						</td>
						<td>
							<?php
							DBC_Admin::button(
								'autoload_on',
								__( 'Put it back', 'wpd-database-cleaner' ),
								array( 'option' => $dbc_name ),
								'button button-small'
							);
							?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
<?php endif; ?>

<?php
/**
 * What the last action did.
 *
 * @var array $report From DBC_Admin::take_report().
 *
 * @package Database_Cleaner
 */

defined( 'ABSPATH' ) || exit;

if ( ! $report ) {
	return;
}

if ( ! empty( $report['error'] ) ) :
	?>
	<div class="notice notice-error"><p><?php echo esc_html( $report['error'] ); ?></p></div>
	<?php
	return;
endif;

if ( ! empty( $report['dropped'] ) ) :
	?>
	<div class="notice notice-success">
		<p>
			<?php
			printf(
				/* translators: %s: table name. */
				esc_html__( 'Dropped %s.', 'wpd-database-cleaner' ),
				'<code>' . esc_html( $report['dropped'] ) . '</code>'
			);
			?>
		</p>
	</div>
	<?php
	return;
endif;

if ( ! empty( $report['autoload_off'] ) ) :
	?>
	<div class="notice notice-success">
		<p>
			<?php
			printf(
				/* translators: %s: option name. */
				esc_html__( '%s no longer loads on every request. Its value is untouched, and it can be put straight back below.', 'wpd-database-cleaner' ),
				'<code>' . esc_html( $report['autoload_off'] ) . '</code>'
			);
			?>
		</p>
	</div>
	<?php
	return;
endif;

if ( ! empty( $report['autoload_on'] ) ) :
	?>
	<div class="notice notice-success">
		<p>
			<?php
			printf(
				/* translators: %s: option name. */
				esc_html__( '%s is autoloading again.', 'wpd-database-cleaner' ),
				'<code>' . esc_html( $report['autoload_on'] ) . '</code>'
			);
			?>
		</p>
	</div>
	<?php
	return;
endif;

if ( isset( $report['optimize'] ) ) :
	$dbc_o = $report['optimize'];
	?>
	<div class="notice notice-success">
		<p>
			<?php
			printf(
				/* translators: 1: table count, 2: bytes reclaimed. */
				esc_html__( 'Optimised %1$d tables and reclaimed %2$s.', 'wpd-database-cleaner' ),
				count( $dbc_o['done'] ),
				esc_html( size_format( (int) $dbc_o['reclaimed'] ) )
			);
			?>
			<?php if ( 0 === (int) $dbc_o['reclaimed'] && $dbc_o['done'] ) : ?>
				<?php esc_html_e( 'Nothing was reclaimed, which is the normal outcome on InnoDB — it reuses that space itself rather than returning it to the filesystem.', 'wpd-database-cleaner' ); ?>
			<?php endif; ?>
		</p>
		<?php if ( $dbc_o['failed'] ) : ?>
			<p><?php esc_html_e( 'These were refused by the database:', 'wpd-database-cleaner' ); ?> <code><?php echo esc_html( implode( ', ', $dbc_o['failed'] ) ); ?></code></p>
		<?php endif; ?>
	</div>
	<?php
	return;
endif;

if ( isset( $report['single'] ) ) :
	$dbc_s = $report['single'];
	?>
	<div class="notice notice-success">
		<p>
			<?php
			printf(
				/* translators: 1: task name, 2: rows removed. */
				esc_html__( '%1$s: removed %2$s rows.', 'wpd-database-cleaner' ),
				esc_html( $dbc_s['label'] ),
				esc_html( number_format_i18n( (int) $dbc_s['removed'] ) )
			);
			?>
			<?php if ( ! $dbc_s['finished'] ) : ?>
				<strong>
					<?php
					printf(
						/* translators: %s: rows left. */
						esc_html__( '%s left — it stopped before your server did. Run it again to carry on.', 'wpd-database-cleaner' ),
						esc_html( number_format_i18n( (int) $dbc_s['remaining'] ) )
					);
					?>
				</strong>
			<?php endif; ?>
		</p>
	</div>
	<?php
	return;
endif;

if ( isset( $report['batch'] ) || isset( $report['network'] ) ) :
	$dbc_runs = isset( $report['network'] ) ? $report['network'] : array( 0 => $report['batch'] );
	$dbc_all  = 0;
	$dbc_more = false;

	foreach ( $dbc_runs as $dbc_run ) {
		$dbc_all += (int) $dbc_run['removed'];
		$dbc_more = $dbc_more || ! empty( $dbc_run['ran_out'] );
	}
	?>
	<div class="notice notice-success">
		<p>
			<strong>
				<?php
				printf(
					/* translators: %s: total rows removed. */
					esc_html__( 'Removed %s rows.', 'wpd-database-cleaner' ),
					esc_html( number_format_i18n( $dbc_all ) )
				);
				?>
			</strong>
			<?php if ( isset( $report['network'] ) ) : ?>
				<?php
				printf(
					/* translators: %d: site count. */
					esc_html__( 'Across %d sites.', 'wpd-database-cleaner' ),
					count( $dbc_runs )
				);
				?>
			<?php endif; ?>
			<?php if ( $dbc_more ) : ?>
				<?php esc_html_e( 'It ran out of time before finishing everything — press the button again to carry on where it stopped.', 'wpd-database-cleaner' ); ?>
			<?php endif; ?>
		</p>

		<?php foreach ( $dbc_runs as $dbc_run ) : ?>
			<?php if ( empty( $dbc_run['tasks'] ) ) : ?>
				<?php continue; ?>
			<?php endif; ?>
			<ul class="dbc-report">
				<?php foreach ( $dbc_run['tasks'] as $dbc_result ) : ?>
					<li>
						<?php echo esc_html( $dbc_result['label'] ); ?>:
						<?php echo esc_html( number_format_i18n( (int) $dbc_result['removed'] ) ); ?>
						<?php if ( ! $dbc_result['finished'] ) : ?>
							<em>
								<?php
								printf(
									/* translators: %s: rows left. */
									esc_html__( '(%s left)', 'wpd-database-cleaner' ),
									esc_html( number_format_i18n( (int) $dbc_result['remaining'] ) )
								);
								?>
							</em>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endforeach; ?>
	</div>
<?php endif; ?>

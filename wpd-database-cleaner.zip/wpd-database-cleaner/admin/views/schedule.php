<?php
/**
 * The scheduling screen.
 *
 * @var array $settings Settings.
 *
 * @package Database_Cleaner
 */

defined( 'ABSPATH' ) || exit;

$dbc_schedulable = DBC_Registry::schedulable();
$dbc_chosen      = (array) $settings['scheduled_tasks'];
$dbc_next        = wp_next_scheduled( DBC_Runner::CRON_HOOK );
?>

<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
	<input type="hidden" name="action" value="dbc_action" />
	<input type="hidden" name="do" value="save" />
	<?php wp_nonce_field( DBC_Admin::NONCE ); ?>

	<div class="dbc-panel">
		<h2><?php esc_html_e( 'Cleaning without being asked', 'wpd-database-cleaner' ); ?></h2>

		<p>
			<?php esc_html_e( 'Off until you turn it on. A plugin that starts deleting on a timer because it was activated has taken a decision that was not its to take.', 'wpd-database-cleaner' ); ?>
		</p>

		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><label for="dbc-schedule"><?php esc_html_e( 'How often', 'wpd-database-cleaner' ); ?></label></th>
				<td>
					<?php
					$dbc_choices = array(
						'off'     => __( 'Never — I will run it myself', 'wpd-database-cleaner' ),
						'daily'   => __( 'Daily', 'wpd-database-cleaner' ),
						'weekly'  => __( 'Weekly', 'wpd-database-cleaner' ),
						'monthly' => __( 'Monthly', 'wpd-database-cleaner' ),
					);
					?>
					<select name="schedule" id="dbc-schedule">
						<?php foreach ( $dbc_choices as $dbc_value => $dbc_label ) : ?>
							<option value="<?php echo esc_attr( $dbc_value ); ?>" <?php selected( $settings['schedule'], $dbc_value ); ?>>
								<?php echo esc_html( $dbc_label ); ?>
							</option>
						<?php endforeach; ?>
					</select>

					<?php if ( $dbc_next ) : ?>
						<p class="description">
							<?php
							printf(
								/* translators: %s: human time difference. */
								esc_html__( 'Next run in %s.', 'wpd-database-cleaner' ),
								esc_html( human_time_diff( (int) $dbc_next ) )
							);
							?>
						</p>
					<?php endif; ?>
				</td>
			</tr>
		</table>
	</div>

	<div class="dbc-panel">
		<h2><?php esc_html_e( 'What it may touch', 'wpd-database-cleaner' ); ?></h2>

		<p class="description">
			<?php esc_html_e( 'Only tasks that cannot lose recoverable data appear here. Anything holding something a person might want back — the trash, duplicate meta — is missing from this list on purpose, and can only be run by hand after you have looked at it.', 'wpd-database-cleaner' ); ?>
		</p>

		<?php foreach ( $dbc_schedulable as $dbc_task ) : ?>
			<p>
				<label>
					<input
						type="checkbox"
						name="scheduled_tasks[]"
						value="<?php echo esc_attr( $dbc_task->key() ); ?>"
						<?php checked( in_array( $dbc_task->key(), $dbc_chosen, true ) ); ?>
					/>
					<?php echo esc_html( $dbc_task->label() ); ?>
				</label>
			</p>
		<?php endforeach; ?>

		<p class="description">
			<?php esc_html_e( 'This list is checked again when the schedule fires, so a task later judged risky stops running unattended without anyone having to remember to untick it.', 'wpd-database-cleaner' ); ?>
		</p>
	</div>

	<div class="dbc-panel">
		<h2><?php esc_html_e( 'How much to keep', 'wpd-database-cleaner' ); ?></h2>

		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><label for="dbc-keep-revisions"><?php esc_html_e( 'Revisions per post', 'wpd-database-cleaner' ); ?></label></th>
				<td>
					<input type="number" min="0" max="50" class="small-text" id="dbc-keep-revisions" name="keep_revisions" value="<?php echo esc_attr( (string) $settings['keep_revisions'] ); ?>" />
					<p class="description">
						<?php esc_html_e( 'Revisions are the only undo an editor has after pasting over a page and saving it. Keeping two or three costs almost nothing. Zero means keep none.', 'wpd-database-cleaner' ); ?>
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="dbc-keep-actions"><?php esc_html_e( 'Scheduled action history', 'wpd-database-cleaner' ); ?></label></th>
				<td>
					<input type="number" min="1" max="365" class="small-text" id="dbc-keep-actions" name="keep_actions_days" value="<?php echo esc_attr( (string) $settings['keep_actions_days'] ); ?>" />
					<?php esc_html_e( 'days', 'wpd-database-cleaner' ); ?>
					<p class="description"><?php esc_html_e( 'Completed background jobs older than this can go. Anything pending or in progress is never touched, at any setting.', 'wpd-database-cleaner' ); ?></p>
				</td>
			</tr>
		</table>
	</div>

	<?php submit_button( __( 'Save changes', 'wpd-database-cleaner' ) ); ?>
</form>

<div class="dbc-panel">
	<h2><?php esc_html_e( 'A note on WP-Cron', 'wpd-database-cleaner' ); ?></h2>
	<p class="description">
		<?php esc_html_e( 'WordPress schedules run when somebody visits the site, not at a fixed time. On a quiet site a "daily" clean may happen every few days; on a busy one it happens close to on time. If that matters, a real cron job calling wp-cron.php is the fix — and it is a hosting setting rather than a plugin one.', 'wpd-database-cleaner' ); ?>
	</p>
	<?php if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) : ?>
		<p class="description">
			<strong><?php esc_html_e( 'DISABLE_WP_CRON is set on this site.', 'wpd-database-cleaner' ); ?></strong>
			<?php esc_html_e( 'Scheduled cleaning will only happen if a real cron job is calling wp-cron.php. If one is not, nothing here will ever run.', 'wpd-database-cleaner' ); ?>
		</p>
	<?php endif; ?>
</div>

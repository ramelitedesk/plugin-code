<?php
/**
 * The tables screen.
 *
 * @package Database_Cleaner
 */

defined( 'ABSPATH' ) || exit;

$dbc_tables    = DBC_Tables::all();
$dbc_unclaimed = DBC_Tables::unclaimed();
$dbc_overhead  = DBC_Tables::total_overhead();
$dbc_innodb    = false;

foreach ( $dbc_tables as $dbc_row ) {
	if ( 0 === strcasecmp( 'InnoDB', $dbc_row['engine'] ) ) {
		$dbc_innodb = true;
		break;
	}
}
?>

<div class="dbc-panel">
	<h2><?php esc_html_e( 'Tables nothing seems to own', 'wpd-database-cleaner' ); ?></h2>

	<div class="notice notice-error inline">
		<p>
			<strong><?php esc_html_e( '"Unused" here is a guess, and a weak one.', 'wpd-database-cleaner' ); ?></strong>
			<?php esc_html_e( 'There is no register of which plugin owns which table. The only evidence available is a name that looks like a plugin slug — and plugins are free to name their tables anything at all.', 'wpd-database-cleaner' ); ?>
		</p>
		<p>
			<?php esc_html_e( 'A table can look abandoned and hold the only copy of something irreplaceable: the order history of a shop plugin that was switched off for a fortnight, a contact form\'s submissions, a membership list. This screen is good at showing you that 400 MB of a 460 MB database belongs to three tables. Deciding they can go is still yours.', 'wpd-database-cleaner' ); ?>
		</p>
	</div>

	<?php if ( ! $dbc_unclaimed ) : ?>
		<p class="dbc-clean"><?php esc_html_e( 'Every table here belongs to WordPress or to a plugin that is currently active.', 'wpd-database-cleaner' ); ?></p>
	<?php else : ?>
		<table class="widefat striped dbc-tables">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Table', 'wpd-database-cleaner' ); ?></th>
					<th><?php esc_html_e( 'Rows', 'wpd-database-cleaner' ); ?></th>
					<th><?php esc_html_e( 'Size', 'wpd-database-cleaner' ); ?></th>
					<th><?php esc_html_e( 'Drop it', 'wpd-database-cleaner' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $dbc_unclaimed as $dbc_row ) : ?>
					<tr>
						<td class="dbc-mono"><?php echo esc_html( $dbc_row['name'] ); ?></td>
						<td><?php echo esc_html( number_format_i18n( $dbc_row['rows'] ) ); ?></td>
						<td><?php echo esc_html( size_format( $dbc_row['total'] ) ); ?></td>
						<td>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="dbc-drop">
								<input type="hidden" name="action" value="dbc_action" />
								<input type="hidden" name="do" value="drop_table" />
								<input type="hidden" name="table" value="<?php echo esc_attr( $dbc_row['name'] ); ?>" />
								<?php wp_nonce_field( DBC_Admin::NONCE ); ?>
								<input
									type="text"
									name="confirm"
									class="dbc-confirm"
									autocomplete="off"
									spellcheck="false"
									placeholder="<?php esc_attr_e( 'type the name', 'wpd-database-cleaner' ); ?>"
									aria-label="<?php
									printf(
										/* translators: %s: table name. */
										esc_attr__( 'Type %s to confirm dropping it', 'wpd-database-cleaner' ),
										esc_attr( $dbc_row['name'] )
									);
									?>"
								/>
								<button type="submit" class="button button-link-delete"><?php esc_html_e( 'Drop', 'wpd-database-cleaner' ); ?></button>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<p class="description">
			<?php esc_html_e( 'Typing the name is not decoration. It is a different act from clicking a button next to it, and the difference is the moment of attention this needs. Dropping is one table at a time, never in bulk, and never automatically.', 'wpd-database-cleaner' ); ?>
		</p>
	<?php endif; ?>
</div>

<div class="dbc-panel">
	<h2><?php esc_html_e( 'Reclaiming space', 'wpd-database-cleaner' ); ?></h2>

	<p>
		<?php
		printf(
			/* translators: 1: overhead size, 2: total database size. */
			esc_html__( '%1$s of reclaimable overhead across a %2$s database.', 'wpd-database-cleaner' ),
			esc_html( size_format( $dbc_overhead ) ),
			esc_html( size_format( DBC_Tables::total_size() ) )
		);
		?>
	</p>

	<?php if ( $dbc_innodb ) : ?>
		<div class="notice notice-warning inline">
			<p>
				<strong><?php esc_html_e( 'This database uses InnoDB, where OPTIMIZE means something different.', 'wpd-database-cleaner' ); ?></strong>
				<?php esc_html_e( 'On MyISAM it reclaims the space deleted rows left behind. On InnoDB it is a full table rebuild that locks the table while it runs and frequently reclaims nothing, because InnoDB reuses that space itself.', 'wpd-database-cleaner' ); ?>
			</p>
			<p>
				<?php esc_html_e( 'On a large orders or postmeta table that lock can last minutes, during which the site is effectively down. If you run this, run it when nobody is using the site.', 'wpd-database-cleaner' ); ?>
			</p>
		</div>
	<?php endif; ?>

	<p>
		<?php
		DBC_Admin::button(
			'optimize',
			__( 'Optimise tables with overhead', 'wpd-database-cleaner' ),
			array(),
			'button',
			__( 'Optimising…', 'wpd-database-cleaner' )
		);
		?>
	</p>
</div>

<div class="dbc-panel">
	<h2><?php esc_html_e( 'Everything, by size', 'wpd-database-cleaner' ); ?></h2>

	<table class="widefat striped dbc-tables">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Table', 'wpd-database-cleaner' ); ?></th>
				<th><?php esc_html_e( 'Rows', 'wpd-database-cleaner' ); ?></th>
				<th><?php esc_html_e( 'Data', 'wpd-database-cleaner' ); ?></th>
				<th><?php esc_html_e( 'Index', 'wpd-database-cleaner' ); ?></th>
				<th><?php esc_html_e( 'Overhead', 'wpd-database-cleaner' ); ?></th>
				<th><?php esc_html_e( 'Engine', 'wpd-database-cleaner' ); ?></th>
				<th><?php esc_html_e( 'Belongs to', 'wpd-database-cleaner' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $dbc_tables as $dbc_row ) : ?>
				<tr>
					<td class="dbc-mono"><?php echo esc_html( $dbc_row['name'] ); ?></td>
					<td><?php echo esc_html( number_format_i18n( $dbc_row['rows'] ) ); ?></td>
					<td><?php echo esc_html( size_format( $dbc_row['data'] ) ); ?></td>
					<td><?php echo esc_html( size_format( $dbc_row['index'] ) ); ?></td>
					<td><?php echo $dbc_row['overhead'] > 0 ? esc_html( size_format( $dbc_row['overhead'] ) ) : '—'; ?></td>
					<td><?php echo esc_html( $dbc_row['engine'] ); ?></td>
					<td>
						<?php if ( $dbc_row['core'] ) : ?>
							<span class="dbc-badge"><?php esc_html_e( 'WordPress', 'wpd-database-cleaner' ); ?></span>
						<?php elseif ( '' !== $dbc_row['claimed'] ) : ?>
							<?php echo esc_html( $dbc_row['claimed'] ); ?>
							<span class="dbc-guess"><?php esc_html_e( '(guessed from the name)', 'wpd-database-cleaner' ); ?></span>
						<?php elseif ( ! $dbc_row['ours'] ) : ?>
							<span class="dbc-badge"><?php esc_html_e( 'another install', 'wpd-database-cleaner' ); ?></span>
						<?php else : ?>
							<span class="dbc-badge dbc-badge--consider"><?php esc_html_e( 'nothing active claims it', 'wpd-database-cleaner' ); ?></span>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>

	<p class="description">
		<?php esc_html_e( 'Tables without this install\'s prefix belong to something else sharing the database. They are listed so the size figures make sense, and they cannot be touched from here.', 'wpd-database-cleaner' ); ?>
	</p>
</div>

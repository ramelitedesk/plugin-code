# WPD SEO &amp; Performance Suite

A drop-in WordPress plugin that handles technical SEO and Core Web Vitals on **any** site — hand-coded themes and page-builder sites alike. Detection is automatic: Elementor, WPBakery, Bricks, Beaver Builder, Divi, Oxygen and the block editor each get their own adapter, and every optimisation switches itself off inside a builder's editor.

---

## Folder structure

```
seo/
├── wpd-seo.php                  Plugin bootstrap: constants, module registry, load order
├── uninstall.php                Cleanup on delete
├── README.md                    This file
├── INSTALL.md                   Step-by-step install + the 96–100 checklist
│
├── includes/                    SEO layer (what search engines read)
│   ├── helpers.php              Shared functions + the global wpd_should_optimize() gate
│   ├── class-wpd-options.php    Settings storage and defaults
│   ├── class-wpd-context.php    Page type, canonical URL, indexability, hero image
│   ├── class-wpd-meta.php       <title>, description, canonical, robots, OG, Twitter
│   ├── class-wpd-schema.php     JSON-LD @graph (Organization, WebSite, WebPage, Article, Breadcrumb)
│   ├── class-wpd-sitemap.php    Hardens the core XML sitemap (lastmod, noindex exclusion)
│   ├── class-wpd-robots.php     Virtual robots.txt
│   └── class-wpd-breadcrumbs.php  Trail data + [wpd_breadcrumbs] + template tag
│
├── performance/                 Core Web Vitals layer
│   ├── class-wpd-perf.php       Core bloat removal, heartbeat, head cleanup
│   ├── class-wpd-assets.php     defer JS, delay third-party JS, async CSS, critical CSS
│   ├── class-wpd-images.php     LCP preload + fetchpriority, lazy loading, CLS dimensions
│   ├── class-wpd-fonts.php      Font preload, preconnect, font-display: swap
│   ├── class-wpd-html.php       Output buffer + conservative HTML minifier
│   └── class-wpd-headers.php    Cache-Control, security headers
│
├── builders/                    Page-builder sites
│   ├── class-wpd-builder-base.php     The adapter contract
│   ├── class-wpd-builder-detect.php   Registry, detection, protected-handle aggregation
│   ├── class-wpd-builder-elementor.php
│   ├── class-wpd-builder-wpbakery.php
│   ├── class-wpd-builder-bricks.php
│   ├── class-wpd-builder-beaver.php
│   ├── class-wpd-builder-divi.php
│   ├── class-wpd-builder-oxygen.php
│   ├── class-wpd-builder-gutenberg.php
│   └── builder-recipes.php            Opt-in per-builder tuning snippets (not auto-loaded)
│
├── woocommerce/                 Store sites (loads only when WooCommerce is active)
│   ├── class-wpd-woo.php          Safety gate: transactional pages, protected handles, no-store headers
│   ├── class-wpd-woo-seo.php      noindex cart/checkout/filters, product descriptions, product LCP image
│   ├── class-wpd-woo-schema.php   Product / Offer / AggregateOffer / Review / ItemList JSON-LD
│   └── class-wpd-woo-perf.php     Conditional store assets, cart-fragments control, gallery scripts
│
├── custom/                      Hand-coded / custom themes
│   ├── class-wpd-custom-theme.php  Fills the gaps custom themes commonly leave
│   └── theme-snippets.php          Copy-paste functions.php snippets (not auto-loaded)
│
├── admin/
│   ├── class-wpd-admin.php      Settings screen, per-post SEO box, health checks
│   └── views/settings-page.php
│
├── assets/css/admin.css
│
└── config/                      Server-level configuration (outside PHP's reach)
    ├── htaccess-rules.conf      Apache: compression, immutable caching, webp, headers
    ├── nginx-rules.conf         Nginx equivalent
    ├── wp-config-snippets.php   Constants worth setting on every site
    └── mu-loader.php            Optional must-use loader
```

**Why the split.** `includes/` is what search engines read, `performance/` is what browsers feel, `builders/` is the compatibility layer that keeps the two from breaking a builder's markup, `custom/` is the set of fixes only a hand-coded theme needs, and `woocommerce/` is the store layer. You can delete any one folder's module from the registry in `wpd-seo.php` and the rest keeps working.

---

## WooCommerce

The store layer loads only when WooCommerce is active, and its first job is to *stop* optimisation, not add it.

- **Cart, checkout, my-account and every WC endpoint are excluded from everything** — no HTML buffering, no minification, no shared-cache headers. They are sent `no-store`. The same applies site-wide once the visitor has items in the cart, because the mini-cart makes every page personalised.
- **The entire checkout script stack is protected** from defer/delay, including Stripe and PayPal.
- **`Product` schema** with `Offer` (or `AggregateOffer` with a real low/high range for variable products), `availability`, `sku`, brand from whichever brand taxonomy the site uses, `aggregateRating` **only when real reviews exist**, and up to five reviews. WooCommerce's own disconnected Product JSON-LD is switched off so there is exactly one product entity per page.
- **`noindex`** on cart/checkout/account and on filtered or sorted archive URLs (`?orderby=`, `?min_price=`, `?filter_*`, `?add-to-cart=`) — the usual source of thousands of junk indexed URLs.
- **Cart fragments** — the uncached admin-ajax request WooCommerce fires on *every* page view — disabled off cart/checkout. If your header shows a live cart count, turn that toggle off or use `add_filter( 'wpd_seo_woo_keep_fragments', '__return_true' )`.
- **Store CSS/JS loads only where store UI appears**, and the ~90 KB zoom/flexslider/PhotoSwipe gallery stack only on product pages.
- **The main product image** gets `fetchpriority=high` and eager loading — it is the LCP element on essentially every product page.

WooCommerce filters: `wpd_seo_woo_is_transactional`, `wpd_seo_woo_is_woo_page`, `wpd_seo_woo_keep_fragments`, `wpd_seo_woo_product_schema`, `wpd_seo_woo_brand_taxonomies`, `wpd_seo_woo_brand_name`, `wpd_seo_woo_styles`, `wpd_seo_woo_trim_admin`.

---

## Install

1. Copy the whole `seo/` folder to `wp-content/plugins/seo/`.
2. Activate **WPD SEO &amp; Performance Suite** in Plugins.
3. Open **SEO &amp; Speed** in the admin menu, fill in the organisation fields, and read the Site health panel at the top — it flags the things no plugin can fix for you (permalinks, HTTPS, a physical robots.txt shadowing the virtual one).
4. Apply the matching file from `config/` at the server level. **This step is not optional if you want 96+**: PHP cannot set cache headers or compression for static files.

See [INSTALL.md](INSTALL.md) for the full checklist.

---

## Playing well with others

- **An existing SEO plugin** (Yoast, Rank Math, AIOSEO, SEOPress, Slim SEO) — the meta, schema and sitemap modules disable themselves automatically. The performance modules keep running. Nothing is duplicated.
- **A caching plugin** (WP Rocket, LiteSpeed, W3TC) — keep it. Turn *off* this plugin's overlapping toggles (defer JS, minify HTML, lazy load) so one layer owns each job. Doing both is the usual cause of "the site broke after I installed a speed plugin".
- **A builder's own optimiser** (Elementor experiments, Divi dynamic CSS) — leave them on; the recipes in `builders/builder-recipes.php` enable them programmatically.

---

## Everything is filterable

Turn off any module:

```php
add_filter( 'wpd_seo_module_html', '__return_false' );   // no HTML minification
add_filter( 'wpd_seo_module_schema', '__return_false' ); // no JSON-LD
```

Never optimise a particular page:

```php
add_filter( 'wpd_seo_should_optimize', function ( $ok ) {
	return is_page( 'checkout' ) ? false : $ok;
} );
```

Protect a script the defer logic would otherwise touch:

```php
add_filter( 'wpd_seo_protected_handles', function ( $handles ) {
	$handles[] = 'my-slider';
	return $handles;
} );
```

Override the LCP image, the title, or the description:

```php
add_filter( 'wpd_seo_image_id', fn( $id ) => is_front_page() ? 42 : $id );
add_filter( 'wpd_seo_title', fn( $title ) => $title );
add_filter( 'wpd_seo_description', fn( $desc ) => $desc );
```

Add your own builder:

```php
add_filter( 'wpd_seo_builder_adapters', function ( $adapters ) {
	$adapters['mybuilder'] = new My_Builder_Adapter(); // extends WPD_Builder_Base
	return $adapters;
} );
```

### Full filter reference

| Filter | Purpose |
| --- | --- |
| `wpd_seo_module_{key}` | Enable/disable a module (`meta`, `schema`, `sitemap`, `robots`, `breadcrumbs`, `perf`, `assets`, `images`, `fonts`, `html`, `headers`, `custom`) |
| `wpd_seo_should_optimize` | Master gate for every front-end optimisation |
| `wpd_seo_optimize_logged_in` | Optimise for logged-in users too (default `false`) |
| `wpd_seo_title` / `wpd_seo_description` / `wpd_seo_canonical` | Override the computed values |
| `wpd_seo_is_indexable` | Force index/noindex per view |
| `wpd_seo_og_tags` / `wpd_seo_twitter_tags` | Add or remove social tags |
| `wpd_seo_schema_graph` | Add, edit or remove JSON-LD nodes |
| `wpd_seo_schema_article_type` | e.g. return `NewsArticle` or `BlogPosting` |
| `wpd_seo_sitemap_post_types` / `wpd_seo_sitemap_posts_args` | Control sitemap contents |
| `wpd_seo_robots_rules` | Replace the robots.txt directives |
| `wpd_seo_protected_handles` / `wpd_seo_protected_styles` | Never touch these handles |
| `wpd_seo_defer_script` | Per-handle defer decision |
| `wpd_seo_delay_scripts` / `wpd_seo_delay_timeout` | Which third-party scripts to delay, and the fallback timeout |
| `wpd_seo_async_styles` | Style handles to load non-blocking |
| `wpd_seo_critical_css` | Return critical CSS from a file instead of the settings field |
| `wpd_seo_preload_fonts` / `wpd_seo_preconnect` | Font preloads and early connections |
| `wpd_seo_image_id` | The LCP / social image |
| `wpd_seo_html` | Post-process the finished page HTML |
| `wpd_seo_html_cache_ttl` / `wpd_seo_extra_headers` | Response headers |
| `wpd_seo_builder_adapters` | Register a custom builder adapter |
| `wpd_seo_is_builder_editor` | Force editor detection on/off |

---

## Template tags

```php
<?php wpd_breadcrumbs(); ?>              // or the [wpd_breadcrumbs] shortcode
<?php if ( wpd_should_optimize() ) : ?>  // true only on optimisable front-end views
```

---

## Requirements

WordPress 5.8+, PHP 7.4+. No build step, no dependencies, no external services.

<?php
/**
 * Runs when the plugin is deleted (not merely deactivated).
 *
 * @package WPD_SEO
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'wpd_seo_settings' );

// Per-post overrides are the user's content, so they are only removed when
// explicitly requested via this constant in wp-config.php.
if ( defined( 'WPD_SEO_PURGE_POST_META' ) && WPD_SEO_PURGE_POST_META ) {
	foreach ( array( '_wpd_title', '_wpd_description', '_wpd_noindex' ) as $key ) {
		delete_post_meta_by_key( $key );
	}
}

# Install &amp; the 96–100 checklist

Lighthouse **SEO** reaching 100 is straightforward and this plugin does almost all of it. Lighthouse **Performance** at 96+ is a whole-stack result: the plugin fixes the WordPress layer, but hosting, images and third-party scripts are yours to control. This file is the order to do it in.

---

## 1. Install the plugin

```
wp-content/plugins/seo/          ← copy the folder here
```

Activate **WPD SEO &amp; Performance Suite**, then open **SEO &amp; Speed**.

If you would rather the client could not deactivate it:

```
cp config/mu-loader.php wp-content/mu-plugins/wpd-seo-loader.php
```

…and leave the plugin itself *deactivated* in the Plugins screen (mu-plugins load it directly; activating it as well loads it twice).

## 2. Fill in the settings

| Field | Why it matters |
| --- | --- |
| Organisation name + logo | Schema `Organization`, and the fallback social image |
| Social profile URLs | Schema `sameAs` — helps entity resolution |
| Preload fonts | The two woff2 faces used above the fold. Two is the sweet spot; four is the hard cap |
| Preconnect origins | Your font/CDN origins only |
| Critical CSS | Above-the-fold CSS, inlined. The single biggest FCP/LCP lever on a slow theme |

Leave **Delay third-party JS** off until you have tested the site with it on — it is the biggest TBT win available and also the most likely thing to break a chat widget.

## 3. Apply the server config — do not skip this

PHP cannot set headers for `.css`, `.js`, or images. Without this step, "Serve static assets with an efficient cache policy" and "Enable text compression" stay red no matter what the plugin does.

- **Apache / cPanel / shared hosting** — paste `config/htaccess-rules.conf` above `# BEGIN WordPress` in the site root `.htaccess`.
- **Nginx / VPS** — include `config/nginx-rules.conf` in the `server { }` block, move the `map` directive into `http { }`, then `nginx -t && systemctl reload nginx`.
- **Cloudflare / CDN in front** — set the same cache rules at the edge instead; leave Auto Minify off (it double-minifies what this plugin already handled).

Optionally apply `config/wp-config-snippets.php` to `wp-config.php`.

## 4. Verify

```bash
curl -sI https://example.com | grep -i 'cache-control\|content-encoding'
curl -s  https://example.com/robots.txt
curl -s  https://example.com/wp-sitemap.xml | head -20
```

Then run Lighthouse **in an incognito window** — extensions and a logged-in admin bar both cost real points, and the plugin deliberately skips optimisation for logged-in users.

---

## What the plugin handles for you

**SEO (this should reach 100 on its own)**

- Unique `<title>` and meta description on every view, per-post overrides in the editor
- Paged-aware `rel=canonical`, `rel=prev/next`
- `noindex` for search results, attachments, private and password-protected posts
- Valid `robots.txt` with the sitemap declared
- XML sitemap with `lastmod`, no user sitemap, no empty terms, noindex posts excluded
- JSON-LD `@graph`: Organization → WebSite → WebPage → Article → BreadcrumbList
- Open Graph + Twitter Card tags
- `lang` on `<html>`, viewport meta, `rel=noopener` on `target=_blank`

**Performance**

- LCP image preloaded with `fetchpriority=high`, never lazy-loaded
- Everything below the fold lazy + `decoding=async`; iframes lazy
- Missing `width`/`height` filled in from attachment metadata (CLS)
- `defer` on non-critical scripts; builder bundles excluded automatically
- Optional delay-until-interaction for analytics and pixels
- Emoji script, oEmbed script, Dashicons, jQuery Migrate, block CSS removed when unused
- Critical CSS inlined; other stylesheets can be made non-blocking per handle
- Fonts preloaded and forced to `font-display: swap`
- Conservative HTML minification (never touches `pre`, `textarea`, `script`, `style`, `code`)
- Front-end heartbeat off, admin heartbeat throttled to 60s

---

**WooCommerce (only when the store is active)**

- Cart/checkout/account/endpoints excluded from all optimisation and sent `no-store`; same once the cart is non-empty
- Checkout, Stripe and PayPal scripts never deferred or delayed
- `Product` + `Offer`/`AggregateOffer` + `Review` JSON-LD, replacing Woo's disconnected version
- `noindex` on cart/checkout/account and on `?orderby` / `?filter_*` / `?add-to-cart` archive permutations
- Cart-fragments AJAX disabled off cart/checkout; store CSS/JS loaded only where store UI appears
- Main product image marked as the LCP element

After enabling store mode, test one full purchase end to end — add to cart, apply a coupon, check out with a real gateway. If the cart count in your header stops updating, that is the cart-fragments toggle; turn it off.

---

## What the plugin cannot do — the remaining gap to 96+

These are, in practice, the whole difference between 80 and 98:

1. **Hosting / TTFB.** Target TTFB under 200 ms. Shared hosting on PHP 7.4 with no object cache will cap your score no matter what else you do. Use PHP 8.1+, enable OPcache, add a page cache, and put a CDN in front.
2. **Image weight.** Convert to WebP/AVIF and serve the *displayed* size, not a 4000 px original scaled by CSS. This is usually the largest single number in the "Opportunities" list.
3. **Third-party scripts.** Every chat widget, heatmap and pixel is main-thread time you do not control. Audit them, delete what nobody reads, and delay the rest.
4. **Theme / builder weight.** A page with 40 Elementor sections and six sliders will not hit 96 on mobile. Reduce the section count above the fold; the recipes in `builders/builder-recipes.php` help with the icon-font and Swiper bloat.
5. **Fonts.** Self-host, subset to the characters you use, two weights maximum.

Run PageSpeed Insights and work the Opportunities list top-down. The plugin has already removed everything in that list that lives in WordPress itself.

---

## Rollback

Every optimisation is a toggle in the settings screen or a one-line filter. If something breaks:

```php
// Turn everything off without deactivating the plugin.
add_filter( 'wpd_seo_should_optimize', '__return_false' );
```

Then re-enable module by module to find the culprit. Most conflicts come from **defer JS** (a script that expects to run synchronously) or **minify HTML** (markup that depends on whitespace) — try those two first.

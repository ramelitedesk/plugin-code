<?php
/**
 * Drop-in snippets for hand-coded themes.
 *
 * This file is NOT loaded by the plugin. Copy the pieces you want into your
 * theme's functions.php (or a child theme), or require the whole file:
 *
 *     require_once get_stylesheet_directory() . '/inc/theme-snippets.php';
 *
 * Every snippet is standalone and namespaced with the `mytheme_` prefix —
 * rename it to your theme's prefix before shipping.
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

/* -------------------------------------------------------------------------
 * 1. Theme supports that Lighthouse / Search Console actually grade.
 * ---------------------------------------------------------------------- */

add_action(
	'after_setup_theme',
	function () {
		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'responsive-embeds' );
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );

		// One hero size, cropped, so the LCP image is never oversized.
		add_image_size( 'mytheme-hero', 1600, 900, true );
		add_image_size( 'mytheme-card', 800, 600, true );
	}
);

/* -------------------------------------------------------------------------
 * 2. Enqueue with versioning tied to file mtime — long cache headers become
 *    safe because the URL changes whenever the file does.
 * ---------------------------------------------------------------------- */

add_action(
	'wp_enqueue_scripts',
	function () {
		$dir = get_stylesheet_directory();
		$uri = get_stylesheet_directory_uri();

		$css = '/assets/css/main.css';
		if ( file_exists( $dir . $css ) ) {
			wp_enqueue_style( 'mytheme', $uri . $css, array(), (string) filemtime( $dir . $css ) );
		}

		$js = '/assets/js/main.js';
		if ( file_exists( $dir . $js ) ) {
			// in_footer + defer keeps JS off the critical path entirely.
			wp_enqueue_script( 'mytheme', $uri . $js, array(), (string) filemtime( $dir . $js ), true );
			wp_script_add_data( 'mytheme', 'strategy', 'defer' );
		}

		// Comment-reply only matters once a visitor clicks "reply".
		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}
	}
);

/* -------------------------------------------------------------------------
 * 3. Inline the critical CSS, load the rest asynchronously.
 *    Generate critical.css with any tool (e.g. `critical`, penthouse) and drop
 *    it at assets/css/critical.css.
 * ---------------------------------------------------------------------- */

add_action(
	'wp_head',
	function () {
		$file = get_stylesheet_directory() . '/assets/css/critical.css';
		if ( ! file_exists( $file ) ) {
			return;
		}
		echo '<style id="mytheme-critical">' . file_get_contents( $file ) . '</style>' . "\n"; // phpcs:ignore
	},
	2
);

add_filter(
	'wpd_seo_async_styles',
	function ( $handles ) {
		// Only safe once critical CSS above covers the fold.
		$handles[] = 'mytheme';
		return $handles;
	}
);

/* -------------------------------------------------------------------------
 * 4. Preload the hero image for the current view (LCP).
 *    WPD_Images already does this from the featured image; this shows how to
 *    override it when your hero comes from a custom field.
 * ---------------------------------------------------------------------- */

add_filter(
	'wpd_seo_image_id',
	function ( $id, $context ) {
		if ( is_front_page() ) {
			$custom = (int) get_theme_mod( 'mytheme_hero_image_id' );
			if ( $custom ) {
				return $custom;
			}
		}
		return $id;
	},
	10,
	2
);

/* -------------------------------------------------------------------------
 * 5. Self-host your fonts, preload the two faces used above the fold.
 * ---------------------------------------------------------------------- */

add_filter(
	'wpd_seo_preload_fonts',
	function ( $fonts ) {
		$uri = get_stylesheet_directory_uri();
		return array_merge(
			$fonts,
			array(
				$uri . '/assets/fonts/inter-regular.woff2',
				$uri . '/assets/fonts/inter-semibold.woff2',
			)
		);
	}
);

/* -------------------------------------------------------------------------
 * 6. Template tags to call from header.php / single.php.
 * ---------------------------------------------------------------------- */

if ( ! function_exists( 'mytheme_skip_link' ) ) {
	/**
	 * Print an accessible skip link. Call first thing after <body>.
	 */
	function mytheme_skip_link() {
		printf(
			'<a class="skip-link screen-reader-text" href="#main">%s</a>',
			esc_html__( 'Skip to content', 'mytheme' )
		);
	}
}

if ( ! function_exists( 'mytheme_hero_image' ) ) {
	/**
	 * Render the LCP image with the right priority hints.
	 *
	 * @param int    $attachment_id Attachment ID.
	 * @param string $size          Image size.
	 */
	function mytheme_hero_image( $attachment_id, $size = 'mytheme-hero' ) {
		if ( ! $attachment_id ) {
			return;
		}
		echo wp_get_attachment_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			(int) $attachment_id,
			$size,
			false,
			array(
				'loading'       => 'eager',
				'fetchpriority' => 'high',
				'decoding'      => 'sync',
				'class'         => 'hero__image',
			)
		);
	}
}

if ( ! function_exists( 'mytheme_breadcrumbs' ) ) {
	/**
	 * Thin wrapper so templates do not depend on the plugin being active.
	 */
	function mytheme_breadcrumbs() {
		if ( function_exists( 'wpd_breadcrumbs' ) ) {
			wpd_breadcrumbs();
		}
	}
}

/* -------------------------------------------------------------------------
 * 7. Trim the query-string cruft that splits your cache.
 * ---------------------------------------------------------------------- */

add_filter(
	'script_loader_src',
	'mytheme_strip_default_ver',
	15
);
add_filter(
	'style_loader_src',
	'mytheme_strip_default_ver',
	15
);

/**
 * Drop ?ver=<wp-version> from core asset URLs — it leaks the WP version and
 * adds nothing, while file-mtime versions above stay intact.
 *
 * @param string $src Asset URL.
 * @return string
 */
function mytheme_strip_default_ver( $src ) {
	global $wp_version;
	if ( $src && false !== strpos( $src, 'ver=' . $wp_version ) ) {
		$src = remove_query_arg( 'ver', $src );
	}
	return $src;
}

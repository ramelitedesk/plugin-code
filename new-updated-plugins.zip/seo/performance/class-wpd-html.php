<?php
/**
 * Whole-page output buffer: conservative HTML minification plus the
 * `wpd_seo_html` filter every other module can hook to post-process markup
 * regardless of which builder produced it.
 *
 * The minifier is deliberately timid — it never touches pre, textarea, script
 * or style bodies, because "smart" HTML minifiers are the number one cause of
 * mysterious layout breakage on builder sites.
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

class WPD_Html {

	/** @var WPD_Html|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'template_redirect', array( $this, 'start_buffer' ), 1 );
	}

	public function start_buffer() {
		if ( ! wpd_should_optimize() ) {
			return;
		}
		if ( ! apply_filters( 'wpd_seo_buffer_output', true ) ) {
			return;
		}
		ob_start( array( $this, 'process' ) );
	}

	/**
	 * @param string $html Full page HTML.
	 * @return string
	 */
	public function process( $html ) {
		if ( '' === trim( (string) $html ) ) {
			return $html;
		}
		// Only touch real HTML documents (skip XML sitemaps, JSON, feeds).
		if ( false === stripos( $html, '</html>' ) ) {
			return $html;
		}

		/**
		 * Post-process the finished page.
		 *
		 * @param string $html Page HTML.
		 */
		$html = (string) apply_filters( 'wpd_seo_html', $html );

		if ( WPD_Options::enabled( 'minify_html' ) ) {
			$before = strlen( $html );
			$html   = $this->minify( $html );
			$after  = strlen( $html );

			// The report was already printed at wp_footer, so append the one
			// number that can only be known after minification runs.
			if ( class_exists( 'WPD_Debug' ) && WPD_Debug::is_enabled() && $before > 0 ) {
				$html .= sprintf(
					"\n<!-- WPD minify: %s → %s (-%d%%) -->\n",
					size_format( $before ),
					size_format( $after ),
					round( ( 1 - ( $after / $before ) ) * 100 )
				);
			}
		}

		return $html;
	}

	/**
	 * @param string $html Page HTML.
	 * @return string
	 */
	private function minify( $html ) {
		$original  = $html;
		$protected = array();

		// Stash anything whitespace-sensitive.
		$stashed = preg_replace_callback(
			'#<(pre|textarea|script|style|code)\b[^>]*>.*?</\1>#is',
			function ( $m ) use ( &$protected ) {
				$key               = '<!--wpd-keep-' . count( $protected ) . '-->';
				$protected[ $key ] = $m[0];
				return $key;
			},
			$html
		);

		// If stashing failed there is no safe way to continue: unstashed
		// script/style bodies would have their whitespace collapsed.
		if ( null === $stashed || PREG_NO_ERROR !== preg_last_error() ) {
			return $original;
		}
		$html = $stashed;

		/*
		 * Drop comments, keeping conditional comments and our own markers.
		 *
		 * Matched with a possessive-style negated class rather than a lazy
		 * tempered dot: "(?:(?!-->).)*" backtracks catastrophically on a large
		 * page and blows pcre.backtrack_limit, which returns null — i.e. a
		 * blank page. [^-]*+(?:-(?!->)[^-]*)*+ cannot backtrack at all.
		 */
		$html = wpd_preg_replace(
			'/<!--(?!\s*(?:\[if|<!|wpd-keep-|>))[^-]*+(?:-(?!->)[^-]*+)*+-->/',
			'',
			$html
		);

		// Collapse runs of whitespace and inter-tag whitespace.
		$html = wpd_preg_replace( '/\s{2,}/u', ' ', $html );
		$html = wpd_preg_replace( '/>\s+</', '><', $html );

		foreach ( $protected as $key => $snippet ) {
			$html = str_replace( $key, $snippet, $html );
		}

		// Last safety net: never return something that lost the document.
		if ( '' === trim( $html ) || false === stripos( $html, '</html>' ) ) {
			return $original;
		}

		return $html;
	}
}

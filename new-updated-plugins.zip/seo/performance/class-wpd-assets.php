<?php
/**
 * Script strategy: defer everything that is safe to defer, and (optionally)
 * delay third-party scripts until the first user interaction — the single
 * biggest TBT win on builder sites.
 *
 * Protected handles come from the active builder adapters, so Elementor's
 * frontend bundle or Divi's module script is never touched.
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

class WPD_Assets {

	/** @var WPD_Assets|null */
	private static $instance = null;

	/** @var string[]|null */
	private $protected = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		if ( WPD_Options::enabled( 'defer_js' ) ) {
			add_filter( 'script_loader_tag', array( $this, 'defer_tag' ), 20, 3 );
		}
		if ( WPD_Options::enabled( 'delay_js_until_input' ) ) {
			add_filter( 'script_loader_tag', array( $this, 'delay_tag' ), 30, 3 );
			add_action( 'wp_footer', array( $this, 'print_delay_runtime' ), 99 );
		}

		add_filter( 'style_loader_tag', array( $this, 'async_print_styles' ), 20, 4 );
		add_action( 'wp_enqueue_scripts', array( $this, 'inline_critical_css' ), 1 );
	}

	/**
	 * @return string[]
	 */
	private function protected_handles() {
		if ( null === $this->protected ) {
			$this->protected = class_exists( 'WPD_Builder_Detect' )
				? WPD_Builder_Detect::instance()->protected_handles()
				: array( 'jquery', 'jquery-core' );
		}
		return $this->protected;
	}

	/**
	 * @param string $handle Script handle.
	 * @return bool
	 */
	private function is_protected( $handle ) {
		if ( in_array( $handle, $this->protected_handles(), true ) ) {
			return true;
		}
		// Wildcard entries such as "bricks-element-*". fnmatch() is missing on
		// some Windows PHP builds, so fall back to a prefix comparison.
		foreach ( $this->protected_handles() as $pattern ) {
			if ( false === strpos( $pattern, '*' ) ) {
				continue;
			}
			if ( function_exists( 'fnmatch' ) ) {
				if ( fnmatch( $pattern, $handle ) ) {
					return true;
				}
				continue;
			}
			$prefix = substr( $pattern, 0, strpos( $pattern, '*' ) );
			if ( '' !== $prefix && 0 === strpos( $handle, $prefix ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Add defer to render-blocking scripts.
	 *
	 * defer (not async) keeps execution order, which matters because plugin
	 * scripts routinely assume their dependency already ran.
	 *
	 * @param string $tag    Script tag HTML.
	 * @param string $handle Script handle.
	 * @param string $src    Script URL.
	 * @return string
	 */
	public function defer_tag( $tag, $handle, $src ) {
		if ( ! wpd_should_optimize() ) {
			WPD_Debug::log( 'script', $handle, 'skipped — optimisation gate closed' );
			return $tag;
		}
		if ( $this->is_protected( $handle ) ) {
			WPD_Debug::log( 'script', $handle, 'skipped — protected handle (builder/checkout/jQuery)' );
			return $tag;
		}
		if ( false !== strpos( $tag, ' defer' ) || false !== strpos( $tag, ' async' ) ) {
			WPD_Debug::log( 'script', $handle, 'already defer/async — left as-is' );
			return $tag;
		}
		// Inline / module / JSON-LD tags are left alone.
		if ( false === strpos( $tag, ' src=' ) ) {
			WPD_Debug::log( 'script', $handle, 'skipped — inline script, nothing to defer' );
			return $tag;
		}
		if ( false !== strpos( $tag, 'type="module"' ) ) {
			WPD_Debug::log( 'script', $handle, 'skipped — type=module (already deferred by spec)' );
			return $tag;
		}
		if ( ! apply_filters( 'wpd_seo_defer_script', true, $handle, $src ) ) {
			WPD_Debug::log( 'script', $handle, 'skipped — wpd_seo_defer_script filter returned false' );
			return $tag;
		}

		WPD_Debug::log( 'script', $handle, 'DEFERRED' );

		return str_replace( '<script ', '<script defer ', $tag );
	}

	/**
	 * Swap src for data-wpd-src so the browser never fetches the script until
	 * the visitor interacts. Only ever applied to handles you opt in.
	 *
	 * @param string $tag    Script tag HTML.
	 * @param string $handle Script handle.
	 * @param string $src    Script URL.
	 * @return string
	 */
	public function delay_tag( $tag, $handle, $src ) {
		if ( ! wpd_should_optimize() || $this->is_protected( $handle ) ) {
			return $tag;
		}

		/**
		 * Handles or URL fragments to delay. Defaults cover the usual
		 * third-party TBT offenders.
		 *
		 * @param string[] $targets Handles or URL substrings.
		 */
		$targets = apply_filters(
			'wpd_seo_delay_scripts',
			array(
				'googletagmanager.com',
				'google-analytics.com',
				'connect.facebook.net',
				'static.hotjar.com',
				'platform.twitter.com',
				'analytics.tiktok.com',
			)
		);

		$match = in_array( $handle, $targets, true );
		if ( ! $match ) {
			foreach ( $targets as $needle ) {
				if ( '' !== $needle && false !== strpos( $src, $needle ) ) {
					$match = true;
					break;
				}
			}
		}
		if ( ! $match ) {
			return $tag;
		}

		WPD_Debug::log( 'script', $handle, 'DELAYED until first interaction' );

		$tag = str_replace( ' src=', ' data-wpd-src=', $tag );
		return str_replace( '<script ', '<script type="text/wpd-delayed" ', $tag );
	}

	/**
	 * Tiny inline runtime: on first interaction (or after a timeout), promote
	 * every delayed script back to a real one, in document order.
	 */
	public function print_delay_runtime() {
		if ( ! wpd_should_optimize() ) {
			return;
		}

		$timeout = (int) apply_filters( 'wpd_seo_delay_timeout', 6000 );
		?>
<script id="wpd-delay-runtime">
(function(){
	var fired=false,events=['keydown','mousemove','wheel','touchstart','touchmove','pointerdown','scroll'];
	function run(){
		if(fired){return;}fired=true;
		events.forEach(function(e){window.removeEventListener(e,run,{passive:true});});
		var nodes=document.querySelectorAll('script[type="text/wpd-delayed"]');
		var i=0;
		(function next(){
			if(i>=nodes.length){document.dispatchEvent(new Event('wpd-delayed-loaded'));return;}
			var old=nodes[i++],s=document.createElement('script');
			for(var a=0;a<old.attributes.length;a++){
				var at=old.attributes[a];
				if(at.name==='type'){continue;}
				s.setAttribute(at.name==='data-wpd-src'?'src':at.name,at.value);
			}
			if(!old.getAttribute('data-wpd-src')){s.text=old.text;old.parentNode.replaceChild(s,old);next();return;}
			s.onload=s.onerror=next;
			old.parentNode.replaceChild(s,old);
		})();
	}
	events.forEach(function(e){window.addEventListener(e,run,{passive:true});});
	setTimeout(run,<?php echo (int) $timeout; ?>);
})();
</script>
		<?php
	}

	/**
	 * Print-only stylesheets block rendering for no reason. media="print" with
	 * a load handler is the standard fix.
	 *
	 * @param string $tag    Link tag HTML.
	 * @param string $handle Style handle.
	 * @param string $href   Stylesheet URL.
	 * @param string $media  Media attribute.
	 * @return string
	 */
	public function async_print_styles( $tag, $handle, $href, $media ) {
		if ( ! wpd_should_optimize() ) {
			return $tag;
		}

		/**
		 * Style handles to load non-blocking. Empty by default: getting this
		 * wrong causes a flash of unstyled content, so it is opt-in per site.
		 *
		 * @param string[] $handles Style handles.
		 */
		$async = (array) apply_filters( 'wpd_seo_async_styles', array() );
		if ( ! in_array( $handle, $async, true ) ) {
			return $tag;
		}

		$tag = str_replace( "media='" . $media . "'", "media='print' onload=\"this.media='all';this.onload=null;\"", $tag );
		$tag = str_replace( 'media="' . $media . '"', 'media="print" onload="this.media=\'all\';this.onload=null;"', $tag );

		return $tag . '<noscript><link rel="stylesheet" href="' . esc_url( $href ) . '" /></noscript>';
	}

	/**
	 * Inline above-the-fold CSS so first paint never waits on a round trip.
	 */
	public function inline_critical_css() {
		if ( ! wpd_should_optimize() ) {
			return;
		}

		$css = (string) apply_filters( 'wpd_seo_critical_css', (string) WPD_Options::get( 'critical_css', '' ) );
		if ( '' === trim( $css ) ) {
			return;
		}

		/*
		 * Not wp_strip_all_tags(): it runs strip_tags(), which treats "<" as
		 * the start of a tag and silently eats valid CSS such as
		 * @media (max-width:600px) and content:"<". Only the sequence that
		 * could actually break out of the <style> element needs removing.
		 */
		$css = str_ireplace( array( '</style', '<script' ), '', $css );

		wp_register_style( 'wpd-critical', false, array(), WPD_SEO_VERSION );
		wp_enqueue_style( 'wpd-critical' );
		wp_add_inline_style( 'wpd-critical', $css );
	}
}

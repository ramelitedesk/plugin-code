<?php
/**
 * Response headers.
 *
 * PHP-level headers only apply to the HTML document — static assets are served
 * by the web server, so the far-future caching rules for those live in
 * config/htaccess-rules.conf and config/nginx-rules.conf.
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

class WPD_Headers {

	/** @var WPD_Headers|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_filter( 'wp_headers', array( $this, 'filter_headers' ), 20 );
		add_action( 'send_headers', array( $this, 'send_extra_headers' ), 20 );
	}

	/**
	 * @param array $headers Headers.
	 * @return array
	 */
	public function filter_headers( $headers ) {
		if ( ! WPD_Options::enabled( 'cache_headers' ) || is_user_logged_in() ) {
			return $headers;
		}

		if ( is_admin() || is_feed() ) {
			return $headers;
		}

		$ttl = (int) apply_filters( 'wpd_seo_html_cache_ttl', 600 );
		if ( $ttl > 0 ) {
			// s-maxage targets CDNs; browsers revalidate quickly so edits show up.
			$headers['Cache-Control'] = sprintf( 'public, max-age=0, s-maxage=%d, stale-while-revalidate=%d', $ttl, $ttl * 6 );
		}

		return $headers;
	}

	/**
	 * Security + privacy headers. They cost nothing and Lighthouse's
	 * best-practices audit checks several of them.
	 */
	public function send_extra_headers() {
		if ( headers_sent() ) {
			return;
		}

		$headers = array(
			'X-Content-Type-Options' => 'nosniff',
			'Referrer-Policy'        => 'strict-origin-when-cross-origin',
			'X-Frame-Options'        => 'SAMEORIGIN',
		);

		/**
		 * @param array $headers Header => value.
		 */
		$headers = (array) apply_filters( 'wpd_seo_extra_headers', $headers );

		foreach ( $headers as $name => $value ) {
			if ( '' === (string) $value ) {
				continue;
			}
			header( sprintf( '%s: %s', $name, $value ), true );
		}
	}
}

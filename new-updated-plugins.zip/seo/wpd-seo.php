<?php
/**
 * Plugin Name:       WPD SEO & Performance Suite
 * Plugin URI:        https://webart.technology/
 * Description:       Drop-in SEO + Core Web Vitals toolkit for any WordPress site. Builder-aware (Elementor, WPBakery, Bricks, Beaver Builder, Divi, Oxygen, Gutenberg) and safe on hand-coded themes.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Ramakrishna
 * License:           GPL-2.0-or-later
 * Text Domain:       wpd-seo
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

define( 'WPD_SEO_VERSION', '1.0.0' );
define( 'WPD_SEO_FILE', __FILE__ );
define( 'WPD_SEO_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPD_SEO_URL', plugin_dir_url( __FILE__ ) );

/**
 * Everything is opt-out via filters, so the suite never fights an existing
 * SEO plugin or a builder's own optimisation layer.
 */
final class WPD_SEO {

	/** @var WPD_SEO|null */
	private static $instance = null;

	/** @var array Runtime module registry. */
	private $modules = array();

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->boot();
		}
		return self::$instance;
	}

	private function boot() {
		require_once WPD_SEO_DIR . 'includes/helpers.php';
		require_once WPD_SEO_DIR . 'includes/class-wpd-options.php';
		require_once WPD_SEO_DIR . 'includes/class-wpd-context.php';

		// Builder layer must load first: it tells every other module what to skip.
		require_once WPD_SEO_DIR . 'builders/class-wpd-builder-base.php';
		require_once WPD_SEO_DIR . 'builders/class-wpd-builder-detect.php';

		require_once WPD_SEO_DIR . 'includes/class-wpd-meta.php';
		require_once WPD_SEO_DIR . 'includes/class-wpd-schema.php';
		require_once WPD_SEO_DIR . 'includes/class-wpd-sitemap.php';
		require_once WPD_SEO_DIR . 'includes/class-wpd-robots.php';
		require_once WPD_SEO_DIR . 'includes/class-wpd-breadcrumbs.php';

		require_once WPD_SEO_DIR . 'performance/class-wpd-perf.php';
		require_once WPD_SEO_DIR . 'performance/class-wpd-assets.php';
		require_once WPD_SEO_DIR . 'performance/class-wpd-images.php';
		require_once WPD_SEO_DIR . 'performance/class-wpd-fonts.php';
		require_once WPD_SEO_DIR . 'performance/class-wpd-html.php';
		require_once WPD_SEO_DIR . 'performance/class-wpd-headers.php';

		require_once WPD_SEO_DIR . 'custom/class-wpd-custom-theme.php';
		require_once WPD_SEO_DIR . 'woocommerce/class-wpd-woo.php';

		require_once WPD_SEO_DIR . 'includes/class-wpd-debug.php';

		if ( is_admin() ) {
			require_once WPD_SEO_DIR . 'admin/class-wpd-admin.php';
		}

		add_action( 'init', array( $this, 'load_textdomain' ), 1 );
		add_action( 'plugins_loaded', array( $this, 'init_modules' ), 5 );
		register_activation_hook( WPD_SEO_FILE, array( __CLASS__, 'on_activate' ) );
		register_deactivation_hook( WPD_SEO_FILE, array( __CLASS__, 'on_deactivate' ) );
	}

	public function load_textdomain() {
		load_plugin_textdomain( 'wpd-seo', false, dirname( plugin_basename( WPD_SEO_FILE ) ) . '/languages' );
	}

	public function init_modules() {
		// Repair settings written by an older version before reading them.
		WPD_Options::maybe_upgrade();

		// Detection runs before anything reads WPD_Context.
		WPD_Builder_Detect::instance();

		$map = array(
			'context'     => 'WPD_Context',
			'meta'        => 'WPD_Meta',
			'schema'      => 'WPD_Schema',
			'sitemap'     => 'WPD_Sitemap',
			'robots'      => 'WPD_Robots',
			'breadcrumbs' => 'WPD_Breadcrumbs',
			'perf'        => 'WPD_Perf',
			'assets'      => 'WPD_Assets',
			'images'      => 'WPD_Images',
			'fonts'       => 'WPD_Fonts',
			'html'        => 'WPD_Html',
			'headers'     => 'WPD_Headers',
			'custom'      => 'WPD_Custom_Theme',
			'woo'         => 'WPD_Woo',
		);

		foreach ( $map as $key => $class ) {
			if ( ! class_exists( $class ) ) {
				continue;
			}
			/**
			 * Disable any single module:
			 *   add_filter( 'wpd_seo_module_schema', '__return_false' );
			 */
			if ( ! apply_filters( "wpd_seo_module_{$key}", WPD_Options::enabled( $key ) ) ) {
				continue;
			}
			$this->modules[ $key ] = $class::instance();
		}

		if ( is_admin() && class_exists( 'WPD_Admin' ) ) {
			$this->modules['admin'] = WPD_Admin::instance();
		}

		// Loaded last so its script counter sees every other module's output.
		if ( class_exists( 'WPD_Debug' ) && WPD_Debug::is_enabled() ) {
			WPD_Debug::instance();
		}

		do_action( 'wpd_seo_loaded', $this );
	}

	/**
	 * @param string $key Module key.
	 * @return object|null
	 */
	public function module( $key ) {
		return isset( $this->modules[ $key ] ) ? $this->modules[ $key ] : null;
	}

	/**
	 * @return string[] Keys of the modules that actually initialised.
	 */
	public function active_modules() {
		return array_keys( $this->modules );
	}

	public static function on_activate() {
		require_once WPD_SEO_DIR . 'includes/class-wpd-options.php';
		WPD_Options::install_defaults();
		flush_rewrite_rules();
	}

	public static function on_deactivate() {
		flush_rewrite_rules();
	}
}

WPD_SEO::instance();

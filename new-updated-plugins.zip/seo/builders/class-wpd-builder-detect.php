<?php
/**
 * Builder registry + detection.
 *
 * Loads every adapter, answers "which builder is in play?" once per request,
 * and exposes the aggregated protected-handle lists that the performance
 * modules must respect.
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

class WPD_Builder_Detect {

	/** @var WPD_Builder_Detect|null */
	private static $instance = null;

	/** @var WPD_Builder_Base[] slug => adapter */
	private $adapters = array();

	/** @var WPD_Builder_Base[]|null Active adapters (cached). */
	private $active = null;

	/** @var bool|null Editor-mode result (cached). */
	private $editing = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$this->load_adapters();
	}

	private function load_adapters() {
		$files = array(
			'elementor'  => 'class-wpd-builder-elementor.php',
			'wpbakery'   => 'class-wpd-builder-wpbakery.php',
			'bricks'     => 'class-wpd-builder-bricks.php',
			'beaver'     => 'class-wpd-builder-beaver.php',
			'divi'       => 'class-wpd-builder-divi.php',
			'oxygen'     => 'class-wpd-builder-oxygen.php',
			'gutenberg'  => 'class-wpd-builder-gutenberg.php',
		);

		$classes = array(
			'elementor' => 'WPD_Builder_Elementor',
			'wpbakery'  => 'WPD_Builder_WPBakery',
			'bricks'    => 'WPD_Builder_Bricks',
			'beaver'    => 'WPD_Builder_Beaver',
			'divi'      => 'WPD_Builder_Divi',
			'oxygen'    => 'WPD_Builder_Oxygen',
			'gutenberg' => 'WPD_Builder_Gutenberg',
		);

		foreach ( $files as $slug => $file ) {
			$path = WPD_SEO_DIR . 'builders/' . $file;
			if ( file_exists( $path ) ) {
				require_once $path;
			}
			$class = $classes[ $slug ];
			if ( class_exists( $class ) ) {
				$this->adapters[ $slug ] = new $class();
			}
		}

		/**
		 * Register a custom adapter:
		 *   add_filter( 'wpd_seo_builder_adapters', function ( $a ) {
		 *       $a['mybuilder'] = new My_Adapter();
		 *       return $a;
		 *   } );
		 *
		 * @param WPD_Builder_Base[] $adapters Registered adapters.
		 */
		$this->adapters = apply_filters( 'wpd_seo_builder_adapters', $this->adapters );
	}

	/**
	 * @return WPD_Builder_Base[] Adapters whose builder is installed.
	 */
	public function active_builders() {
		if ( null === $this->active ) {
			$this->active = array();
			foreach ( $this->adapters as $slug => $adapter ) {
				if ( $adapter->is_active() ) {
					$this->active[ $slug ] = $adapter;
				}
			}
		}
		return $this->active;
	}

	/**
	 * The adapter that actually rendered a given post.
	 *
	 * @param int $post_id Post ID. Defaults to the queried object.
	 * @return WPD_Builder_Base|null
	 */
	public function builder_for( $post_id = 0 ) {
		$post_id = $post_id ? (int) $post_id : (int) get_queried_object_id();
		if ( ! $post_id ) {
			return null;
		}

		foreach ( $this->active_builders() as $slug => $adapter ) {
			if ( 'gutenberg' === $slug ) {
				continue; // Checked last, it is the fallback.
			}
			if ( $adapter->built_with( $post_id ) ) {
				return $adapter;
			}
		}

		if ( isset( $this->adapters['gutenberg'] ) && $this->adapters['gutenberg']->built_with( $post_id ) ) {
			return $this->adapters['gutenberg'];
		}
		return null;
	}

	/**
	 * @param string $slug Builder slug.
	 * @return WPD_Builder_Base|null
	 */
	public function get( $slug ) {
		return isset( $this->adapters[ $slug ] ) ? $this->adapters[ $slug ] : null;
	}

	/**
	 * Are we inside ANY builder editor / preview right now?
	 *
	 * @return bool
	 */
	public function is_editing() {
		if ( null !== $this->editing ) {
			return $this->editing;
		}

		$this->editing = false;
		foreach ( $this->active_builders() as $adapter ) {
			if ( $adapter->is_editing() ) {
				$this->editing = true;
				break;
			}
		}

		/**
		 * Last-resort guard for builders we do not ship an adapter for: most of
		 * them expose an editor flag in the query string.
		 */
		if ( ! $this->editing ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only detection.
			$keys = array_keys( (array) $_GET );
			foreach ( $keys as $key ) {
				if ( preg_match( '/(builder|_edit|preview|_fb|editor)/i', (string) $key ) ) {
					$this->editing = true;
					break;
				}
			}
		}

		return (bool) apply_filters( 'wpd_seo_is_builder_editor', $this->editing );
	}

	/**
	 * Aggregated script handles no optimisation may touch.
	 *
	 * @return string[]
	 */
	public function protected_handles() {
		$handles = array( 'jquery', 'jquery-core', 'wpd-seo-runtime' );
		foreach ( $this->active_builders() as $adapter ) {
			$handles = array_merge( $handles, $adapter->protected_handles() );
		}
		return array_values( array_unique( apply_filters( 'wpd_seo_protected_handles', $handles ) ) );
	}

	/**
	 * Aggregated style handles no optimisation may touch.
	 *
	 * @return string[]
	 */
	public function protected_styles() {
		$handles = array();
		foreach ( $this->active_builders() as $adapter ) {
			$handles = array_merge( $handles, $adapter->protected_styles() );
		}
		return array_values( array_unique( apply_filters( 'wpd_seo_protected_styles', $handles ) ) );
	}

	/**
	 * Clean text for the queried post, using the right adapter.
	 *
	 * @param int $post_id Post ID.
	 * @return string
	 */
	public function text_for( $post_id ) {
		$adapter = $this->builder_for( $post_id );
		if ( $adapter ) {
			return $adapter->get_text( $post_id );
		}
		$post = get_post( $post_id );
		return $post ? (string) $post->post_content : '';
	}

	/**
	 * @param int $post_id Post ID.
	 * @return int
	 */
	public function hero_image_for( $post_id ) {
		$adapter = $this->builder_for( $post_id );
		$id      = $adapter ? (int) $adapter->get_hero_image_id( $post_id ) : 0;
		return $id ? $id : (int) wpd_first_image_id( $post_id );
	}

	/**
	 * Human-readable summary for the admin screen.
	 *
	 * @return string
	 */
	public function summary() {
		$labels = array();
		foreach ( $this->active_builders() as $adapter ) {
			$labels[] = $adapter->label();
		}
		return $labels ? implode( ', ', $labels ) : __( 'Classic / hand-coded theme', 'wpd-seo' );
	}
}

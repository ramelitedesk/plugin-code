<?php
/**
 * Bricks Builder adapter.
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

class WPD_Builder_Bricks extends WPD_Builder_Base {

	protected $slug  = 'bricks';
	protected $label = 'Bricks Builder';

	public function is_active() {
		return defined( 'BRICKS_VERSION' ) || class_exists( '\Bricks\Theme' );
	}

	public function built_with( $post_id ) {
		if ( ! $this->is_active() ) {
			return false;
		}
		$data = get_post_meta( $post_id, '_bricks_page_content_2', true );
		return ! empty( $data );
	}

	public function is_editing() {
		if ( ! $this->is_active() ) {
			return false;
		}
		if ( $this->has_query_arg( array( 'bricks' ) ) ) {
			return true;
		}
		if ( $this->is_ajax_action( 'bricks_' ) ) {
			return true;
		}
		if ( class_exists( '\Bricks\Helpers' ) && method_exists( '\Bricks\Helpers', 'is_bricks_preview' ) ) {
			return (bool) \Bricks\Helpers::is_bricks_preview();
		}
		return false;
	}

	public function get_text( $post_id ) {
		$data = get_post_meta( $post_id, '_bricks_page_content_2', true );
		if ( ! is_array( $data ) ) {
			return parent::get_text( $post_id );
		}

		$text = '';
		foreach ( $data as $element ) {
			if ( empty( $element['settings'] ) || ! is_array( $element['settings'] ) ) {
				continue;
			}
			foreach ( array( 'text', 'content', 'title' ) as $key ) {
				if ( ! empty( $element['settings'][ $key ] ) && is_string( $element['settings'][ $key ] ) ) {
					$text .= ' ' . $element['settings'][ $key ];
				}
			}
			if ( mb_strlen( $text ) > 1200 ) {
				break;
			}
		}

		$text = trim( $text );
		return '' !== $text ? $text : parent::get_text( $post_id );
	}

	public function get_hero_image_id( $post_id ) {
		$data = get_post_meta( $post_id, '_bricks_page_content_2', true );
		if ( ! is_array( $data ) ) {
			return 0;
		}
		foreach ( $data as $element ) {
			if ( ! empty( $element['settings']['image']['id'] ) ) {
				return (int) $element['settings']['image']['id'];
			}
		}
		return 0;
	}

	public function protected_handles() {
		return array( 'bricks-scripts', 'bricks-frontend', 'bricks-photoswipe', 'bricks-swiper' );
	}

	public function protected_styles() {
		return array( 'bricks-frontend', 'bricks-frontend-inline-css' );
	}
}

<?php
/**
 * Base contract every builder adapter implements.
 *
 * An adapter answers three questions for the rest of the suite:
 *   1. Is this builder active (site-wide / for this post)?
 *   2. Are we inside its editor right now? (=> disable all optimisation)
 *   3. What is its plain-text content, and which handles must stay untouched?
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

abstract class WPD_Builder_Base {

	/** @var string Machine slug, e.g. "elementor". */
	protected $slug = '';

	/** @var string Human label. */
	protected $label = '';

	/**
	 * @return string
	 */
	public function slug() {
		return $this->slug;
	}

	/**
	 * @return string
	 */
	public function label() {
		return $this->label;
	}

	/**
	 * Is the builder installed and active on this site?
	 *
	 * @return bool
	 */
	abstract public function is_active();

	/**
	 * Was this specific post built with this builder?
	 *
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	public function built_with( $post_id ) {
		return $this->is_active();
	}

	/**
	 * Are we inside this builder's editor, preview iframe or AJAX handler?
	 *
	 * @return bool
	 */
	public function is_editing() {
		return false;
	}

	/**
	 * Plain-text content for meta descriptions. Builders store layout JSON or
	 * shortcode soup in post_content, so each adapter cleans its own format.
	 *
	 * @param int $post_id Post ID.
	 * @return string
	 */
	public function get_text( $post_id ) {
		$post = get_post( $post_id );
		return $post ? (string) $post->post_content : '';
	}

	/**
	 * LCP / above-the-fold image for this post, if the builder can tell us.
	 *
	 * @param int $post_id Post ID.
	 * @return int Attachment ID or 0.
	 */
	public function get_hero_image_id( $post_id ) {
		return 0;
	}

	/**
	 * Script handles that must never be deferred/delayed for this builder.
	 *
	 * @return string[]
	 */
	public function protected_handles() {
		return array();
	}

	/**
	 * Style handles that must never be removed or inlined-away.
	 *
	 * @return string[]
	 */
	public function protected_styles() {
		return array();
	}

	/**
	 * Query args / cookies that signal an editor session for this builder.
	 *
	 * @param string[] $args Query arg names.
	 * @return bool
	 */
	protected function has_query_arg( array $args ) {
		foreach ( $args as $arg ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only detection.
			if ( isset( $_GET[ $arg ] ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @param string $action Expected admin-ajax action prefix.
	 * @return bool
	 */
	protected function is_ajax_action( $action ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only detection.
		$current = isset( $_REQUEST['action'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['action'] ) ) : '';
		return '' !== $current && 0 === strpos( $current, $action );
	}
}

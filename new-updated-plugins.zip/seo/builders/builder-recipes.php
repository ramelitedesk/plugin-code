<?php
/**
 * Per-builder tuning recipes.
 *
 * NOT loaded automatically. Each block is a copy-paste snippet for a specific
 * builder — enable the ones that match the site. They are separated out because
 * every one of them trades a little safety for a little speed, and that trade
 * has to be a per-site decision.
 *
 * To use the whole file:
 *     require_once WPD_SEO_DIR . 'builders/builder-recipes.php';
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

/* =========================================================================
 * ELEMENTOR
 * ====================================================================== */

if ( defined( 'ELEMENTOR_VERSION' ) ) {

	// Elementor loads eicons + FontAwesome site-wide even on pages with no icons.
	add_action(
		'wp_enqueue_scripts',
		function () {
			if ( ! wpd_should_optimize() ) {
				return;
			}
			global $post;
			$content = $post ? (string) get_post_meta( $post->ID, '_elementor_data', true ) : '';

			if ( false === strpos( $content, 'fa-' ) && false === strpos( $content, 'font-awesome' ) ) {
				wp_dequeue_style( 'font-awesome' );
				wp_dequeue_style( 'elementor-icons-fa-solid' );
				wp_dequeue_style( 'elementor-icons-fa-regular' );
				wp_dequeue_style( 'elementor-icons-fa-brands' );
			}
			if ( false === strpos( $content, 'eicon' ) ) {
				wp_dequeue_style( 'elementor-icons' );
			}
			// Swiper only ships with carousels/sliders.
			if ( false === strpos( $content, 'slides' ) && false === strpos( $content, 'carousel' ) && false === strpos( $content, 'testimonial' ) ) {
				wp_dequeue_style( 'e-swiper' );
				wp_dequeue_style( 'swiper' );
				wp_dequeue_script( 'swiper' );
			}
		},
		999
	);

	// Elementor's dialog/waypoints libs are only needed by popups & animations.
	add_filter(
		'wpd_seo_defer_script',
		function ( $defer, $handle ) {
			// These are safe to defer; the frontend bundle is protected already.
			return $defer;
		},
		10,
		2
	);

	// Turn on Elementor's own optimisation experiments programmatically.
	add_filter( 'elementor/experiments/default-features', function ( $features ) {
		foreach ( array( 'e_optimized_assets_loading', 'e_optimized_css_loading', 'e_font_icon_svg', 'additional_custom_breakpoints' ) as $key ) {
			if ( isset( $features[ $key ] ) ) {
				$features[ $key ]['default'] = 'active';
			}
		}
		return $features;
	} );
}

/* =========================================================================
 * WPBAKERY / VISUAL COMPOSER
 * ====================================================================== */

if ( defined( 'WPB_VC_VERSION' ) ) {

	// WPBakery enqueues its icon fonts on every page regardless of use.
	add_action(
		'wp_enqueue_scripts',
		function () {
			if ( ! wpd_should_optimize() ) {
				return;
			}
			global $post;
			$content = $post ? (string) $post->post_content : '';

			if ( false === strpos( $content, 'i_type="fontawesome"' ) ) {
				wp_dequeue_style( 'vc_font_awesome_5' );
			}
			if ( false === strpos( $content, 'openiconic' ) ) {
				wp_dequeue_style( 'vc_openiconic' );
			}
			if ( false === strpos( $content, 'animation' ) && false === strpos( $content, 'css_animation' ) ) {
				wp_dequeue_style( 'animate-css' );
			}
			// The bundled Google Font loader duplicates the theme's fonts.
			wp_dequeue_style( 'vc_google_fonts' );
		},
		999
	);

	// WPBakery's grid JS is heavy and only used by post grids.
	add_filter(
		'wpd_seo_dequeue_scripts',
		function ( $handles ) {
			global $post;
			$content = $post ? (string) $post->post_content : '';
			if ( false === strpos( $content, '[vc_basic_grid' ) && false === strpos( $content, '[vc_masonry' ) ) {
				$handles[] = 'vc_grid';
				$handles[] = 'vc_waypoints';
			}
			return $handles;
		}
	);
}

/* =========================================================================
 * BRICKS
 * ====================================================================== */

if ( defined( 'BRICKS_VERSION' ) ) {

	// Bricks already scopes most CSS; the remaining wins are font + query loop.
	add_filter( 'bricks/frontend/disable_opacity_animation', '__return_true' );

	add_action(
		'wp_enqueue_scripts',
		function () {
			if ( ! wpd_should_optimize() ) {
				return;
			}
			wp_dequeue_style( 'bricks-tooltips' );
			wp_dequeue_script( 'bricks-tooltips' );
		},
		999
	);
}

/* =========================================================================
 * DIVI
 * ====================================================================== */

if ( defined( 'ET_BUILDER_VERSION' ) ) {

	// Divi's dynamic CSS/JS options, forced on.
	add_filter( 'et_use_dynamic_css', '__return_true' );
	add_filter( 'et_should_load_dynamic_css', '__return_true' );

	add_action(
		'wp_enqueue_scripts',
		function () {
			if ( ! wpd_should_optimize() ) {
				return;
			}
			// Divi's Google Fonts loader — self-host instead and drop this.
			if ( apply_filters( 'wpd_seo_divi_drop_google_fonts', false ) ) {
				wp_dequeue_style( 'divi-fonts' );
			}
			wp_dequeue_style( 'et-gf-open-sans' );
		},
		999
	);
}

/* =========================================================================
 * BEAVER BUILDER
 * ====================================================================== */

if ( class_exists( 'FLBuilder' ) ) {

	// Beaver ships one CSS/JS file per layout — keep them, but drop the
	// bundled animate.css on layouts with no animations.
	add_action(
		'wp_enqueue_scripts',
		function () {
			if ( ! wpd_should_optimize() ) {
				return;
			}
			wp_dequeue_style( 'font-awesome-5' );
			wp_dequeue_style( 'foundation-icons' );
		},
		999
	);
}

/* =========================================================================
 * OXYGEN
 * ====================================================================== */

if ( defined( 'CT_VERSION' ) ) {

	add_action(
		'wp_enqueue_scripts',
		function () {
			if ( ! wpd_should_optimize() ) {
				return;
			}
			// Oxygen's AOS animation library is opt-in per site.
			if ( apply_filters( 'wpd_seo_oxygen_drop_aos', true ) ) {
				wp_dequeue_script( 'oxygen-aos' );
				wp_dequeue_style( 'oxygen-aos' );
			}
		},
		999
	);
}

/* =========================================================================
 * GUTENBERG / FSE
 * ====================================================================== */

// Load block styles only for blocks actually present on the page (WP 5.8+).
add_filter( 'should_load_separate_core_block_assets', '__return_true' );

// Drop the SVG duotone filter block that core injects into every page body.
add_action(
	'wp_footer',
	function () {
		if ( wpd_should_optimize() ) {
			remove_action( 'wp_body_open', 'wp_global_styles_render_svg_filters' );
		}
	},
	1
);

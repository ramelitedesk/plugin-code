<?php
/**
 * Elementor adapter.
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

class WPD_Builder_Elementor extends WPD_Builder_Base {

	protected $slug  = 'elementor';
	protected $label = 'Elementor';

	public function is_active() {
		return did_action( 'elementor/loaded' ) || defined( 'ELEMENTOR_VERSION' );
	}

	public function built_with( $post_id ) {
		if ( ! $this->is_active() ) {
			return false;
		}
		return '' !== (string) get_post_meta( $post_id, '_elementor_edit_mode', true );
	}

	public function is_editing() {
		if ( ! $this->is_active() ) {
			return false;
		}
		if ( $this->has_query_arg( array( 'elementor-preview' ) ) ) {
			return true;
		}
		if ( $this->is_ajax_action( 'elementor' ) ) {
			return true;
		}
		if ( class_exists( '\Elementor\Plugin' ) ) {
			$plugin = \Elementor\Plugin::$instance;
			if ( isset( $plugin->editor ) && method_exists( $plugin->editor, 'is_edit_mode' ) && $plugin->editor->is_edit_mode() ) {
				return true;
			}
			if ( isset( $plugin->preview ) && method_exists( $plugin->preview, 'is_preview_mode' ) && $plugin->preview->is_preview_mode() ) {
				return true;
			}
		}
		return false;
	}

	public function get_text( $post_id ) {
		if ( ! $this->built_with( $post_id ) ) {
			return parent::get_text( $post_id );
		}

		$data = get_post_meta( $post_id, '_elementor_data', true );
		if ( empty( $data ) ) {
			return parent::get_text( $post_id );
		}
		if ( is_string( $data ) ) {
			$data = json_decode( $data, true );
		}
		if ( ! is_array( $data ) ) {
			return parent::get_text( $post_id );
		}

		$text = $this->walk_elements( $data );

		return '' !== $text ? $text : parent::get_text( $post_id );
	}

	public function get_hero_image_id( $post_id ) {
		$data = get_post_meta( $post_id, '_elementor_data', true );
		if ( is_string( $data ) ) {
			$data = json_decode( $data, true );
		}
		if ( ! is_array( $data ) ) {
			return 0;
		}
		return $this->find_first_image( $data );
	}

	public function protected_handles() {
		return array(
			'elementor-frontend',
			'elementor-frontend-modules',
			'elementor-webpack-runtime',
			'elementor-pro-frontend',
			'elementor-pro-webpack-runtime',
			'swiper',
			'elementor-waypoints',
		);
	}

	public function protected_styles() {
		return array( 'elementor-frontend', 'elementor-icons', 'elementor-global' );
	}

	/**
	 * Recursively pull text settings out of Elementor's element tree.
	 *
	 * @param array $elements Element tree.
	 * @param int   $depth    Recursion guard.
	 * @return string
	 */
	private function walk_elements( array $elements, $depth = 0 ) {
		if ( $depth > 12 ) {
			return '';
		}

		$text = '';
		$keys = array( 'title', 'editor', 'text', 'heading_title', 'description_text', 'title_text', 'testimonial_content' );

		foreach ( $elements as $element ) {
			if ( ! is_array( $element ) ) {
				continue;
			}
			if ( ! empty( $element['settings'] ) && is_array( $element['settings'] ) ) {
				foreach ( $keys as $key ) {
					if ( ! empty( $element['settings'][ $key ] ) && is_string( $element['settings'][ $key ] ) ) {
						$text .= ' ' . $element['settings'][ $key ];
					}
				}
			}
			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				$text .= ' ' . $this->walk_elements( $element['elements'], $depth + 1 );
			}
			if ( mb_strlen( $text ) > 1200 ) {
				break;
			}
		}

		return trim( $text );
	}

	/**
	 * @param array $elements Element tree.
	 * @param int   $depth    Recursion guard.
	 * @return int
	 */
	private function find_first_image( array $elements, $depth = 0 ) {
		if ( $depth > 12 ) {
			return 0;
		}
		foreach ( $elements as $element ) {
			if ( ! is_array( $element ) ) {
				continue;
			}
			if ( ! empty( $element['settings']['image']['id'] ) ) {
				return (int) $element['settings']['image']['id'];
			}
			if ( ! empty( $element['settings']['background_image']['id'] ) ) {
				return (int) $element['settings']['background_image']['id'];
			}
			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				$found = $this->find_first_image( $element['elements'], $depth + 1 );
				if ( $found ) {
					return $found;
				}
			}
		}
		return 0;
	}
}

# Tests

Standalone runtime tests. No PHPUnit, no WordPress install, no database — they
load the plugin against stubbed WordPress functions and actually call every
output path, so undefined methods, wrong argument counts, null-to-string
deprecations and type errors surface here rather than on a live site.

Run them after any edit:

```bash
cd seo/tests
php smoke-test.php
php settings-save-test.php
```

## smoke-test.php

Executes ~100 checks across four scenarios:

| Scenario | What it proves |
| --- | --- |
| Front page | Every module's output path runs clean on a non-singular view |
| Singular post | Same, with a queried object, permalink, terms and author |
| Logged-in visitor | The gate closes: scripts, images and markup come back **byte-identical** |
| WooCommerce active | Product schema, transactional-page detection, asset dequeuing |

It also asserts the two failure modes that would blank a page:

- **Invalid UTF-8** in the page body (`/u` regexes return null)
- **Backtrack-limit exhaustion** in the comment-stripping regex

Both must return the original HTML, not an empty string.

The final section reports PHP notices, warnings and deprecations. It must
print `none`.

## settings-save-test.php

Regression test for the settings-save bug where saving the form disabled every
module key that has no checkbox on that form — which silently switched off the
whole performance layer. Asserts that:

- Module keys with no checkbox keep their stored value
- Checkboxes the form *did* render still save on and off correctly
- Non-form string values (the debug token) survive a save

## Adding a stub

If a test fails with `Call to undefined function`, that is almost always a
missing stub rather than a plugin bug — add it to `bootstrap.php` and re-run.
`bootstrap.php` is generated from the top of `smoke-test.php`; keep them in
sync if you edit either.

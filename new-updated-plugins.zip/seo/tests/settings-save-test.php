<?php
/**
 * Regression test for the settings-save bug: saving the form must not disable
 * module keys that have no checkbox on that form.
 */
/*
 * Command line only.
 *
 * These files ship inside the plugin, which means they sit under a web root
 * and can be requested directly. Nothing in WordPress can prevent that — the
 * request never reaches WordPress. Running this over HTTP would print a
 * complete inventory of the firewall's rules to whoever asked, which is a
 * map of the defences for anyone planning to get around them.
 */
if ( 'cli' !== PHP_SAPI ) {
	http_response_code( 404 );
	exit;
}
require __DIR__ . '/bootstrap.php';

require_once $dir . 'admin/class-wpd-admin.php';

// Simulate the form posting only the checkboxes it renders.
$_POST = array(
	'wpd_present' => array( 'schema', 'sitemap', 'robots', 'breadcrumbs', 'defer_js', 'minify_html' ),
	'schema'      => '1',
	'sitemap'     => '1',
	'robots'      => '1',
	'breadcrumbs' => '1',
	'defer_js'    => '1',
	// minify_html deliberately absent = user unchecked it.
	'title_separator' => '|',
);

WPD_Options::install_defaults();
$before = WPD_Options::all();

// Run the same sanitising loop handle_save() uses.
$defaults = WPD_Options::defaults();
$current  = WPD_Options::all();
$clean    = array();
$rendered = array_map( 'sanitize_key', (array) $_POST['wpd_present'] );

foreach ( $defaults as $key => $default ) {
	$posted = isset( $_POST[ $key ] );
	$raw    = $posted ? $_POST[ $key ] : null;

	if ( '_schema' === $key ) { $clean[ $key ] = WPD_Options::SCHEMA_VERSION; continue; }
	if ( ! $posted && ! in_array( $key, $rendered, true ) ) {
		$clean[ $key ] = isset( $current[ $key ] ) ? $current[ $key ] : $default;
		continue;
	}
	if ( is_int( $default ) ) { $clean[ $key ] = ( null === $raw ) ? 0 : 1; continue; }
	$clean[ $key ] = is_string( $raw ) ? sanitize_text_field( $raw ) : $default;
}

WPD_Options::update( $clean );
$after = WPD_Options::all();

$fail = 0;

echo "Module keys with no checkbox on the form:\n";
foreach ( WPD_Options::INTERNAL_KEYS as $key ) {
	$ok = ! empty( $after[ $key ] );
	printf( "  %-10s before=%s after=%s  %s\n", $key, (int) $before[ $key ], (int) $after[ $key ], $ok ? 'ok' : 'FAIL - DISABLED' );
	if ( ! $ok ) { $fail++; }
}

echo "\nCheckboxes the form did render:\n";
foreach ( array( 'schema' => 1, 'sitemap' => 1, 'defer_js' => 1, 'minify_html' => 0 ) as $key => $want ) {
	$got = (int) $after[ $key ];
	printf( "  %-12s want=%d got=%d  %s\n", $key, $want, $got, $got === $want ? 'ok' : 'FAIL' );
	if ( $got !== $want ) { $fail++; }
}

echo "\nNon-form string values preserved across a second save:\n";

// Generate the token the way the admin screen does.
WPD_Options::update( array( 'debug_token' => 'secrettoken123' ) );

// Now simulate ANOTHER save from the form, which never posts debug_token.
$current2 = WPD_Options::all();
$clean2   = array();
foreach ( $defaults as $key => $default ) {
	$posted = isset( $_POST[ $key ] );
	$raw    = $posted ? $_POST[ $key ] : null;
	if ( '_schema' === $key ) { $clean2[ $key ] = WPD_Options::SCHEMA_VERSION; continue; }
	if ( ! $posted && ! in_array( $key, $rendered, true ) ) {
		$clean2[ $key ] = isset( $current2[ $key ] ) ? $current2[ $key ] : $default;
		continue;
	}
	if ( is_int( $default ) ) { $clean2[ $key ] = ( null === $raw ) ? 0 : 1; continue; }
	$clean2[ $key ] = is_string( $raw ) ? sanitize_text_field( $raw ) : $default;
}
WPD_Options::update( $clean2 );

$token = WPD_Options::get( 'debug_token' );
printf( "  debug_token  [%s]  %s\n", $token, 'secrettoken123' === $token ? 'ok' : 'FAIL - WIPED' );
if ( 'secrettoken123' !== $token ) { $fail++; }

echo "\n" . ( $fail ? "$fail FAILURE(S)\n" : "All save-round-trip checks passed\n" );

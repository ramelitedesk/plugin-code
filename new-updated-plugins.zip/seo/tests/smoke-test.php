<?php
/**
 * Runtime smoke test: loads the whole plugin against stubbed WordPress
 * functions and actually calls every output path, so undefined methods, bad
 * argument counts, null-to-string deprecations and type errors surface here
 * instead of on a live site.
 */

/*
 * Command line only.
 *
 * These files ship inside the plugin, which means they sit under a web root
 * and can be requested directly. Nothing in WordPress can prevent that — the
 * request never reaches WordPress. Running this over HTTP would print a
 * complete inventory of the firewall's rules to whoever asked, which is a
 * map of the defences for anyone planning to get around them.
 */
if ( 'cli' !== PHP_SAPI ) {
	http_response_code( 404 );
	exit;
}
error_reporting( E_ALL );
ini_set( 'display_errors', '1' );

define( 'ABSPATH', __DIR__ . '/' );
define( 'WP_DEBUG', true );
define( 'DATE_W3C_FALLBACK', 'Y-m-d\TH:i:sP' );

$GLOBALS['wpd_state'] = array(
	'singular' => false,
	'front'    => true,
	'loggedin' => false,
	'cart'     => false,
	'product'  => false,
);

$GLOBALS['wp_options'] = array();
$GLOBALS['wp_filters'] = array();

// ---------------------------------------------------------------- stubs ----

$return_false = array(
	'is_admin', 'wp_doing_ajax', 'wp_doing_cron', 'is_customize_preview', 'is_feed',
	'is_embed', 'is_preview', 'is_search', 'is_404', 'is_category', 'is_tag', 'is_tax',
	'is_author', 'is_date', 'is_post_type_archive', 'is_attachment', 'is_archive',
	'is_paged', 'post_password_required', 'has_excerpt', 'is_admin_bar_showing',
	'has_blocks', 'is_wp_error', 'is_ssl', 'is_home',
	'is_taxonomy_hierarchical', 'is_post_type_hierarchical', 'wp_is_json_request',
	'is_multisite', 'wp_style_is', 'wp_script_is', 'is_woocommerce',
);

$return_empty_string = array(
	'get_search_query', 'get_the_archive_title', 'get_search_link',
);

$return_empty_array = array(
	'get_post_ancestors', 'get_ancestors', 'get_object_taxonomies', 'get_posts',
	'get_comments', 'parse_blocks', 'wp_get_attachment_image_srcset',
);

$noop = array(
	'add_action', 'add_filter', 'remove_action', 'remove_filter', 'do_action',
	'add_theme_support', 'register_activation_hook', 'register_deactivation_hook',
	'flush_rewrite_rules', 'wp_dequeue_style', 'wp_deregister_style',
	'wp_dequeue_script', 'wp_deregister_script', 'wp_enqueue_style',
	'wp_register_style', 'wp_add_inline_style', 'wp_enqueue_script',
	'add_shortcode', 'load_plugin_textdomain', 'add_meta_box', 'header',
	'wp_script_add_data', 'add_image_size', 'delete_post_meta', 'update_post_meta',
	'delete_option',
);

foreach ( $return_false as $fn ) {
	if ( ! function_exists( $fn ) ) { eval( "function $fn() { return false; }" ); }
}
foreach ( $return_empty_string as $fn ) {
	if ( ! function_exists( $fn ) ) { eval( "function $fn() { return ''; }" ); }
}
foreach ( $return_empty_array as $fn ) {
	if ( ! function_exists( $fn ) ) { eval( "function $fn() { return array(); }" ); }
}
foreach ( $noop as $fn ) {
	if ( ! function_exists( $fn ) ) { eval( "function $fn() { return null; }" ); }
}

function apply_filters( $tag, $value = null ) { return $value; }
function has_action( $tag, $cb = false ) { return false; }
function did_action( $tag ) { return 0; }
function plugin_dir_path( $f ) { return dirname( $f ) . '/'; }
function plugin_dir_url( $f ) { return 'https://example.test/wp-content/plugins/seo/'; }
function plugin_basename( $f ) { return 'seo/wpd-seo.php'; }
function home_url( $path = '/' ) { return 'https://example.test' . ( '/' === substr( (string) $path, 0, 1 ) ? $path : '/' . $path ); }
function admin_url( $p = '' ) { return 'https://example.test/wp-admin/' . $p; }
function get_bloginfo( $what = 'name', $filter = 'raw' ) {
	$map = array( 'name' => 'Example Site', 'description' => 'A tagline', 'language' => 'en-US', 'version' => '6.9' );
	return isset( $map[ $what ] ) ? $map[ $what ] : '';
}
function get_option( $k, $d = false ) { return isset( $GLOBALS['wp_options'][ $k ] ) ? $GLOBALS['wp_options'][ $k ] : $d; }
function update_option( $k, $v ) { $GLOBALS['wp_options'][ $k ] = $v; return true; }
function add_option( $k, $v ) { $GLOBALS['wp_options'][ $k ] = $v; return true; }
function wp_parse_args( $args, $defaults = array() ) { return array_merge( $defaults, (array) $args ); }
function is_singular( $t = '' ) { return $GLOBALS['wpd_state']['singular']; }
function is_front_page() { return $GLOBALS['wpd_state']['front']; }
function is_user_logged_in() { return $GLOBALS['wpd_state']['loggedin']; }
function get_queried_object_id() { return $GLOBALS['wpd_state']['singular'] ? 42 : 0; }
function get_queried_object() { return null; }
function get_query_var( $v, $d = '' ) { return $d; }
function get_permalink( $id = 0 ) { return 'https://example.test/sample-post/'; }
function get_term_link( $t ) { return 'https://example.test/category/news/'; }
function get_author_posts_url( $id ) { return 'https://example.test/author/jane/'; }
function get_post_type_archive_link( $t ) { return 'https://example.test/things/'; }
function get_pagenum_link( $n ) { return 'https://example.test/page/' . (int) $n . '/'; }
function trailingslashit( $s ) { return rtrim( (string) $s, '/\\' ) . '/'; }
function untrailingslashit( $s ) { return rtrim( (string) $s, '/\\' ); }
function user_trailingslashit( $s ) { return $s; }
function add_query_arg() {
	$a = func_get_args();
	if ( is_array( $a[0] ) ) { return isset( $a[1] ) ? $a[1] : 'https://example.test/'; }
	return 'https://example.test/?' . $a[0] . '=' . $a[1];
}
function remove_query_arg( $k, $u = '' ) { return $u; }
function get_post( $id = null ) {
	static $p = null;
	if ( null === $p ) {
		$p = (object) array(
			'ID'           => 42,
			'post_title'   => 'A sample post title',
			'post_content' => '<p>Body copy with an <img src="https://example.test/a.jpg" class="wp-image-7" /> inside.</p>[vc_row]shortcode[/vc_row]',
			'post_type'    => 'post',
			'post_status'  => 'publish',
			'post_author'  => 3,
			'post_excerpt' => '',
			'post_date_gmt' => '2026-01-01 00:00:00',
		);
	}
	return $p;
}
function get_post_type( $id = 0 ) { return 'post'; }
function get_post_meta( $id, $key, $single = false ) {
	$map = array( '_wpd_title' => '', '_wpd_description' => '', '_wpd_noindex' => '' );
	return isset( $map[ $key ] ) ? $map[ $key ] : '';
}
function get_the_title( $p = 0 ) { return 'A sample post title'; }
function get_the_excerpt( $p = 0 ) { return 'An excerpt.'; }
function get_the_date( $f = '', $p = 0 ) { return '2026-01-01T00:00:00+00:00'; }
function get_the_modified_date( $f = '', $p = 0 ) { return '2026-02-01T00:00:00+00:00'; }
function get_post_modified_time( $f = '', $gmt = false, $p = 0 ) { return '2026-02-01T00:00:00+00:00'; }
function get_the_author_meta( $f, $id = 0 ) { return 'Jane Doe'; }
function get_post_type_object( $t ) { return (object) array( 'labels' => (object) array( 'name' => 'Posts' ), 'has_archive' => true, 'description' => '' ); }
function get_the_terms( $p, $tax ) { return array( (object) array( 'term_id' => 5, 'name' => 'News', 'taxonomy' => $tax ) ); }
function get_term( $id, $tax = '' ) { return (object) array( 'term_id' => $id, 'name' => 'News', 'taxonomy' => $tax ); }
function taxonomy_exists( $t ) { return false; }
function get_post_types( $a = array(), $o = 'names' ) { return array( 'post' => 'post', 'page' => 'page' ); }
function has_post_thumbnail( $p = 0 ) { return true; }
function get_post_thumbnail_id( $p = 0 ) { return 7; }
function attachment_url_to_postid( $u ) { return 7; }
function wp_get_attachment_image_src( $id, $size = 'full' ) { return array( 'https://example.test/hero.jpg', 1600, 900 ); }
function wp_get_attachment_image_sizes( $id, $size = 'full' ) { return '(max-width: 1600px) 100vw, 1600px'; }
function wp_get_attachment_image( $id, $size = '', $icon = false, $attr = array() ) { return '<img src="https://example.test/a.jpg" />'; }
function wp_strip_all_tags( $s, $br = false ) { return strip_tags( (string) $s ); }
function strip_shortcodes( $s ) { return (string) $s; }
function excerpt_remove_blocks( $s ) { return (string) $s; }
function esc_attr( $s ) { return htmlspecialchars( (string) $s, ENT_QUOTES, 'UTF-8' ); }
function esc_html( $s ) { return htmlspecialchars( (string) $s, ENT_QUOTES, 'UTF-8' ); }
function esc_textarea( $s ) { return htmlspecialchars( (string) $s, ENT_QUOTES, 'UTF-8' ); }
function esc_url( $s ) { return (string) $s; }
function esc_url_raw( $s ) { return (string) $s; }
function esc_js( $s ) { return (string) $s; }
function sanitize_text_field( $s ) { return trim( strip_tags( (string) $s ) ); }
function sanitize_textarea_field( $s ) { return (string) $s; }
function sanitize_key( $s ) { return preg_replace( '/[^a-z0-9_\-]/', '', strtolower( (string) $s ) ); }
function wp_unslash( $s ) { return $s; }
function wp_json_encode( $d, $f = 0 ) { return json_encode( $d, $f ); }
function wp_parse_url( $u, $c = -1 ) { return parse_url( (string) $u, $c ); }
function wp_list_pluck( $list, $field ) { return array_map( function ( $i ) use ( $field ) { return is_object( $i ) ? $i->$field : $i[ $field ]; }, (array) $list ); }
function wp_generate_password( $l = 12, $s = true ) { return str_repeat( 'a', $l ); }
function wp_get_theme() { return new class { public function get( $k ) { return 'TestTheme'; } }; }
function wp_get_current_user() { return (object) array( 'user_login' => 'admin' ); }
function get_num_queries() { return 42; }
function get_locale() { return "en_US"; }
function get_woocommerce_currency() { return "USD"; }
function wc_get_price_decimals() { return 2; }
function wc_format_decimal( $v, $d = 2 ) { return number_format( (float) $v, (int) $d, ".", "" ); }
function wc_get_page_id( $p ) { return 9; }
function is_cart() { return $GLOBALS["wpd_state"]["cart"]; }
function is_checkout() { return false; }
function is_account_page() { return false; }
function is_wc_endpoint_url( $e = "" ) { return false; }
function is_shop() { return false; }
function is_product() { return $GLOBALS["wpd_state"]["product"]; }
function is_product_category() { return false; }
function is_product_tag() { return false; }
function WC() { return null; }
function wc_get_product( $id ) { return $GLOBALS["wpd_state"]["product"] ? new WPD_Test_Product() : false; }
function timer_stop( $d = 0, $p = 3 ) { return '0.123'; }
function size_format( $b, $dec = 0 ) { return round( $b / 1024 ) . ' KB'; }
function mysql2date( $f, $d, $t = true ) { return '2026-01-01T00:00:00+00:00'; }
function get_comment_meta( $id, $k, $s = false ) { return 5; }
function shortcode_atts( $pairs, $atts, $sc = '' ) { return array_merge( $pairs, (array) $atts ); }
function wp_sitemaps_get_server() { return null; }
function wp_scripts() { return (object) array( 'registered' => array() ); }
function checked( $a, $b = true, $echo = true ) { return ''; }
function submit_button() { return ''; }
function wp_nonce_field() { return ''; }
function __( $s, $d = '' ) { return $s; }
function esc_html__( $s, $d = '' ) { return $s; }
function esc_attr__( $s, $d = '' ) { return $s; }
function esc_html_e( $s, $d = '' ) { echo $s; }
function _e( $s, $d = '' ) { echo $s; }
function ob_start_stub() {}

if ( ! defined( 'DATE_W3C' ) ) { define( 'DATE_W3C', 'Y-m-d\TH:i:sP' ); }

// ---------------------------------------------------------------- run ------

$errors = array();
set_error_handler( function ( $no, $str, $file, $line ) use ( &$errors ) {
	$errors[] = sprintf( '%s in %s:%d', $str, basename( $file ), $line );
	return true;
} );

$dir = dirname( __DIR__ ) . '/';

require_once $dir . 'includes/helpers.php';
require_once $dir . 'includes/class-wpd-options.php';
require_once $dir . 'includes/class-wpd-context.php';
require_once $dir . 'builders/class-wpd-builder-base.php';
require_once $dir . 'builders/class-wpd-builder-detect.php';
require_once $dir . 'includes/class-wpd-meta.php';
require_once $dir . 'includes/class-wpd-schema.php';
require_once $dir . 'includes/class-wpd-sitemap.php';
require_once $dir . 'includes/class-wpd-robots.php';
require_once $dir . 'includes/class-wpd-breadcrumbs.php';
require_once $dir . 'performance/class-wpd-perf.php';
require_once $dir . 'performance/class-wpd-assets.php';
require_once $dir . 'performance/class-wpd-images.php';
require_once $dir . 'performance/class-wpd-fonts.php';
require_once $dir . 'performance/class-wpd-html.php';
require_once $dir . 'performance/class-wpd-headers.php';
require_once $dir . 'custom/class-wpd-custom-theme.php';
require_once $dir . 'woocommerce/class-wpd-woo.php';
require_once $dir . 'includes/class-wpd-debug.php';

if ( ! defined( 'WPD_SEO_DIR' ) ) {
	define( 'WPD_SEO_DIR', $dir );
	define( 'WPD_SEO_URL', 'https://example.test/wp-content/plugins/seo/' );
	define( 'WPD_SEO_VERSION', '1.0.0' );
	define( 'WPD_SEO_FILE', $dir . 'wpd-seo.php' );
}

class WPD_SEO {
	private static $i = null;
	public static function instance() { if ( null === self::$i ) { self::$i = new self(); } return self::$i; }
	public function active_modules() { return array( "context", "meta", "schema", "perf", "assets", "images", "fonts", "html", "headers", "custom" ); }
}

class WPD_Test_Product {
	public function get_name() { return "Test Product"; }
	public function get_short_description() { return "A short description."; }
	public function get_description() { return "A long description."; }
	public function get_sku() { return "SKU-1"; }
	public function get_price() { return "19.99"; }
	public function is_in_stock() { return true; }
	public function is_on_backorder() { return false; }
	public function is_type( $t ) { return false; }
	public function get_image_id() { return 7; }
	public function get_gallery_image_ids() { return array( 8, 9 ); }
	public function get_children() { return array(); }
	public function get_review_count() { return 0; }
	public function get_average_rating() { return 0; }
	public function get_catalog_visibility() { return "visible"; }
	public function get_date_on_sale_to() { return null; }
	public function get_variation_prices( $b = true ) { return array(); }
}

function step( $label, callable $fn ) {
	try {
		$r = $fn();
		echo "  ok   $label\n";
		return $r;
	} catch ( \Throwable $e ) {
		echo "  FAIL $label :: " . get_class( $e ) . ': ' . $e->getMessage() . ' @ ' . basename( $e->getFile() ) . ':' . $e->getLine() . "\n";
		return null;
	}
}

foreach ( array( 'front page' => array( true, false ), 'singular post' => array( false, true ) ) as $scenario => $flags ) {
	echo "\n=== $scenario ===\n";
	$GLOBALS['wpd_state']['front']    = $flags[0];
	$GLOBALS['wpd_state']['singular'] = $flags[1];

	step( 'Options::maybe_upgrade', function () { WPD_Options::maybe_upgrade(); } );
	step( 'Builder_Detect', function () { return WPD_Builder_Detect::instance()->summary(); } );
	step( 'Context::type', function () { return WPD_Context::instance()->type(); } );
	step( 'Context::canonical', function () { return WPD_Context::instance()->canonical(); } );
	step( 'Context::is_indexable', function () { return WPD_Context::instance()->is_indexable(); } );
	step( 'Context::image_id', function () { return WPD_Context::instance()->image_id(); } );
	step( 'Meta::filter_title', function () { return WPD_Meta::instance()->filter_title( '' ); } );
	step( 'Meta::description', function () { return WPD_Meta::instance()->description(); } );
	step( 'Meta::filter_robots', function () { return WPD_Meta::instance()->filter_robots( array() ); } );
	step( 'Meta::render', function () { ob_start(); WPD_Meta::instance()->render(); return ob_get_clean(); } );
	step( 'Schema::render', function () { ob_start(); WPD_Schema::instance()->render(); return ob_get_clean(); } );
	step( 'Breadcrumbs::items', function () { return WPD_Breadcrumbs::instance()->items(); } );
	step( 'Breadcrumbs::render', function () { return WPD_Breadcrumbs::instance()->render(); } );
	step( 'Robots::filter', function () { return WPD_Robots::instance()->filter( "User-agent: *\nDisallow: /wp-admin/\nDisallow: /custom/", true ); } );
	step( 'Sitemap::add_lastmod', function () { return WPD_Sitemap::instance()->add_lastmod( array(), get_post() ); } );
	step( 'Sitemap::exclude_noindex', function () { return WPD_Sitemap::instance()->exclude_noindex_posts( array(), 'post' ); } );
	step( 'Perf::init', function () { WPD_Perf::instance()->init(); } );
	step( 'Perf::late_cleanup', function () { WPD_Perf::instance()->late_cleanup(); } );
	step( 'Assets::defer_tag', function () { return WPD_Assets::instance()->defer_tag( "<script src='https://x.test/a.js' id='a-js'></script>", 'a', 'https://x.test/a.js' ); } );
	step( 'Assets::defer_tag inline', function () { return WPD_Assets::instance()->defer_tag( '<script id="b">var x=1;</script>', 'b', '' ); } );
	step( 'Assets::delay_tag', function () { return WPD_Assets::instance()->delay_tag( "<script src='https://www.googletagmanager.com/gtm.js'></script>", 'gtm', 'https://www.googletagmanager.com/gtm.js' ); } );
	step( 'Assets::async_print_styles', function () { return WPD_Assets::instance()->async_print_styles( "<link rel='stylesheet' href='https://x.test/a.css' media='all' />", 'a', 'https://x.test/a.css', 'all' ); } );
	step( 'Assets::inline_critical_css', function () { WPD_Assets::instance()->inline_critical_css(); } );
	step( 'Images::preload_lcp', function () { ob_start(); WPD_Images::instance()->preload_lcp_image(); return ob_get_clean(); } );
	step( 'Images::attachment_attributes', function () { return WPD_Images::instance()->attachment_attributes( array(), get_post(), 'full' ); } );
	step( 'Images::process_content', function () { return WPD_Images::instance()->process_content_images( '<img src="/a.jpg"><img src="/b.jpg" data-src="/c.jpg">' ); } );
	step( 'Images::lazy_iframe', function () { return WPD_Images::instance()->lazy_iframe( '<iframe src="https://y.test"></iframe>' ); } );
	step( 'Fonts::preconnect', function () { ob_start(); WPD_Fonts::instance()->preconnect(); return ob_get_clean(); } );
	step( 'Fonts::preload_fonts', function () { ob_start(); WPD_Fonts::instance()->preload_fonts(); return ob_get_clean(); } );
	step( 'Fonts::google swap', function () { return WPD_Fonts::instance()->force_swap_on_google_fonts( "<link href='https://fonts.googleapis.com/css2?family=Inter' />", 'g', 'https://fonts.googleapis.com/css2?family=Inter', 'all' ); } );
	step( 'Html::process', function () { return WPD_Html::instance()->process( "<html><head>  <title>x</title></head>\n\n<body>  <p>Hi</p>  <!-- drop --><pre>  keep  </pre></body></html>" ); } );
	step( 'Html::process invalid utf8', function () { $r = WPD_Html::instance()->process( "<html><body>caf\xE9   broken</body></html>" ); return strlen( $r ) > 0 ? 'survived' : 'BLANK'; } );
	step( 'Headers::filter', function () { return WPD_Headers::instance()->filter_headers( array() ); } );
	step( 'Headers::send', function () { WPD_Headers::instance()->send_extra_headers(); } );
	step( 'Custom::repair_markup', function () { return WPD_Custom_Theme::instance()->repair_markup( '<html><head><meta name="viewport" content="a"><meta name="viewport" content="b"></head><body><a href="#" target="_blank">x</a><script>var s=\'target="_blank"\';</script></body></html>' ); } );
	step( 'Custom::add_missing_alt', function () { return WPD_Custom_Theme::instance()->add_missing_alt( '<img src="/a.jpg" class="wp-image-7">' ); } );
	step( 'Custom::external_link_attrs', function () { return WPD_Custom_Theme::instance()->external_link_attrs( array( 'target' => '_blank' ), null, null ); } );
	step( 'Woo (inactive)', function () { return WPD_Woo::instance(); } );
	step( 'Debug::report', function () { ob_start(); WPD_Debug::instance()->report(); return ob_get_clean(); } );
}

restore_error_handler();

echo "\n=== PHP notices / warnings / deprecations ===\n";
if ( $errors ) {
	foreach ( array_unique( $errors ) as $e ) {
		echo "  ! $e\n";
	}
} else {
	echo "  none\n";
}

// ------------------------------------------------- extra scenarios --------

echo "\n=== logged-in visitor (gate must be closed) ===\n";
$GLOBALS['wpd_state']['loggedin'] = true;
step( 'wpd_should_optimize() === false', function () {
	if ( wpd_should_optimize() ) { throw new \RuntimeException( 'gate is OPEN while logged in' ); }
	return true;
} );
step( 'defer_tag leaves tag alone', function () {
	$in  = "<script src='https://x.test/a.js'></script>";
	$out = WPD_Assets::instance()->defer_tag( $in, 'a', 'https://x.test/a.js' );
	if ( $out !== $in ) { throw new \RuntimeException( 'tag was modified while gate closed' ); }
	return true;
} );
step( 'images untouched', function () {
	$in  = '<img src="/a.jpg">';
	$out = WPD_Images::instance()->process_content_images( $in );
	if ( $out !== $in ) { throw new \RuntimeException( 'image was modified while gate closed' ); }
	return true;
} );
$GLOBALS['wpd_state']['loggedin'] = false;

echo "\n=== WooCommerce active ===\n";
if ( ! class_exists( 'WooCommerce' ) ) { eval( 'class WooCommerce {}' ); }
if ( ! defined( 'WC_VERSION' ) ) { define( 'WC_VERSION', '9.0.0' ); }
$GLOBALS['wpd_state']['product']  = true;
$GLOBALS['wpd_state']['singular'] = true;
$GLOBALS['wpd_state']['front']    = false;

require_once $dir . 'woocommerce/class-wpd-woo-seo.php';
require_once $dir . 'woocommerce/class-wpd-woo-schema.php';
require_once $dir . 'woocommerce/class-wpd-woo-perf.php';

step( 'Woo::is_active', function () { return WPD_Woo::is_active() ? true : ( function () { throw new \RuntimeException( 'not detected' ); } )(); } );
step( 'Woo::is_transactional_page', function () { return WPD_Woo::is_transactional_page(); } );
step( 'Woo::has_cart_contents', function () { return WPD_Woo::has_cart_contents(); } );
step( 'Woo::protected_handles', function () { return count( WPD_Woo::instance()->protected_handles( array() ) ); } );
step( 'Woo::cache_ttl', function () { return WPD_Woo::instance()->cache_ttl( 600 ); } );
step( 'Woo::no_store_headers', function () { return WPD_Woo::instance()->no_store_headers( array() ); } );
step( 'Woo_Seo::filter_indexable', function () { return WPD_Woo_Seo::instance()->filter_indexable( true, WPD_Context::instance() ); } );
step( 'Woo_Seo::filter_description', function () { return WPD_Woo_Seo::instance()->filter_description( '', WPD_Context::instance() ); } );
step( 'Woo_Seo::filter_image', function () { return WPD_Woo_Seo::instance()->filter_image( 0, WPD_Context::instance() ); } );
step( 'Woo_Seo::filter_og', function () { return WPD_Woo_Seo::instance()->filter_og( array(), WPD_Context::instance() ); } );
step( 'Woo_Seo::filter_canonical', function () { return WPD_Woo_Seo::instance()->filter_canonical( 'https://example.test/p/', WPD_Context::instance() ); } );
step( 'Woo_Seo::filter_breadcrumbs', function () { return WPD_Woo_Seo::instance()->filter_breadcrumbs( array( array( 'label' => 'Home', 'url' => 'https://example.test/' ) ), WPD_Context::instance() ); } );
step( 'Woo_Seo::sitemap_post_types', function () { return WPD_Woo_Seo::instance()->filter_sitemap_post_types( array( 'post' => 1, 'shop_order' => 1 ) ); } );
step( 'Woo_Schema::add_nodes', function () { return WPD_Woo_Schema::instance()->add_nodes( array(), WPD_Context::instance() ); } );
step( 'Woo_Perf::is_woo_page', function () { return WPD_Woo_Perf::is_woo_page(); } );
step( 'Woo_Perf::dequeue_non_woo', function () { WPD_Woo_Perf::instance()->dequeue_on_non_woo_pages(); } );
step( 'Woo_Perf::handle_cart_fragments', function () { WPD_Woo_Perf::instance()->handle_cart_fragments(); } );
step( 'Woo_Perf::dequeue_gallery', function () { WPD_Woo_Perf::instance()->dequeue_gallery_scripts(); } );
step( 'Woo_Perf::trim_block_styles', function () { WPD_Woo_Perf::instance()->trim_block_styles(); } );
step( 'Woo_Perf::prioritise_main_image', function () { return WPD_Woo_Perf::instance()->prioritise_main_image( '<img src="/p.jpg" loading="lazy">', 7 ); } );
step( 'Woo_Perf::trim_admin_features', function () { return WPD_Woo_Perf::instance()->trim_admin_features( array( 'marketing', 'analytics' ) ); } );

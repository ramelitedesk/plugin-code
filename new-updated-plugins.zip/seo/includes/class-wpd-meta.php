<?php
/**
 * Title, description, canonical, robots, Open Graph and Twitter tags.
 *
 * Bails entirely when Yoast / Rank Math / AIOSEO / SEOPress is active so two
 * plugins never print competing tags.
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

class WPD_Meta {

	/** @var WPD_Meta|null */
	private static $instance = null;

	/** @var bool */
	private $conflict = false;

	/** @var string|null Memoised title. */
	private $title_cache = null;

	/** @var string|null Memoised description. */
	private $desc_cache = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$this->conflict = self::has_conflicting_seo_plugin();

		// WPD_Schema calls into this class for titles/descriptions, so the
		// instance must be constructible even when the meta module is off —
		// it just must not register any output hooks in that case.
		if ( $this->conflict || ! WPD_Options::enabled( 'meta' ) ) {
			return;
		}

		add_theme_support( 'title-tag' );
		add_filter( 'pre_get_document_title', array( $this, 'filter_title' ), 20 );
		add_filter( 'document_title_separator', array( $this, 'filter_separator' ) );

		// Core prints its own rel=canonical; we replace it with a paged-aware one.
		remove_action( 'wp_head', 'rel_canonical' );
		add_action( 'wp_head', array( $this, 'render' ), 1 );

		add_filter( 'wp_robots', array( $this, 'filter_robots' ), 20 );
	}

	/**
	 * @return bool
	 */
	public static function has_conflicting_seo_plugin() {
		$conflict = defined( 'WPSEO_VERSION' )        // Yoast.
			|| defined( 'RANK_MATH_VERSION' )          // Rank Math.
			|| defined( 'AIOSEO_VERSION' )             // All in One SEO.
			|| defined( 'SEOPRESS_VERSION' )           // SEOPress.
			|| defined( 'SLIM_SEO_VER' );              // Slim SEO.

		return (bool) apply_filters( 'wpd_seo_meta_conflict', $conflict );
	}

	/**
	 * @param string $sep Separator.
	 * @return string
	 */
	public function filter_separator( $sep ) {
		$custom = (string) WPD_Options::get( 'title_separator', '|' );
		return '' !== $custom ? $custom : $sep;
	}

	/**
	 * @param string $title Current title.
	 * @return string
	 */
	public function filter_title( $title ) {
		/*
		 * Called five times per request (document title, og:title,
		 * twitter:title, schema WebPage name, schema headline). Without this
		 * memo, any user filter that appends to the title would append once per
		 * call and the tags would disagree with each other.
		 */
		if ( null !== $this->title_cache ) {
			return $this->title_cache;
		}

		$ctx    = WPD_Context::instance();
		$sep    = $this->filter_separator( '|' );
		$name   = get_bloginfo( 'name', 'display' );
		$custom = $ctx->post_id() ? (string) get_post_meta( $ctx->post_id(), '_wpd_title', true ) : '';

		if ( '' !== $custom ) {
			$built = $custom;
		} else {
			switch ( $ctx->type() ) {
				case 'front_page':
					$tagline = get_bloginfo( 'description', 'display' );
					$built   = $tagline ? $name . ' ' . $sep . ' ' . $tagline : $name;
					break;
				case 'home':
					$page_for_posts = (int) get_option( 'page_for_posts' );
					$built          = $page_for_posts ? get_the_title( $page_for_posts ) : __( 'Blog', 'wpd-seo' );
					$built         .= ' ' . $sep . ' ' . $name;
					break;
				case 'singular':
					$built = get_the_title( $ctx->post_id() ) . ' ' . $sep . ' ' . $name;
					break;
				case 'search':
					/* translators: %s: search term. */
					$built = sprintf( __( 'Search results for “%s”', 'wpd-seo' ), get_search_query() ) . ' ' . $sep . ' ' . $name;
					break;
				case '404':
					$built = __( 'Page not found', 'wpd-seo' ) . ' ' . $sep . ' ' . $name;
					break;
				default:
					$built = wp_strip_all_tags( get_the_archive_title() ) . ' ' . $sep . ' ' . $name;
			}
		}

		$paged = max( (int) get_query_var( 'paged' ), (int) get_query_var( 'page' ) );
		if ( $paged > 1 ) {
			/* translators: %d: page number. */
			$built .= ' ' . $sep . ' ' . sprintf( __( 'Page %d', 'wpd-seo' ), $paged );
		}

		$built = wpd_trim_text( $built, 65 );

		/**
		 * @param string $built Final document title.
		 * @param string $title Title WordPress would have used.
		 */
		$this->title_cache = (string) apply_filters( 'wpd_seo_title', $built, $title );

		return $this->title_cache;
	}

	/**
	 * @return string
	 */
	public function description() {
		if ( null !== $this->desc_cache ) {
			return $this->desc_cache;
		}

		$ctx  = WPD_Context::instance();
		$text = wpd_trim_text( $ctx->description_source(), 158 );

		$this->desc_cache = (string) apply_filters( 'wpd_seo_description', $text, $ctx );

		return $this->desc_cache;
	}

	/**
	 * @param array $robots Robots directives.
	 * @return array
	 */
	public function filter_robots( $robots ) {
		$ctx = WPD_Context::instance();

		if ( ! $ctx->is_indexable() ) {
			$robots['noindex']  = true;
			$robots['nofollow'] = false;
			unset( $robots['index'] );
			return $robots;
		}

		$robots['index']              = true;
		$robots['follow']             = true;
		$robots['max-image-preview']  = 'large';
		$robots['max-snippet']        = -1;
		$robots['max-video-preview']  = -1;

		return $robots;
	}

	/**
	 * Print the head block.
	 */
	public function render() {
		$ctx         = WPD_Context::instance();
		$description = $this->description();
		$canonical   = $ctx->canonical();

		echo "\n<!-- WPD SEO " . esc_html( WPD_SEO_VERSION ) . " -->\n";

		if ( '' !== $description ) {
			printf( "<meta name=\"description\" content=\"%s\" />\n", esc_attr( $description ) );
		}
		if ( '' !== $canonical ) {
			printf( "<link rel=\"canonical\" href=\"%s\" />\n", esc_url( $canonical ) );
		}

		$this->render_pagination_links();

		if ( WPD_Options::enabled( 'og_enabled' ) ) {
			$this->render_open_graph( $description, $canonical );
			$this->render_twitter( $description );
		}

		echo "<!-- /WPD SEO -->\n";
	}

	private function render_pagination_links() {
		global $wp_query;

		$paged = (int) get_query_var( 'paged' );
		$max   = isset( $wp_query->max_num_pages ) ? (int) $wp_query->max_num_pages : 0;

		if ( $max < 2 || is_singular() ) {
			return;
		}
		if ( $paged > 1 ) {
			printf( "<link rel=\"prev\" href=\"%s\" />\n", esc_url( get_pagenum_link( $paged - 1 ) ) );
		}
		if ( $paged < $max ) {
			printf( "<link rel=\"next\" href=\"%s\" />\n", esc_url( get_pagenum_link( max( $paged, 1 ) + 1 ) ) );
		}
	}

	/**
	 * @param string $description Meta description.
	 * @param string $canonical   Canonical URL.
	 */
	private function render_open_graph( $description, $canonical ) {
		$ctx  = WPD_Context::instance();
		$tags = array(
			'og:locale'    => get_locale(),
			'og:site_name' => get_bloginfo( 'name', 'display' ),
			'og:type'      => is_singular( 'post' ) ? 'article' : 'website',
			'og:title'     => $this->filter_title( '' ),
			'og:url'       => $canonical,
		);

		if ( '' !== $description ) {
			$tags['og:description'] = $description;
		}

		$image_id = $ctx->image_id();
		if ( $image_id ) {
			$src = wp_get_attachment_image_src( $image_id, 'full' );
			if ( $src ) {
				$tags['og:image']        = $src[0];
				$tags['og:image:width']  = $src[1];
				$tags['og:image:height'] = $src[2];
				$alt                     = get_post_meta( $image_id, '_wp_attachment_image_alt', true );
				if ( $alt ) {
					$tags['og:image:alt'] = $alt;
				}
			}
		}

		if ( is_singular( 'post' ) ) {
			$tags['article:published_time'] = get_the_date( DATE_W3C, $ctx->post_id() );
			$tags['article:modified_time']  = get_the_modified_date( DATE_W3C, $ctx->post_id() );
		}

		/**
		 * @param array $tags Property => content.
		 */
		$tags = apply_filters( 'wpd_seo_og_tags', $tags, $ctx );

		foreach ( $tags as $property => $content ) {
			if ( '' === (string) $content ) {
				continue;
			}
			printf( "<meta property=\"%s\" content=\"%s\" />\n", esc_attr( $property ), esc_attr( $content ) );
		}
	}

	/**
	 * @param string $description Meta description.
	 */
	private function render_twitter( $description ) {
		$card = (string) WPD_Options::get( 'twitter_card', 'summary_large_image' );
		$site = trim( (string) WPD_Options::get( 'twitter_site', '' ) );

		$tags = array(
			'twitter:card'  => $card,
			'twitter:title' => $this->filter_title( '' ),
		);
		if ( '' !== $description ) {
			$tags['twitter:description'] = $description;
		}
		if ( '' !== $site ) {
			$tags['twitter:site'] = '@' . ltrim( $site, '@' );
		}

		$tags = apply_filters( 'wpd_seo_twitter_tags', $tags, WPD_Context::instance() );

		foreach ( $tags as $name => $content ) {
			if ( '' === (string) $content ) {
				continue;
			}
			printf( "<meta name=\"%s\" content=\"%s\" />\n", esc_attr( $name ), esc_attr( $content ) );
		}
	}
}

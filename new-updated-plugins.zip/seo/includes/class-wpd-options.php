<?php
/**
 * Single source of truth for settings + defaults.
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

class WPD_Options {

	const OPTION = 'wpd_seo_settings';

	/**
	 * Bump when stored settings need repairing. See maybe_upgrade().
	 */
	const SCHEMA_VERSION = 2;

	/**
	 * Module switches with no checkbox on the settings screen. They are
	 * code-level only (via the wpd_seo_module_{key} filter), so the save
	 * handler must never infer "off" from their absence in $_POST.
	 */
	const INTERNAL_KEYS = array(
		'context',
		'meta',
		'perf',
		'assets',
		'images',
		'fonts',
		'html',
		'headers',
		'custom',
		'woo',
	);

	/** @var array|null */
	private static $cache = null;

	/**
	 * @return array
	 */
	public static function defaults() {
		return apply_filters(
			'wpd_seo_default_settings',
			array(
				'_schema'              => self::SCHEMA_VERSION,

				// Modules.
				'meta'                 => 1,
				'schema'               => 1,
				'sitemap'              => 1,
				'robots'               => 1,
				'breadcrumbs'          => 1,
				'perf'                 => 1,
				'assets'               => 1,
				'images'               => 1,
				'fonts'                => 1,
				'html'                 => 1,
				'headers'              => 1,
				'context'              => 1,
				'custom'               => 1,
				'woo'                  => 1,

				// WooCommerce.
				'woo_schema'              => 1,
				'woo_noindex_pages'       => 1,
				'woo_conditional_assets'  => 1,
				'woo_disable_cart_fragments' => 1,

				// SEO.
				'title_separator'      => '|',
				'og_enabled'           => 1,
				'twitter_card'         => 'summary_large_image',
				'twitter_site'         => '',
				'org_name'             => '',
				'org_logo'             => '',
				'org_type'             => 'Organization',
				'social_profiles'      => '',
				'noindex_search'       => 1,
				'noindex_archives'     => 0,
				'noindex_attachment'   => 1,

				// Performance.
				'defer_js'             => 1,
				'delay_js_until_input' => 0,
				'remove_emojis'        => 1,
				'remove_embeds'        => 1,
				'remove_block_css'     => 0,
				'disable_dashicons'    => 1,
				'jquery_migrate'       => 1,
				'lazy_images'          => 1,
				'lcp_priority'         => 1,
				'add_dimensions'       => 1,
				'preload_fonts'        => '',
				'font_display_swap'    => 1,
				'preconnect'           => "https://fonts.gstatic.com",
				'minify_html'          => 1,
				'critical_css'         => '',
				'cache_headers'        => 1,
				'heartbeat_throttle'   => 1,

				// Diagnostics. The token is generated on first admin load.
				'debug_token'          => '',
			)
		);
	}

	/**
	 * @return array
	 */
	public static function all() {
		if ( null === self::$cache ) {
			$saved       = get_option( self::OPTION, array() );
			self::$cache = wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
		}
		return self::$cache;
	}

	/**
	 * @param string $key     Setting key.
	 * @param mixed  $default Fallback.
	 * @return mixed
	 */
	public static function get( $key, $default = null ) {
		$all   = self::all();
		$value = array_key_exists( $key, $all ) ? $all[ $key ] : $default;
		return apply_filters( 'wpd_seo_option', $value, $key );
	}

	/**
	 * @param string $key Setting key.
	 * @return bool
	 */
	public static function enabled( $key ) {
		return (bool) self::get( $key, false );
	}

	/**
	 * @param array $values Raw values to persist.
	 */
	public static function update( array $values ) {
		$clean = wp_parse_args( $values, self::all() );
		update_option( self::OPTION, $clean );
		self::$cache = null;
	}

	public static function install_defaults() {
		if ( false === get_option( self::OPTION, false ) ) {
			add_option( self::OPTION, self::defaults() );
		}
	}

	/**
	 * Repair stored settings written by an older version.
	 *
	 * v2: a save from the settings screen used to switch off every module key
	 * that has no checkbox in the form — which silently disabled the entire
	 * performance layer. Restore those keys to their defaults once.
	 */
	public static function maybe_upgrade() {
		$saved = get_option( self::OPTION, false );

		if ( false === $saved || ! is_array( $saved ) ) {
			return;
		}

		$version = isset( $saved['_schema'] ) ? (int) $saved['_schema'] : 1;
		if ( $version >= self::SCHEMA_VERSION ) {
			return;
		}

		$defaults = self::defaults();
		foreach ( self::INTERNAL_KEYS as $key ) {
			if ( empty( $saved[ $key ] ) && ! empty( $defaults[ $key ] ) ) {
				$saved[ $key ] = $defaults[ $key ];
			}
		}

		$saved['_schema'] = self::SCHEMA_VERSION;

		update_option( self::OPTION, $saved );
		self::$cache = null;
	}

	/**
	 * Split a textarea of one-per-line values into a clean array.
	 *
	 * @param string $key Setting key.
	 * @return array
	 */
	public static function lines( $key ) {
		$raw = (string) self::get( $key, '' );
		if ( '' === trim( $raw ) ) {
			return array();
		}
		return array_values( array_filter( array_map( 'trim', preg_split( '/[\r\n,]+/', $raw ) ) ) );
	}
}

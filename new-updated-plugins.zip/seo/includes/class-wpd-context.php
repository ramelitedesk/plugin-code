<?php
/**
 * Request context: what kind of page is this, what is its canonical URL, and
 * should it be indexed. Every other module reads from here so the answers stay
 * consistent (and get computed once).
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

class WPD_Context {

	/** @var WPD_Context|null */
	private static $instance = null;

	/** @var array Memoised values. */
	private $cache = array();

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp', array( $this, 'reset' ), 1 );
	}

	public function reset() {
		$this->cache = array();
	}

	/**
	 * One of: home, front_page, singular, category, tag, tax, author, date,
	 * post_type_archive, search, 404, archive.
	 *
	 * @return string
	 */
	public function type() {
		if ( isset( $this->cache['type'] ) ) {
			return $this->cache['type'];
		}

		$type = 'archive';
		if ( is_front_page() && is_home() ) {
			$type = 'front_page';
		} elseif ( is_front_page() ) {
			$type = 'front_page';
		} elseif ( is_home() ) {
			$type = 'home';
		} elseif ( is_singular() ) {
			$type = 'singular';
		} elseif ( is_search() ) {
			$type = 'search';
		} elseif ( is_404() ) {
			$type = '404';
		} elseif ( is_category() ) {
			$type = 'category';
		} elseif ( is_tag() ) {
			$type = 'tag';
		} elseif ( is_tax() ) {
			$type = 'tax';
		} elseif ( is_author() ) {
			$type = 'author';
		} elseif ( is_date() ) {
			$type = 'date';
		} elseif ( is_post_type_archive() ) {
			$type = 'post_type_archive';
		}

		$this->cache['type'] = $type;
		return $type;
	}

	/**
	 * @return int Queried post ID, or 0 on non-singular views.
	 */
	public function post_id() {
		return is_singular() ? (int) get_queried_object_id() : 0;
	}

	/**
	 * @return WPD_Builder_Base|null
	 */
	public function builder() {
		if ( ! array_key_exists( 'builder', $this->cache ) ) {
			$this->cache['builder'] = class_exists( 'WPD_Builder_Detect' )
				? WPD_Builder_Detect::instance()->builder_for( $this->post_id() )
				: null;
		}
		return $this->cache['builder'];
	}

	/**
	 * Canonical URL for the current request, paged-aware.
	 *
	 * @return string
	 */
	public function canonical() {
		if ( isset( $this->cache['canonical'] ) ) {
			return $this->cache['canonical'];
		}

		$canonical = '';

		switch ( $this->type() ) {
			case 'front_page':
				$canonical = home_url( '/' );
				break;
			case 'home':
				$page_for_posts = (int) get_option( 'page_for_posts' );
				$canonical      = $page_for_posts ? get_permalink( $page_for_posts ) : home_url( '/' );
				break;
			case 'singular':
				$canonical = get_permalink( $this->post_id() );
				break;
			case 'category':
			case 'tag':
			case 'tax':
				$term = get_queried_object();
				if ( $term && ! is_wp_error( $term ) && isset( $term->term_id ) ) {
					$link = get_term_link( $term );
					$canonical = is_wp_error( $link ) ? '' : $link;
				}
				break;
			case 'author':
				$canonical = get_author_posts_url( (int) get_queried_object_id() );
				break;
			case 'post_type_archive':
				$link      = get_post_type_archive_link( get_query_var( 'post_type' ) );
				$canonical = $link ? $link : '';
				break;
			case 'search':
				$canonical = get_search_link( get_search_query() );
				break;
			case 'date':
				$canonical = wpd_current_url();
				break;
		}

		if ( $canonical ) {
			$paged = max( (int) get_query_var( 'paged' ), (int) get_query_var( 'page' ) );
			if ( $paged > 1 ) {
				$canonical = is_singular()
					? trailingslashit( $canonical ) . $paged . '/'
					: trailingslashit( $canonical ) . 'page/' . $paged . '/';
			}
		}

		/**
		 * @param string      $canonical Canonical URL.
		 * @param WPD_Context $context   Context object.
		 */
		$canonical = apply_filters( 'wpd_seo_canonical', $canonical, $this );

		$this->cache['canonical'] = esc_url_raw( $canonical );
		return $this->cache['canonical'];
	}

	/**
	 * Should this view be indexed?
	 *
	 * @return bool
	 */
	public function is_indexable() {
		if ( isset( $this->cache['index'] ) ) {
			return $this->cache['index'];
		}

		$index = true;

		if ( '0' === (string) get_option( 'blog_public' ) ) {
			$index = false;
		} elseif ( '404' === $this->type() ) {
			$index = false;
		} elseif ( 'search' === $this->type() && WPD_Options::enabled( 'noindex_search' ) ) {
			$index = false;
		} elseif ( is_attachment() && WPD_Options::enabled( 'noindex_attachment' ) ) {
			$index = false;
		} elseif ( is_archive() && WPD_Options::enabled( 'noindex_archives' ) ) {
			$index = false;
		} elseif ( is_paged() && (int) get_query_var( 'paged' ) > 1 && apply_filters( 'wpd_seo_noindex_paged', false ) ) {
			$index = false;
		}

		if ( $index && $this->post_id() ) {
			$post = get_post( $this->post_id() );
			if ( $post && ( 'private' === $post->post_status || post_password_required( $post ) ) ) {
				$index = false;
			}
			if ( '1' === (string) get_post_meta( $this->post_id(), '_wpd_noindex', true ) ) {
				$index = false;
			}
		}

		$this->cache['index'] = (bool) apply_filters( 'wpd_seo_is_indexable', $index, $this );
		return $this->cache['index'];
	}

	/**
	 * Raw description source text for the current view.
	 *
	 * @return string
	 */
	public function description_source() {
		if ( isset( $this->cache['desc_src'] ) ) {
			return $this->cache['desc_src'];
		}

		$text = '';

		switch ( $this->type() ) {
			case 'front_page':
			case 'home':
				$front = (int) get_option( 'page_on_front' );
				if ( 'front_page' === $this->type() && $front ) {
					$text = $this->post_text( $front );
				}
				if ( '' === trim( (string) $text ) ) {
					$text = get_bloginfo( 'description' );
				}
				break;
			case 'singular':
				$post_id = $this->post_id();
				$custom  = (string) get_post_meta( $post_id, '_wpd_description', true );
				if ( '' !== $custom ) {
					$text = $custom;
					break;
				}
				$excerpt = has_excerpt( $post_id ) ? get_the_excerpt( $post_id ) : '';
				$text    = '' !== trim( $excerpt ) ? $excerpt : $this->post_text( $post_id );
				break;
			case 'category':
			case 'tag':
			case 'tax':
				$term = get_queried_object();
				$text = ( $term && isset( $term->description ) ) ? $term->description : '';
				if ( '' === trim( (string) $text ) && isset( $term->name ) ) {
					/* translators: %s: term name. */
					$text = sprintf( __( 'Browse everything filed under %s.', 'wpd-seo' ), $term->name );
				}
				break;
			case 'author':
				$text = get_the_author_meta( 'description', (int) get_queried_object_id() );
				break;
			case 'post_type_archive':
				$obj  = get_post_type_object( get_query_var( 'post_type' ) );
				$text = $obj && ! empty( $obj->description ) ? $obj->description : get_bloginfo( 'description' );
				break;
			default:
				$text = get_bloginfo( 'description' );
		}

		$this->cache['desc_src'] = (string) $text;
		return $this->cache['desc_src'];
	}

	/**
	 * Builder-aware content text for a post.
	 *
	 * @param int $post_id Post ID.
	 * @return string
	 */
	public function post_text( $post_id ) {
		if ( class_exists( 'WPD_Builder_Detect' ) ) {
			return WPD_Builder_Detect::instance()->text_for( $post_id );
		}
		$post = get_post( $post_id );
		return $post ? (string) $post->post_content : '';
	}

	/**
	 * Representative / LCP image for the current view.
	 *
	 * @return int Attachment ID or 0.
	 */
	public function image_id() {
		if ( isset( $this->cache['image'] ) ) {
			return $this->cache['image'];
		}

		$id = 0;
		if ( $this->post_id() && class_exists( 'WPD_Builder_Detect' ) ) {
			$id = WPD_Builder_Detect::instance()->hero_image_for( $this->post_id() );
		}
		if ( ! $id ) {
			$fallback = (string) WPD_Options::get( 'org_logo', '' );
			$id       = $fallback ? (int) attachment_url_to_postid( $fallback ) : 0;
		}

		$this->cache['image'] = (int) apply_filters( 'wpd_seo_image_id', $id, $this );
		return $this->cache['image'];
	}
}

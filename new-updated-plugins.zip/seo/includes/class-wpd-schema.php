<?php
/**
 * JSON-LD structured data as a single connected @graph — the shape Google
 * prefers and the one Rich Results Test scores cleanly.
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

class WPD_Schema {

	/** @var WPD_Schema|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		if ( WPD_Meta::has_conflicting_seo_plugin() ) {
			return;
		}
		add_action( 'wp_head', array( $this, 'render' ), 5 );
	}

	public function render() {
		$graph = array_values( array_filter( array(
			$this->publisher(),
			$this->website(),
			$this->webpage(),
			$this->primary_entity(),
			$this->breadcrumb_list(),
		) ) );

		/**
		 * @param array $graph JSON-LD graph nodes.
		 */
		$graph = apply_filters( 'wpd_seo_schema_graph', $graph, WPD_Context::instance() );

		if ( ! $graph ) {
			return;
		}

		$json = wp_json_encode(
			array(
				'@context' => 'https://schema.org',
				'@graph'   => $graph,
			),
			JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
		);

		echo '<script type="application/ld+json">' . $json . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_json_encode output.
	}

	/**
	 * @return string
	 */
	private function id( $fragment ) {
		return home_url( '/' ) . '#' . $fragment;
	}

	/**
	 * Organization or Person that publishes the site.
	 *
	 * @return array
	 */
	private function publisher() {
		$type = (string) WPD_Options::get( 'org_type', 'Organization' );
		$name = (string) WPD_Options::get( 'org_name', '' );
		if ( '' === $name ) {
			$name = get_bloginfo( 'name', 'display' );
		}

		$node = array(
			'@type' => in_array( $type, array( 'Organization', 'Person', 'LocalBusiness' ), true ) ? $type : 'Organization',
			'@id'   => $this->id( 'publisher' ),
			'name'  => $name,
			'url'   => home_url( '/' ),
		);

		$logo = (string) WPD_Options::get( 'org_logo', '' );
		if ( '' !== $logo ) {
			$node['logo'] = array(
				'@type' => 'ImageObject',
				'@id'   => $this->id( 'logo' ),
				'url'   => $logo,
			);
			$node['image'] = array( '@id' => $this->id( 'logo' ) );
		}

		$profiles = WPD_Options::lines( 'social_profiles' );
		if ( $profiles ) {
			$node['sameAs'] = array_map( 'esc_url_raw', $profiles );
		}

		return $node;
	}

	/**
	 * @return array
	 */
	private function website() {
		$node = array(
			'@type'     => 'WebSite',
			'@id'       => $this->id( 'website' ),
			'url'       => home_url( '/' ),
			'name'      => get_bloginfo( 'name', 'display' ),
			'publisher' => array( '@id' => $this->id( 'publisher' ) ),
			'inLanguage' => get_bloginfo( 'language' ),
		);

		$description = get_bloginfo( 'description', 'display' );
		if ( $description ) {
			$node['description'] = $description;
		}

		if ( apply_filters( 'wpd_seo_schema_sitelinks_searchbox', true ) ) {
			$node['potentialAction'] = array(
				array(
					'@type'       => 'SearchAction',
					'target'      => array(
						'@type'       => 'EntryPoint',
						'urlTemplate' => home_url( '/?s={search_term_string}' ),
					),
					'query-input' => 'required name=search_term_string',
				),
			);
		}

		return $node;
	}

	/**
	 * @return array
	 */
	private function webpage() {
		$ctx  = WPD_Context::instance();
		$url  = $ctx->canonical();
		if ( '' === $url ) {
			return array();
		}

		$node = array(
			'@type'      => 'WebPage',
			'@id'        => $url . '#webpage',
			'url'        => $url,
			'name'       => wp_strip_all_tags( WPD_Meta::instance()->filter_title( '' ) ),
			'isPartOf'   => array( '@id' => $this->id( 'website' ) ),
			'inLanguage' => get_bloginfo( 'language' ),
		);

		$description = WPD_Meta::instance()->description();
		if ( '' !== $description ) {
			$node['description'] = $description;
		}

		if ( 'front_page' === $ctx->type() ) {
			$node['@type'] = 'WebPage';
			$node['about'] = array( '@id' => $this->id( 'publisher' ) );
		}

		if ( $ctx->post_id() ) {
			$node['datePublished'] = get_the_date( DATE_W3C, $ctx->post_id() );
			$node['dateModified']  = get_the_modified_date( DATE_W3C, $ctx->post_id() );
		}

		$image = $this->image_node();
		if ( $image ) {
			$node['primaryImageOfPage'] = array( '@id' => $image['@id'] );
			$node['image']              = array( '@id' => $image['@id'] );
		}

		if ( class_exists( 'WPD_Breadcrumbs' ) && WPD_Options::enabled( 'breadcrumbs' ) ) {
			$node['breadcrumb'] = array( '@id' => $url . '#breadcrumb' );
		}

		return $node;
	}

	/**
	 * Article / Product-ish node for singular views.
	 *
	 * @return array
	 */
	private function primary_entity() {
		$ctx = WPD_Context::instance();
		if ( ! $ctx->post_id() ) {
			return array();
		}

		$post_id = $ctx->post_id();
		$post    = get_post( $post_id );
		if ( ! $post ) {
			return array();
		}

		/**
		 * Post types that get no Article node. Products are here because
		 * WPD_Woo_Schema adds a Product node instead — two primary entities on
		 * one page is worse than none.
		 *
		 * @param string[] $skip Post types to skip.
		 */
		$skip = apply_filters( 'wpd_seo_schema_skip_post_types', array( 'page', 'product', 'attachment' ) );
		if ( in_array( $post->post_type, (array) $skip, true ) ) {
			return array();
		}

		$url  = $ctx->canonical();
		$node = array(
			'@type'            => apply_filters( 'wpd_seo_schema_article_type', 'Article', $post ),
			'@id'              => $url . '#article',
			'isPartOf'         => array( '@id' => $url . '#webpage' ),
			'mainEntityOfPage' => array( '@id' => $url . '#webpage' ),
			'headline'         => wpd_trim_text( get_the_title( $post_id ), 110 ),
			'datePublished'    => get_the_date( DATE_W3C, $post_id ),
			'dateModified'     => get_the_modified_date( DATE_W3C, $post_id ),
			'publisher'        => array( '@id' => $this->id( 'publisher' ) ),
			'inLanguage'       => get_bloginfo( 'language' ),
		);

		$author_id = (int) $post->post_author;
		if ( $author_id ) {
			$node['author'] = array(
				'@type' => 'Person',
				'@id'   => home_url( '/#author-' . $author_id ),
				'name'  => get_the_author_meta( 'display_name', $author_id ),
				'url'   => get_author_posts_url( $author_id ),
			);
		}

		$description = WPD_Meta::instance()->description();
		if ( '' !== $description ) {
			$node['description'] = $description;
		}

		$image = $this->image_node();
		if ( $image ) {
			$node['image'] = array( '@id' => $image['@id'] );
		}

		$terms = get_the_terms( $post_id, 'category' );
		if ( $terms && ! is_wp_error( $terms ) ) {
			$node['articleSection'] = wp_list_pluck( $terms, 'name' );
		}

		return $node;
	}

	/**
	 * @return array
	 */
	private function image_node() {
		static $node = null;
		if ( null !== $node ) {
			return $node;
		}

		$node     = array();
		$image_id = WPD_Context::instance()->image_id();
		if ( ! $image_id ) {
			return $node;
		}

		$src = wp_get_attachment_image_src( $image_id, 'full' );
		if ( ! $src ) {
			return $node;
		}

		$node = array(
			'@type'      => 'ImageObject',
			'@id'        => WPD_Context::instance()->canonical() . '#primaryimage',
			'url'        => $src[0],
			'contentUrl' => $src[0],
			'width'      => $src[1],
			'height'     => $src[2],
		);

		$alt = get_post_meta( $image_id, '_wp_attachment_image_alt', true );
		if ( $alt ) {
			$node['caption'] = $alt;
		}

		// The node itself is emitted through the graph filter below.
		add_filter(
			'wpd_seo_schema_graph',
			function ( $graph ) use ( $node ) {
				$graph[] = $node;
				return $graph;
			},
			5
		);

		return $node;
	}

	/**
	 * @return array
	 */
	private function breadcrumb_list() {
		if ( ! class_exists( 'WPD_Breadcrumbs' ) || ! WPD_Options::enabled( 'breadcrumbs' ) ) {
			return array();
		}

		$items = WPD_Breadcrumbs::instance()->items();
		if ( count( $items ) < 2 ) {
			return array();
		}

		$list = array();
		foreach ( array_values( $items ) as $i => $item ) {
			$entry = array(
				'@type'    => 'ListItem',
				'position' => $i + 1,
				'name'     => $item['label'],
			);
			if ( ! empty( $item['url'] ) ) {
				$entry['item'] = $item['url'];
			}
			$list[] = $entry;
		}

		return array(
			'@type'           => 'BreadcrumbList',
			'@id'             => WPD_Context::instance()->canonical() . '#breadcrumb',
			'itemListElement' => $list,
		);
	}
}

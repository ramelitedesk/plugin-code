<?php
/**
 * Shared helpers. Deliberately procedural + prefixed so theme authors can call
 * them from templates without touching the class layer.
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'wpd_seo' ) ) {
	/**
	 * @return WPD_SEO
	 */
	function wpd_seo() {
		return WPD_SEO::instance();
	}
}

if ( ! function_exists( 'wpd_is_builder_editor' ) ) {
	/**
	 * True while a page builder editor / preview iframe is rendering.
	 * Every optimisation must bail here or builders break.
	 */
	function wpd_is_builder_editor() {
		return class_exists( 'WPD_Builder_Detect' ) && WPD_Builder_Detect::instance()->is_editing();
	}
}

if ( ! function_exists( 'wpd_should_optimize' ) ) {
	/**
	 * Global gate for every front-end optimisation.
	 */
	function wpd_should_optimize() {
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
			return false;
		}
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return false;
		}
		if ( is_customize_preview() || wpd_is_builder_editor() ) {
			return false;
		}
		if ( is_user_logged_in() && ! apply_filters( 'wpd_seo_optimize_logged_in', false ) ) {
			return false;
		}
		if ( is_feed() || is_embed() || is_preview() ) {
			return false;
		}
		return apply_filters( 'wpd_seo_should_optimize', true );
	}
}

if ( ! function_exists( 'wpd_preg_replace' ) ) {
	/**
	 * preg_replace() that can never destroy the subject.
	 *
	 * PCRE returns null on failure — invalid UTF-8 with the /u modifier, or a
	 * blown backtrack limit on a large page. Assigning that null back to the
	 * page HTML is how an optimisation plugin serves a blank screen. This
	 * wrapper keeps the original string whenever the replace did not succeed.
	 *
	 * @param string $pattern     Regex.
	 * @param string $replacement Replacement.
	 * @param string $subject     Subject.
	 * @param int    $limit       Max replacements.
	 * @return string
	 */
	function wpd_preg_replace( $pattern, $replacement, $subject, $limit = -1 ) {
		$subject = (string) $subject;
		$result  = preg_replace( $pattern, $replacement, $subject, $limit );

		if ( null === $result || PREG_NO_ERROR !== preg_last_error() ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG && function_exists( 'error_log' ) ) {
				error_log( 'WPD SEO: regex failed (' . preg_last_error_msg() . '), original output kept.' ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			}
			return $subject;
		}

		return $result;
	}
}

if ( ! function_exists( 'preg_last_error_msg' ) ) {
	/**
	 * Polyfill for PHP < 8.0.
	 *
	 * @return string
	 */
	function preg_last_error_msg() {
		return 'preg error ' . preg_last_error();
	}
}

if ( ! function_exists( 'wpd_trim_text' ) ) {
	/**
	 * Word-safe truncation for meta descriptions / titles.
	 *
	 * @param string $text  Raw text.
	 * @param int    $limit Character budget.
	 * @return string
	 */
	function wpd_trim_text( $text, $limit = 160 ) {
		$text = wp_strip_all_tags( strip_shortcodes( (string) $text ), true );
		$text = wpd_preg_replace( '/\s+/u', ' ', $text );
		$text = trim( (string) html_entity_decode( $text, ENT_QUOTES, 'UTF-8' ) );

		if ( '' === $text || mb_strlen( $text ) <= $limit ) {
			return $text;
		}

		$cut = mb_substr( $text, 0, $limit );
		$pos = mb_strrpos( $cut, ' ' );
		if ( false !== $pos && $pos > (int) ( $limit * 0.6 ) ) {
			$cut = mb_substr( $cut, 0, $pos );
		}
		return rtrim( $cut, " ,.;:-" ) . '…';
	}
}

if ( ! function_exists( 'wpd_first_image_id' ) ) {
	/**
	 * Best-guess representative image for a post: featured image, then the first
	 * attachment referenced in the content (works for builder markup too).
	 *
	 * @param int $post_id Post ID.
	 * @return int Attachment ID or 0.
	 */
	function wpd_first_image_id( $post_id ) {
		$post_id = (int) $post_id;
		if ( has_post_thumbnail( $post_id ) ) {
			return (int) get_post_thumbnail_id( $post_id );
		}

		$post = get_post( $post_id );
		if ( ! $post ) {
			return 0;
		}

		if ( preg_match( '/wp-image-(\d+)/', (string) $post->post_content, $m ) ) {
			return (int) $m[1];
		}
		if ( preg_match( '/<img[^>]+src=["\']([^"\']+)["\']/i', (string) $post->post_content, $m ) ) {
			return (int) attachment_url_to_postid( $m[1] );
		}
		return 0;
	}
}

if ( ! function_exists( 'wpd_absolute_url' ) ) {
	/**
	 * Normalise a possibly protocol-relative / relative URL to absolute.
	 *
	 * @param string $url URL.
	 * @return string
	 */
	function wpd_absolute_url( $url ) {
		$url = trim( (string) $url );
		if ( '' === $url ) {
			return '';
		}
		if ( 0 === strpos( $url, '//' ) ) {
			return ( is_ssl() ? 'https:' : 'http:' ) . $url;
		}
		if ( 0 === strpos( $url, '/' ) ) {
			return home_url( $url );
		}
		return $url;
	}
}

if ( ! function_exists( 'wpd_is_local_asset' ) ) {
	/**
	 * @param string $url Asset URL.
	 * @return bool
	 */
	function wpd_is_local_asset( $url ) {
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		$test = wp_parse_url( wpd_absolute_url( $url ), PHP_URL_HOST );
		return ! $test || $test === $host;
	}
}

if ( ! function_exists( 'wpd_current_url' ) ) {
	/**
	 * Canonical-safe current URL (query strings stripped unless whitelisted).
	 *
	 * @return string
	 */
	function wpd_current_url() {
		global $wp;
		$url = home_url( add_query_arg( array(), $wp ? $wp->request : '' ) );
		return user_trailingslashit( $url );
	}
}

<?php
/**
 * Virtual robots.txt.
 *
 * Only applies when no physical robots.txt exists at the web root — WordPress
 * cannot override a real file, and silently pretending otherwise is the most
 * common robots.txt support ticket there is.
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

class WPD_Robots {

	/** @var WPD_Robots|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_filter( 'robots_txt', array( $this, 'filter' ), 20, 2 );
	}

	/**
	 * @param string $output Existing robots.txt body.
	 * @param bool   $public Value of blog_public.
	 * @return string
	 */
	public function filter( $output, $public ) {
		// Discouraged sites keep core's blanket Disallow.
		if ( ! $public ) {
			return $output;
		}

		$rules = array(
			'User-agent: *',
			'Disallow: /wp-admin/',
			'Allow: /wp-admin/admin-ajax.php',
			'Disallow: /wp-login.php',
			'Disallow: /xmlrpc.php',
			'Disallow: /*?s=',
			'Disallow: /*?replytocom=',
			'Disallow: /*?attachment_id=',
			'Disallow: /readme.html',
			'Allow: /wp-content/uploads/',
			'Allow: /wp-includes/*.js',
			'Allow: /wp-content/*.js',
			'Allow: /wp-content/*.css',
		);

		/**
		 * @param string[] $rules One directive per line.
		 */
		$rules = apply_filters( 'wpd_seo_robots_rules', $rules );

		$body = implode( "\n", $rules ) . "\n";

		/*
		 * Other plugins add their own directives through this same filter at
		 * priority 10. Returning only our block would throw those away, so
		 * carry over any line we did not already emit — minus core's own
		 * defaults, which our rules supersede.
		 */
		$core_defaults = array(
			'User-agent: *',
			'Disallow: /wp-admin/',
			'Allow: /wp-admin/admin-ajax.php',
		);

		$carried = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $output ) as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				continue;
			}
			if ( in_array( $line, $core_defaults, true ) || in_array( $line, $rules, true ) ) {
				continue;
			}
			// Someone else already declared a sitemap; ours is added below.
			if ( 0 === stripos( $line, 'Sitemap:' ) ) {
				continue;
			}
			$carried[] = $line;
		}

		if ( $carried ) {
			$body .= "\n# Added by other plugins\n" . implode( "\n", $carried ) . "\n";
		}

		if ( WPD_Options::enabled( 'sitemap' ) && class_exists( 'WPD_Sitemap' ) ) {
			$body .= "\nSitemap: " . esc_url_raw( WPD_Sitemap::index_url() ) . "\n";
		}

		return $body;
	}

	/**
	 * True when a physical robots.txt shadows the virtual one.
	 *
	 * @return bool
	 */
	public static function has_physical_file() {
		return file_exists( ABSPATH . 'robots.txt' );
	}
}

<?php
/**
 * XML sitemaps.
 *
 * Core has shipped sitemaps since WP 5.5, so we harden that implementation
 * (lastmod, noindex exclusion, no user sitemap) instead of adding a second,
 * competing set of URLs. If core sitemaps are unavailable or disabled by
 * another plugin, we step aside quietly.
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

class WPD_Sitemap {

	/** @var WPD_Sitemap|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		if ( WPD_Meta::has_conflicting_seo_plugin() ) {
			return;
		}

		add_filter( 'wp_sitemaps_enabled', '__return_true', 5 );
		add_filter( 'wp_sitemaps_add_provider', array( $this, 'filter_providers' ), 10, 2 );
		add_filter( 'wp_sitemaps_posts_query_args', array( $this, 'exclude_noindex_posts' ), 10, 2 );
		add_filter( 'wp_sitemaps_taxonomies_query_args', array( $this, 'taxonomy_query_args' ), 10, 2 );
		add_filter( 'wp_sitemaps_posts_entry', array( $this, 'add_lastmod' ), 10, 2 );
		add_filter( 'wp_sitemaps_index_entry', array( $this, 'index_lastmod' ), 10, 4 );
		add_filter( 'wp_sitemaps_max_urls', array( $this, 'max_urls' ), 10, 2 );

		add_filter( 'wp_sitemaps_post_types', array( $this, 'filter_post_types' ) );
	}

	/**
	 * Drop the users sitemap: author archives are rarely index-worthy and it
	 * leaks the login-name surface for no ranking benefit.
	 *
	 * @param WP_Sitemaps_Provider $provider Provider instance.
	 * @param string               $name     Provider name.
	 * @return WP_Sitemaps_Provider|false
	 */
	public function filter_providers( $provider, $name ) {
		if ( 'users' === $name && apply_filters( 'wpd_seo_sitemap_disable_users', true ) ) {
			return false;
		}
		return $provider;
	}

	/**
	 * @param array $post_types Post type objects keyed by name.
	 * @return array
	 */
	public function filter_post_types( $post_types ) {
		unset( $post_types['attachment'] );
		/**
		 * @param array $post_types Post types included in the sitemap.
		 */
		return apply_filters( 'wpd_seo_sitemap_post_types', $post_types );
	}

	/**
	 * @param array  $args      WP_Query args.
	 * @param string $post_type Post type.
	 * @return array
	 */
	public function exclude_noindex_posts( $args, $post_type ) {
		$meta_query = isset( $args['meta_query'] ) ? $args['meta_query'] : array();

		$meta_query[] = array(
			'relation' => 'OR',
			array(
				'key'     => '_wpd_noindex',
				'compare' => 'NOT EXISTS',
			),
			array(
				'key'     => '_wpd_noindex',
				'value'   => '1',
				'compare' => '!=',
			),
		);

		$args['meta_query']    = $meta_query;
		$args['no_found_rows'] = false;

		return apply_filters( 'wpd_seo_sitemap_posts_args', $args, $post_type );
	}

	/**
	 * Empty terms add crawl budget cost with no content behind them.
	 *
	 * @param array  $args     get_terms() args.
	 * @param string $taxonomy Taxonomy name.
	 * @return array
	 */
	public function taxonomy_query_args( $args, $taxonomy ) {
		$args['hide_empty'] = true;
		return apply_filters( 'wpd_seo_sitemap_terms_args', $args, $taxonomy );
	}

	/**
	 * Core omits <lastmod>; crawlers use it to prioritise re-crawls.
	 *
	 * @param array   $entry Sitemap entry.
	 * @param WP_Post $post  Post object.
	 * @return array
	 */
	public function add_lastmod( $entry, $post ) {
		$entry['lastmod'] = get_post_modified_time( DATE_W3C, true, $post );
		return $entry;
	}

	/**
	 * @param array  $entry    Index entry.
	 * @param string $type     Object type.
	 * @param string $name     Object subtype.
	 * @param int    $page     Page number.
	 * @return array
	 */
	public function index_lastmod( $entry, $type, $name, $page ) {
		if ( 'post' === $type ) {
			$latest = get_posts(
				array(
					'post_type'        => $name ? $name : 'post',
					'post_status'      => 'publish',
					'posts_per_page'   => 1,
					'orderby'          => 'modified',
					'order'            => 'DESC',
					'suppress_filters' => false,
					'no_found_rows'    => true,
					'fields'           => 'ids',
				)
			);
			if ( $latest ) {
				$entry['lastmod'] = get_post_modified_time( DATE_W3C, true, $latest[0] );
			}
		}
		return $entry;
	}

	/**
	 * 2000 URLs per file keeps each sitemap comfortably under the 50 MB / 50k
	 * limit while staying fast to generate on shared hosting.
	 *
	 * @param int    $max_urls    Default max.
	 * @param string $object_type Object type.
	 * @return int
	 */
	public function max_urls( $max_urls, $object_type ) {
		return (int) apply_filters( 'wpd_seo_sitemap_max_urls', 2000, $object_type );
	}

	/**
	 * @return string Sitemap index URL.
	 */
	public static function index_url() {
		if ( function_exists( 'wp_sitemaps_get_server' ) ) {
			$server = wp_sitemaps_get_server();
			if ( $server && method_exists( $server, 'get_index_url' ) ) {
				return $server->get_index_url();
			}
		}
		return home_url( '/wp-sitemap.xml' );
	}
}

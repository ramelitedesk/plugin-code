<?php
/**
 * Breadcrumb trail: data source for BreadcrumbList schema and an optional
 * visual trail via [wpd_breadcrumbs] or wpd_breadcrumbs() in a template.
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

class WPD_Breadcrumbs {

	/** @var WPD_Breadcrumbs|null */
	private static $instance = null;

	/** @var array|null */
	private $items = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'wpd_breadcrumbs', array( $this, 'shortcode' ) );
		add_action( 'wp', array( $this, 'reset' ), 1 );
	}

	public function reset() {
		$this->items = null;
	}

	/**
	 * Trail as an ordered array of array( 'label' => string, 'url' => string ).
	 * The last item has an empty URL (it is the current page).
	 *
	 * @return array
	 */
	public function items() {
		if ( null !== $this->items ) {
			return $this->items;
		}

		$items = array(
			array(
				'label' => apply_filters( 'wpd_seo_breadcrumb_home_label', __( 'Home', 'wpd-seo' ) ),
				'url'   => home_url( '/' ),
			),
		);

		$ctx = WPD_Context::instance();

		switch ( $ctx->type() ) {
			case 'front_page':
				$items = array();
				break;

			case 'singular':
				$post = get_post( $ctx->post_id() );
				if ( $post ) {
					$items = array_merge( $items, $this->singular_ancestors( $post ) );
					$items[] = array( 'label' => get_the_title( $post ), 'url' => '' );
				}
				break;

			case 'home':
				$page_for_posts = (int) get_option( 'page_for_posts' );
				$items[]        = array(
					'label' => $page_for_posts ? get_the_title( $page_for_posts ) : __( 'Blog', 'wpd-seo' ),
					'url'   => '',
				);
				break;

			case 'category':
			case 'tag':
			case 'tax':
				$term = get_queried_object();
				if ( $term && isset( $term->term_id ) ) {
					$items = array_merge( $items, $this->term_ancestors( $term ) );
					$items[] = array( 'label' => $term->name, 'url' => '' );
				}
				break;

			case 'post_type_archive':
				$obj = get_post_type_object( get_query_var( 'post_type' ) );
				if ( $obj ) {
					$items[] = array( 'label' => $obj->labels->name, 'url' => '' );
				}
				break;

			case 'author':
				$items[] = array(
					'label' => get_the_author_meta( 'display_name', (int) get_queried_object_id() ),
					'url'   => '',
				);
				break;

			case 'search':
				/* translators: %s: search term. */
				$items[] = array( 'label' => sprintf( __( 'Search: %s', 'wpd-seo' ), get_search_query() ), 'url' => '' );
				break;

			case '404':
				$items[] = array( 'label' => __( 'Page not found', 'wpd-seo' ), 'url' => '' );
				break;

			default:
				$items[] = array( 'label' => wp_strip_all_tags( get_the_archive_title() ), 'url' => '' );
		}

		/**
		 * @param array $items Breadcrumb trail.
		 */
		$this->items = apply_filters( 'wpd_seo_breadcrumb_items', $items, $ctx );
		return $this->items;
	}

	/**
	 * Parent pages, or the primary term for posts.
	 *
	 * @param WP_Post $post Post object.
	 * @return array
	 */
	private function singular_ancestors( $post ) {
		$items = array();

		if ( is_post_type_hierarchical( $post->post_type ) ) {
			$ancestors = array_reverse( get_post_ancestors( $post ) );
			foreach ( $ancestors as $ancestor_id ) {
				$items[] = array(
					'label' => get_the_title( $ancestor_id ),
					'url'   => get_permalink( $ancestor_id ),
				);
			}
			return $items;
		}

		$post_type = get_post_type_object( $post->post_type );
		if ( $post_type && ! empty( $post_type->has_archive ) && 'post' !== $post->post_type ) {
			$link = get_post_type_archive_link( $post->post_type );
			if ( $link ) {
				$items[] = array( 'label' => $post_type->labels->name, 'url' => $link );
			}
		}

		$taxonomy = 'post' === $post->post_type ? 'category' : '';
		if ( ! $taxonomy ) {
			$taxes    = get_object_taxonomies( $post->post_type, 'objects' );
			foreach ( $taxes as $tax ) {
				if ( $tax->hierarchical && $tax->public ) {
					$taxonomy = $tax->name;
					break;
				}
			}
		}

		if ( $taxonomy ) {
			$terms = get_the_terms( $post, $taxonomy );
			if ( $terms && ! is_wp_error( $terms ) ) {
				$primary = reset( $terms );
				$items   = array_merge( $items, $this->term_ancestors( $primary ) );
				$link    = get_term_link( $primary );
				if ( ! is_wp_error( $link ) ) {
					$items[] = array( 'label' => $primary->name, 'url' => $link );
				}
			}
		}

		return $items;
	}

	/**
	 * @param WP_Term $term Term object.
	 * @return array
	 */
	private function term_ancestors( $term ) {
		$items = array();
		if ( ! isset( $term->taxonomy ) || ! is_taxonomy_hierarchical( $term->taxonomy ) ) {
			return $items;
		}

		$ancestors = array_reverse( get_ancestors( $term->term_id, $term->taxonomy, 'taxonomy' ) );
		foreach ( $ancestors as $ancestor_id ) {
			$ancestor = get_term( $ancestor_id, $term->taxonomy );
			if ( ! $ancestor || is_wp_error( $ancestor ) ) {
				continue;
			}
			$link = get_term_link( $ancestor );
			$items[] = array(
				'label' => $ancestor->name,
				'url'   => is_wp_error( $link ) ? '' : $link,
			);
		}
		return $items;
	}

	/**
	 * Accessible visual trail. Schema is emitted separately by WPD_Schema, so
	 * no microdata attributes are needed here.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public function render( $atts = array() ) {
		$atts = shortcode_atts(
			array(
				'separator' => '/',
				'class'     => 'wpd-breadcrumbs',
			),
			$atts,
			'wpd_breadcrumbs'
		);

		$items = $this->items();
		if ( count( $items ) < 2 ) {
			return '';
		}

		$html  = '<nav class="' . esc_attr( $atts['class'] ) . '" aria-label="' . esc_attr__( 'Breadcrumb', 'wpd-seo' ) . '">';
		$html .= '<ol>';

		$last = count( $items ) - 1;
		foreach ( array_values( $items ) as $i => $item ) {
			$html .= '<li>';
			if ( ! empty( $item['url'] ) && $i !== $last ) {
				$html .= '<a href="' . esc_url( $item['url'] ) . '">' . esc_html( $item['label'] ) . '</a>';
			} else {
				$html .= '<span aria-current="page">' . esc_html( $item['label'] ) . '</span>';
			}
			if ( $i !== $last ) {
				$html .= '<span class="sep" aria-hidden="true"> ' . esc_html( $atts['separator'] ) . ' </span>';
			}
			$html .= '</li>';
		}

		$html .= '</ol></nav>';
		return $html;
	}

	/**
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public function shortcode( $atts ) {
		return $this->render( is_array( $atts ) ? $atts : array() );
	}
}

if ( ! function_exists( 'wpd_breadcrumbs' ) ) {
	/**
	 * Template tag: <?php wpd_breadcrumbs(); ?>
	 *
	 * @param array $atts Options.
	 */
	function wpd_breadcrumbs( $atts = array() ) {
		if ( class_exists( 'WPD_Breadcrumbs' ) ) {
			echo WPD_Breadcrumbs::instance()->render( $atts ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in render().
		}
	}
}

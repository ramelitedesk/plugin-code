<?php
/**
 * Product structured data.
 *
 * WooCommerce ships its own JSON-LD, but it emits a standalone Product node
 * that is not connected to the page graph. We disable that and add a Product
 * node wired into the same @graph WPD_Schema builds, so Google resolves one
 * entity per page instead of two competing ones.
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

class WPD_Woo_Schema {

	/** @var WPD_Woo_Schema|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		// Only take over if our own schema module is doing the emitting.
		if ( ! WPD_Options::enabled( 'schema' ) || WPD_Meta::has_conflicting_seo_plugin() ) {
			return;
		}

		add_filter( 'woocommerce_structured_data_product', '__return_empty_array' );
		add_filter( 'wpd_seo_schema_graph', array( $this, 'add_nodes' ), 10, 2 );
	}

	/**
	 * @param array       $graph   Graph nodes.
	 * @param WPD_Context $context Context.
	 * @return array
	 */
	public function add_nodes( $graph, $context = null ) {
		if ( ! function_exists( 'wc_get_product' ) ) {
			return $graph;
		}

		$context = $context ? $context : WPD_Context::instance();
		$post_id = $context->post_id();

		if ( $post_id && 'product' === get_post_type( $post_id ) ) {
			$node = $this->product_node( $post_id, $context );
			if ( $node ) {
				$graph[] = $node;
			}
			return $graph;
		}

		if ( function_exists( 'is_shop' ) && ( is_shop() || is_product_category() || is_product_tag() ) ) {
			$node = $this->item_list_node();
			if ( $node ) {
				$graph[] = $node;
			}
		}

		return $graph;
	}

	/**
	 * @param int         $post_id Product ID.
	 * @param WPD_Context $context Context.
	 * @return array
	 */
	private function product_node( $post_id, $context ) {
		$product = wc_get_product( $post_id );
		if ( ! $product ) {
			return array();
		}

		$url  = $context->canonical();
		$node = array(
			'@type'       => 'Product',
			'@id'         => $url . '#product',
			'name'        => wp_strip_all_tags( $product->get_name() ),
			'url'         => $url,
			'mainEntityOfPage' => array( '@id' => $url . '#webpage' ),
		);

		$description = $product->get_short_description() ? $product->get_short_description() : $product->get_description();
		if ( '' !== trim( (string) $description ) ) {
			$node['description'] = wpd_trim_text( $description, 300 );
		}

		$sku = $product->get_sku();
		if ( $sku ) {
			$node['sku'] = $sku;
		}

		// GTIN/MPN if the store records them (core Woo has no field, so this
		// reads the de-facto standard meta keys plugins use).
		foreach ( array( 'gtin' => '_gtin', 'mpn' => '_mpn', 'gtin13' => '_gtin13' ) as $prop => $meta_key ) {
			$value = get_post_meta( $post_id, $meta_key, true );
			if ( $value ) {
				$node[ $prop ] = (string) $value;
			}
		}

		$images = $this->image_urls( $product );
		if ( $images ) {
			$node['image'] = $images;
		}

		$brand = $this->brand( $post_id );
		if ( $brand ) {
			$node['brand'] = array(
				'@type' => 'Brand',
				'name'  => $brand,
			);
		}

		$node['offers'] = $this->offers( $product, $url );

		$rating = $this->rating( $product );
		if ( $rating ) {
			$node['aggregateRating'] = $rating;
		}

		$reviews = $this->reviews( $post_id );
		if ( $reviews ) {
			$node['review'] = $reviews;
		}

		/**
		 * @param array      $node    Product node.
		 * @param WC_Product $product Product object.
		 */
		return apply_filters( 'wpd_seo_woo_product_schema', $node, $product );
	}

	/**
	 * Variable products get an AggregateOffer with the real price range;
	 * everything else gets a single Offer.
	 *
	 * @param WC_Product $product Product.
	 * @param string     $url     Canonical URL.
	 * @return array
	 */
	private function offers( $product, $url ) {
		$currency     = get_woocommerce_currency();
		$availability = $product->is_in_stock()
			? 'https://schema.org/InStock'
			: ( $product->is_on_backorder() ? 'https://schema.org/BackOrder' : 'https://schema.org/OutOfStock' );

		// A sale end date is the only defensible priceValidUntil; guessing a
		// date makes Search Console complain once it passes.
		$valid_until = $product->get_date_on_sale_to() ? $product->get_date_on_sale_to()->date( 'Y-m-d' ) : '';

		if ( $product->is_type( 'variable' ) ) {
			$prices = $product->get_variation_prices( true );
			$low    = $prices && ! empty( $prices['price'] ) ? min( $prices['price'] ) : $product->get_price();
			$high   = $prices && ! empty( $prices['price'] ) ? max( $prices['price'] ) : $product->get_price();

			$offer = array(
				'@type'         => 'AggregateOffer',
				'@id'           => $url . '#offer',
				'url'           => $url,
				'priceCurrency' => $currency,
				'lowPrice'      => wc_format_decimal( $low, wc_get_price_decimals() ),
				'highPrice'     => wc_format_decimal( $high, wc_get_price_decimals() ),
				'offerCount'    => count( $product->get_children() ),
				'availability'  => $availability,
			);
		} else {
			$offer = array(
				'@type'         => 'Offer',
				'@id'           => $url . '#offer',
				'url'           => $url,
				'priceCurrency' => $currency,
				'price'         => wc_format_decimal( $product->get_price(), wc_get_price_decimals() ),
				'availability'  => $availability,
				'itemCondition' => 'https://schema.org/NewCondition',
			);
			if ( $valid_until ) {
				$offer['priceValidUntil'] = $valid_until;
			}
		}

		$offer['seller'] = array( '@id' => home_url( '/' ) . '#publisher' );

		return $offer;
	}

	/**
	 * @param WC_Product $product Product.
	 * @return array
	 */
	private function image_urls( $product ) {
		$ids = array();
		if ( $product->get_image_id() ) {
			$ids[] = (int) $product->get_image_id();
		}
		foreach ( array_slice( (array) $product->get_gallery_image_ids(), 0, 5 ) as $gallery_id ) {
			$ids[] = (int) $gallery_id;
		}

		$urls = array();
		foreach ( array_unique( $ids ) as $id ) {
			$src = wp_get_attachment_image_src( $id, 'full' );
			if ( $src ) {
				$urls[] = $src[0];
			}
		}
		return $urls;
	}

	/**
	 * @param int $post_id Product ID.
	 * @return string
	 */
	private function brand( $post_id ) {
		/**
		 * Brand taxonomies differ per plugin (Perfect Brands, YITH, Woo Brands).
		 *
		 * @param string[] $taxonomies Candidate taxonomy names.
		 */
		$taxonomies = apply_filters(
			'wpd_seo_woo_brand_taxonomies',
			array( 'product_brand', 'pwb-brand', 'yith_product_brand', 'pa_brand' )
		);

		foreach ( $taxonomies as $taxonomy ) {
			if ( ! taxonomy_exists( $taxonomy ) ) {
				continue;
			}
			$terms = get_the_terms( $post_id, $taxonomy );
			if ( $terms && ! is_wp_error( $terms ) ) {
				$first = reset( $terms );
				return $first->name;
			}
		}

		return (string) apply_filters( 'wpd_seo_woo_brand_name', '', $post_id );
	}

	/**
	 * @param WC_Product $product Product.
	 * @return array
	 */
	private function rating( $product ) {
		$count = (int) $product->get_review_count();
		$avg   = (float) $product->get_average_rating();

		// Google rejects an aggregateRating with no underlying reviews.
		if ( $count < 1 || $avg <= 0 ) {
			return array();
		}

		return array(
			'@type'       => 'AggregateRating',
			'ratingValue' => (string) round( $avg, 2 ),
			'reviewCount' => $count,
			'bestRating'  => '5',
			'worstRating' => '1',
		);
	}

	/**
	 * @param int $post_id Product ID.
	 * @return array
	 */
	private function reviews( $post_id ) {
		$comments = get_comments(
			array(
				'post_id' => $post_id,
				'status'  => 'approve',
				'type'    => 'review',
				'number'  => 5,
			)
		);

		$reviews = array();
		foreach ( $comments as $comment ) {
			$rating = (int) get_comment_meta( $comment->comment_ID, 'rating', true );
			if ( $rating < 1 ) {
				continue;
			}
			$reviews[] = array(
				'@type'         => 'Review',
				'reviewRating'  => array(
					'@type'       => 'Rating',
					'ratingValue' => (string) $rating,
					'bestRating'  => '5',
					'worstRating' => '1',
				),
				'author'        => array(
					'@type' => 'Person',
					'name'  => $comment->comment_author,
				),
				'datePublished' => mysql2date( DATE_W3C, $comment->comment_date_gmt ),
				'reviewBody'    => wpd_trim_text( $comment->comment_content, 300 ),
			);
		}

		return $reviews;
	}

	/**
	 * Shop and product-category archives: an ItemList of the products on this
	 * page of results.
	 *
	 * @return array
	 */
	private function item_list_node() {
		global $wp_query;

		if ( empty( $wp_query->posts ) ) {
			return array();
		}

		$items = array();
		foreach ( array_slice( $wp_query->posts, 0, 30 ) as $i => $post ) {
			$items[] = array(
				'@type'    => 'ListItem',
				'position' => $i + 1,
				'url'      => get_permalink( $post ),
				'name'     => wp_strip_all_tags( get_the_title( $post ) ),
			);
		}

		return array(
			'@type'           => 'ItemList',
			'@id'             => WPD_Context::instance()->canonical() . '#itemlist',
			'itemListElement' => $items,
		);
	}
}

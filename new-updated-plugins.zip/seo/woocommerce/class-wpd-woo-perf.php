<?php
/**
 * WooCommerce performance.
 *
 * WooCommerce loads its full CSS/JS bundle — plus the cart-fragments AJAX call
 * that fires on every single page view — even on a blog post or contact page.
 * On a typical store that is the difference between a 60 and a 90 Lighthouse
 * score, and it is entirely safe to remove where the store UI is not present.
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

class WPD_Woo_Perf {

	/** @var WPD_Woo_Perf|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'dequeue_on_non_woo_pages' ), 99 );
		add_action( 'wp_enqueue_scripts', array( $this, 'handle_cart_fragments' ), 100 );

		// The product gallery's zoom/lightbox stack is only needed on a product.
		add_action( 'wp_enqueue_scripts', array( $this, 'dequeue_gallery_scripts' ), 99 );

		add_filter( 'woocommerce_enqueue_styles', array( $this, 'filter_woo_styles' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'trim_block_styles' ), 99 );

		// Marketing hub / connect notices run queries on every admin load.
		add_filter( 'woocommerce_admin_features', array( $this, 'trim_admin_features' ) );

		// The first product gallery image is the LCP element — never lazy.
		add_filter( 'woocommerce_single_product_image_thumbnail_html', array( $this, 'prioritise_main_image' ), 10, 2 );
	}

	/**
	 * True on any page where WooCommerce UI can appear.
	 *
	 * @return bool
	 */
	public static function is_woo_page() {
		if ( ! function_exists( 'is_woocommerce' ) ) {
			return true; // Be conservative if Woo has not bootstrapped.
		}

		$is_woo = is_woocommerce() || is_cart() || is_checkout() || is_account_page() || is_wc_endpoint_url();

		/*
		 * A shortcode or block can put products on any page. Match the actual
		 * shortcode/block syntax, not bare words: testing for "product"
		 * anywhere in the content matches ordinary prose ("our product range")
		 * and keeps the whole store bundle on pages that have no store UI,
		 * which quietly cancels the optimisation.
		 */
		if ( ! $is_woo ) {
			$post = get_post();
			if ( $post instanceof WP_Post ) {
				$content = (string) $post->post_content;
				$needles = array(
					'[woocommerce_',
					'[products',
					'[product_',
					'[product ',
					'[add_to_cart',
					'[shop_',
					'wp:woocommerce',
					'class="wp-block-woocommerce',
				);
				foreach ( $needles as $needle ) {
					if ( false !== stripos( $content, $needle ) ) {
						$is_woo = true;
						break;
					}
				}
			}
		}

		/**
		 * Themes with a persistent mini-cart in the header need the Woo assets
		 * everywhere — return true here in that case.
		 *
		 * @param bool $is_woo Whether this page needs WooCommerce assets.
		 */
		return (bool) apply_filters( 'wpd_seo_woo_is_woo_page', $is_woo );
	}

	/**
	 * Drop the store bundle on pages with no store UI.
	 */
	public function dequeue_on_non_woo_pages() {
		if ( ! wpd_should_optimize() || self::is_woo_page() ) {
			return;
		}
		if ( ! WPD_Options::enabled( 'woo_conditional_assets' ) ) {
			return;
		}

		$styles = array(
			'woocommerce-general',
			'woocommerce-layout',
			'woocommerce-smallscreen',
			'woocommerce_frontend_styles',
			'woocommerce_fancybox_styles',
			'woocommerce_chosen_styles',
			'woocommerce_prettyPhoto_css',
			'wc-blocks-style',
			'brands-styles',
		);
		// Dequeue only. Deregistering would break any third-party style or
		// script that declares a WooCommerce handle as a dependency.
		foreach ( $styles as $handle ) {
			wp_dequeue_style( $handle );
		}

		$scripts = array(
			'woocommerce',
			'wc-add-to-cart',
			'wc-cart-fragments',
			'wc-order-attribution',
			'jquery-blockui',
			'jquery-placeholder',
			'selectWoo',
			'prettyPhoto',
			'prettyPhoto-init',
			'fancybox',
		);
		foreach ( $scripts as $handle ) {
			wp_dequeue_script( $handle );
			WPD_Debug::log( 'asset', $handle, 'dequeued — no store UI on this page' );
		}
	}

	/**
	 * wc-cart-fragments fires an uncached admin-ajax request on every page load
	 * and is the most common single cause of a slow WooCommerce TTFB.
	 *
	 * It is only genuinely needed where a cart count updates without a reload.
	 */
	public function handle_cart_fragments() {
		if ( ! wpd_should_optimize() ) {
			return;
		}
		if ( ! WPD_Options::enabled( 'woo_disable_cart_fragments' ) ) {
			return;
		}

		// Keep them wherever the cart itself is on screen.
		if ( function_exists( 'is_cart' ) && ( is_cart() || is_checkout() ) ) {
			return;
		}

		/**
		 * Set to true if the theme shows a live mini-cart count in the header.
		 *
		 * @param bool $keep Whether to keep cart fragments.
		 */
		if ( apply_filters( 'wpd_seo_woo_keep_fragments', false ) ) {
			return;
		}

		wp_dequeue_script( 'wc-cart-fragments' );
	}

	/**
	 * Zoom, flexslider and PhotoSwipe are ~90 KB that only a product page uses.
	 */
	public function dequeue_gallery_scripts() {
		if ( ! wpd_should_optimize() ) {
			return;
		}
		if ( function_exists( 'is_product' ) && is_product() ) {
			return;
		}

		foreach ( array( 'zoom', 'flexslider', 'photoswipe', 'photoswipe-ui-default', 'wc-single-product' ) as $handle ) {
			wp_dequeue_script( $handle );
		}
		foreach ( array( 'photoswipe', 'photoswipe-default-skin' ) as $handle ) {
			wp_dequeue_style( $handle );
		}
	}

	/**
	 * The small-screen stylesheet is only parsed under its media query, but
	 * it is still a request. Keep it — this filter exists so sites that ship
	 * their own store CSS can drop Woo's entirely.
	 *
	 * @param array $styles Woo style definitions.
	 * @return array
	 */
	public function filter_woo_styles( $styles ) {
		/**
		 * Return an empty array to fully replace WooCommerce's CSS with the
		 * theme's own.
		 *
		 * @param array $styles Registered WooCommerce styles.
		 */
		return (array) apply_filters( 'wpd_seo_woo_styles', $styles );
	}

	/**
	 * WooCommerce Blocks registers a stylesheet per block type; only keep the
	 * ones for blocks actually on the page.
	 */
	public function trim_block_styles() {
		if ( ! wpd_should_optimize() || ! function_exists( 'has_block' ) ) {
			return;
		}

		$post = get_post();
		if ( ! $post instanceof WP_Post ) {
			return;
		}
		if ( false !== stripos( (string) $post->post_content, 'wp:woocommerce' ) ) {
			return;
		}

		wp_dequeue_style( 'wc-blocks-style' );
		wp_dequeue_style( 'wc-blocks-packages-style' );
	}

	/**
	 * @param array $features Admin feature slugs.
	 * @return array
	 */
	public function trim_admin_features( $features ) {
		if ( ! apply_filters( 'wpd_seo_woo_trim_admin', true ) ) {
			return $features;
		}
		return array_values(
			array_diff(
				(array) $features,
				array( 'marketing', 'mobile-app-banner', 'payment-gateway-suggestions', 'remote-inbox-notifications' )
			)
		);
	}

	/**
	 * Give the main product image eager loading and high fetch priority.
	 *
	 * @param string $html          Image HTML.
	 * @param int    $attachment_id Attachment ID.
	 * @return string
	 */
	public function prioritise_main_image( $html, $attachment_id ) {
		static $first = true;

		if ( ! $first || ! wpd_should_optimize() ) {
			return $html;
		}
		$first = false;

		$html = str_replace( ' loading="lazy"', ' loading="eager"', $html );
		if ( false === strpos( $html, 'fetchpriority' ) ) {
			$html = wpd_preg_replace( '/<img\s/i', '<img fetchpriority="high" ', $html, 1 );
		}

		return $html;
	}
}

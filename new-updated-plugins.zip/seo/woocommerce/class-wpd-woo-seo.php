<?php
/**
 * WooCommerce SEO: keep transactional pages out of the index, give products a
 * description worth showing in the SERP, and point the LCP machinery at the
 * product image instead of whatever the theme happened to render first.
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

class WPD_Woo_Seo {

	/** @var WPD_Woo_Seo|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_filter( 'wpd_seo_is_indexable', array( $this, 'filter_indexable' ), 10, 2 );
		add_filter( 'wpd_seo_canonical', array( $this, 'filter_canonical' ), 10, 2 );
		add_filter( 'wpd_seo_description', array( $this, 'filter_description' ), 10, 2 );
		add_filter( 'wpd_seo_image_id', array( $this, 'filter_image' ), 10, 2 );
		add_filter( 'wpd_seo_og_tags', array( $this, 'filter_og' ), 10, 2 );
		add_filter( 'wpd_seo_sitemap_post_types', array( $this, 'filter_sitemap_post_types' ) );
		add_filter( 'wpd_seo_breadcrumb_items', array( $this, 'filter_breadcrumbs' ), 10, 2 );
	}

	/**
	 * Cart/checkout/account must never be indexed — Google crawling an
	 * add-to-cart URL is how phantom "?add-to-cart=123" pages end up in the
	 * index. Hidden and out-of-catalogue products go too.
	 *
	 * @param bool        $index   Current decision.
	 * @param WPD_Context $context Context.
	 * @return bool
	 */
	public function filter_indexable( $index, $context ) {
		if ( ! $index ) {
			return $index;
		}

		if ( WPD_Woo::is_transactional_page() && WPD_Options::enabled( 'woo_noindex_pages' ) ) {
			return false;
		}

		// Filtered / sorted archive permutations are near-duplicates.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only.
		$noisy = array( 'orderby', 'min_price', 'max_price', 'filter_', 'rating_filter', 'add-to-cart' );
		foreach ( array_keys( (array) $_GET ) as $key ) {
			foreach ( $noisy as $needle ) {
				if ( 0 === strpos( (string) $key, $needle ) ) {
					return false;
				}
			}
		}

		$post_id = $context->post_id();
		if ( $post_id && 'product' === get_post_type( $post_id ) && function_exists( 'wc_get_product' ) ) {
			$product = wc_get_product( $post_id );
			if ( $product && 'hidden' === $product->get_catalog_visibility() ) {
				return false;
			}
		}

		return $index;
	}

	/**
	 * A filtered shop archive should point back at the clean archive URL.
	 *
	 * @param string      $canonical Canonical URL.
	 * @param WPD_Context $context   Context.
	 * @return string
	 */
	public function filter_canonical( $canonical, $context ) {
		if ( ! function_exists( 'is_shop' ) || ! is_shop() ) {
			return $canonical;
		}

		$shop_id = (int) wc_get_page_id( 'shop' );
		if ( $shop_id > 0 ) {
			$link = get_permalink( $shop_id );
			if ( $link ) {
				$paged = (int) get_query_var( 'paged' );
				return $paged > 1 ? trailingslashit( $link ) . 'page/' . $paged . '/' : $link;
			}
		}
		return $canonical;
	}

	/**
	 * Products rarely have an excerpt, but they almost always have a short
	 * description — which is exactly the sentence a SERP snippet wants.
	 *
	 * @param string      $description Current description.
	 * @param WPD_Context $context     Context.
	 * @return string
	 */
	public function filter_description( $description, $context ) {
		if ( '' !== trim( (string) $description ) ) {
			return $description;
		}

		if ( function_exists( 'is_shop' ) && is_shop() ) {
			$shop_id = (int) wc_get_page_id( 'shop' );
			if ( $shop_id > 0 ) {
				$shop = get_post( $shop_id );
				if ( $shop ) {
					return wpd_trim_text( $shop->post_content, 158 );
				}
			}
		}

		$post_id = $context->post_id();
		if ( ! $post_id || 'product' !== get_post_type( $post_id ) || ! function_exists( 'wc_get_product' ) ) {
			return $description;
		}

		$product = wc_get_product( $post_id );
		if ( ! $product ) {
			return $description;
		}

		$short = $product->get_short_description();
		if ( '' !== trim( (string) $short ) ) {
			return wpd_trim_text( $short, 158 );
		}
		return wpd_trim_text( $product->get_description(), 158 );
	}

	/**
	 * The product image is the LCP element on virtually every product page.
	 *
	 * @param int         $image_id Current image ID.
	 * @param WPD_Context $context  Context.
	 * @return int
	 */
	public function filter_image( $image_id, $context ) {
		$post_id = $context->post_id();
		if ( ! $post_id || 'product' !== get_post_type( $post_id ) || ! function_exists( 'wc_get_product' ) ) {
			return $image_id;
		}

		$product = wc_get_product( $post_id );
		if ( ! $product ) {
			return $image_id;
		}

		$main = (int) $product->get_image_id();
		if ( $main ) {
			return $main;
		}

		$gallery = $product->get_gallery_image_ids();
		return $gallery ? (int) $gallery[0] : $image_id;
	}

	/**
	 * og:type=product plus the price tags Facebook/Pinterest surface.
	 *
	 * @param array       $tags    Open Graph tags.
	 * @param WPD_Context $context Context.
	 * @return array
	 */
	public function filter_og( $tags, $context ) {
		$post_id = $context->post_id();
		if ( ! $post_id || 'product' !== get_post_type( $post_id ) || ! function_exists( 'wc_get_product' ) ) {
			return $tags;
		}

		$product = wc_get_product( $post_id );
		if ( ! $product ) {
			return $tags;
		}

		$tags['og:type'] = 'product';

		$price = $product->get_price();
		if ( '' !== (string) $price ) {
			$tags['product:price:amount']   = wc_format_decimal( $price, wc_get_price_decimals() );
			$tags['product:price:currency'] = get_woocommerce_currency();
		}
		$tags['product:availability'] = $product->is_in_stock() ? 'instock' : 'outofstock';

		$sku = $product->get_sku();
		if ( $sku ) {
			$tags['product:retailer_item_id'] = $sku;
		}

		return $tags;
	}

	/**
	 * Products belong in the sitemap; coupons and internal order types do not.
	 *
	 * @param array $post_types Post type objects.
	 * @return array
	 */
	public function filter_sitemap_post_types( $post_types ) {
		foreach ( array( 'shop_order', 'shop_order_refund', 'shop_coupon', 'product_variation' ) as $type ) {
			unset( $post_types[ $type ] );
		}
		return $post_types;
	}

	/**
	 * Use WooCommerce's own category hierarchy for product breadcrumbs.
	 *
	 * @param array       $items   Trail.
	 * @param WPD_Context $context Context.
	 * @return array
	 */
	public function filter_breadcrumbs( $items, $context ) {
		$post_id = $context->post_id();
		if ( ! $post_id || 'product' !== get_post_type( $post_id ) ) {
			return $items;
		}

		$shop_id = function_exists( 'wc_get_page_id' ) ? (int) wc_get_page_id( 'shop' ) : 0;
		if ( $shop_id < 1 ) {
			return $items;
		}

		$shop_link = get_permalink( $shop_id );
		if ( ! $shop_link ) {
			return $items;
		}

		// Insert the shop page right after Home, if it is not already there.
		foreach ( $items as $item ) {
			if ( ! empty( $item['url'] ) && untrailingslashit( $item['url'] ) === untrailingslashit( $shop_link ) ) {
				return $items;
			}
		}

		$home = array_shift( $items );
		array_unshift(
			$items,
			$home,
			array(
				'label' => get_the_title( $shop_id ),
				'url'   => $shop_link,
			)
		);

		return $items;
	}
}

<?php
/**
 * WooCommerce layer.
 *
 * A store is the one WordPress site type where aggressive optimisation is
 * genuinely dangerous: cart, checkout and account pages are per-visitor, and
 * caching or minifying them leaks one customer's basket to the next.
 *
 * This class is the safety gate. It loads the SEO and performance sub-modules
 * only when WooCommerce is actually active, and switches every optimisation
 * off on transactional pages before anything else gets a chance to run.
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

class WPD_Woo {

	/** @var WPD_Woo|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		if ( ! self::is_active() ) {
			return;
		}

		require_once WPD_SEO_DIR . 'woocommerce/class-wpd-woo-seo.php';
		require_once WPD_SEO_DIR . 'woocommerce/class-wpd-woo-schema.php';
		require_once WPD_SEO_DIR . 'woocommerce/class-wpd-woo-perf.php';

		WPD_Woo_Seo::instance();
		WPD_Woo_Perf::instance();

		if ( WPD_Options::enabled( 'woo_schema' ) ) {
			WPD_Woo_Schema::instance();
		}

		// Priority 1: this decision has to land before any module reads it.
		add_filter( 'wpd_seo_should_optimize', array( $this, 'never_optimize_transactional' ), 1 );
		add_filter( 'wpd_seo_protected_handles', array( $this, 'protected_handles' ) );
		add_filter( 'wpd_seo_protected_styles', array( $this, 'protected_styles' ) );

		// Never let a personalised page reach a shared cache.
		add_filter( 'wpd_seo_html_cache_ttl', array( $this, 'cache_ttl' ) );
		add_filter( 'wpd_seo_extra_headers', array( $this, 'no_store_headers' ) );
	}

	/**
	 * @return bool
	 */
	public static function is_active() {
		return class_exists( 'WooCommerce' ) || defined( 'WC_VERSION' );
	}

	/**
	 * Cart, checkout, my-account, order-received/pay endpoints.
	 *
	 * @return bool
	 */
	public static function is_transactional_page() {
		if ( ! self::is_active() || is_admin() ) {
			return false;
		}
		// These conditionals only exist once WooCommerce has bootstrapped.
		if ( ! function_exists( 'is_cart' ) ) {
			return false;
		}

		$transactional = is_cart() || is_checkout() || is_account_page() || is_wc_endpoint_url();

		/**
		 * @param bool $transactional Whether this page is per-visitor.
		 */
		return (bool) apply_filters( 'wpd_seo_woo_is_transactional', $transactional );
	}

	/**
	 * A non-empty cart makes every page personalised (mini-cart counts, totals),
	 * so shared caching has to stop there too.
	 *
	 * @return bool
	 */
	public static function has_cart_contents() {
		if ( ! self::is_active() || ! function_exists( 'WC' ) ) {
			return false;
		}
		$wc = WC();
		if ( ! $wc || empty( $wc->cart ) ) {
			return false;
		}
		return ! $wc->cart->is_empty();
	}

	/**
	 * @param bool $optimize Current decision.
	 * @return bool
	 */
	public function never_optimize_transactional( $optimize ) {
		return self::is_transactional_page() ? false : $optimize;
	}

	/**
	 * WooCommerce's checkout stack breaks the moment its execution order
	 * changes, so none of it is ever deferred or delayed.
	 *
	 * @param string[] $handles Protected script handles.
	 * @return string[]
	 */
	public function protected_handles( $handles ) {
		return array_merge(
			$handles,
			array(
				'woocommerce',
				'wc-blocks-checkout',
				'wc-blocks-cart',
				'wc-cart',
				'wc-cart-fragments',
				'wc-checkout',
				'wc-add-to-cart',
				'wc-add-to-cart-variation',
				'wc-single-product',
				'wc-country-select',
				'wc-address-i18n',
				'wc-password-strength-meter',
				'wc-order-attribution',
				'wc-stripe',
				'stripe',
				'paypal',
				'ppcp-smart-button',
				'jquery-blockui',
				'js-cookie',
				'selectWoo',
				'select2',
				'zoom',
				'flexslider',
				'photoswipe',
				'photoswipe-ui-default',
			)
		);
	}

	/**
	 * @param string[] $handles Protected style handles.
	 * @return string[]
	 */
	public function protected_styles( $handles ) {
		return array_merge(
			$handles,
			array(
				'woocommerce-general',
				'woocommerce-layout',
				'woocommerce-smallscreen',
				'wc-blocks-style',
				'wc-blocks-checkout-style',
				'photoswipe',
				'photoswipe-default-skin',
			)
		);
	}

	/**
	 * @param int $ttl Shared-cache lifetime in seconds.
	 * @return int
	 */
	public function cache_ttl( $ttl ) {
		if ( self::is_transactional_page() || self::has_cart_contents() ) {
			return 0;
		}
		return $ttl;
	}

	/**
	 * @param array $headers Header => value.
	 * @return array
	 */
	public function no_store_headers( $headers ) {
		if ( self::is_transactional_page() || self::has_cart_contents() ) {
			$headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0';
			$headers['Pragma']        = 'no-cache';
		}
		return $headers;
	}
}

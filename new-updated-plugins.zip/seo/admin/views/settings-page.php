<?php
/**
 * Settings screen markup.
 *
 * @var array                  $settings Current settings.
 * @var WPD_Builder_Detect|null $detect  Builder detector.
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

/**
 * @param string $key   Setting key.
 * @param string $label Field label.
 * @param string $help  Help text.
 * @param array  $settings Settings array.
 */
$wpd_toggle = static function ( $key, $label, $help, $settings ) {
	?>
	<tr>
		<th scope="row"><?php echo esc_html( $label ); ?></th>
		<td>
			<label>
				<?php // Declares that this checkbox was on the form, so an unchecked box means "off" rather than "not shown". ?>
				<input type="hidden" name="wpd_present[]" value="<?php echo esc_attr( $key ); ?>" />
				<input type="checkbox" name="<?php echo esc_attr( $key ); ?>" value="1" <?php checked( ! empty( $settings[ $key ] ) ); ?> />
				<?php echo esc_html( $help ); ?>
			</label>
		</td>
	</tr>
	<?php
};

/**
 * @param string $key      Setting key.
 * @param string $label    Field label.
 * @param string $help     Help text.
 * @param array  $settings Settings array.
 * @param string $type     text|textarea.
 */
$wpd_field = static function ( $key, $label, $help, $settings, $type = 'text' ) {
	$value = isset( $settings[ $key ] ) ? $settings[ $key ] : '';
	?>
	<tr>
		<th scope="row"><label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
		<td>
			<?php if ( 'textarea' === $type ) : ?>
				<textarea id="<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>" rows="4" class="large-text code"><?php echo esc_textarea( (string) $value ); ?></textarea>
			<?php else : ?>
				<input type="text" id="<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>" class="regular-text" value="<?php echo esc_attr( (string) $value ); ?>" />
			<?php endif; ?>
			<p class="description"><?php echo esc_html( $help ); ?></p>
		</td>
	</tr>
	<?php
};
?>
<div class="wrap wpd-seo-wrap">
	<h1><?php esc_html_e( 'SEO &amp; Performance', 'wpd-seo' ); ?></h1>

	<?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
	<?php if ( isset( $_GET['updated'] ) ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Settings saved.', 'wpd-seo' ); ?></p></div>
	<?php endif; ?>

	<div class="wpd-panel">
		<h2><?php esc_html_e( 'Site health', 'wpd-seo' ); ?></h2>
		<table class="wpd-health">
			<?php foreach ( WPD_Admin::health_checks() as $check ) : ?>
				<tr class="status-<?php echo esc_attr( $check['status'] ); ?>">
					<td class="dot"><span></span></td>
					<th><?php echo esc_html( $check['label'] ); ?></th>
					<td><?php echo esc_html( $check['note'] ); ?></td>
				</tr>
			<?php endforeach; ?>
			<tr>
				<td class="dot"><span></span></td>
				<th><?php esc_html_e( 'Detected builders', 'wpd-seo' ); ?></th>
				<td><?php echo esc_html( $detect ? $detect->summary() : __( 'Unknown', 'wpd-seo' ) ); ?></td>
			</tr>
		</table>
	</div>

	<?php
	$wpd_token     = (string) WPD_Options::get( 'debug_token', '' );
	$wpd_debug_url = $wpd_token ? add_query_arg( 'wpd-debug', $wpd_token, home_url( '/' ) ) : '';
	?>
	<div class="wpd-panel">
		<h2><?php esc_html_e( 'Debugging', 'wpd-seo' ); ?></h2>
		<p class="description">
			<?php esc_html_e( 'Open this URL in a private window, then View Source (Ctrl+U) and scroll to the bottom. The report says whether optimisation ran, and what was decided for every script, stylesheet and image — with the reason for each.', 'wpd-seo' ); ?>
		</p>
		<?php if ( $wpd_debug_url ) : ?>
			<p>
				<input type="text" class="large-text code" readonly
					onfocus="this.select();"
					value="<?php echo esc_attr( $wpd_debug_url ); ?>" />
			</p>
			<p class="description">
				<?php esc_html_e( 'Treat this link as a password — the report lists your active plugins. Add ?wpd-debug=TOKEN to any URL on the site, or define WPD_SEO_DEBUG in wp-config.php to show it on every page.', 'wpd-seo' ); ?>
			</p>
		<?php else : ?>
			<p class="description"><?php esc_html_e( 'Reload this page to generate a debug link.', 'wpd-seo' ); ?></p>
		<?php endif; ?>
	</div>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="wpd_seo_save" />
		<?php wp_nonce_field( WPD_Admin::NONCE ); ?>

		<h2 class="title"><?php esc_html_e( 'SEO', 'wpd-seo' ); ?></h2>
		<table class="form-table" role="presentation">
			<?php
			$wpd_field( 'title_separator', __( 'Title separator', 'wpd-seo' ), __( 'Character between the page title and the site name.', 'wpd-seo' ), $settings );
			$wpd_field( 'org_name', __( 'Organisation name', 'wpd-seo' ), __( 'Used in schema. Defaults to the site title.', 'wpd-seo' ), $settings );
			$wpd_field( 'org_logo', __( 'Organisation logo URL', 'wpd-seo' ), __( 'Square PNG/SVG, at least 112×112. Used in schema and as the social fallback image.', 'wpd-seo' ), $settings );
			$wpd_field( 'twitter_site', __( 'X / Twitter handle', 'wpd-seo' ), __( 'Without the @.', 'wpd-seo' ), $settings );
			$wpd_field( 'social_profiles', __( 'Social profile URLs', 'wpd-seo' ), __( 'One per line. Emitted as schema sameAs.', 'wpd-seo' ), $settings, 'textarea' );
			$wpd_toggle( 'og_enabled', __( 'Social tags', 'wpd-seo' ), __( 'Output Open Graph and Twitter Card tags', 'wpd-seo' ), $settings );
			$wpd_toggle( 'noindex_search', __( 'Search results', 'wpd-seo' ), __( 'noindex internal search result pages (recommended)', 'wpd-seo' ), $settings );
			$wpd_toggle( 'noindex_archives', __( 'Archives', 'wpd-seo' ), __( 'noindex category/tag/date archives', 'wpd-seo' ), $settings );
			$wpd_toggle( 'noindex_attachment', __( 'Attachment pages', 'wpd-seo' ), __( 'noindex attachment pages (recommended)', 'wpd-seo' ), $settings );
			$wpd_toggle( 'schema', __( 'Structured data', 'wpd-seo' ), __( 'Output JSON-LD schema graph', 'wpd-seo' ), $settings );
			$wpd_toggle( 'sitemap', __( 'XML sitemap', 'wpd-seo' ), __( 'Enhance the core sitemap with lastmod and noindex exclusion', 'wpd-seo' ), $settings );
			$wpd_toggle( 'robots', __( 'robots.txt', 'wpd-seo' ), __( 'Serve a managed robots.txt', 'wpd-seo' ), $settings );
			$wpd_toggle( 'breadcrumbs', __( 'Breadcrumbs', 'wpd-seo' ), __( 'Enable [wpd_breadcrumbs] and BreadcrumbList schema', 'wpd-seo' ), $settings );
			?>
		</table>

		<h2 class="title"><?php esc_html_e( 'Performance', 'wpd-seo' ); ?></h2>
		<table class="form-table" role="presentation">
			<?php
			$wpd_toggle( 'defer_js', __( 'Defer JavaScript', 'wpd-seo' ), __( 'Add defer to non-critical scripts (builder scripts are excluded automatically)', 'wpd-seo' ), $settings );
			$wpd_toggle( 'delay_js_until_input', __( 'Delay third-party JS', 'wpd-seo' ), __( 'Hold analytics/pixels until the first interaction — big TBT win, test before shipping', 'wpd-seo' ), $settings );
			$wpd_toggle( 'lcp_priority', __( 'LCP image priority', 'wpd-seo' ), __( 'Preload the hero image and mark it fetchpriority=high', 'wpd-seo' ), $settings );
			$wpd_toggle( 'lazy_images', __( 'Lazy load', 'wpd-seo' ), __( 'Lazy-load below-the-fold images and iframes', 'wpd-seo' ), $settings );
			$wpd_toggle( 'add_dimensions', __( 'Image dimensions', 'wpd-seo' ), __( 'Add missing width/height to prevent layout shift', 'wpd-seo' ), $settings );
			$wpd_toggle( 'remove_emojis', __( 'Emoji script', 'wpd-seo' ), __( 'Remove the core emoji detection script', 'wpd-seo' ), $settings );
			$wpd_toggle( 'remove_embeds', __( 'oEmbed script', 'wpd-seo' ), __( 'Remove wp-embed.js and oEmbed discovery links', 'wpd-seo' ), $settings );
			$wpd_toggle( 'disable_dashicons', __( 'Dashicons', 'wpd-seo' ), __( 'Drop Dashicons on the front end for logged-out visitors', 'wpd-seo' ), $settings );
			$wpd_toggle( 'jquery_migrate', __( 'jQuery Migrate', 'wpd-seo' ), __( 'Remove jquery-migrate (test older themes first)', 'wpd-seo' ), $settings );
			$wpd_toggle( 'remove_block_css', __( 'Block library CSS', 'wpd-seo' ), __( 'Drop wp-block-library on pages with no blocks', 'wpd-seo' ), $settings );
			$wpd_toggle( 'minify_html', __( 'Minify HTML', 'wpd-seo' ), __( 'Collapse whitespace and strip comments', 'wpd-seo' ), $settings );
			$wpd_toggle( 'font_display_swap', __( 'font-display: swap', 'wpd-seo' ), __( 'Force swap on Google Fonts URLs', 'wpd-seo' ), $settings );
			$wpd_toggle( 'cache_headers', __( 'Cache headers', 'wpd-seo' ), __( 'Send s-maxage / stale-while-revalidate for anonymous visitors', 'wpd-seo' ), $settings );
			$wpd_toggle( 'heartbeat_throttle', __( 'Heartbeat', 'wpd-seo' ), __( 'Throttle admin heartbeat and disable it on the front end', 'wpd-seo' ), $settings );
			$wpd_field( 'preload_fonts', __( 'Preload fonts', 'wpd-seo' ), __( 'One woff2 URL per line. Two faces is usually the sweet spot; four is the hard cap.', 'wpd-seo' ), $settings, 'textarea' );
			$wpd_field( 'preconnect', __( 'Preconnect origins', 'wpd-seo' ), __( 'One origin per line, e.g. https://fonts.gstatic.com', 'wpd-seo' ), $settings, 'textarea' );
			$wpd_field( 'critical_css', __( 'Critical CSS', 'wpd-seo' ), __( 'Inlined in the head before anything else. Paste above-the-fold CSS only.', 'wpd-seo' ), $settings, 'textarea' );
			?>
		</table>

		<?php if ( class_exists( 'WPD_Woo' ) && WPD_Woo::is_active() ) : ?>
			<h2 class="title"><?php esc_html_e( 'WooCommerce', 'wpd-seo' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'Cart, checkout, account and order pages are excluded from every optimisation automatically — those pages are per-visitor and must never be cached or rewritten.', 'wpd-seo' ); ?>
			</p>
			<table class="form-table" role="presentation">
				<?php
				$wpd_toggle( 'woo_schema', __( 'Product schema', 'wpd-seo' ), __( 'Emit Product/Offer/AggregateRating JSON-LD and replace WooCommerce\'s disconnected version', 'wpd-seo' ), $settings );
				$wpd_toggle( 'woo_noindex_pages', __( 'noindex store pages', 'wpd-seo' ), __( 'Keep cart, checkout, account and filtered archives out of the index', 'wpd-seo' ), $settings );
				$wpd_toggle( 'woo_conditional_assets', __( 'Conditional store assets', 'wpd-seo' ), __( 'Load WooCommerce CSS/JS only on pages that show store UI', 'wpd-seo' ), $settings );
				$wpd_toggle( 'woo_disable_cart_fragments', __( 'Cart fragments', 'wpd-seo' ), __( 'Disable the cart-fragments AJAX call off the cart/checkout — turn this off if your header shows a live cart count', 'wpd-seo' ), $settings );
				?>
			</table>
		<?php endif; ?>

		<?php submit_button(); ?>
	</form>
</div>

<?php
/**
 * Admin: settings screen, per-post SEO box, and a health panel that reports
 * what was detected on this site.
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

class WPD_Admin {

	const PAGE  = 'wpd-seo';
	const NONCE = 'wpd_seo_save';

	/** @var WPD_Admin|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_init', array( $this, 'ensure_debug_token' ) );
		add_action( 'admin_post_wpd_seo_save', array( $this, 'handle_save' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );

		add_action( 'add_meta_boxes', array( $this, 'add_meta_box' ) );
		add_action( 'save_post', array( $this, 'save_meta_box' ), 10, 2 );
	}

	/**
	 * The debug URL token. Generated once, in admin only, so the front end
	 * never writes to options.
	 */
	public function ensure_debug_token() {
		if ( '' === (string) WPD_Options::get( 'debug_token', '' ) ) {
			WPD_Options::update( array( 'debug_token' => wp_generate_password( 16, false ) ) );
		}
	}

	public function add_menu() {
		add_menu_page(
			__( 'SEO & Performance', 'wpd-seo' ),
			__( 'SEO & Speed', 'wpd-seo' ),
			'manage_options',
			self::PAGE,
			array( $this, 'render_page' ),
			'dashicons-performance',
			66
		);
	}

	/**
	 * @param string $hook Current admin page.
	 */
	public function enqueue( $hook ) {
		if ( false === strpos( $hook, self::PAGE ) ) {
			return;
		}
		wp_enqueue_style( 'wpd-seo-admin', WPD_SEO_URL . 'assets/css/admin.css', array(), WPD_SEO_VERSION );
	}

	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'wpd-seo' ) );
		}
		$settings = WPD_Options::all();
		$detect   = class_exists( 'WPD_Builder_Detect' ) ? WPD_Builder_Detect::instance() : null;
		require WPD_SEO_DIR . 'admin/views/settings-page.php';
	}

	public function handle_save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'wpd-seo' ) );
		}
		check_admin_referer( self::NONCE );

		$defaults = WPD_Options::defaults();
		$current  = WPD_Options::all();
		$clean    = array();

		/**
		 * The form posts the name of every checkbox it rendered. Without this
		 * list, an unchecked box and a field the form never showed look
		 * identical in $_POST — which is how a save could switch off module
		 * keys that have no checkbox at all.
		 */
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked above.
		$rendered = isset( $_POST['wpd_present'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['wpd_present'] ) ) : array();

		foreach ( $defaults as $key => $default ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked above.
			$posted = isset( $_POST[ $key ] );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked above.
			$raw = $posted ? wp_unslash( $_POST[ $key ] ) : null;

			if ( '_schema' === $key ) {
				$clean[ $key ] = WPD_Options::SCHEMA_VERSION;
				continue;
			}

			// Anything this form did not render keeps its stored value. Without
			// this, saving would wipe internal keys such as the debug token.
			if ( ! $posted && ! in_array( $key, $rendered, true ) ) {
				$clean[ $key ] = isset( $current[ $key ] ) ? $current[ $key ] : $default;
				continue;
			}

			if ( is_int( $default ) ) {
				$clean[ $key ] = ( null === $raw ) ? 0 : 1;
				continue;
			}

			if ( in_array( $key, array( 'critical_css' ), true ) ) {
				$clean[ $key ] = is_string( $raw ) ? wp_strip_all_tags( $raw ) : '';
				continue;
			}
			if ( in_array( $key, array( 'preload_fonts', 'preconnect', 'social_profiles' ), true ) ) {
				$clean[ $key ] = is_string( $raw ) ? sanitize_textarea_field( $raw ) : '';
				continue;
			}
			if ( 'org_logo' === $key ) {
				$clean[ $key ] = is_string( $raw ) ? esc_url_raw( $raw ) : '';
				continue;
			}

			$clean[ $key ] = is_string( $raw ) ? sanitize_text_field( $raw ) : $default;
		}

		WPD_Options::update( $clean );

		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE, 'updated' => '1' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public function add_meta_box() {
		foreach ( get_post_types( array( 'public' => true ) ) as $post_type ) {
			add_meta_box(
				'wpd-seo-box',
				__( 'SEO', 'wpd-seo' ),
				array( $this, 'render_meta_box' ),
				$post_type,
				'normal',
				'default'
			);
		}
	}

	/**
	 * @param WP_Post $post Post object.
	 */
	public function render_meta_box( $post ) {
		wp_nonce_field( 'wpd_seo_meta', 'wpd_seo_meta_nonce' );

		$title   = (string) get_post_meta( $post->ID, '_wpd_title', true );
		$desc    = (string) get_post_meta( $post->ID, '_wpd_description', true );
		$noindex = '1' === (string) get_post_meta( $post->ID, '_wpd_noindex', true );
		?>
		<p>
			<label for="wpd_title"><strong><?php esc_html_e( 'Title tag', 'wpd-seo' ); ?></strong></label><br />
			<input type="text" id="wpd_title" name="wpd_title" class="widefat" maxlength="70"
				value="<?php echo esc_attr( $title ); ?>"
				placeholder="<?php echo esc_attr( get_the_title( $post ) ); ?>" />
			<span class="description"><?php esc_html_e( 'Aim for 50–60 characters. Leave empty to use the post title.', 'wpd-seo' ); ?></span>
		</p>
		<p>
			<label for="wpd_description"><strong><?php esc_html_e( 'Meta description', 'wpd-seo' ); ?></strong></label><br />
			<textarea id="wpd_description" name="wpd_description" class="widefat" rows="3" maxlength="200"><?php echo esc_textarea( $desc ); ?></textarea>
			<span class="description"><?php esc_html_e( 'Aim for 140–158 characters. Leave empty to generate one from the content.', 'wpd-seo' ); ?></span>
		</p>
		<p>
			<label>
				<input type="checkbox" name="wpd_noindex" value="1" <?php checked( $noindex ); ?> />
				<?php esc_html_e( 'Hide this from search engines (noindex) and exclude it from the sitemap', 'wpd-seo' ); ?>
			</label>
		</p>
		<?php
	}

	/**
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 */
	public function save_meta_box( $post_id, $post ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$nonce = isset( $_POST['wpd_seo_meta_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['wpd_seo_meta_nonce'] ) ) : '';
		if ( ! $nonce || ! wp_verify_nonce( $nonce, 'wpd_seo_meta' ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$fields = array(
			'_wpd_title'       => isset( $_POST['wpd_title'] ) ? sanitize_text_field( wp_unslash( $_POST['wpd_title'] ) ) : '',
			'_wpd_description' => isset( $_POST['wpd_description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['wpd_description'] ) ) : '',
			'_wpd_noindex'     => isset( $_POST['wpd_noindex'] ) ? '1' : '',
		);

		foreach ( $fields as $key => $value ) {
			if ( '' === $value ) {
				delete_post_meta( $post_id, $key );
			} else {
				update_post_meta( $post_id, $key, $value );
			}
		}
	}

	/**
	 * Environment checks shown on the settings screen.
	 *
	 * @return array List of array( 'label', 'status' => ok|warn|fail, 'note' ).
	 */
	public static function health_checks() {
		$checks = array();

		$checks[] = array(
			'label'  => __( 'Search engine visibility', 'wpd-seo' ),
			'status' => get_option( 'blog_public' ) ? 'ok' : 'fail',
			'note'   => get_option( 'blog_public' )
				? __( 'Site is indexable.', 'wpd-seo' )
				: __( 'Settings → Reading is blocking search engines. Nothing will rank until you uncheck it.', 'wpd-seo' ),
		);

		$permalink = get_option( 'permalink_structure' );
		$checks[]  = array(
			'label'  => __( 'Permalinks', 'wpd-seo' ),
			'status' => $permalink ? 'ok' : 'fail',
			'note'   => $permalink ? $permalink : __( 'Plain permalinks hurt rankings. Switch to Post name.', 'wpd-seo' ),
		);

		$checks[] = array(
			'label'  => __( 'HTTPS', 'wpd-seo' ),
			'status' => is_ssl() ? 'ok' : 'fail',
			'note'   => is_ssl() ? __( 'Serving over HTTPS.', 'wpd-seo' ) : __( 'No TLS. Core Web Vitals and rankings both suffer.', 'wpd-seo' ),
		);

		$checks[] = array(
			'label'  => __( 'robots.txt', 'wpd-seo' ),
			'status' => WPD_Robots::has_physical_file() ? 'warn' : 'ok',
			'note'   => WPD_Robots::has_physical_file()
				? __( 'A physical robots.txt exists at the web root and overrides this plugin. Edit or delete that file.', 'wpd-seo' )
				: __( 'Managed by this plugin.', 'wpd-seo' ),
		);

		$conflict = WPD_Meta::has_conflicting_seo_plugin();
		$checks[] = array(
			'label'  => __( 'Other SEO plugins', 'wpd-seo' ),
			'status' => $conflict ? 'warn' : 'ok',
			'note'   => $conflict
				? __( 'Another SEO plugin is active, so meta/schema/sitemap output here is disabled. The performance modules still run.', 'wpd-seo' )
				: __( 'None detected.', 'wpd-seo' ),
		);

		$checks[] = array(
			'label'  => __( 'Object/page cache', 'wpd-seo' ),
			'status' => ( defined( 'WP_CACHE' ) && WP_CACHE ) ? 'ok' : 'warn',
			'note'   => ( defined( 'WP_CACHE' ) && WP_CACHE )
				? __( 'WP_CACHE is on.', 'wpd-seo' )
				: __( 'No page cache detected. Add one (host-level or a caching plugin) for the biggest TTFB win.', 'wpd-seo' ),
		);

		if ( class_exists( 'WPD_Woo' ) && WPD_Woo::is_active() ) {
			$checks[] = array(
				'label'  => __( 'WooCommerce', 'wpd-seo' ),
				'status' => 'ok',
				'note'   => __( 'Store mode active: product schema on, cart/checkout/account excluded from caching and optimisation.', 'wpd-seo' ),
			);
		}

		$php_ok   = version_compare( PHP_VERSION, '8.0', '>=' );
		$checks[] = array(
			'label'  => __( 'PHP version', 'wpd-seo' ),
			'status' => $php_ok ? 'ok' : 'warn',
			'note'   => PHP_VERSION,
		);

		return $checks;
	}
}

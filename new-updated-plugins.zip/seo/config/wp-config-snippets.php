<?php
/**
 * wp-config.php constants worth setting on every site.
 *
 * NOT loaded by the plugin. Copy the lines you want into wp-config.php, ABOVE
 * the "That's all, stop editing!" comment near the bottom of that file.
 *
 * @package WPD_SEO
 */

/*
 * This file is a template to be copied or included, never executed in place.
 * An ABSPATH check is wrong here — wp-config.php includes it before ABSPATH
 * exists — so the test is whether this file is itself the entry point.
 */
if ( 'cli' !== PHP_SAPI && isset( $_SERVER['SCRIPT_FILENAME'] )
	&& realpath( __FILE__ ) === realpath( $_SERVER['SCRIPT_FILENAME'] ) ) {
	http_response_code( 404 );
	exit;
}
/* -------------------------------------------------------------------------
 * Database / revision load. Each stored revision is a row that autoload and
 * search queries have to step over.
 * ---------------------------------------------------------------------- */
define( 'WP_POST_REVISIONS', 5 );
define( 'AUTOSAVE_INTERVAL', 120 );
define( 'EMPTY_TRASH_DAYS', 14 );

/* -------------------------------------------------------------------------
 * Cron. wp-cron.php fires on page loads, which adds latency to a random
 * visitor's request. Disable it here and add a real cron entry that runs
 * every 5 minutes:
 *
 *   [star]/5 [star] [star] [star] [star] cd /path/to/site && wp cron event run --due-now
 *
 * ([star] stands in for a literal asterisk — writing them out here would close
 * this comment block early.)
 * ---------------------------------------------------------------------- */
define( 'DISABLE_WP_CRON', true );

/* -------------------------------------------------------------------------
 * Page cache flag. Set by most caching plugins; harmless to declare.
 * ---------------------------------------------------------------------- */
define( 'WP_CACHE', true );

/* -------------------------------------------------------------------------
 * Memory. 256M covers image resizing on most builder sites.
 * ---------------------------------------------------------------------- */
define( 'WP_MEMORY_LIMIT', '256M' );
define( 'WP_MAX_MEMORY_LIMIT', '512M' );

/* -------------------------------------------------------------------------
 * Canonical host. Prevents the "site loads on both www and non-www" duplicate
 * content problem at the source. Set to whichever version you 301 to.
 * ---------------------------------------------------------------------- */
// define( 'WP_HOME', 'https://example.com' );
// define( 'WP_SITEURL', 'https://example.com' );

/* -------------------------------------------------------------------------
 * Behind a proxy/CDN (Cloudflare, load balancer), WordPress can think the
 * request is plain HTTP and generate mixed-content URLs.
 * ---------------------------------------------------------------------- */
if ( isset( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) && 'https' === $_SERVER['HTTP_X_FORWARDED_PROTO'] ) {
	$_SERVER['HTTPS'] = 'on';
}

/* -------------------------------------------------------------------------
 * Production hygiene. Never leave display_errors on: a stray notice printed
 * before the doctype breaks the whole document.
 * ---------------------------------------------------------------------- */
define( 'WP_DEBUG', false );
define( 'WP_DEBUG_DISPLAY', false );
define( 'WP_DEBUG_LOG', true );
define( 'SCRIPT_DEBUG', false );
define( 'CONCATENATE_SCRIPTS', true );

/* -------------------------------------------------------------------------
 * Editing files from the dashboard is both a security and a "someone broke
 * production at 2am" risk.
 * ---------------------------------------------------------------------- */
define( 'DISALLOW_FILE_EDIT', true );

<?php
/**
 * Plugin Name: WPD SEO Loader (must-use)
 * Description: Loads the WPD SEO & Performance Suite from wp-content/plugins/seo as a must-use plugin, so a client cannot deactivate it by accident.
 * Version:     1.0.0
 *
 * INSTALL: copy this single file to wp-content/mu-plugins/wpd-seo-loader.php
 * (create the mu-plugins directory if it does not exist) and keep the suite
 * itself at wp-content/plugins/seo/.
 *
 * Do not activate the plugin normally as well — it would load twice.
 *
 * @package WPD_SEO
 */

defined( 'ABSPATH' ) || exit;

$wpd_seo_bootstrap = WP_PLUGIN_DIR . '/seo/wpd-seo.php';

if ( file_exists( $wpd_seo_bootstrap ) ) {
	require_once $wpd_seo_bootstrap;
} elseif ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
	add_action(
		'admin_notices',
		function () {
			echo '<div class="notice notice-error"><p>WPD SEO loader: wp-content/plugins/seo/wpd-seo.php not found.</p></div>';
		}
	);
}

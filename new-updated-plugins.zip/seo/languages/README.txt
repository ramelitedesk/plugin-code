Translation files (.mo / .po) go here.

Text domain: wpd-seo
Example: wpd-seo-de_DE.mo

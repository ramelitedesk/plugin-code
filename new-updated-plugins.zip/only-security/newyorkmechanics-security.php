<?php
/**
 * Plugin Name:       Site Security
 *
 * The name shown in the plugin list, the Tools menu and the settings screen is
 * built from the site title at runtime (see NYMS_Helpers::plugin_name), so this
 * plugin reads as "<Site Name> Security" wherever it is installed. WordPress
 * parses this header statically out of the file, which is why the literal below
 * cannot itself be dynamic; it is only visible while the plugin is inactive.
 *
 * Description:       Advanced hardening for this site: server rules, upload and package controls, request firewall, login and account protection, two-factor authentication and self-protection. Hardening only - malware scanning is left to a dedicated scanner.
 * Version:           2.1.0
 * Requires at least: 4.0
 * Requires PHP:      5.6
 * Author:            New York Mechanics
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       newyorkmechanics-security
 *
 * @package NYMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'NYMS_VERSION', '2.1.0' );
define( 'NYMS_FILE', __FILE__ );
define( 'NYMS_PATH', plugin_dir_path( __FILE__ ) );
define( 'NYMS_BASENAME', plugin_basename( __FILE__ ) );

require_once NYMS_PATH . 'includes/class-nyms-updates.php';
require_once NYMS_PATH . 'includes/class-nyms-settings.php';

NYMS_Updates::hook();

/**
 * Turn every switch into a constant before any module loads.
 *
 * A constant already defined in wp-config.php always wins and is shown as
 * locked on the settings screen, so the strictest settings can be put beyond
 * the reach of anyone who reaches wp-admin.
 */
NYMS_Settings::define_constants();

require_once NYMS_PATH . 'includes/class-nyms-plugin.php';

NYMS_Plugin::instance()->run();

register_activation_hook( __FILE__, array( 'NYMS_Plugin', 'on_activate' ) );
register_deactivation_hook( __FILE__, array( 'NYMS_Plugin', 'on_deactivate' ) );

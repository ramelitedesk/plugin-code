<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class CFW_Activator {
    public static function activate() {
        self::register_post_type();
        flush_rewrite_rules();
    }

    public static function deactivate() {
        flush_rewrite_rules();
    }

    public static function register_post_type() {
        register_post_type( 'cfw_filter', array(
            'labels' => array(
                'name' => 'Custom Filters',
                'singular_name' => 'Custom Filter',
                'add_new' => 'Add New Filter',
                'add_new_item' => 'Add New Filter',
                'edit_item' => 'Edit Filter',
                'new_item' => 'New Filter',
                'view_item' => 'View Filter',
                'search_items' => 'Search Filters',
            ),
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => true,
            'menu_icon' => 'dashicons-filter',
            'supports' => array( 'title' ),
            'show_in_rest' => false,
        ) );
    }
}

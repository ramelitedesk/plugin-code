<?php
/**
 * Where am I, and does this rule apply here?
 *
 * Both halves of the brief run through this class. "Which pages the widget
 * shows on" is a rule matched against the current view, and "AJAX or reload,
 * page-wise" is a second rule matched against the same view. One resolver, so
 * the two can never disagree about what page you are on.
 *
 * NOT ONE FUNCTION FROM WOOCOMMERCE IS CALLED HERE, and that is the point.
 *
 * The previous version matched locations with is_shop(), is_product_category()
 * and is_product_tag(). Those are WooCommerce functions. On a site without
 * WooCommerce they do not exist, and the call sat on pre_get_posts — which runs
 * on every front-end request. A site with this plugin, no WooCommerce and one
 * saved filter was a fatal error on every page, and half the brief is "and
 * normal site".
 *
 * Everything below uses core conditionals instead. WooCommerce's shop page IS a
 * product post-type archive and its category pages ARE product_cat term
 * archives, so is_post_type_archive( 'product' ) and is_tax( 'product_cat' )
 * identify them exactly, and answer false rather than fatally on a site that
 * has never heard of a product.
 *
 * @package Custom_Filter_Widget
 */

defined( 'ABSPATH' ) || exit;

class CFW_Location {

	/** @var string[]|null This request's location keys, most specific first. */
	private static $current = null;

	/**
	 * Every key describing the view being rendered.
	 *
	 * A list, not one value, because a rule should be writable at whatever
	 * altitude suits it. A product category page answers to
	 * 'term:product_cat:42' and to 'tax:product_cat' and to 'archive:product' —
	 * so "every shop archive" and "this one category" are both sayable, and the
	 * more specific one wins because it comes first.
	 *
	 * @return string[]
	 */
	public static function current() {
		if ( null !== self::$current ) {
			return self::$current;
		}

		$keys = array();

		if ( is_admin() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			// Not a front-end view. Returning nothing means no rule matches,
			// which is what stops the widget rendering into a REST response.
			self::$current = $keys;

			return $keys;
		}

		if ( is_search() ) {
			$keys[] = 'search';
		}

		if ( is_front_page() ) {
			$keys[] = 'front';
		}

		if ( is_home() ) {
			$keys[] = 'blog';
		}

		if ( is_singular() ) {
			$id = (int) get_queried_object_id();

			if ( $id ) {
				// Pages by id, because "show it on these pages" is the request
				// and a page is a thing somebody points at by name.
				$keys[] = ( 'page' === get_post_type( $id ) ? 'page:' : 'post:' ) . $id;
			}

			$type = get_post_type();

			if ( $type ) {
				$keys[] = 'singular:' . $type;
			}
		}

		if ( is_tax() || is_category() || is_tag() ) {
			$term = get_queried_object();

			if ( $term instanceof WP_Term ) {
				$keys[] = 'term:' . $term->taxonomy . ':' . (int) $term->term_id;
				$keys[] = 'tax:' . $term->taxonomy;

				/*
				 * A product category page is also, for the purpose of a rule,
				 * a shop archive. Without this line "show on the shop" would
				 * stop applying the moment a visitor narrows to a category —
				 * the filter would vanish exactly when it became useful.
				 */
				foreach ( self::post_types_for_taxonomy( $term->taxonomy ) as $type ) {
					$keys[] = 'archive:' . $type;
				}
			}
		}

		if ( is_post_type_archive() ) {
			$type = get_query_var( 'post_type' );
			$type = is_array( $type ) ? reset( $type ) : $type;

			if ( $type ) {
				$keys[] = 'archive:' . sanitize_key( $type );
			}
		}

		if ( is_author() ) {
			$keys[] = 'author';
		}

		if ( is_date() ) {
			$keys[] = 'date';
		}

		self::$current = array_values( array_unique( $keys ) );

		return self::$current;
	}

	/**
	 * @param string $taxonomy Taxonomy name.
	 * @return string[] Post types it applies to.
	 */
	private static function post_types_for_taxonomy( $taxonomy ) {
		$object = get_taxonomy( $taxonomy );

		return ( $object && ! empty( $object->object_type ) ) ? array_map( 'sanitize_key', (array) $object->object_type ) : array();
	}

	/**
	 * Does this filter set belong on the current view?
	 *
	 * @param array $config From CFW_Settings::get().
	 * @return bool
	 */
	public static function matches( array $config ) {
		$here = self::current();

		if ( ! $here ) {
			return false;
		}

		if ( 'everywhere' === ( $config['where']['mode'] ?? 'rules' ) ) {
			return true;
		}

		$wanted = (array) ( $config['where']['locations'] ?? array() );

		return (bool) array_intersect( $here, $wanted );
	}

	/**
	 * AJAX or reload, for this filter set, on this view.
	 *
	 * The page-wise part of the brief. Overrides are checked in the order the
	 * current view's keys come back — most specific first — so a rule on one
	 * category beats a rule on the whole shop, and both beat the default.
	 *
	 * @param array $config From CFW_Settings::get().
	 * @return string 'ajax' or 'reload'.
	 */
	public static function method( array $config ) {
		$overrides = (array) ( $config['method']['overrides'] ?? array() );

		foreach ( self::current() as $key ) {
			if ( isset( $overrides[ $key ] ) && in_array( $overrides[ $key ], array( 'ajax', 'reload' ), true ) ) {
				return $overrides[ $key ];
			}
		}

		return ( 'ajax' === ( $config['method']['default'] ?? 'reload' ) ) ? 'ajax' : 'reload';
	}

	/**
	 * The post type whose archive this view is, if it is one.
	 *
	 * Used to decide what a filter should be filtering when nothing says
	 * otherwise — on the shop that is products, on the blog it is posts.
	 *
	 * @return string
	 */
	public static function queried_post_type() {
		foreach ( self::current() as $key ) {
			if ( 0 === strpos( $key, 'archive:' ) ) {
				return substr( $key, 8 );
			}
		}

		if ( is_home() || is_search() || is_category() || is_tag() || is_author() || is_date() ) {
			return 'post';
		}

		return '';
	}

	/**
	 * Keep a location key to the shape this class produces.
	 *
	 * @param mixed $key Untrusted.
	 * @return string '' if it is not a location key.
	 */
	public static function sanitize_key_string( $key ) {
		if ( ! is_string( $key ) ) {
			return '';
		}

		$key = trim( $key );

		// Letters, digits, underscore, dash and the colons that separate the
		// parts. Anything else is not a key this class ever made.
		if ( ! preg_match( '/^[a-z0-9_\-]+(:[a-z0-9_\-]+){0,2}$/i', $key ) ) {
			return '';
		}

		return $key;
	}

	/**
	 * The locations offered in the admin, grouped for the screen.
	 *
	 * Built from the site rather than hardcoded, so a shop shows its real
	 * product categories and a site with a Portfolio post type can target the
	 * portfolio archive without anybody writing a line of code.
	 *
	 * @return array<string,array<string,string>> group label => key => label.
	 */
	public static function choices() {
		$groups = array();

		$groups[ __( 'Site', 'custom-filter-widget' ) ] = array(
			'front'  => __( 'Front page', 'custom-filter-widget' ),
			'blog'   => __( 'Blog / posts page', 'custom-filter-widget' ),
			'search' => __( 'Search results', 'custom-filter-widget' ),
			'author' => __( 'Author archives', 'custom-filter-widget' ),
			'date'   => __( 'Date archives', 'custom-filter-widget' ),
		);

		/* ---------------- pages ---------------- */

		$pages = get_posts(
			array(
				'post_type'   => 'page',
				'post_status' => 'publish',
				'numberposts' => 200,
				'orderby'     => 'title',
				'order'       => 'ASC',
			)
		);

		$page_choices = array();

		foreach ( $pages as $page ) {
			$page_choices[ 'page:' . $page->ID ] = $page->post_title ? $page->post_title : sprintf( '#%d', $page->ID );
		}

		if ( $page_choices ) {
			$groups[ __( 'Pages', 'custom-filter-widget' ) ] = $page_choices;
		}

		/* ---------------- archives ---------------- */

		$archives = array();
		$singles  = array();

		foreach ( get_post_types( array( 'public' => true ), 'objects' ) as $type ) {
			if ( 'attachment' === $type->name ) {
				continue;
			}

			if ( $type->has_archive || 'post' === $type->name ) {
				/* translators: %s: post type name. */
				$archives[ 'archive:' . $type->name ] = sprintf( __( '%s archive', 'custom-filter-widget' ), $type->labels->name );
			}

			/* translators: %s: post type name. */
			$singles[ 'singular:' . $type->name ] = sprintf( __( 'Single %s', 'custom-filter-widget' ), $type->labels->singular_name );
		}

		if ( $archives ) {
			$groups[ __( 'Archives', 'custom-filter-widget' ) ] = $archives;
		}

		/* ---------------- taxonomy archives ---------------- */

		$taxes = array();

		foreach ( get_taxonomies( array( 'public' => true ), 'objects' ) as $tax ) {
			/* translators: %s: taxonomy name. */
			$taxes[ 'tax:' . $tax->name ] = sprintf( __( 'Any %s archive', 'custom-filter-widget' ), $tax->labels->singular_name );
		}

		if ( $taxes ) {
			$groups[ __( 'Taxonomy archives', 'custom-filter-widget' ) ] = $taxes;
		}

		if ( $singles ) {
			$groups[ __( 'Single items', 'custom-filter-widget' ) ] = $singles;
		}

		/**
		 * Add or remove locations a rule can name.
		 *
		 * @param array $groups group label => array of key => label.
		 */
		return apply_filters( 'cfw_location_choices', $groups );
	}

	/**
	 * A location key written out for a human.
	 *
	 * @param string $key Location key.
	 * @return string
	 */
	public static function label( $key ) {
		foreach ( self::choices() as $choices ) {
			if ( isset( $choices[ $key ] ) ) {
				return $choices[ $key ];
			}
		}

		// A rule can name a specific term, which is not offered in the list
		// above because a big shop has thousands. Read it back if it is real.
		if ( preg_match( '/^term:([a-z0-9_\-]+):(\d+)$/i', $key, $match ) ) {
			$term = get_term( (int) $match[2], $match[1] );

			if ( $term instanceof WP_Term ) {
				return $term->name;
			}
		}

		return $key;
	}

	/**
	 * Forget this request's answer. Tests only.
	 */
	public static function reset() {
		self::$current = null;
	}
}

<?php
/**
 * Loading the stylesheet and the script, and only where a filter is.
 *
 * Nothing is enqueued until something renders. A site with one filter on one
 * page should not put this plugin's CSS on every other page, and a theme that
 * loads its stylesheet last will win any conflict anyway — so the smaller the
 * footprint, the fewer arguments.
 *
 * @package Custom_Filter_Widget
 */

defined( 'ABSPATH' ) || exit;

class CFW_Assets {

	/** @var bool Has anything on this page asked for the assets? */
	private static $wanted = false;

	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register' ) );
		add_action( 'wp_footer', array( __CLASS__, 'print_custom_css' ), 20 );
	}

	/**
	 * Registered on every page, enqueued only when asked for.
	 *
	 * Registering early matters: a filter rendered inside the_content runs
	 * after wp_enqueue_scripts has finished, and wp_enqueue_style on an
	 * unregistered handle at that point does nothing at all — silently.
	 */
	public static function register() {
		wp_register_style( 'cfw', CFW_URL . 'public/css/filter.css', array(), CFW_VERSION );

		wp_register_script( 'cfw', CFW_URL . 'public/js/filter.js', array(), CFW_VERSION, true );

		wp_localize_script(
			'cfw',
			'CFWData',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				/*
				 * No nonce, deliberately.
				 *
				 * This endpoint reads published content and writes nothing, so
				 * a nonce buys no protection — and it costs a great deal. A
				 * nonce is baked into the HTML, so on any page served from a
				 * full-page cache it is stale, and every AJAX filter on the
				 * site fails for as long as the cache lives. The previous
				 * version had exactly this problem.
				 */
				'i18n'    => array(
					'loading' => __( 'Loading…', 'custom-filter-widget' ),
					'failed'  => __( 'Could not load results. Please try again.', 'custom-filter-widget' ),
				),
			)
		);
	}

	/**
	 * Something is being rendered; the assets will be needed.
	 */
	public static function needed() {
		self::$wanted = true;

		wp_enqueue_style( 'cfw' );
		wp_enqueue_script( 'cfw' );
	}

	/**
	 * @return bool
	 */
	public static function is_wanted() {
		return self::$wanted;
	}

	/**
	 * Any custom CSS the filter sets on this page carry.
	 */
	public static function print_custom_css() {
		if ( ! self::$wanted ) {
			return;
		}

		$css = CFW_Render::custom_css( CFW_Query::active_filters() );

		if ( '' === trim( $css ) ) {
			return;
		}

		printf( "<style id='cfw-custom-css'>%s</style>\n", $css ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- stripped of tags by CFW_Settings::clean_css().
	}
}

<?php
/**
 * The sidebar widget.
 *
 * A thin wrapper: it picks a filter set and hands off to CFW_Render, which is
 * the same path the shortcode takes. The widget deciding anything for itself is
 * how a sidebar filter and a shortcode filter end up behaving differently.
 *
 * @package Custom_Filter_Widget
 */

defined( 'ABSPATH' ) || exit;

class CFW_Widget extends WP_Widget {

	public static function init() {
		add_action(
			'widgets_init',
			static function () {
				register_widget( 'CFW_Widget' );
			}
		);
	}

	public function __construct() {
		parent::__construct(
			'cfw_filter_widget',
			__( 'Custom Filter', 'custom-filter-widget' ),
			array(
				'description' => __( 'Shows one of your filter sets. Where it appears is set on the filter set itself.', 'custom-filter-widget' ),
				'show_instance_in_rest' => true,
			)
		);
	}

	/**
	 * @param array $args     Sidebar wrappers.
	 * @param array $instance Saved settings.
	 */
	public function widget( $args, $instance ) {
		$id = absint( $instance['filter_id'] ?? 0 );

		if ( ! $id ) {
			return;
		}

		$html = CFW_Render::widget( $id );

		/*
		 * before_widget goes out only if there is something to put in it.
		 *
		 * Printing the wrapper first and finding nothing to render leaves an
		 * empty bordered box in the sidebar on every page the filter is not
		 * meant for — which, given the whole point is page-wise display, is
		 * most of them.
		 */
		if ( '' === $html ) {
			return;
		}

		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- theme markup.
		echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in CFW_Render.
		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- theme markup.
	}

	/**
	 * @param array $instance Saved settings.
	 */
	public function form( $instance ) {
		$selected = absint( $instance['filter_id'] ?? 0 );

		$sets = get_posts(
			array(
				'post_type'   => CFW_Settings::POST_TYPE,
				'post_status' => 'publish',
				'numberposts' => 100,
				'orderby'     => 'title',
				'order'       => 'ASC',
			)
		);
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'filter_id' ) ); ?>">
				<?php esc_html_e( 'Filter set:', 'custom-filter-widget' ); ?>
			</label>

			<select class="widefat"
				id="<?php echo esc_attr( $this->get_field_id( 'filter_id' ) ); ?>"
				name="<?php echo esc_attr( $this->get_field_name( 'filter_id' ) ); ?>">
				<option value="0"><?php esc_html_e( '— Select —', 'custom-filter-widget' ); ?></option>
				<?php foreach ( $sets as $set ) : ?>
					<option value="<?php echo esc_attr( $set->ID ); ?>" <?php selected( $selected, $set->ID ); ?>>
						<?php echo esc_html( $set->post_title ? $set->post_title : sprintf( '#%d', $set->ID ) ); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</p>

		<?php if ( ! $sets ) : ?>
			<p><?php esc_html_e( 'No filter sets yet — create one under Custom Filters first.', 'custom-filter-widget' ); ?></p>
		<?php endif; ?>

		<p class="description">
			<?php esc_html_e( 'Which pages this appears on, and whether it uses AJAX or a page reload, are set on the filter set itself — not here.', 'custom-filter-widget' ); ?>
		</p>
		<?php
	}

	/**
	 * @param array $new_instance Submitted.
	 * @param array $old_instance Previous.
	 * @return array
	 */
	public function update( $new_instance, $old_instance ) {
		return array( 'filter_id' => absint( $new_instance['filter_id'] ?? 0 ) );
	}
}

<?php
/**
 * The hooks: rendering, the reload path, and the AJAX path.
 *
 * BOTH PATHS ARE ALWAYS BUILT. Which one a visitor gets is decided per page by
 * CFW_Location::method(), which is the page-wise part of the brief. The server
 * always applies the filters to the main query, whatever the method — so a
 * filtered URL opened directly, shared, bookmarked or crawled shows filtered
 * results even in AJAX mode. AJAX only saves the round trip; it is not what
 * makes the filtering happen.
 *
 * @package Custom_Filter_Widget
 */

defined( 'ABSPATH' ) || exit;

class CFW_Frontend {

	/**
	 * Whether a constraint pass is already running.
	 *
	 * Reading the configuration means querying the posts it is stored in, and
	 * WooCommerce runs its product_query hook over that query too — which
	 * calls straight back in here. Without this the shop page recursed until
	 * PHP ran out of memory, which on a 1 GB limit took about four seconds
	 * and produced a blank page.
	 *
	 * @var bool
	 */
	private static $constraining = false;

	public static function init() {
		add_shortcode( 'cfw_filter', array( __CLASS__, 'shortcode_filter' ) );
		add_shortcode( 'cfw_results', array( __CLASS__, 'shortcode_results' ) );

		// Priority 20: WooCommerce rewrites the shop page's query into a
		// product query on pre_get_posts at 10, and these constraints have to
		// merge on top of that rather than be overwritten by it.
		add_action( 'pre_get_posts', array( __CLASS__, 'filter_main_query' ), 20 );

		add_action( 'wp_ajax_cfw_filter', array( __CLASS__, 'ajax' ) );
		add_action( 'wp_ajax_nopriv_cfw_filter', array( __CLASS__, 'ajax' ) );

		/*
		 * Wrappers around WooCommerce's product loop, so the script has
		 * something to replace. Hooked only when WooCommerce is present —
		 * add_action on a hook that never fires is harmless, but the callbacks
		 * would call is_shop().
		 */
		if ( CFW_Sources::woo() ) {
			/*
			 * The product loop is not always the main query.
			 *
			 * On a theme with no WooCommerce support the shop page renders
			 * through woocommerce_content(), which runs a *secondary* WP_Query
			 * for the products while the main query stays on the shop page
			 * itself. Filtering only the main query therefore filtered the
			 * page object and left the product grid untouched — the widget
			 * worked, the URL updated, and the same products came back.
			 *
			 * This is WooCommerce's own extension point for the loop, and it
			 * fires whichever query is behind it.
			 */
			add_action( 'woocommerce_product_query', array( __CLASS__, 'filter_product_query' ), 20 );

			add_action( 'woocommerce_before_shop_loop', array( __CLASS__, 'results_open' ), 5 );
			add_action( 'woocommerce_after_shop_loop', array( __CLASS__, 'results_close' ), 999 );
			add_action( 'woocommerce_no_products_found', array( __CLASS__, 'empty_marker' ), 5 );
		}
	}

	/* ------------------------------------------------------------------ *
	 * Rendering
	 * ------------------------------------------------------------------ */

	/**
	 * @param array $atts id.
	 * @return string
	 */
	public static function shortcode_filter( $atts ) {
		$atts = shortcode_atts( array( 'id' => 0 ), $atts, 'cfw_filter' );

		return CFW_Render::widget( absint( $atts['id'] ) );
	}

	/* ------------------------------------------------------------------ *
	 * The reload path — and the foundation under the AJAX one
	 * ------------------------------------------------------------------ */

	/**
	 * Apply whatever is in the URL to the page's own query.
	 *
	 * Runs for both methods on purpose. In AJAX mode the script replaces the
	 * results without a reload, but the URL it writes has to mean something on
	 * its own: somebody will copy it, send it to a colleague, or refresh. If
	 * only the AJAX path filtered, that URL would come back unfiltered and the
	 * filter would look like it had forgotten.
	 *
	 * @param WP_Query $query The query being prepared.
	 */
	public static function filter_main_query( $query ) {
		if ( is_admin() || ! $query->is_main_query() ) {
			return;
		}

		/*
		 * Only real content archives. Without this the filters would also be
		 * applied to a feed, and to the query behind a sitemap — both of which
		 * are main queries on the front end.
		 *
		 * The exception is the one page that matters most. WooCommerce's shop
		 * is a *page* — is_singular() is true on it — whose main query has
		 * been turned into a product listing. Treating it like any other
		 * singular view switched the filter off on the single view this
		 * plugin most exists for, and did it silently: the widget rendered,
		 * the URL updated, the checkboxes stayed ticked, and the same
		 * products came back every time.
		 */
		if ( is_feed() || is_404() ) {
			return;
		}

		if ( is_singular() && ! self::is_listing_page() ) {
			return;
		}

		self::constrain( $query );
	}

	/**
	 * The WooCommerce product loop, wherever it is being run from.
	 *
	 * @param WP_Query $query The loop's query.
	 */
	public static function filter_product_query( $query ) {
		if ( is_admin() ) {
			return;
		}

		self::constrain( $query );
	}

	/**
	 * Merge whatever is in the request into one query.
	 *
	 * @param WP_Query $query Query to constrain.
	 */
	private static function constrain( $query ) {
		if ( self::$constraining ) {
			return;
		}

		self::$constraining = true;

		self::apply_request( $query );

		self::$constraining = false;
	}

	/**
	 * @param WP_Query $query Query to constrain.
	 */
	private static function apply_request( $query ) {
		$active = CFW_Query::active_filters();

		if ( ! $active ) {
			return;
		}

		$pieces = CFW_Query::pieces( $active );

		if ( ! $pieces['tax'] && ! $pieces['meta'] && ! $pieces['date'] && ! $pieces['extra'] ) {
			return;
		}

		CFW_Query::apply( $query, $pieces );
	}

	/**
	 * Is this a singular view whose main query is really a listing?
	 *
	 * Only WooCommerce does this in core, but a theme or plugin can do the
	 * same trick, so the answer is filterable rather than hard-coded.
	 *
	 * @return bool
	 */
	private static function is_listing_page() {
		// function_exists() is the whole test: is_shop() only exists when
		// WooCommerce is loaded, so asking twice adds nothing.
		$listing = function_exists( 'is_shop' ) && is_shop();

		/**
		 * Whether the current singular view should be filtered anyway.
		 *
		 * @param bool $listing Whether this page lists content.
		 */
		return (bool) apply_filters( 'cfw_is_listing_page', $listing );
	}

	/* ------------------------------------------------------------------ *
	 * The AJAX path
	 * ------------------------------------------------------------------ */

	/**
	 * Re-render the results for a set of filters.
	 *
	 * Public and unauthenticated, because the content it returns is already
	 * public. What it must not become is a way to read drafts, private posts or
	 * an arbitrary post type, so the post type is checked against what the site
	 * publishes rather than trusted.
	 */
	public static function ajax() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- public read-only endpoint; see CFW_Assets.
		$request = isset( $_POST['filters'] ) && is_array( $_POST['filters'] )
			? map_deep( wp_unslash( $_POST['filters'] ), 'sanitize_text_field' )
			: array();

		$filter_ids = isset( $_POST['filter_ids'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['filter_ids'] ) ) : array();

		$post_type = isset( $_POST['post_type'] ) ? sanitize_key( wp_unslash( $_POST['post_type'] ) ) : 'post';
		$paged     = isset( $_POST['paged'] ) ? max( 1, absint( $_POST['paged'] ) ) : 1;
		// phpcs:enable

		/*
		 * A post type this site publishes, or nothing.
		 *
		 * The previous version took sanitize_key( $_POST['post_type'] ) and
		 * handed it straight to WP_Query. Any registered post type would do,
		 * including private ones, and the loop then printed titles and
		 * excerpts of posts nobody was meant to see.
		 */
		$public = get_post_types( array( 'public' => true ), 'names' );

		if ( ! in_array( $post_type, $public, true ) ) {
			$post_type = 'post';
		}

		// Only filter sets that really belong on the page that asked, so a
		// crafted request cannot borrow a filter set from somewhere else.
		$filter_ids = array_values( array_intersect( $filter_ids, CFW_Settings::all_ids() ) );

		if ( ! $filter_ids ) {
			wp_send_json_error( array( 'message' => __( 'No filters were recognised.', 'custom-filter-widget' ) ), 400 );
		}

		$per_page = (int) get_option( 'posts_per_page', 10 );

		if ( 'product' === $post_type && function_exists( 'wc_get_default_products_per_row' ) ) {
			$per_page = (int) apply_filters( 'loop_shop_per_page', $per_page );
		}

		// Clamped. The old handler took posts_per_page from the request, so one
		// POST asking for 100000 was a way to make the site render itself to
		// death.
		$per_page = max( 1, min( 100, $per_page ) );

		$args = CFW_Query::args(
			$filter_ids,
			$request,
			array(
				'post_type'      => $post_type,
				'posts_per_page' => $per_page,
				'paged'          => $paged,
				'post_status'    => 'publish',
			)
		);

		$query = new WP_Query( $args );

		wp_send_json_success(
			array(
				'html'  => self::results_html( $query, $post_type ),
				'found' => (int) $query->found_posts,
				'pages' => (int) $query->max_num_pages,
			)
		);
	}

	/**
	 * @param WP_Query $query     Results.
	 * @param string   $post_type What was queried.
	 * @return string
	 */
	private static function results_html( WP_Query $query, $post_type ) {
		ob_start();

		if ( ! $query->have_posts() ) {
			printf(
				'<p class="cfw-empty">%s</p>',
				esc_html__( 'No results found.', 'custom-filter-widget' )
			);

			return ob_get_clean();
		}

		/*
		 * Products go through WooCommerce's own template, so the card matches
		 * the rest of the shop — its price format, its badges, its add-to-cart
		 * button, and any override the theme has put in its own woocommerce/
		 * folder. Rendering our own product card would produce a grid that
		 * looks subtly unlike the one it replaced.
		 */
		if ( 'product' === $post_type && function_exists( 'wc_get_template_part' ) ) {
			woocommerce_product_loop_start();

			while ( $query->have_posts() ) {
				$query->the_post();

				wc_get_template_part( 'content', 'product' );
			}

			woocommerce_product_loop_end();

			wp_reset_postdata();

			return ob_get_clean();
		}

		echo '<div class="cfw-results__list">';

		while ( $query->have_posts() ) {
			$query->the_post();

			self::card();
		}

		echo '</div>';

		wp_reset_postdata();

		return ob_get_clean();
	}

	/**
	 * One result, for content that is not a product.
	 */
	private static function card() {
		?>
		<article <?php post_class( 'cfw-card' ); ?>>
			<?php if ( has_post_thumbnail() ) : ?>
				<a class="cfw-card__thumb" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
					<?php the_post_thumbnail( 'medium' ); ?>
				</a>
			<?php endif; ?>

			<h3 class="cfw-card__title">
				<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
			</h3>

			<div class="cfw-card__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 24 ) ); ?></div>
		</article>
		<?php
	}

	/* ------------------------------------------------------------------ *
	 * Marking where the results are, so the script knows what to replace
	 * ------------------------------------------------------------------ */

	/**
	 * @param array  $atts    post_type, per_page.
	 * @param string $content Unused.
	 * @return string
	 */
	public static function shortcode_results( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'post_type' => 'post',
				'per_page'  => (int) get_option( 'posts_per_page', 10 ),
			),
			$atts,
			'cfw_results'
		);

		$post_type = sanitize_key( $atts['post_type'] );

		if ( ! in_array( $post_type, get_post_types( array( 'public' => true ), 'names' ), true ) ) {
			$post_type = 'post';
		}

		$paged = max( 1, (int) get_query_var( 'paged' ), (int) get_query_var( 'page' ) );

		$query = new WP_Query(
			CFW_Query::args(
				CFW_Query::active_filters(),
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended
				$_GET,
				array(
					'post_type'      => $post_type,
					'posts_per_page' => max( 1, min( 100, absint( $atts['per_page'] ) ) ),
					'paged'          => $paged,
					'post_status'    => 'publish',
				)
			)
		);

		CFW_Assets::needed();

		return sprintf(
			'<div class="cfw-results" data-post-type="%s">%s</div>',
			esc_attr( $post_type ),
			self::results_html( $query, $post_type )
		);
	}

	/**
	 * Should the product loop be wrapped on this view?
	 *
	 * Asked of the configuration, not of what has rendered so far.
	 *
	 * It used to ask CFW_Assets::is_wanted() — "has a widget rendered yet?" —
	 * and that is a question about ordering, not about the page. Almost every
	 * theme prints the main content before the sidebar, so at
	 * woocommerce_before_shop_loop the answer was no, the wrapper was never
	 * printed, and the script found nothing to replace. It then did the
	 * honest thing and fell back to a full reload, so an AJAX filter quietly
	 * behaved exactly like a reload one on most themes on the market.
	 *
	 * @return bool
	 */
	private static function should_wrap() {
		return (bool) CFW_Query::active_filters();
	}

	public static function results_open() {
		if ( ! self::should_wrap() ) {
			return;
		}

		echo '<div class="cfw-results" data-post-type="product">';
	}

	public static function results_close() {
		if ( ! self::should_wrap() ) {
			return;
		}

		echo '</div>';
	}

	/**
	 * WooCommerce prints its "no products" notice outside the loop hooks, so
	 * without this the wrapper is never opened on an empty shop — and the
	 * script has nothing to put results back into once a filter is cleared.
	 */
	public static function empty_marker() {
		if ( ! self::should_wrap() ) {
			return;
		}

		echo '<div class="cfw-results" data-post-type="product"></div>';
	}
}

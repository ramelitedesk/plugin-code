<?php
/**
 * One filter set's configuration: reading it, and writing it back safely.
 *
 * Everything else in this plugin asks this class what a filter set is made of.
 * There used to be two copies of the defaults — one in the admin screen and one
 * in the query builder — and they had already drifted: the admin offered a
 * 'chips' style the query builder had never heard of. Two copies of a defaults
 * array is a bug with a delay on it, so there is now one.
 *
 * @package Custom_Filter_Widget
 */

defined( 'ABSPATH' ) || exit;

class CFW_Settings {

	/** The post type each filter set is stored as. */
	const POST_TYPE = 'cfw_filter';

	/** Meta key holding the whole configuration, as one array. */
	const META = '_cfw_config';

	/** @var array<int,array> Configurations already read this request. */
	private static $cache = array();

	/** @var int[]|null The filter sets on this site, read once per request. */
	private static $ids = null;

	/**
	 * What a brand new filter set looks like.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'enabled'  => 1,

			/*
			 * The items shown in the widget, in order.
			 *
			 * A list rather than a single choice, because "category" and "price"
			 * in one sidebar is the normal case, not the exotic one. The old
			 * shape allowed one source per filter set, so a shop wanting three
			 * facets needed three filter sets, three shortcodes and three sets
			 * of page rules kept in step by hand.
			 */
			'items'    => array(),

			/*
			 * Where the widget is allowed to appear.
			 *
			 * 'everywhere' is honest about what it means: every front-end view,
			 * including search results and single posts. 'rules' is the useful
			 * one — a list of locations from CFW_Location.
			 */
			'where'    => array(
				'mode'      => 'rules',
				'locations' => array(),
			),

			/*
			 * How the filter applies, per location.
			 *
			 * 'default' is what any location without its own rule gets. The
			 * overrides are what makes this page-wise: a shop page can reload
			 * (so Woo's own loop, pagination and sorting do the work) while a
			 * blog archive updates over AJAX, in one filter set.
			 */
			'method'   => array(
				'default'   => 'reload',
				'overrides' => array(),
			),

			'labels'   => array(
				'apply'      => 'Apply filters',
				'reset'      => 'Reset',
				'no_results' => 'No results found.',
			),

			/*
			 * Off. An Apply button is one more thing to press, but it is also
			 * the only way to choose three boxes without three page loads.
			 * Switched on automatically for reload locations at render time.
			 */
			'auto_apply' => 0,

			'style'    => array(
				'heading_color'    => '#1d2327',
				'text_color'       => '#3c434a',
				'accent_color'     => '#2271b1',
				'background_color' => '#ffffff',
				'border_color'     => '#dcdcde',
				'border_width'     => 1,
				'border_radius'    => 4,
				'padding'          => 16,
				'item_spacing'     => 8,
				'heading_size'     => 16,
				'font_size'        => 14,
				'layout'           => 'list',
				'custom_css'       => '',
			),
		);
	}

	/**
	 * What one item in the widget looks like.
	 *
	 * @return array
	 */
	public static function item_defaults() {
		return array(
			'source'       => 'product_cat',

			// Filled in from the source's own name when left blank, so a new
			// item is never a heading-less box of checkboxes.
			'heading'      => '',

			/*
			 * Per item, which is what was asked for and is also the only
			 * placement that makes sense. A widget with four facets needs four
			 * headings or it is one undifferentiated list of checkboxes —
			 * "Red, Large, Under £20" with nothing saying which is which.
			 */
			'show_heading' => 1,

			'style'        => 'checkbox',
			'multiple'     => 1,
			'show_count'   => 0,
			'hide_empty'   => 1,

			// How many terms before the list collapses behind a "show all".
			// 0 means never collapse.
			'limit'        => 0,

			// Only meaningful when source is 'taxonomy'.
			'taxonomy'     => '',
		);
	}

	/**
	 * Read one filter set.
	 *
	 * @param int $id Filter set post id.
	 * @return array
	 */
	public static function get( $id ) {
		$id = absint( $id );

		if ( isset( self::$cache[ $id ] ) ) {
			return self::$cache[ $id ];
		}

		$stored = get_post_meta( $id, self::META, true );
		$config = self::merge( is_array( $stored ) ? $stored : array() );

		self::$cache[ $id ] = $config;

		return $config;
	}

	/**
	 * Fill in whatever a stored configuration is missing.
	 *
	 * Recursive over the nested groups rather than a flat wp_parse_args,
	 * because a flat merge on 'style' replaces the whole group: a set saved
	 * before a new style key existed would come back without it, and the
	 * renderer would emit `border-radius: px`.
	 *
	 * @param array $stored What was in the database.
	 * @return array
	 */
	private static function merge( array $stored ) {
		$config = self::defaults();

		foreach ( array( 'where', 'method', 'labels', 'style' ) as $group ) {
			if ( isset( $stored[ $group ] ) && is_array( $stored[ $group ] ) ) {
				$config[ $group ] = array_merge( $config[ $group ], $stored[ $group ] );
			}
		}

		foreach ( array( 'enabled', 'auto_apply' ) as $flag ) {
			if ( isset( $stored[ $flag ] ) ) {
				$config[ $flag ] = (int) $stored[ $flag ];
			}
		}

		if ( ! empty( $stored['items'] ) && is_array( $stored['items'] ) ) {
			foreach ( $stored['items'] as $item ) {
				if ( is_array( $item ) ) {
					$config['items'][] = array_merge( self::item_defaults(), $item );
				}
			}
		}

		return $config;
	}

	/**
	 * Save one filter set, sanitising everything on the way in.
	 *
	 * Sanitising on save rather than on output is deliberate. Output happens on
	 * every page load and in three different renderers; save happens once, in
	 * one place, by somebody who already has edit_post. Cleaning at the door
	 * means the renderers can trust what they are given.
	 *
	 * @param int   $id     Filter set post id.
	 * @param array $raw    Unsanitised input.
	 */
	public static function save( $id, array $raw ) {
		$id = absint( $id );

		$clean = self::defaults();

		$clean['enabled']    = empty( $raw['enabled'] ) ? 0 : 1;
		$clean['auto_apply'] = empty( $raw['auto_apply'] ) ? 0 : 1;

		/* ---------------- items ---------------- */

		if ( ! empty( $raw['items'] ) && is_array( $raw['items'] ) ) {
			foreach ( $raw['items'] as $item ) {
				if ( ! is_array( $item ) || empty( $item['source'] ) ) {
					continue;
				}

				$source = sanitize_key( $item['source'] );

				// An item naming a source this site does not have is dropped
				// rather than kept. Keeping it means a widget that renders an
				// empty box with a heading over it and no way to tell why.
				if ( ! CFW_Sources::exists( $source ) ) {
					continue;
				}

				$clean['items'][] = array(
					'source'       => $source,
					'heading'      => sanitize_text_field( $item['heading'] ?? '' ),
					'show_heading' => empty( $item['show_heading'] ) ? 0 : 1,
					'style'        => in_array( $item['style'] ?? '', array( 'checkbox', 'radio', 'dropdown', 'chips' ), true ) ? $item['style'] : 'checkbox',
					'multiple'     => empty( $item['multiple'] ) ? 0 : 1,
					'show_count'   => empty( $item['show_count'] ) ? 0 : 1,
					'hide_empty'   => empty( $item['hide_empty'] ) ? 0 : 1,
					'limit'        => min( 200, absint( $item['limit'] ?? 0 ) ),
					'taxonomy'     => sanitize_key( $item['taxonomy'] ?? '' ),
				);
			}
		}

		/* ---------------- where ---------------- */

		$clean['where']['mode'] = ( 'everywhere' === ( $raw['where']['mode'] ?? '' ) ) ? 'everywhere' : 'rules';

		if ( ! empty( $raw['where']['locations'] ) && is_array( $raw['where']['locations'] ) ) {
			foreach ( $raw['where']['locations'] as $location ) {
				$location = CFW_Location::sanitize_key_string( $location );

				if ( '' !== $location ) {
					$clean['where']['locations'][] = $location;
				}
			}

			$clean['where']['locations'] = array_values( array_unique( $clean['where']['locations'] ) );
		}

		/* ---------------- method, per location ---------------- */

		$clean['method']['default'] = ( 'ajax' === ( $raw['method']['default'] ?? '' ) ) ? 'ajax' : 'reload';

		if ( ! empty( $raw['method']['overrides'] ) && is_array( $raw['method']['overrides'] ) ) {
			foreach ( $raw['method']['overrides'] as $location => $method ) {
				$location = CFW_Location::sanitize_key_string( $location );

				// 'inherit' is a real choice and it is the one that must not be
				// stored: an override recorded as "same as the default" stops
				// following the default the moment somebody changes it.
				if ( '' === $location || ! in_array( $method, array( 'ajax', 'reload' ), true ) ) {
					continue;
				}

				$clean['method']['overrides'][ $location ] = $method;
			}
		}

		/* ---------------- labels ---------------- */

		foreach ( array( 'apply', 'reset', 'no_results' ) as $key ) {
			$value = sanitize_text_field( $raw['labels'][ $key ] ?? '' );

			if ( '' !== $value ) {
				$clean['labels'][ $key ] = $value;
			}
		}

		/* ---------------- style ---------------- */

		foreach ( array( 'heading_color', 'text_color', 'accent_color', 'background_color', 'border_color' ) as $key ) {
			$colour = sanitize_hex_color( $raw['style'][ $key ] ?? '' );

			// A rejected colour falls back to the default rather than to empty.
			// An empty custom property makes the whole declaration invalid, and
			// the element inherits something arbitrary from the theme.
			if ( $colour ) {
				$clean['style'][ $key ] = $colour;
			}
		}

		$limits = array(
			'border_width'  => 20,
			'border_radius' => 60,
			'padding'       => 80,
			'item_spacing'  => 60,
			'heading_size'  => 60,
			'font_size'     => 40,
		);

		foreach ( $limits as $key => $max ) {
			if ( isset( $raw['style'][ $key ] ) ) {
				$clean['style'][ $key ] = min( $max, absint( $raw['style'][ $key ] ) );
			}
		}

		$clean['style']['layout'] = in_array( $raw['style']['layout'] ?? '', array( 'list', 'inline' ), true ) ? $raw['style']['layout'] : 'list';

		/*
		 * Custom CSS is stripped of anything that could close the <style> block
		 * it is printed into. Without that, "}</style><script>" in this box is
		 * stored XSS — available to any role that can edit a filter set, which
		 * on a lot of sites is more people than can install a plugin.
		 */
		$clean['style']['custom_css'] = self::clean_css( $raw['style']['custom_css'] ?? '' );

		update_post_meta( $id, self::META, $clean );

		unset( self::$cache[ $id ] );
	}

	/**
	 * Make a block of CSS safe to print inside a <style> element.
	 *
	 * @param string $css What was typed.
	 * @return string
	 */
	public static function clean_css( $css ) {
		$css = (string) $css;

		// Anything that looks like a tag. The only characters CSS needs from
		// this set are '>' in selectors, and losing that is a smaller problem
		// than a script tag surviving.
		$css = wp_strip_all_tags( $css );

		$css = str_replace( array( '<', '>' ), '', $css );

		// Expressions and url(javascript:...) — old, but still parsed by
		// enough things to be worth removing.
		$css = preg_replace( '/(javascript|expression|behaviour|behavior)\s*:/i', '', $css );

		return trim( $css );
	}

	/**
	 * Every published, enabled filter set.
	 *
	 * @return int[]
	 */
	public static function all_ids() {
		/*
		 * Memoised, because this is asked on every query the page runs and the
		 * answer cannot change mid-request. It also keeps the number of times
		 * the configuration query re-enters the filter hooks down to one.
		 */
		if ( null !== self::$ids ) {
			return self::$ids;
		}

		$ids = get_posts(
			array(
				'post_type'        => self::POST_TYPE,
				'post_status'      => 'publish',
				'numberposts'      => 100,
				'fields'           => 'ids',
				'suppress_filters' => false,
				'no_found_rows'    => true,
			)
		);

		self::$ids = array_map( 'absint', (array) $ids );

		return self::$ids;
	}

	/**
	 * Forget what has been read.
	 *
	 * Needed after a filter set is saved in the same request that goes on to
	 * render one, and by the tests.
	 *
	 * @return void
	 */
	public static function reset() {
		self::$cache = array();
		self::$ids   = null;
	}
}

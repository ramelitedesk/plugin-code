<?php
/**
 * Drawing one filter set.
 *
 * Kept apart from the hooks so the markup has one home. The widget, the
 * shortcode and the block all end up here, which is what stops the sidebar
 * version and the shortcode version drifting into two different widgets that
 * happen to share a name.
 *
 * @package Custom_Filter_Widget
 */

defined( 'ABSPATH' ) || exit;

class CFW_Render {

	/** @var int Instances drawn this request, so each gets its own ids. */
	private static $drawn = 0;

	/**
	 * @param int $filter_id Filter set.
	 * @return string Markup, or '' if it does not belong here.
	 */
	public static function widget( $filter_id ) {
		$filter_id = absint( $filter_id );

		if ( ! $filter_id || CFW_Settings::POST_TYPE !== get_post_type( $filter_id ) ) {
			return '';
		}

		$config = CFW_Settings::get( $filter_id );

		if ( empty( $config['enabled'] ) || ! CFW_Location::matches( $config ) ) {
			return '';
		}

		if ( empty( $config['items'] ) ) {
			return '';
		}

		self::$drawn++;

		$uid    = 'cfw-' . $filter_id . '-' . self::$drawn;
		$method = CFW_Location::method( $config );

		/*
		 * Auto-apply is only ever offered on AJAX. On a reload it would mean a
		 * full page load per tick — three choices, three round trips, and the
		 * second tick made while the first is still loading is lost.
		 */
		$auto = ( 'ajax' === $method && ! empty( $config['auto_apply'] ) ) ? 1 : 0;

		CFW_Assets::needed();

		ob_start();
		?>
		<div
			class="cfw <?php echo esc_attr( 'cfw--' . $config['style']['layout'] ); ?>"
			id="<?php echo esc_attr( $uid ); ?>"
			data-filter-id="<?php echo esc_attr( $filter_id ); ?>"
			data-method="<?php echo esc_attr( $method ); ?>"
			data-auto="<?php echo esc_attr( $auto ); ?>"
			style="<?php echo esc_attr( self::css_vars( $config['style'] ) ); ?>"
		>
			<form class="cfw__form" method="get" action="<?php echo esc_url( self::form_action() ); ?>">
				<?php
				/*
				 * A real form, submitting by GET to the current URL.
				 *
				 * That is what makes reload mode work with JavaScript switched
				 * off, and it is why the parameters this plugin reads are the
				 * same ones a form submits. The script upgrades it; it does not
				 * make it work.
				 */
				$owned = array();

				foreach ( $config['items'] as $item ) {
					$owned[] = CFW_Query::param( $item );
				}

				if ( in_array( 'price', wp_list_pluck( $config['items'], 'source' ), true ) ) {
					$owned[] = CFW_Query::PREFIX . 'price_min';
					$owned[] = CFW_Query::PREFIX . 'price_max';
				}

				self::preserved_fields( $owned );

				foreach ( $config['items'] as $index => $item ) {
					self::item( $item, $uid . '-' . $index );
				}
				?>

				<div class="cfw__actions">
					<button type="submit" class="cfw__apply"><?php echo esc_html( $config['labels']['apply'] ); ?></button>
					<a class="cfw__reset" href="<?php echo esc_url( self::reset_url() ); ?>"><?php echo esc_html( $config['labels']['reset'] ); ?></a>
				</div>
			</form>
		</div>
		<?php

		return ob_get_clean();
	}

	/**
	 * One item: its heading, if it has one, and its control.
	 *
	 * @param array  $item Item config.
	 * @param string $uid  Unique id stem for this item.
	 */
	private static function item( array $item, $uid ) {
		$options = CFW_Sources::options( $item );
		$source  = $item['source'];

		/*
		 * An item with nothing to show is skipped entirely, heading included.
		 *
		 * A heading over an empty box is the worst of the options: it says the
		 * filter exists, gives no way to use it, and looks identical to a
		 * filter that is still loading. price and search draw their own
		 * controls and so are never "empty".
		 */
		if ( ! $options && ! in_array( $source, array( 'price', 'search' ), true ) ) {
			return;
		}

		$heading = '' !== trim( (string) $item['heading'] ) ? $item['heading'] : CFW_Sources::label( $source );

		echo '<div class="cfw__item cfw__item--' . esc_attr( $source ) . '">';

		/*
		 * The heading is a <legend> inside a <fieldset> when it is shown, and
		 * the fieldset carries an invisible label when it is not.
		 *
		 * Hiding the heading is a styling choice; leaving a group of checkboxes
		 * with nothing naming it is not. A screen reader would announce eight
		 * unlabelled checkboxes with no way to tell which facet they belong to.
		 */
		echo '<fieldset class="cfw__group">';

		if ( ! empty( $item['show_heading'] ) ) {
			echo '<legend class="cfw__heading">' . esc_html( $heading ) . '</legend>';
		} else {
			echo '<legend class="screen-reader-text">' . esc_html( $heading ) . '</legend>';
		}

		if ( 'price' === $source ) {
			self::price_control( $uid );
		} elseif ( 'search' === $source ) {
			self::search_control( $uid, $heading );
		} else {
			self::choice_control( $item, $options, $uid );
		}

		echo '</fieldset>';
		echo '</div>';
	}

	/**
	 * Checkboxes, radios, chips or a dropdown.
	 *
	 * @param array  $item    Item config.
	 * @param array  $options From CFW_Sources::options().
	 * @param string $uid     Id stem.
	 */
	private static function choice_control( array $item, array $options, $uid ) {
		$selected = CFW_Query::selected( $item );
		$name     = CFW_Query::param( $item );
		$style    = $item['style'];
		$limit    = (int) $item['limit'];

		if ( 'dropdown' === $style ) {
			printf(
				'<select class="cfw__select" name="%s"%s>',
				esc_attr( $name ),
				! empty( $item['multiple'] ) ? ' multiple size="6"' : ''
			);

			if ( empty( $item['multiple'] ) ) {
				echo '<option value="">' . esc_html__( 'Any', 'custom-filter-widget' ) . '</option>';
			}

			foreach ( $options as $option ) {
				printf(
					'<option value="%1$s"%2$s>%3$s%4$s</option>',
					esc_attr( $option['value'] ),
					selected( in_array( (string) $option['value'], $selected, true ), true, false ),
					esc_html( str_repeat( '— ', (int) $option['depth'] ) . $option['label'] ),
					( ! empty( $item['show_count'] ) && null !== $option['count'] ) ? esc_html( ' (' . $option['count'] . ')' ) : ''
				);
			}

			echo '</select>';

			return;
		}

		$input = ( 'radio' === $style ) ? 'radio' : 'checkbox';

		/*
		 * The name gets [] whenever more than one value can be sent. Without
		 * it a form submits only the last ticked box, so a no-JavaScript
		 * visitor ticking three categories filters by one of them — quietly,
		 * and with the other two still ticked when the page comes back.
		 */
		$field = ( 'checkbox' === $input && ! empty( $item['multiple'] ) ) ? $name . '[]' : $name;

		echo '<div class="cfw__options' . ( 'chips' === $style ? ' cfw__options--chips' : '' ) . '">';

		foreach ( $options as $index => $option ) {
			$id     = $uid . '-o' . $index;
			$hidden = ( $limit > 0 && $index >= $limit );

			printf(
				'<div class="cfw__option cfw__option--d%1$d%2$s">',
				(int) $option['depth'],
				$hidden ? ' cfw__option--extra' : ''
			);

			printf(
				'<input type="%1$s" id="%2$s" name="%3$s" value="%4$s"%5$s />',
				esc_attr( $input ),
				esc_attr( $id ),
				esc_attr( $field ),
				esc_attr( $option['value'] ),
				checked( in_array( (string) $option['value'], $selected, true ), true, false )
			);

			printf(
				'<label for="%1$s">%2$s%3$s</label>',
				esc_attr( $id ),
				esc_html( $option['label'] ),
				( ! empty( $item['show_count'] ) && null !== $option['count'] )
					? ' <span class="cfw__count">' . esc_html( $option['count'] ) . '</span>'
					: ''
			);

			echo '</div>';
		}

		if ( $limit > 0 && count( $options ) > $limit ) {
			printf(
				'<button type="button" class="cfw__more" aria-expanded="false">%s</button>',
				esc_html(
					sprintf(
						/* translators: %d: how many more choices there are. */
						__( 'Show %d more', 'custom-filter-widget' ),
						count( $options ) - $limit
					)
				)
			);
		}

		echo '</div>';
	}

	/**
	 * Two number boxes, bounded by what the shop actually sells.
	 *
	 * @param string $uid Id stem.
	 */
	private static function price_control( $uid ) {
		$bounds  = CFW_Sources::price_bounds();
		$current = CFW_Query::price_from_request();

		$symbol = function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol() : '';

		echo '<div class="cfw__price">';

		$boxes = array(
			'min' => __( 'Min', 'custom-filter-widget' ),
			'max' => __( 'Max', 'custom-filter-widget' ),
		);

		foreach ( $boxes as $which => $label ) {
			$id = $uid . '-' . $which;

			printf( '<span class="cfw__price-box"><label for="%1$s">%2$s</label>', esc_attr( $id ), esc_html( $label ) );

			if ( '' !== $symbol ) {
				echo '<span class="cfw__currency">' . esc_html( $symbol ) . '</span>';
			}

			printf(
				'<input type="number" inputmode="decimal" id="%1$s" name="%2$s" value="%3$s" min="%4$s" max="%5$s" step="any" placeholder="%6$s" /></span>',
				esc_attr( $id ),
				esc_attr( CFW_Query::PREFIX . 'price_' . $which ),
				esc_attr( null !== $current[ $which ] ? (string) $current[ $which ] : '' ),
				esc_attr( (string) $bounds['min'] ),
				esc_attr( (string) $bounds['max'] ),
				// The placeholder carries the real bound, so an empty box still
				// tells you the range rather than looking like a broken control.
				esc_attr( (string) $bounds[ $which ] )
			);
		}

		echo '</div>';
	}

	/**
	 * @param string $uid     Id stem.
	 * @param string $heading What the box is for.
	 */
	private static function search_control( $uid, $heading ) {
		printf(
			'<input type="search" class="cfw__search" id="%1$s" name="%2$s" value="%3$s" placeholder="%4$s" aria-label="%5$s" />',
			esc_attr( $uid . '-s' ),
			esc_attr( CFW_Query::PREFIX . 'search' ),
			esc_attr( CFW_Query::search_from_request() ),
			esc_attr__( 'Search…', 'custom-filter-widget' ),
			esc_attr( $heading )
		);
	}

	/**
	 * Where the form posts to.
	 *
	 * The current URL with this plugin's own parameters stripped, because they
	 * are about to be sent again as fields. Leaving them on the action would
	 * mean a GET form submitting f_product_cat in the query string and in the
	 * body, and browsers drop the query string of a GET action entirely — so
	 * pagination and sort parameters would vanish on every apply.
	 *
	 * @return string
	 */
	private static function form_action() {
		return self::current_url( true );
	}

	/**
	 * Everything else in the URL, as hidden fields.
	 *
	 * A GET form throws away its action's query string, so anything that was
	 * in the URL and is not one of ours has to be resubmitted by hand — the
	 * theme's sort order, a tracking parameter, the search term on a search
	 * page. Without this, applying a filter silently resets the sort.
	 *
	 * Another widget's filter parameters are preserved too, and only the ones
	 * this widget draws controls for are left out. Two filter widgets on a page
	 * are two separate forms; without this, submitting the sidebar would drop
	 * everything chosen in the mobile drawer, because a form only ever sends
	 * its own fields.
	 *
	 * @param string[] $owned Parameter names this widget renders itself.
	 */
	private static function preserved_fields( array $owned ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		foreach ( $_GET as $key => $value ) {
			$key = sanitize_text_field( wp_unslash( (string) $key ) );

			if ( '' === $key || 'paged' === $key || in_array( $key, $owned, true ) ) {
				continue;
			}

			// Arrays are flattened one level; anything deeper is not something
			// a filter form should be carrying around.
			foreach ( (array) wp_unslash( $value ) as $one ) {
				if ( is_scalar( $one ) ) {
					printf(
						'<input type="hidden" name="%s" value="%s" />',
						esc_attr( is_array( $value ) ? $key . '[]' : $key ),
						esc_attr( sanitize_text_field( (string) $one ) )
					);
				}
			}
		}
	}

	/**
	 * @return string The current URL with every filter parameter removed.
	 */
	public static function reset_url() {
		return self::current_url( true );
	}

	/**
	 * @param bool $strip Whether to drop this plugin's parameters.
	 * @return string
	 */
	private static function current_url( $strip = false ) {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$path = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';

		/*
		 * The origin comes from the site's own settings; the path comes from
		 * the request.
		 *
		 * home_url( $path ) is the obvious way to write this and it is wrong
		 * on any installation in a subdirectory: REQUEST_URI already contains
		 * that subdirectory, and home_url() puts it on again. A site at
		 * example.com/shop got a form action of example.com/shop/shop/... —
		 * so submitting the filter with JavaScript off landed on a 404. On a
		 * site installed at the domain root the two are identical, which is
		 * why it survives casual testing.
		 */
		$home = wp_parse_url( home_url() );

		$origin = ( isset( $home['scheme'] ) ? $home['scheme'] : 'http' ) . '://'
			. ( isset( $home['host'] ) ? $home['host'] : '' )
			. ( isset( $home['port'] ) ? ':' . (int) $home['port'] : '' );

		$url = esc_url_raw( $origin . '/' . ltrim( $path, '/' ) );

		if ( ! $strip ) {
			return $url;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$ours = array( 'paged' );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		foreach ( array_keys( $_GET ) as $key ) {
			if ( 0 === strpos( (string) $key, CFW_Query::PREFIX ) ) {
				$ours[] = sanitize_text_field( (string) $key );
			}
		}

		return remove_query_arg( $ours, $url );
	}

	/**
	 * The style settings, as custom properties on the wrapper.
	 *
	 * Inline on the element rather than in a <style> block, so two filter sets
	 * with different colours on one page each get their own — a stylesheet
	 * rule would have the second one overwrite the first.
	 *
	 * @param array $style Style settings.
	 * @return string
	 */
	private static function css_vars( array $style ) {
		$vars = array(
			'--cfw-heading'       => $style['heading_color'],
			'--cfw-text'          => $style['text_color'],
			'--cfw-accent'        => $style['accent_color'],
			'--cfw-bg'            => $style['background_color'],
			'--cfw-border'        => $style['border_color'],
			'--cfw-border-width'  => (int) $style['border_width'] . 'px',
			'--cfw-radius'        => (int) $style['border_radius'] . 'px',
			'--cfw-padding'       => (int) $style['padding'] . 'px',
			'--cfw-gap'           => (int) $style['item_spacing'] . 'px',
			'--cfw-heading-size'  => (int) $style['heading_size'] . 'px',
			'--cfw-font-size'     => (int) $style['font_size'] . 'px',
		);

		$out = '';

		foreach ( $vars as $name => $value ) {
			$out .= $name . ':' . $value . ';';
		}

		return $out;
	}

	/**
	 * Custom CSS for every filter set on this page, printed once.
	 *
	 * @return string
	 */
	public static function custom_css( array $filter_ids ) {
		$css = '';

		foreach ( $filter_ids as $id ) {
			$config = CFW_Settings::get( $id );

			if ( '' !== trim( $config['style']['custom_css'] ) ) {
				// Cleaned on save as well. Twice, because this one is printed
				// raw into a <style> element and the cost of being wrong here
				// is stored XSS.
				$css .= CFW_Settings::clean_css( $config['style']['custom_css'] ) . "\n";
			}
		}

		return $css;
	}
}

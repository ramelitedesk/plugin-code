<?php
/**
 * What can be filtered on, and what choices each one offers.
 *
 * A source is one facet: a taxonomy, a price range, a rating. The admin picks
 * them from a list built out of the site itself rather than a hardcoded one —
 * the old version offered "Product Attribute: Brand", "Color" and "Size" as
 * literals, so a shop with pa_material got nothing and a shop with no pa_color
 * got a filter that rendered an empty box.
 *
 * Taxonomies are named directly ('product_cat'), and the handful of things that
 * are not taxonomies have reserved names ('price', 'rating', ...). A taxonomy
 * is looked for first, so a site that really does have a taxonomy called
 * 'price' gets its taxonomy rather than a silently broken price filter.
 *
 * @package Custom_Filter_Widget
 */

defined( 'ABSPATH' ) || exit;

class CFW_Sources {

	/** Sources that are not taxonomies. */
	const SPECIAL = array( 'price', 'rating', 'stock', 'onsale', 'author', 'date', 'search' );

	/**
	 * Is WooCommerce actually here?
	 *
	 * Asked before every Woo-only source, and the reason this plugin no longer
	 * dies on a site without it.
	 *
	 * @return bool
	 */
	public static function woo() {
		return class_exists( 'WooCommerce' );
	}

	/**
	 * Everything this site can filter on, grouped for the admin screen.
	 *
	 * @return array<string,array<string,string>> group => key => label.
	 */
	public static function all() {
		$groups = array();

		/* ---------------- WooCommerce ---------------- */

		if ( self::woo() ) {
			$shop = array();

			foreach ( get_object_taxonomies( 'product', 'objects' ) as $tax ) {
				if ( ! $tax->public || 'product_type' === $tax->name ) {
					continue;
				}

				$shop[ $tax->name ] = $tax->labels->singular_name;
			}

			$shop['price']  = __( 'Price range', 'custom-filter-widget' );
			$shop['rating'] = __( 'Average rating', 'custom-filter-widget' );
			$shop['stock']  = __( 'Stock status', 'custom-filter-widget' );
			$shop['onsale'] = __( 'On sale only', 'custom-filter-widget' );

			$groups[ __( 'WooCommerce', 'custom-filter-widget' ) ] = $shop;
		}

		/* ---------------- everything else ---------------- */

		$content = array();

		foreach ( get_taxonomies( array( 'public' => true ), 'objects' ) as $tax ) {
			// Already offered above, and offering it twice makes the second one
			// look like a different thing.
			if ( self::woo() && in_array( 'product', (array) $tax->object_type, true ) ) {
				continue;
			}

			$content[ $tax->name ] = $tax->labels->singular_name;
		}

		$content['search'] = __( 'Keyword search', 'custom-filter-widget' );
		$content['author'] = __( 'Author', 'custom-filter-widget' );
		$content['date']   = __( 'Date posted', 'custom-filter-widget' );

		$groups[ __( 'Posts and pages', 'custom-filter-widget' ) ] = $content;

		/**
		 * Add or remove filterable sources.
		 *
		 * @param array $groups group label => array of key => label.
		 */
		return apply_filters( 'cfw_sources', $groups );
	}

	/**
	 * @param string $source Source key.
	 * @return bool
	 */
	public static function exists( $source ) {
		return taxonomy_exists( $source ) || in_array( $source, self::SPECIAL, true );
	}

	/**
	 * @param string $source Source key.
	 * @return string 'taxonomy', or the source key itself.
	 */
	public static function type( $source ) {
		return taxonomy_exists( $source ) ? 'taxonomy' : $source;
	}

	/**
	 * The name to put over an item when the admin left the heading blank.
	 *
	 * @param string $source Source key.
	 * @return string
	 */
	public static function label( $source ) {
		if ( taxonomy_exists( $source ) ) {
			$tax = get_taxonomy( $source );

			return $tax ? $tax->labels->singular_name : $source;
		}

		$names = array(
			'price'  => __( 'Price', 'custom-filter-widget' ),
			'rating' => __( 'Rating', 'custom-filter-widget' ),
			'stock'  => __( 'Availability', 'custom-filter-widget' ),
			'onsale' => __( 'Offers', 'custom-filter-widget' ),
			'author' => __( 'Author', 'custom-filter-widget' ),
			'date'   => __( 'Date', 'custom-filter-widget' ),
			'search' => __( 'Search', 'custom-filter-widget' ),
		);

		return $names[ $source ] ?? $source;
	}

	/**
	 * The choices one item renders.
	 *
	 * @param array $item One entry from a filter set's items.
	 * @return array[] Each: value, label, count (or null), depth.
	 */
	public static function options( array $item ) {
		$source = $item['source'];

		if ( taxonomy_exists( $source ) ) {
			return self::taxonomy_options( $source, $item );
		}

		switch ( $source ) {
			case 'rating':
				$out = array();

				for ( $stars = 5; $stars >= 1; $stars-- ) {
					$out[] = array(
						/* translators: %d: number of stars. */
						'label' => sprintf( _n( '%d star and up', '%d stars and up', $stars, 'custom-filter-widget' ), $stars ),
						'value' => (string) $stars,
						'count' => null,
						'depth' => 0,
					);
				}

				return $out;

			case 'stock':
				return array(
					array(
						'label' => __( 'In stock', 'custom-filter-widget' ),
						'value' => 'instock',
						'count' => null,
						'depth' => 0,
					),
					array(
						'label' => __( 'On backorder', 'custom-filter-widget' ),
						'value' => 'onbackorder',
						'count' => null,
						'depth' => 0,
					),
					array(
						'label' => __( 'Out of stock', 'custom-filter-widget' ),
						'value' => 'outofstock',
						'count' => null,
						'depth' => 0,
					),
				);

			case 'onsale':
				return array(
					array(
						'label' => __( 'On sale', 'custom-filter-widget' ),
						'value' => '1',
						'count' => null,
						'depth' => 0,
					),
				);

			case 'date':
				return array(
					array(
						'label' => __( 'Last 24 hours', 'custom-filter-widget' ),
						'value' => 'day',
						'count' => null,
						'depth' => 0,
					),
					array(
						'label' => __( 'Last 7 days', 'custom-filter-widget' ),
						'value' => 'week',
						'count' => null,
						'depth' => 0,
					),
					array(
						'label' => __( 'Last 30 days', 'custom-filter-widget' ),
						'value' => 'month',
						'count' => null,
						'depth' => 0,
					),
					array(
						'label' => __( 'Last 12 months', 'custom-filter-widget' ),
						'value' => 'year',
						'count' => null,
						'depth' => 0,
					),
				);

			case 'author':
				$users = get_users(
					array(
						/*
						 * 'capability', not the 'who' => 'authors' this used to
						 * pass. 'who' was deprecated in WordPress 5.9 and emits a
						 * notice on every page the filter renders on.
						 */
						'capability' => array( 'edit_posts' ),
						'fields'     => array( 'ID', 'display_name' ),
						'number'     => 200,
						'orderby'    => 'display_name',
					)
				);

				$out = array();

				foreach ( $users as $user ) {
					$out[] = array(
						'label' => $user->display_name,
						'value' => (string) $user->ID,
						'count' => null,
						'depth' => 0,
					);
				}

				return $out;
		}

		// price and search draw their own controls rather than a list.
		return array();
	}

	/**
	 * Terms for a taxonomy item, flattened but keeping their depth.
	 *
	 * Flattened rather than nested because the renderer wants one loop and the
	 * indent is a class name. Nesting the array would push the tree walk into
	 * three renderers instead of one.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @param array  $item     Item config.
	 * @return array[]
	 */
	private static function taxonomy_options( $taxonomy, array $item ) {
		$terms = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => ! empty( $item['hide_empty'] ),
				'orderby'    => 'name',
				'order'      => 'ASC',
				// A shop with 5,000 brands would otherwise render 5,000
				// checkboxes into a sidebar and time out doing it.
				'number'     => 300,
			)
		);

		if ( is_wp_error( $terms ) || ! $terms ) {
			return array();
		}

		$object = get_taxonomy( $taxonomy );

		if ( ! $object || ! $object->hierarchical ) {
			$out = array();

			foreach ( $terms as $term ) {
				$out[] = array(
					'label' => $term->name,
					'value' => $term->slug,
					'count' => (int) $term->count,
					'depth' => 0,
				);
			}

			return $out;
		}

		return self::branch( $terms, 0, 0 );
	}

	/**
	 * Walk a hierarchical taxonomy into a flat list with depths.
	 *
	 * @param WP_Term[] $terms  All terms.
	 * @param int       $parent Parent term id.
	 * @param int       $depth  Current depth.
	 * @return array[]
	 */
	private static function branch( array $terms, $parent, $depth ) {
		$out = array();

		// Five levels is already deeper than any sidebar can show usefully, and
		// the guard means a corrupted parent loop cannot recurse forever.
		if ( $depth > 5 ) {
			return $out;
		}

		foreach ( $terms as $term ) {
			if ( (int) $term->parent !== (int) $parent ) {
				continue;
			}

			$out[] = array(
				'label' => $term->name,
				'value' => $term->slug,
				'count' => (int) $term->count,
				'depth' => $depth,
			);

			$out = array_merge( $out, self::branch( $terms, (int) $term->term_id, $depth + 1 ) );
		}

		return $out;
	}

	/**
	 * The cheapest and dearest published product, for the price boxes.
	 *
	 * Cached for an hour. Without the cache this is a full table scan of
	 * postmeta on every render of a shop sidebar, which on a large catalogue is
	 * the slowest thing on the page.
	 *
	 * @return array{min:float,max:float}
	 */
	public static function price_bounds() {
		if ( ! self::woo() ) {
			return array(
				'min' => 0.0,
				'max' => 0.0,
			);
		}

		$cached = get_transient( 'cfw_price_bounds' );

		if ( is_array( $cached ) ) {
			return $cached;
		}

		global $wpdb;

		$row = $wpdb->get_row(
			"SELECT MIN( CAST( meta_value AS DECIMAL(20,4) ) ) AS min_price,
			        MAX( CAST( meta_value AS DECIMAL(20,4) ) ) AS max_price
			   FROM {$wpdb->postmeta} pm
			   JOIN {$wpdb->posts} p ON p.ID = pm.post_id
			  WHERE pm.meta_key = '_price'
			    AND pm.meta_value != ''
			    AND p.post_type IN ( 'product', 'product_variation' )
			    AND p.post_status = 'publish'"
		);

		$bounds = array(
			'min' => $row ? (float) $row->min_price : 0.0,
			// Rounded outward, so the dearest product is inside the range
			// rather than one penny above the top of it.
			'max' => $row ? (float) ceil( (float) $row->max_price ) : 0.0,
		);

		set_transient( 'cfw_price_bounds', $bounds, HOUR_IN_SECONDS );

		return $bounds;
	}
}

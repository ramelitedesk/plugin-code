<?php
/**
 * Turning a request into query arguments, and applying them.
 *
 * One builder, used by all three paths — the main query on a reload, the AJAX
 * handler, and the [cfw_results] shortcode — because a filter that means one
 * thing on a reload and another over AJAX is worse than a filter that does not
 * work at all. The second one you find on the first try; the first one you find
 * in a support email six weeks later.
 *
 * @package Custom_Filter_Widget
 */

defined( 'ABSPATH' ) || exit;

class CFW_Query {

	/** Prefix for every query parameter this plugin reads and writes. */
	const PREFIX = 'f_';

	/**
	 * The query parameter one item uses.
	 *
	 * Named after the source rather than the filter set's post id, which is
	 * what it used to be ('cfw_41'). Two consequences, both bad: the URL said
	 * nothing to anyone reading it, and the same category filter in a sidebar
	 * and in a mobile drawer had different parameter names, so opening the
	 * drawer showed nothing selected.
	 *
	 * @param array $item Item config.
	 * @return string
	 */
	public static function param( array $item ) {
		$source = $item['source'];

		return self::PREFIX . preg_replace( '/[^a-z0-9_]/i', '_', $source );
	}

	/**
	 * What is selected for one item, from a request.
	 *
	 * @param array      $item    Item config.
	 * @param array|null $request Defaults to $_GET.
	 * @return string[]
	 */
	public static function selected( array $item, $request = null ) {
		if ( ! is_array( $request ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a public, read-only filter.
			$request = $_GET;
		}

		$key = self::param( $item );

		if ( ! isset( $request[ $key ] ) ) {
			return array();
		}

		$raw = wp_unslash( $request[ $key ] );

		/*
		 * Both shapes are accepted on the way in: f_product_cat=a,b from a
		 * hand-written link and f_product_cat[]=a&f_product_cat[]=b from a
		 * posted form. Only the first is ever written out, so URLs stay short
		 * and shareable.
		 */
		$values = is_array( $raw ) ? $raw : explode( ',', (string) $raw );

		$values = array_map( 'sanitize_text_field', array_map( 'strval', $values ) );
		$values = array_values( array_filter( $values, 'strlen' ) );
		$values = array_values( array_unique( $values ) );

		if ( empty( $item['multiple'] ) && count( $values ) > 1 ) {
			$values = array( reset( $values ) );
		}

		// A crafted request with ten thousand values would otherwise become a
		// ten thousand term IN() clause.
		return array_slice( $values, 0, 50 );
	}

	/**
	 * Build the query pieces every selected item implies.
	 *
	 * Returns the pieces rather than a whole WP_Query argument array, because
	 * the caller decides what to do with them: the main query merges them into
	 * what is already there, while AJAX starts from nothing.
	 *
	 * @param int[]      $filter_ids Filter set ids to read.
	 * @param array|null $request    Defaults to $_GET.
	 * @return array{tax:array,meta:array,date:array,extra:array}
	 */
	public static function pieces( array $filter_ids, $request = null ) {
		$out = array(
			'tax'   => array(),
			'meta'  => array(),
			'date'  => array(),
			'extra' => array(),
		);

		$price = array(
			'min' => null,
			'max' => null,
		);

		foreach ( $filter_ids as $filter_id ) {
			$config = CFW_Settings::get( $filter_id );

			if ( empty( $config['enabled'] ) ) {
				continue;
			}

			foreach ( $config['items'] as $item ) {
				$source = $item['source'];

				/*
				 * Price is read straight from the request rather than through
				 * selected(), because it is two numbers and not a list. This
				 * is the filter that did not work at all before: the admin
				 * offered "Price Range", the term list for it returned an
				 * empty array, and so the widget rendered a heading with
				 * nothing underneath it.
				 */
				if ( 'price' === $source ) {
					$bounds = self::price_from_request( $request );

					if ( null !== $bounds['min'] ) {
						$price['min'] = $bounds['min'];
					}

					if ( null !== $bounds['max'] ) {
						$price['max'] = $bounds['max'];
					}

					continue;
				}

				if ( 'search' === $source ) {
					$term = self::search_from_request( $request );

					if ( '' !== $term ) {
						$out['extra']['s'] = $term;
					}

					continue;
				}

				$values = self::selected( $item, $request );

				if ( ! $values ) {
					continue;
				}

				if ( taxonomy_exists( $source ) ) {
					$out['tax'][] = array(
						'taxonomy' => $source,
						'field'    => 'slug',
						'terms'    => $values,
						/*
						 * IN, not AND. Ticking Red and Blue means "either",
						 * which is what a shopper means and what every shop
						 * they have used does. AND would return the products
						 * that are both, which is almost always none — a
						 * filter that empties the page looks broken.
						 */
						'operator' => 'IN',
					);

					continue;
				}

				switch ( $source ) {
					case 'rating':
						$out['meta'][] = array(
							'key'     => '_wc_average_rating',
							'value'   => max( 1, min( 5, (int) $values[0] ) ),
							'type'    => 'DECIMAL(3,2)',
							'compare' => '>=',
						);
						break;

					case 'stock':
						$out['meta'][] = array(
							'key'     => '_stock_status',
							'value'   => array_values( array_intersect( $values, array( 'instock', 'outofstock', 'onbackorder' ) ) ),
							'compare' => 'IN',
						);
						break;

					case 'onsale':
						if ( function_exists( 'wc_get_product_ids_on_sale' ) ) {
							$ids = wc_get_product_ids_on_sale();

							/*
							 * An empty sale list has to become an impossible
							 * id, not an empty post__in. WP_Query treats
							 * post__in => array() as "no restriction", so an
							 * empty sale would show the entire catalogue —
							 * the exact opposite of what was asked for.
							 */
							$out['extra']['post__in'] = $ids ? array_map( 'absint', $ids ) : array( 0 );
						}
						break;

					case 'author':
						$out['extra']['author__in'] = array_map( 'absint', $values );
						break;

					case 'date':
						$after = self::date_after( $values[0] );

						if ( $after ) {
							$out['date'][] = array(
								'after'     => $after,
								'inclusive' => true,
							);
						}
						break;
				}
			}
		}

		if ( null !== $price['min'] || null !== $price['max'] ) {
			$out['meta'][] = array(
				'key'     => '_price',
				'value'   => array(
					null !== $price['min'] ? $price['min'] : 0,
					null !== $price['max'] ? $price['max'] : PHP_INT_MAX,
				),
				'type'    => 'DECIMAL(20,4)',
				'compare' => 'BETWEEN',
			);
		}

		return $out;
	}

	/**
	 * @param array|null $request Defaults to $_GET.
	 * @return array{min:float|null,max:float|null}
	 */
	public static function price_from_request( $request = null ) {
		if ( ! is_array( $request ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$request = $_GET;
		}

		$read = function ( $key ) use ( $request ) {
			if ( ! isset( $request[ $key ] ) || '' === $request[ $key ] || is_array( $request[ $key ] ) ) {
				return null;
			}

			$value = (float) wp_unslash( $request[ $key ] );

			return $value >= 0 ? $value : null;
		};

		$min = $read( self::PREFIX . 'price_min' );
		$max = $read( self::PREFIX . 'price_max' );

		// Typed the wrong way round. Swapping is what the visitor meant;
		// returning nothing would silently drop the filter they just set.
		if ( null !== $min && null !== $max && $min > $max ) {
			list( $min, $max ) = array( $max, $min );
		}

		return array(
			'min' => $min,
			'max' => $max,
		);
	}

	/**
	 * @param array|null $request Defaults to $_GET.
	 * @return string
	 */
	public static function search_from_request( $request = null ) {
		if ( ! is_array( $request ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$request = $_GET;
		}

		$key = self::PREFIX . 'search';

		if ( ! isset( $request[ $key ] ) || is_array( $request[ $key ] ) ) {
			return '';
		}

		return trim( sanitize_text_field( wp_unslash( $request[ $key ] ) ) );
	}

	/**
	 * @param string $value day|week|month|year.
	 * @return string A date string, or ''.
	 */
	private static function date_after( $value ) {
		$spans = array(
			'day'   => '-1 day',
			'week'  => '-7 days',
			'month' => '-30 days',
			'year'  => '-1 year',
		);

		if ( ! isset( $spans[ $value ] ) ) {
			return '';
		}

		return wp_date( 'Y-m-d H:i:s', strtotime( $spans[ $value ], current_time( 'timestamp' ) ) );
	}

	/**
	 * Apply the filters to a query object, keeping what is already on it.
	 *
	 * MERGED, not assigned, and this is the bug that mattered most in the
	 * previous version. It did $query->set( 'tax_query', $args['tax_query'] ) —
	 * which throws away whatever tax_query the archive had already built. On a
	 * product category page WooCommerce puts the category in that tax_query, so
	 * ticking any filter on /product-category/shoes/ replaced "in shoes" with
	 * "in the ticked colour" and the page filled up with products from every
	 * category on the site. It reads as the filter working, and it is not.
	 *
	 * @param WP_Query $query  Query to modify.
	 * @param array    $pieces From pieces().
	 */
	public static function apply( $query, array $pieces ) {
		if ( $pieces['tax'] ) {
			$existing = (array) $query->get( 'tax_query' );

			// A one-clause tax_query has no relation and does not need one.
			// Adding relation => AND to a single clause is harmless but noisy
			// in debugging output, so it goes on only when it means something.
			$merged = array_merge( array_filter( $existing, 'is_array' ), $pieces['tax'] );

			if ( count( $merged ) > 1 ) {
				$merged['relation'] = 'AND';
			}

			$query->set( 'tax_query', $merged );
		}

		if ( $pieces['meta'] ) {
			$existing = (array) $query->get( 'meta_query' );

			$merged = array_merge( array_filter( $existing, 'is_array' ), $pieces['meta'] );

			if ( count( $merged ) > 1 ) {
				$merged['relation'] = 'AND';
			}

			$query->set( 'meta_query', $merged );
		}

		if ( $pieces['date'] ) {
			$existing = (array) $query->get( 'date_query' );

			$query->set( 'date_query', array_merge( array_filter( $existing, 'is_array' ), $pieces['date'] ) );
		}

		foreach ( $pieces['extra'] as $key => $value ) {
			if ( 'post__in' === $key ) {
				$existing = (array) $query->get( 'post__in' );

				/*
				 * Intersected, not replaced. Another plugin narrowing the same
				 * query has as much right to its restriction as this one, and
				 * an empty intersection is a real answer — nothing is both on
				 * sale and in whatever the other plugin allowed.
				 */
				$value = $existing ? array_values( array_intersect( $existing, $value ) ) : $value;

				$query->set( 'post__in', $value ? $value : array( 0 ) );

				continue;
			}

			$query->set( $key, $value );
		}
	}

	/**
	 * Build a standalone argument array, for AJAX and [cfw_results].
	 *
	 * @param int[]  $filter_ids Filter sets.
	 * @param array  $request    The request to read.
	 * @param array  $base       post_type, posts_per_page, paged.
	 * @return array
	 */
	public static function args( array $filter_ids, array $request, array $base = array() ) {
		$pieces = self::pieces( $filter_ids, $request );

		$args = wp_parse_args(
			$base,
			array(
				'post_type'           => 'post',
				'posts_per_page'      => (int) get_option( 'posts_per_page', 10 ),
				'paged'               => 1,
				'ignore_sticky_posts' => true,
			)
		);

		if ( $pieces['tax'] ) {
			$args['tax_query'] = count( $pieces['tax'] ) > 1
				? array_merge( array( 'relation' => 'AND' ), $pieces['tax'] )
				: $pieces['tax'];
		}

		if ( $pieces['meta'] ) {
			$args['meta_query'] = count( $pieces['meta'] ) > 1
				? array_merge( array( 'relation' => 'AND' ), $pieces['meta'] )
				: $pieces['meta'];
		}

		if ( $pieces['date'] ) {
			$args['date_query'] = $pieces['date'];
		}

		return array_merge( $args, $pieces['extra'] );
	}

	/**
	 * Filter sets that belong on the view being rendered.
	 *
	 * @return int[]
	 */
	public static function active_filters() {
		$active = array();

		foreach ( CFW_Settings::all_ids() as $id ) {
			$config = CFW_Settings::get( $id );

			if ( empty( $config['enabled'] ) ) {
				continue;
			}

			if ( CFW_Location::matches( $config ) ) {
				$active[] = $id;
			}
		}

		return $active;
	}
}

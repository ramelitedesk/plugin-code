<?php
/**
 * Plugin Name:       Custom Filter Widget
 * Plugin URI:        https://webart.technology/
 * Description:       Build a filter widget from any taxonomy, price, rating, stock, author or date — choose which pages it appears on, and whether each of those pages uses AJAX or a page reload. Works with WooCommerce and without it.
 * Version:           2.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Ramakrishna
 * License:           GPL-2.0-or-later
 * Text Domain:       custom-filter-widget
 *
 * @package Custom_Filter_Widget
 */

defined( 'ABSPATH' ) || exit;

define( 'CFW_VERSION', '2.0.0' );
define( 'CFW_FILE', __FILE__ );
define( 'CFW_DIR', plugin_dir_path( __FILE__ ) );
define( 'CFW_URL', plugin_dir_url( __FILE__ ) );

/**
 * A filter that quietly returns the wrong products is worse than one that
 * plainly does not work.
 *
 * Both failures happen, and only one of them gets reported. A filter that shows
 * nothing gets an email the same afternoon. A filter that shows a few too many
 * products — because it replaced the category constraint instead of adding to
 * it — looks like it is working from every angle except the till.
 *
 * So the rules this is built on:
 *
 *   • The server filters the query on every request, AJAX or not. AJAX saves a
 *     page load; it is never the thing that makes the filtering happen. A
 *     filtered URL that is shared, bookmarked, refreshed or crawled shows the
 *     filtered results.
 *   • Query constraints are MERGED into what the page already had, never
 *     assigned over it.
 *   • Not one WooCommerce function is called without checking WooCommerce is
 *     actually installed. Half of what this plugin is for is sites that do not
 *     have it.
 *   • The form works with JavaScript switched off, because it is a real GET
 *     form. Everything in the script is an upgrade on that.
 */
final class Custom_Filter_Widget {

	/** @var Custom_Filter_Widget|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->boot();
		}

		return self::$instance;
	}

	private function boot() {
		require_once CFW_DIR . 'includes/class-cfw-settings.php';
		require_once CFW_DIR . 'includes/class-cfw-location.php';
		require_once CFW_DIR . 'includes/class-cfw-sources.php';
		require_once CFW_DIR . 'includes/class-cfw-query.php';
		require_once CFW_DIR . 'includes/class-cfw-assets.php';
		require_once CFW_DIR . 'includes/class-cfw-render.php';
		require_once CFW_DIR . 'includes/class-cfw-frontend.php';
		require_once CFW_DIR . 'includes/class-cfw-widget.php';

		if ( is_admin() ) {
			require_once CFW_DIR . 'includes/class-cfw-admin.php';
		}

		add_action( 'init', array( $this, 'register_post_type' ), 5 );
		add_action( 'init', array( $this, 'load_textdomain' ), 1 );

		/*
		 * Priority 20 on plugins_loaded, so WooCommerce has declared itself
		 * before anything asks whether it is there. Going earlier means
		 * class_exists( 'WooCommerce' ) answers no on a site that has it, and
		 * the whole WooCommerce half of the source list silently disappears
		 * from the admin screen.
		 */
		add_action( 'plugins_loaded', array( $this, 'init' ), 20 );

		register_activation_hook( CFW_FILE, array( __CLASS__, 'activate' ) );
	}

	public function load_textdomain() {
		load_plugin_textdomain( 'custom-filter-widget', false, dirname( plugin_basename( CFW_FILE ) ) . '/languages' );
	}

	/**
	 * Registered on init, on both sides.
	 *
	 * The front end needs it too — get_posts() for a post type that has not
	 * been registered returns nothing, so registering this only in the admin
	 * means every filter set is invisible to the very pages meant to show them.
	 */
	public function register_post_type() {
		register_post_type(
			CFW_Settings::POST_TYPE,
			array(
				'labels'          => array(
					'name'               => __( 'Custom Filters', 'custom-filter-widget' ),
					'singular_name'      => __( 'Filter Set', 'custom-filter-widget' ),
					'add_new'            => __( 'Add New', 'custom-filter-widget' ),
					'add_new_item'       => __( 'Add Filter Set', 'custom-filter-widget' ),
					'edit_item'          => __( 'Edit Filter Set', 'custom-filter-widget' ),
					'new_item'           => __( 'New Filter Set', 'custom-filter-widget' ),
					'search_items'       => __( 'Search Filter Sets', 'custom-filter-widget' ),
					'not_found'          => __( 'No filter sets yet.', 'custom-filter-widget' ),
					'not_found_in_trash' => __( 'Nothing in the bin.', 'custom-filter-widget' ),
				),
				'public'          => false,
				'show_ui'         => true,
				'show_in_menu'    => true,
				'menu_position'   => 58,
				'menu_icon'       => 'dashicons-filter',
				'supports'        => array( 'title' ),
				'capability_type' => 'page',
				/*
				 * Off. The configuration lives in one meta key that the block
				 * editor knows nothing about, so opening a filter set in Gutenberg
				 * would show an empty document and saving it could drop the meta
				 * boxes' values entirely.
				 */
				'show_in_rest'    => false,
			)
		);
	}

	public function init() {
		CFW_Assets::init();
		CFW_Frontend::init();
		CFW_Widget::init();

		if ( is_admin() && class_exists( 'CFW_Admin' ) ) {
			CFW_Admin::init();
		}

		do_action( 'cfw_loaded', $this );
	}

	public static function activate() {
		// Nothing to install. The post type registers on init and there are no
		// options until somebody saves a filter set — so activating this plugin
		// changes nothing about how the site behaves, which is the point.
		delete_transient( 'cfw_price_bounds' );
	}
}

Custom_Filter_Widget::instance();

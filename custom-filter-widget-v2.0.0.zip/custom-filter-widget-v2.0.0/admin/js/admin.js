/**
 * The filter-set editor: adding, removing and reordering items.
 *
 * @package Custom_Filter_Widget
 */
( function ( $ ) {
	'use strict';

	var list = $( '#cfw-items' );

	if ( ! list.length ) {
		return;
	}

	/**
	 * Renumber every row's field names.
	 *
	 * Runs after any add, remove or drag. PHP reads cfw[items][N][...] as an
	 * ordered list, so a gap left by a deleted row or a stale index after a
	 * drag would either reorder the widget behind the admin's back or drop a
	 * row entirely on save.
	 */
	function renumber() {
		list.find( '.cfw-a__item' ).each( function ( index ) {
			$( this ).attr( 'data-index', index )
				.find( 'input, select, textarea' ).each( function () {
					var name = $( this ).attr( 'name' );

					if ( name ) {
						$( this ).attr( 'name', name.replace( /cfw\[items\]\[[^\]]*\]/, 'cfw[items][' + index + ']' ) );
					}
				} );
		} );
	}

	$( '#cfw-add-item' ).on( 'click', function () {
		var template = $( '#tmpl-cfw-item' ).html();

		if ( ! template ) {
			return;
		}

		list.append( template.replace( /__INDEX__/g, list.find( '.cfw-a__item' ).length ) );

		renumber();

		list.find( '.cfw-a__item' ).last().find( '.cfw-a__source' ).trigger( 'focus' );
	} );

	list.on( 'click', '.cfw-a__remove', function () {
		$( this ).closest( '.cfw-a__item' ).remove();

		renumber();
	} );

	/*
	 * The heading placeholder follows the source, so a new item does not sit
	 * there suggesting "Product Category" after being switched to Price.
	 */
	list.on( 'change', '.cfw-a__source', function () {
		var label = $( this ).find( 'option:selected' ).text().trim();

		$( this ).closest( '.cfw-a__item' )
			.find( 'input[name*="[heading]"]' ).attr( 'placeholder', label );
	} );

	if ( $.fn.sortable ) {
		list.sortable( {
			handle: '.cfw-a__grip',
			axis: 'y',
			update: renumber
		} );
	}
}( jQuery ) );

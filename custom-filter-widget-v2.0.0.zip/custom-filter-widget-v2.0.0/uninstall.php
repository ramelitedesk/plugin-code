<?php
/**
 * Removing the plugin's data when it is deleted.
 *
 * Deleted, not deactivated. Deactivating is what somebody does to find out
 * whether this plugin is causing a problem, and a plugin that throws away every
 * filter set the moment it is switched off makes that a one-way test.
 *
 * @package Custom_Filter_Widget
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

/*
 * The filter sets themselves are left alone.
 *
 * They are posts, they are visible in the admin, and somebody who spent an
 * afternoon building fifteen of them is entitled to reinstall and find them
 * still there. WordPress does not delete a post type's posts when its plugin
 * goes, and neither does this — deleting them is a decision for the person
 * doing it, made from the Custom Filters screen, not a side effect of
 * uninstalling.
 *
 * What goes is the cache, which is derived, worthless once the plugin is gone,
 * and would otherwise sit in the options table until it expired.
 */
delete_transient( 'cfw_price_bounds' );

// Widget instances pointing at filter sets that may no longer render.
$sidebars = get_option( 'widget_cfw_filter_widget' );

if ( false !== $sidebars ) {
	delete_option( 'widget_cfw_filter_widget' );
}

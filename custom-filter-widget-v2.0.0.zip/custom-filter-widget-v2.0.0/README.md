# Custom Filter Widget

Build a filter widget out of whatever your site already has — categories, tags,
product attributes, price, rating, stock, author, date — decide which pages it
appears on, and decide **per page** whether it filters with AJAX or a page
reload.

Works with WooCommerce. Works without it.

---

## What you configure

Everything lives on one screen, under **Custom Filters**. A *filter set* is one
widget's worth of configuration.

### 1. Items — what the visitor can filter by

Add as many as you like; drag to reorder. Each item is one facet, and each one
has its own settings:

| | |
| --- | --- |
| **Source** | Any public taxonomy on the site — product categories, tags, `pa_colour`, your own custom taxonomy — plus price, rating, stock status, on-sale, keyword, author and date. The list is built from your site, not hardcoded. |
| **Heading** | Its own text. Left blank, the source's own name is used. |
| **Show heading** | Per item, so you can hide the label on some and not others. |
| **Style** | Checkboxes, radio buttons, inline chips, or a dropdown. |
| **Several at once** | Whether ticking two values means "either". |
| **Counts** | Show how many items are in each term. |
| **Collapse after** | Show a "show 12 more" button past N choices. |

Hiding a heading hides it *on screen only*. It is still there for screen
readers, because a group of eight checkboxes with nothing naming it cannot be
used — the visitor hears eight options and no idea which facet they belong to.

### 2. Where it shows

Tick the locations. Pages by name, post type archives, taxonomy archives, single
items, search, the blog, the front page.

The check happens wherever the widget is placed, so a filter in a site-wide
sidebar still only renders on the pages you ticked.

> **For a shop, tick "Products archive."** That covers the Shop page *and* every
> product category and tag archive beneath it. A filter that vanished when the
> visitor narrowed to a category would disappear exactly when it became useful.

### 3. How it applies — page-wise

Pick a default for the set, then override it per location:

```
Default:  Page reload

  Products archive     →  Use the default   (reload)
  Blog / posts page    →  AJAX
  Shoes                →  AJAX
```

A rule on one specific page beats a rule on the archive it belongs to, and both
beat the default.

**Both paths are always built.** The server applies the filters to the query on
every request, whichever method is in play — so a filtered URL that is shared,
bookmarked, refreshed or crawled shows filtered results. AJAX only saves the
page load; it is never what makes the filtering happen.

### 4. Styling

Colours, border, radius, padding, spacing, text and heading sizes, stacked or
inline layout, button wording, and a custom CSS box. Everything is emitted as
CSS custom properties on the widget, so two filter sets with different colours
on one page do not fight.

---

## Placing it

| | |
| --- | --- |
| Shortcode | `[cfw_filter id="12"]` |
| Sidebar | **Appearance → Widgets → Custom Filter** |
| Results area | `[cfw_results post_type="post"]` |

`[cfw_results]` is only needed outside a WooCommerce shop archive — there, the
product loop is wrapped automatically and rendered through WooCommerce's own
template, so the cards match the rest of the shop.

Without a results container, an AJAX filter falls back to a reload rather than
appearing to do nothing.

---

## What it does not do

- **It does not need JavaScript.** The widget is a real GET form pointing at the
  current URL. With scripts off, Apply reloads the page and the server filters
  it. Everything in the script is an upgrade on that.
- **It does not replace your theme's loop.** On a reload it adjusts the query the
  page was already going to run, so pagination, sorting and any other plugin
  touching that query keep working.
- **It does not call a WooCommerce function unless WooCommerce is installed.**

---

## Notes on the rewrite (2.0.0)

The previous version had four problems worth naming, because the fixes are most
of what changed:

**It fatally errored on any site without WooCommerce.** `is_shop()` was called
from `pre_get_posts`, which runs on every front-end request. Location matching
now uses core conditionals only — WooCommerce's shop page *is* a product post
type archive and its category pages *are* `product_cat` term archives, so
`is_post_type_archive()` and `is_tax()` identify them exactly and answer `false`
rather than fatally.

**It replaced the query's existing constraints instead of adding to them.**
`$query->set( 'tax_query', ... )` threw away whatever the archive had already
built, so ticking any filter on `/product-category/shoes/` replaced "in shoes"
with "in the ticked colour" and filled the page with products from every
category on the site. It looked like the filter working. Constraints are now
merged, and there is a test for it.

**One source per filter set.** Category *and* price in one sidebar needed two
filter sets, two shortcodes and two sets of page rules kept in step by hand.
Items are now a list.

**One heading per widget, not per item.** Four facets under one heading is one
undifferentiated column of checkboxes.

Also fixed along the way: the price filter rendered a heading with nothing under
it (its option list always returned empty); the AJAX endpoint took
`posts_per_page` and `post_type` straight from the request, so it would render
100,000 posts or read a private post type on demand; the nonce on that endpoint
broke every AJAX filter on any page served from a full-page cache; `get_users`
used the `who` argument deprecated in WordPress 5.9; and the back button did
nothing after an AJAX filter.

---

## Tests

```
php tests/test.php
```

71 assertions, no WordPress required — the bootstrap stubs enough of it to
exercise the decisions. The three worth reading are the no-WooCommerce section,
the page-wise method section, and "Merging, not replacing".

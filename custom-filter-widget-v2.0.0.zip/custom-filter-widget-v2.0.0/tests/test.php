<?php
/**
 * What has to stay true.
 *
 * Three things above the rest, all of which were broken before:
 *
 *   1. Nothing calls a WooCommerce function on a site without WooCommerce. The
 *      old version did, on pre_get_posts, which meant every front-end page of
 *      a non-shop site was a fatal error.
 *   2. Query constraints are merged into what the page already had, never
 *      assigned over it. Assigning replaced a product category archive's own
 *      tax_query and quietly showed the whole catalogue.
 *   3. The method is decided per location, most specific rule first.
 *
 * @package Custom_Filter_Widget
 */

require __DIR__ . '/bootstrap.php';

$pass = 0;
$fail = 0;

/**
 * @param string $label What is being asserted.
 * @param bool   $ok    Whether it holds.
 * @param string $note  Shown on failure.
 */
function check( $label, $ok, $note = '' ) {
	global $pass, $fail;

	if ( $ok ) {
		$pass++;
		printf( "  ok    %s\n", $label );

		return;
	}

	$fail++;
	printf( "  FAIL  %s%s\n", $label, '' !== $note ? ' :: ' . $note : '' );
}

/**
 * Store a filter set and return its id.
 *
 * @param array $raw Configuration, as the admin form would post it.
 * @return int
 */
function make_set( array $raw ) {
	static $next = 100;

	$id = $next++;

	CFW_Settings::save( $id, $raw );

	return $id;
}

/* ================================================================ *
 * A site with no WooCommerce
 * ================================================================ */

echo "\n=== A site that has never had WooCommerce ===\n";

check( 'WooCommerce is genuinely absent', ! class_exists( 'WooCommerce' ), 'the rest of this section proves nothing otherwise' );
check( 'and the plugin knows it', ! CFW_Sources::woo() );

cfw_view( array( 'home' ) );

check( 'working out the location does not fatal', is_array( CFW_Location::current() ) );
check( 'and identifies the blog', in_array( 'blog', CFW_Location::current(), true ) );

$sources = CFW_Sources::all();

check( 'the source list has no WooCommerce group', ! isset( $sources['WooCommerce'] ) );
check( 'but still offers ordinary taxonomies', isset( $sources['Posts and pages']['category'] ) );

check( 'price bounds answer zero rather than querying', 0.0 === CFW_Sources::price_bounds()['max'] );

$set = make_set(
	array(
		'enabled' => 1,
		'items'   => array( array( 'source' => 'category', 'multiple' => 1 ) ),
		'where'   => array( 'mode' => 'rules', 'locations' => array( 'blog' ) ),
	)
);

check( 'a filter set still matches a page', CFW_Location::matches( CFW_Settings::get( $set ) ) );

/* ================================================================ *
 * Where it shows
 * ================================================================ */

echo "\n=== Which pages it shows on ===\n";

$shop_set = make_set(
	array(
		'enabled' => 1,
		'items'   => array( array( 'source' => 'product_cat' ) ),
		'where'   => array( 'mode' => 'rules', 'locations' => array( 'archive:product' ) ),
	)
);

$config = CFW_Settings::get( $shop_set );

cfw_view( array( 'post_type_archive' ), null, array( 'post_type' => 'product' ) );
check( 'ticking the products archive matches the shop', CFW_Location::matches( $config ) );

cfw_view( array( 'tax' ), new WP_Term( 42, 'product_cat', 'Shoes', 'shoes' ) );
check(
	'and still matches a product category under it',
	CFW_Location::matches( $config ),
	'a filter that vanishes when a visitor narrows to a category disappears exactly when it becomes useful'
);

cfw_view( array( 'home' ) );
check( 'but not the blog', ! CFW_Location::matches( $config ) );

cfw_view( array( 'admin' ) );
check( 'and never in the admin', ! CFW_Location::matches( $config ), 'get_queried_object in the admin is somebody else' );

$everywhere = CFW_Settings::get( make_set( array( 'enabled' => 1, 'items' => array( array( 'source' => 'category' ) ), 'where' => array( 'mode' => 'everywhere' ) ) ) );

cfw_view( array( 'admin' ) );
check( '"everywhere" still means the front end only', ! CFW_Location::matches( $everywhere ) );

cfw_view( array( 'singular' ), (object) array( 'ID' => 9 ) );
check( 'a page is matchable by id', in_array( 'post:9', CFW_Location::current(), true ) || in_array( 'page:9', CFW_Location::current(), true ) );

/* ================================================================ *
 * Page-wise method
 * ================================================================ */

echo "\n=== AJAX or reload, per page ===\n";

$mixed = CFW_Settings::get(
	make_set(
		array(
			'enabled' => 1,
			'items'   => array( array( 'source' => 'product_cat' ) ),
			'where'   => array( 'mode' => 'rules', 'locations' => array( 'archive:product', 'blog' ) ),
			'method'  => array(
				'default'   => 'reload',
				'overrides' => array(
					'blog'                => 'ajax',
					'term:product_cat:42' => 'ajax',
				),
			),
		)
	)
);

cfw_view( array( 'post_type_archive' ), null, array( 'post_type' => 'product' ) );
check( 'the shop uses the default', 'reload' === CFW_Location::method( $mixed ) );

cfw_view( array( 'home' ) );
check( 'the blog uses its override', 'ajax' === CFW_Location::method( $mixed ) );

cfw_view( array( 'tax' ), new WP_Term( 42, 'product_cat', 'Shoes', 'shoes' ) );
check(
	'one category beats the archive it belongs to',
	'ajax' === CFW_Location::method( $mixed ),
	'the specific rule has to win or a per-page override is unreachable'
);

cfw_view( array( 'tax' ), new WP_Term( 43, 'product_cat', 'Hats', 'hats' ) );
check( 'a sibling category without a rule falls back to the default', 'reload' === CFW_Location::method( $mixed ) );

check(
	'"use the default" is never stored as an override',
	! isset( CFW_Settings::get( make_set( array( 'items' => array( array( 'source' => 'category' ) ), 'method' => array( 'default' => 'ajax', 'overrides' => array( 'blog' => '' ) ) ) ) )['method']['overrides']['blog'] ),
	'stored, it would stop following the default the moment somebody changed it'
);

/* ================================================================ *
 * Reading a request
 * ================================================================ */

echo "\n=== Reading what a visitor chose ===\n";

$item = array_merge( CFW_Settings::item_defaults(), array( 'source' => 'product_cat', 'multiple' => 1 ) );

check( 'the parameter is named after the source', 'f_product_cat' === CFW_Query::param( $item ) );

check( 'a comma list is read', array( 'a', 'b' ) === CFW_Query::selected( $item, array( 'f_product_cat' => 'a,b' ) ) );
check( 'an array is read too', array( 'a', 'b' ) === CFW_Query::selected( $item, array( 'f_product_cat' => array( 'a', 'b' ) ) ) );
check( 'duplicates collapse', array( 'a' ) === CFW_Query::selected( $item, array( 'f_product_cat' => 'a,a,a' ) ) );
check( 'empties are dropped', array( 'a' ) === CFW_Query::selected( $item, array( 'f_product_cat' => 'a,,' ) ) );
check( 'nothing chosen is an empty list', array() === CFW_Query::selected( $item, array() ) );

$single = array_merge( $item, array( 'multiple' => 0 ) );
check( 'a single-choice item takes only the first', array( 'a' ) === CFW_Query::selected( $single, array( 'f_product_cat' => 'a,b,c' ) ) );

$flood = CFW_Query::selected( $item, array( 'f_product_cat' => implode( ',', range( 1, 500 ) ) ) );
check( 'a flood of values is capped', 50 === count( $flood ), 'otherwise a crafted URL builds a 500-term IN() clause' );

check( 'price reads both ends', array( 'min' => 10.0, 'max' => 50.0 ) === CFW_Query::price_from_request( array( 'f_price_min' => '10', 'f_price_max' => '50' ) ) );
check( 'price typed backwards is swapped, not dropped', array( 'min' => 10.0, 'max' => 50.0 ) === CFW_Query::price_from_request( array( 'f_price_min' => '50', 'f_price_max' => '10' ) ) );
check( 'a negative price is ignored', null === CFW_Query::price_from_request( array( 'f_price_min' => '-5' ) )['min'] );
check( 'one end alone is allowed', array( 'min' => null, 'max' => 50.0 ) === CFW_Query::price_from_request( array( 'f_price_max' => '50' ) ) );

/* ================================================================ *
 * Building the query
 * ================================================================ */

echo "\n=== What goes on the query ===\n";

$tax_set = make_set(
	array(
		'enabled' => 1,
		'items'   => array(
			array( 'source' => 'product_cat', 'multiple' => 1 ),
			array( 'source' => 'pa_colour', 'multiple' => 1 ),
		),
		'where'   => array( 'mode' => 'everywhere' ),
	)
);

$pieces = CFW_Query::pieces( array( $tax_set ), array( 'f_product_cat' => 'shoes', 'f_pa_colour' => 'red,blue' ) );

check( 'two facets make two clauses', 2 === count( $pieces['tax'] ) );
check( 'values within one facet are OR', 'IN' === $pieces['tax'][1]['operator'], 'AND would return the products that are both red and blue, which is none' );
check( 'the terms come through', array( 'red', 'blue' ) === $pieces['tax'][1]['terms'] );

$empty = CFW_Query::pieces( array( $tax_set ), array() );
check( 'nothing chosen builds nothing', ! $empty['tax'] && ! $empty['meta'] && ! $empty['extra'] );

/* --- the one that mattered most --- */

echo "\n=== Merging, not replacing ===\n";

$query = new WP_Query();

// What a product category archive already has on it before this plugin runs.
$existing = array( array( 'taxonomy' => 'product_cat', 'field' => 'slug', 'terms' => array( 'shoes' ) ) );

$query->set( 'tax_query', $existing );

CFW_Query::apply( $query, CFW_Query::pieces( array( $tax_set ), array( 'f_pa_colour' => 'red' ) ) );

$after = $query->get( 'tax_query' );

check( 'the archive\'s own constraint survives', 2 === count( array_filter( $after, 'is_array' ) ), 'assigning over it showed the whole catalogue and looked like the filter working' );
check( 'and the new one was added', 'pa_colour' === $after[1]['taxonomy'] );
check( 'with an AND between them', 'AND' === ( $after['relation'] ?? '' ) );

$single_query = new WP_Query();

CFW_Query::apply( $single_query, CFW_Query::pieces( array( $tax_set ), array( 'f_pa_colour' => 'red' ) ) );

check( 'a lone clause gets no needless relation', ! isset( $single_query->get( 'tax_query' )['relation'] ) );

/* --- meta, and the empty-sale trap --- */

$meta_set = make_set(
	array(
		'enabled' => 1,
		'items'   => array( array( 'source' => 'rating' ), array( 'source' => 'stock', 'multiple' => 1 ) ),
		'where'   => array( 'mode' => 'everywhere' ),
	)
);

$pieces = CFW_Query::pieces( array( $meta_set ), array( 'f_rating' => '4', 'f_stock' => 'instock' ) );

check( 'rating becomes a >= comparison', '>=' === $pieces['meta'][0]['compare'] && 4 === $pieces['meta'][0]['value'] );
check( 'a rating outside 1-5 is clamped', 5 === CFW_Query::pieces( array( $meta_set ), array( 'f_rating' => '99' ) )['meta'][0]['value'] );
check( 'stock becomes an IN', array( 'instock' ) === $pieces['meta'][1]['value'] );
check( 'an invented stock status is dropped', array() === CFW_Query::pieces( array( $meta_set ), array( 'f_stock' => 'nonsense' ) )['meta'][0]['value'] );

$price_set = make_set( array( 'enabled' => 1, 'items' => array( array( 'source' => 'price' ) ), 'where' => array( 'mode' => 'everywhere' ) ) );

$pieces = CFW_Query::pieces( array( $price_set ), array( 'f_price_min' => '10', 'f_price_max' => '50' ) );

check( 'price builds a BETWEEN', 'BETWEEN' === $pieces['meta'][0]['compare'] );
check( 'over the price key', '_price' === $pieces['meta'][0]['key'] );
check( 'with both ends', array( 10.0, 50.0 ) === $pieces['meta'][0]['value'] );
check( 'a min with no max still filters', 10.0 === CFW_Query::pieces( array( $price_set ), array( 'f_price_min' => '10' ) )['meta'][0]['value'][0] );

/* --- post__in is intersected --- */

$sale_query = new WP_Query();
$sale_query->set( 'post__in', array( 1, 2, 3 ) );

CFW_Query::apply( $sale_query, array( 'tax' => array(), 'meta' => array(), 'date' => array(), 'extra' => array( 'post__in' => array( 2, 3, 4 ) ) ) );

check( 'post__in is intersected with what was there', array( 2, 3 ) === array_values( $sale_query->get( 'post__in' ) ), 'replacing it would undo another plugin\'s restriction' );

$none_query = new WP_Query();
$none_query->set( 'post__in', array( 1 ) );

CFW_Query::apply( $none_query, array( 'tax' => array(), 'meta' => array(), 'date' => array(), 'extra' => array( 'post__in' => array( 9 ) ) ) );

check( 'an empty intersection blocks everything', array( 0 ) === $none_query->get( 'post__in' ), 'an empty post__in means "no restriction" to WP_Query, so it would show the lot' );

/* ================================================================ *
 * Saving
 * ================================================================ */

echo "\n=== What survives a save ===\n";

$saved = CFW_Settings::get(
	make_set(
		array(
			'enabled' => 1,
			'items'   => array(
				array( 'source' => 'category', 'heading' => '  Browse  ', 'show_heading' => 1, 'style' => 'chips', 'limit' => '5' ),
				array( 'source' => 'not_a_real_taxonomy' ),
				array( 'source' => 'post_tag', 'style' => 'nonsense' ),
				array( 'heading' => 'no source at all' ),
			),
			'where'   => array( 'mode' => 'rules', 'locations' => array( 'blog', 'blog', '<script>', 'archive:post' ) ),
			'style'   => array(
				'accent_color' => '#ff0000',
				'text_color'   => 'red',
				'border_width' => '9999',
				'layout'       => 'diagonal',
				'custom_css'   => '.cfw{color:red}</style><script>alert(1)</script>',
			),
			'labels'  => array( 'apply' => 'Go', 'reset' => '' ),
		)
	)
);

check( 'a valid item is kept', 3 === count( $saved['items'] ) || 2 === count( $saved['items'] ) );
check( 'an item naming a source this site lacks is dropped', ! in_array( 'not_a_real_taxonomy', wp_list_pluck( $saved['items'], 'source' ), true ) );
check( 'an item with no source is dropped', 2 === count( $saved['items'] ) );
check( 'headings are trimmed', 'Browse' === $saved['items'][0]['heading'] );
check( 'a real style is kept', 'chips' === $saved['items'][0]['style'] );
check( 'an invented style falls back to checkboxes', 'checkbox' === $saved['items'][1]['style'] );
check( 'limits are numbers', 5 === $saved['items'][0]['limit'] );

check( 'duplicate locations collapse', 2 === count( $saved['where']['locations'] ) );
check( 'a location that is not a key is dropped', ! in_array( '<script>', $saved['where']['locations'], true ) );

check( 'a valid colour is kept', '#ff0000' === $saved['style']['accent_color'] );
check( 'a colour that is not hex falls back to the default', '#3c434a' === $saved['style']['text_color'], 'an empty custom property makes the whole declaration invalid' );
check( 'sizes are capped', 20 === $saved['style']['border_width'] );
check( 'an invented layout falls back', 'list' === $saved['style']['layout'] );

check( 'custom CSS keeps the CSS', false !== strpos( $saved['style']['custom_css'], 'color:red' ) );
check( 'and loses the script tag', false === stripos( $saved['style']['custom_css'], '<script' ), 'this box is printed raw into a <style> element' );
check( 'and cannot close the style element', false === strpos( $saved['style']['custom_css'], '</style>' ) );

check( 'a given label is kept', 'Go' === $saved['labels']['apply'] );
check( 'a blank label falls back rather than rendering an empty button', 'Reset' === $saved['labels']['reset'] );

/* ================================================================ *
 * Defaults
 * ================================================================ */

echo "\n=== Defaults are cautious ===\n";

$defaults = CFW_Settings::defaults();

check( 'a new set has no items', array() === $defaults['items'] );
check( 'and shows nowhere until told', 'rules' === $defaults['where']['mode'] && array() === $defaults['where']['locations'] );
check(
	'and defaults to a page reload',
	'reload' === $defaults['method']['default'],
	'reload works on every theme; AJAX needs somewhere to put the results'
);

$fresh = CFW_Settings::get( 99999 );
check( 'an unsaved set reads as defaults rather than warning', is_array( $fresh['items'] ) && isset( $fresh['style']['accent_color'] ) );


/* --------------------------------------------------------------------- *
 * Regressions
 *
 * Each of these made the plugin look like it did nothing at all on a real
 * WooCommerce site, while every screen in the admin said it was working.
 * --------------------------------------------------------------------- */

echo "\n=== The shop page is a page, and still has to be filtered ===\n";

/*
 * WooCommerce's shop is a *page*, so is_singular() is true on it, and the
 * guard read "if ( is_feed() || is_singular() || is_404() ) return;". That
 * switched the filter off on the one view this plugin most exists for, and
 * did it in silence: the widget rendered, the URL updated, the boxes stayed
 * ticked, and the same sixteen products came back every time.
 */
$cfw_listing = new ReflectionMethod( 'CFW_Frontend', 'is_listing_page' );
$cfw_listing->setAccessible( true );

cfw_view( array( 'singular', 'shop' ), null, array( 'woo' => true ) );
check( 'the shop page counts as a listing', $cfw_listing->invoke( null ), 'is_singular() is true there, but it lists products' );

cfw_view( array( 'singular' ), null, array( 'woo' => true ) );
check( 'an ordinary page does not', ! $cfw_listing->invoke( null ) );


echo "\n=== The product loop is not always the main query ===\n";

/*
 * On a theme with no WooCommerce support the shop renders through
 * woocommerce_content(), which runs a *secondary* WP_Query for the products
 * while the main query stays on the shop page itself. Filtering only the
 * main query filtered the page object and left the grid untouched.
 */
check(
	'there is a callback for the WooCommerce product loop',
	is_callable( array( 'CFW_Frontend', 'filter_product_query' ) ),
	'woocommerce_product_query is the loop, whichever query is behind it'
);

echo "\n=== Reading the configuration cannot re-enter the filters ===\n";

/*
 * active_filters() queries the posts the configuration is stored in, and
 * WooCommerce runs its product_query hook over that query too — straight
 * back into the callback that asked. The shop page recursed until PHP ran
 * out of memory and served a blank page in about four seconds.
 */
$cfw_guard = new ReflectionProperty( 'CFW_Frontend', 'constraining' );
$cfw_guard->setAccessible( true );

check( 'there is a re-entrancy guard', false === $cfw_guard->getValue() );

$cfw_guard->setValue( null, true );

$cfw_probe = new WP_Query();
CFW_Frontend::filter_product_query( $cfw_probe );

check(
	'and a re-entrant call changes nothing',
	'' === $cfw_probe->get( 'tax_query' ),
	'otherwise it recurses until memory runs out'
);

$cfw_guard->setValue( null, false );

echo "\n=== The form action survives a subdirectory install ===\n";

/*
 * home_url( $_SERVER['REQUEST_URI'] ) doubles the path on any site that is
 * not at a domain root, because REQUEST_URI already contains the
 * subdirectory. A site at example.test/shop produced an action of
 * example.test/shop/shop/..., so submitting the filter with JavaScript off
 * landed on a 404. On a root install the two are identical, which is why it
 * survived every casual test.
 */
$cfw_url = new ReflectionMethod( 'CFW_Render', 'current_url' );
$cfw_url->setAccessible( true );

$GLOBALS['cfw_test']['home'] = 'https://example.test/shop';
$_SERVER['REQUEST_URI']      = '/shop/product-category/beauty/';

check(
	'a subdirectory is not repeated',
	'https://example.test/shop/product-category/beauty/' === $cfw_url->invoke( null, false ),
	$cfw_url->invoke( null, false )
);

$GLOBALS['cfw_test']['home'] = 'https://example.test';
$_SERVER['REQUEST_URI']      = '/product-category/beauty/';

check(
	'and a root install is unchanged',
	'https://example.test/product-category/beauty/' === $cfw_url->invoke( null, false ),
	$cfw_url->invoke( null, false )
);

$_SERVER['REQUEST_URI'] = '/?f_product_cat=beauty&paged=2&keep=1';
$_GET                   = array( 'f_product_cat' => 'beauty', 'paged' => '2', 'keep' => '1' );

$cfw_stripped = $cfw_url->invoke( null, true );

check( 'stripping drops this plugin\'s own parameters', false === strpos( $cfw_stripped, 'f_product_cat' ), $cfw_stripped );
check( 'and the page number', false === strpos( $cfw_stripped, 'paged' ), $cfw_stripped );
check( 'and keeps everything that is not ours', false !== strpos( $cfw_stripped, 'keep=1' ), $cfw_stripped );

$_GET                        = array();
$GLOBALS['cfw_test']['home'] = 'https://example.test';


echo "\n=== The AJAX target does not depend on render order ===\n";

/*
 * The product loop is wrapped in .cfw-results so the script has something to
 * replace. Whether to wrap used to be decided by "has a widget rendered
 * yet?", which is a question about ordering rather than about the page:
 * almost every theme prints the main content before the sidebar, so at
 * woocommerce_before_shop_loop the answer was no, the wrapper was never
 * printed, and the script found no target. It then fell back to a full
 * reload — so an AJAX filter behaved exactly like a reload one, silently, on
 * most themes on the market.
 */
$cfw_wrap = new ReflectionMethod( 'CFW_Frontend', 'should_wrap' );
$cfw_wrap->setAccessible( true );

$GLOBALS['cfw_test']['meta'][ 700 ] = array(
	'_cfw_config' => array(
		'enabled' => 1,
		'items'   => array( array( 'source' => 'product_cat' ) ),
		'where'   => array( 'mode' => 'everywhere', 'locations' => array() ),
	),
);

$cfw_ids = function ( $ids ) {
	CFW_Settings::reset();

	$GLOBALS['cfw_test']['ids'] = $ids;
};

cfw_view( array( 'shop', 'singular' ), null, array( 'woo' => true, 'post_type' => 'product' ) );

$cfw_ids( array( 700 ) );

check(
	'a view with an active filter set is wrapped',
	$cfw_wrap->invoke( null ),
	'nothing has rendered yet at woocommerce_before_shop_loop, and that must not matter'
);

$cfw_ids( array() );

check( 'and a view with none is not', ! $cfw_wrap->invoke( null ), 'no filter, no wrapper' );

$GLOBALS['cfw_test']['ids'] = array();
printf( "\n----\npassed: %d   failed: %d\n", $pass, $fail );

exit( $fail > 0 ? 1 : 0 );

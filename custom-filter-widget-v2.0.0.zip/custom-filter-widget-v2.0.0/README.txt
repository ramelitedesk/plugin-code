CUSTOM FILTER WIDGET
====================

Version: 1.0.0

INSTALLATION
1. Upload the custom-filter-widget folder to wp-content/plugins/ or upload the ZIP in Plugins > Add New > Upload Plugin.
2. Activate the plugin.
3. Go to Custom Filters > Add New.
4. Create a filter and publish it.
5. Add [cfw_filter id="FILTER_ID"] where the filter should appear, or use the Custom Filter Widget in a WordPress widget area.

NORMAL WORDPRESS AJAX RESULTS
Use the results shortcode on a page/template:
[cfw_results post_type="post" posts_per_page="12"]

WOOCommerce
- Product Category, Product Tag, product attributes, stock status and rating are supported.
- For AJAX WooCommerce filtering, put the filter widget on the Shop/archive page. The plugin replaces a .cfw-results container if one exists.
- For a custom WooCommerce archive/template, wrap the product loop with a .cfw-results container or adapt the template to use the provided AJAX result area.

PAGE-WISE DISPLAY
- Select specific WordPress pages in the filter settings, or choose All compatible pages.
- A filter only renders on pages where its display rule matches.

AJAX VS RELOAD
- Each filter has a Method setting: AJAX or Page Reload.
- If any visible filter on the current page is configured for Page Reload, the frontend uses page reload mode for the combined filter set. This avoids conflicting transport modes in one request.

IMPORTANT
This is a framework intended to be extended for a site's exact WooCommerce theme/Elementor loop. Some themes replace the WooCommerce loop markup, so test AJAX filtering with the active theme and custom archive templates.

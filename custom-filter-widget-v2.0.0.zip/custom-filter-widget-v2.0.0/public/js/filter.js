/**
 * The browser half: URL building, AJAX swapping, and the small niceties.
 *
 * The form works without any of this. It is a real GET form pointing at the
 * current URL, so a visitor with no JavaScript presses Apply, the page reloads,
 * and the server filters it. Everything here is an upgrade on that — which is
 * why every path below still ends in either a navigation or a request the
 * server would have handled anyway.
 *
 * @package Custom_Filter_Widget
 */
( function () {
	'use strict';

	var settings = window.CFWData || {};
	var PREFIX = 'f_';

	/**
	 * Every filter parameter currently chosen, across every widget on the page.
	 *
	 * Read from all of them, not just the one submitted. Two widgets — a
	 * sidebar and a mobile drawer, say — are two forms, and submitting one
	 * natively would send only its own fields and silently drop whatever was
	 * chosen in the other.
	 *
	 * @return {Object} name -> array of values.
	 */
	function collect() {
		var values = {};

		document.querySelectorAll( '.cfw' ).forEach( function ( widget ) {
			widget.querySelectorAll( 'input, select' ).forEach( function ( field ) {
				var name = ( field.name || '' ).replace( /\[\]$/, '' );

				if ( ! name || name.indexOf( PREFIX ) !== 0 ) {
					return;
				}

				if ( ( field.type === 'checkbox' || field.type === 'radio' ) && ! field.checked ) {
					return;
				}

				if ( field.tagName === 'SELECT' && field.multiple ) {
					Array.prototype.forEach.call( field.selectedOptions, function ( option ) {
						if ( option.value !== '' ) {
							push( values, name, option.value );
						}
					} );

					return;
				}

				if ( field.value !== '' ) {
					push( values, name, field.value );
				}
			} );
		} );

		return values;
	}

	/**
	 * @param {Object} bag   Where to put it.
	 * @param {string} name  Parameter.
	 * @param {string} value Value.
	 */
	function push( bag, name, value ) {
		bag[ name ] = bag[ name ] || [];

		// Two widgets can carry the same facet, and both being ticked must not
		// send the value twice — the server would build "IN (shoes, shoes)".
		if ( bag[ name ].indexOf( value ) === -1 ) {
			bag[ name ].push( value );
		}
	}

	/**
	 * The current URL with this plugin's parameters replaced by the given ones.
	 *
	 * @param {Object} values From collect().
	 * @return {string}
	 */
	function buildUrl( values ) {
		var url = new URL( window.location.href );

		// Cleared first. Building on top of what is there would make an
		// unticked box impossible to unstick: its old value is still in the URL
		// and nothing in the new set overwrites it.
		Array.prototype.slice.call( url.searchParams.keys() ).forEach( function ( key ) {
			if ( key.indexOf( PREFIX ) === 0 ) {
				url.searchParams.delete( key );
			}
		} );

		Object.keys( values ).forEach( function ( name ) {
			if ( values[ name ].length ) {
				url.searchParams.set( name, values[ name ].join( ',' ) );
			}
		} );

		// Back to page one. Staying on page four of a narrower result set is
		// how a visitor filters and lands on "nothing found" with results
		// sitting on page one.
		url.searchParams.delete( 'paged' );
		url.pathname = url.pathname.replace( /\/page\/\d+\/?$/, '/' );

		return url.toString();
	}

	/**
	 * @param {Element} widget A .cfw element.
	 * @return {string} 'ajax' or 'reload'.
	 */
	function methodOf( widget ) {
		return widget && widget.dataset.method === 'ajax' ? 'ajax' : 'reload';
	}

	/**
	 * Swap the results in place.
	 *
	 * @param {Element} widget  The widget that asked.
	 * @param {boolean} history Whether to add a history entry.
	 */
	function ajaxApply( widget, history ) {
		var targets = document.querySelectorAll( '.cfw-results' );
		var values = collect();
		var url = buildUrl( values );

		/*
		 * No results container on the page means the theme's loop is not one
		 * this plugin can find. Falling back to a reload is the honest answer:
		 * the alternative is a filter that appears to do nothing.
		 */
		if ( ! targets.length ) {
			window.location.href = url;

			return;
		}

		var ids = [];

		document.querySelectorAll( '.cfw' ).forEach( function ( one ) {
			var id = parseInt( one.dataset.filterId, 10 );

			if ( id && ids.indexOf( id ) === -1 ) {
				ids.push( id );
			}
		} );

		var body = new URLSearchParams();

		body.append( 'action', 'cfw_filter' );
		body.append( 'post_type', targets[ 0 ].dataset.postType || 'post' );

		ids.forEach( function ( id ) {
			body.append( 'filter_ids[]', id );
		} );

		Object.keys( values ).forEach( function ( name ) {
			values[ name ].forEach( function ( value ) {
				body.append( 'filters[' + name + '][]', value );
			} );
		} );

		setBusy( widget, targets, true );

		window.fetch( settings.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		} )
			.then( function ( response ) {
				return response.json();
			} )
			.then( function ( payload ) {
				if ( ! payload || ! payload.success ) {
					throw new Error( 'bad response' );
				}

				targets.forEach( function ( target ) {
					target.innerHTML = payload.data.html;
				} );

				if ( history ) {
					window.history.pushState( { cfw: true }, '', url );
				}

				/*
				 * Announced, not just swapped. Replacing the page's contents
				 * silently leaves anyone using a screen reader on a page that
				 * has changed underneath them with no indication it has.
				 */
				announce( payload.data.found );

				// Other scripts — lazy images, quick view, add-to-cart — need
				// telling that there is new markup to bind to.
				document.body.dispatchEvent( new CustomEvent( 'cfw:updated', { detail: payload.data } ) );
			} )
			.catch( function () {
				/*
				 * A failed request falls back to the reload the form would have
				 * done anyway. The visitor gets their results; they just get
				 * them the slow way.
				 */
				window.location.href = url;
			} )
			.finally( function () {
				setBusy( widget, targets, false );
			} );
	}

	/**
	 * @param {Element}  widget  The widget.
	 * @param {NodeList} targets Result containers.
	 * @param {boolean}  busy    Whether a request is in flight.
	 */
	function setBusy( widget, targets, busy ) {
		targets.forEach( function ( target ) {
			target.classList.toggle( 'cfw-results--busy', busy );
			target.setAttribute( 'aria-busy', busy ? 'true' : 'false' );
		} );

		if ( widget ) {
			widget.classList.toggle( 'cfw--busy', busy );

			widget.querySelectorAll( 'button, input, select' ).forEach( function ( field ) {
				field.disabled = busy;
			} );
		}
	}

	/**
	 * @param {number} found How many results.
	 */
	function announce( found ) {
		var region = document.getElementById( 'cfw-live' );

		if ( ! region ) {
			region = document.createElement( 'div' );
			region.id = 'cfw-live';
			region.className = 'screen-reader-text';
			region.setAttribute( 'aria-live', 'polite' );
			region.setAttribute( 'role', 'status' );

			document.body.appendChild( region );
		}

		region.textContent = String( found );
	}

	/**
	 * @param {Element} widget The widget that triggered it.
	 */
	function apply( widget ) {
		if ( methodOf( widget ) === 'ajax' ) {
			ajaxApply( widget, true );

			return;
		}

		window.location.href = buildUrl( collect() );
	}

	/* ---------------- events ---------------- */

	document.addEventListener( 'submit', function ( event ) {
		var form = event.target.closest ? event.target.closest( '.cfw__form' ) : null;

		if ( ! form ) {
			return;
		}

		// Only now is the native submit taken over. Until this line runs the
		// form is a working GET form, which is what a visitor with no
		// JavaScript — or with a script error higher up the page — still gets.
		event.preventDefault();

		apply( form.closest( '.cfw' ) );
	} );

	document.addEventListener( 'change', function ( event ) {
		var widget = event.target.closest ? event.target.closest( '.cfw' ) : null;

		if ( ! widget || widget.dataset.auto !== '1' ) {
			return;
		}

		// A search box firing a request on every change event would fire one
		// per keystroke on some browsers. It waits for Apply.
		if ( event.target.type === 'search' || event.target.type === 'number' ) {
			return;
		}

		apply( widget );
	} );

	document.addEventListener( 'click', function ( event ) {
		var more = event.target.closest ? event.target.closest( '.cfw__more' ) : null;

		if ( ! more ) {
			return;
		}

		var group = more.parentNode;
		var open = more.getAttribute( 'aria-expanded' ) === 'true';

		group.querySelectorAll( '.cfw__option--extra' ).forEach( function ( option ) {
			option.classList.toggle( 'is-open', ! open );
		} );

		more.setAttribute( 'aria-expanded', open ? 'false' : 'true' );
	} );

	/*
	 * The back button, in AJAX mode.
	 *
	 * Without this, pushing a state and never listening for it means Back
	 * changes the URL and leaves the results exactly as they were — the one
	 * bug every AJAX filter ships with.
	 */
	window.addEventListener( 'popstate', function () {
		var widget = document.querySelector( '.cfw[data-method="ajax"]' );

		if ( ! widget ) {
			return;
		}

		syncFromUrl();

		ajaxApply( widget, false );
	} );

	/**
	 * Put the controls back in step with the URL.
	 */
	function syncFromUrl() {
		var params = new URL( window.location.href ).searchParams;

		document.querySelectorAll( '.cfw' ).forEach( function ( widget ) {
			widget.querySelectorAll( 'input, select' ).forEach( function ( field ) {
				var name = ( field.name || '' ).replace( /\[\]$/, '' );

				if ( ! name || name.indexOf( PREFIX ) !== 0 ) {
					return;
				}

				var wanted = ( params.get( name ) || '' ).split( ',' ).filter( Boolean );

				if ( field.type === 'checkbox' || field.type === 'radio' ) {
					field.checked = wanted.indexOf( field.value ) !== -1;

					return;
				}

				if ( field.tagName === 'SELECT' && field.multiple ) {
					Array.prototype.forEach.call( field.options, function ( option ) {
						option.selected = wanted.indexOf( option.value ) !== -1;
					} );

					return;
				}

				field.value = wanted.length ? wanted[ 0 ] : '';
			} );
		} );
	}
}() );
